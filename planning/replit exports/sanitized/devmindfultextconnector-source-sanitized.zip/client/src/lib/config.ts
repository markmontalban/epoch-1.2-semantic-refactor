import { getApiBaseUrl } from "./env";

// MindfulText API Configuration
export const config = {
  // API Configuration - uses environment-specific base URL
  API_BASE_URL: getApiBaseUrl(),
  
  // Authentication endpoints
  AUTH_ENDPOINTS: {
    LOGIN: '/api/login',
    LOGOUT: '/api/logout',
    REFRESH: '/api/refresh',
    ME: '/api/me',
  },
  
  // Storage keys
  STORAGE_KEYS: {
    TOKEN: 'mindfultext_token',
    USER: 'mindfultext_user',
  },
  
  // App settings
  APP_NAME: 'MindfulText',
  APP_VERSION: '1.0.0',
} as const;

// Helper function to get full API URL
export function getApiUrl(endpoint: string): string {
  return `${config.API_BASE_URL}${endpoint}`;
}

// Environment-specific overrides
if (import.meta.env.DEV) {
  // Development overrides can be added here
  console.log('Running in development mode');
}

if (import.meta.env.PROD) {
  // Production overrides can be added here
  console.log('Running in production mode');
} 