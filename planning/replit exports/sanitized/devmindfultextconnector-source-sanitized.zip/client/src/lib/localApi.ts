const DEFAULT_ORG_ID = "00000022";
const ORG_ID_KEY = "mindfultext_org_id";

function padOrgId(id: string | number): string {
  const str = String(id);
  if (/^\d+$/.test(str)) return str.padStart(8, "0");
  return str;
}

/**
 * Single-user mode: the configured org id is the source of truth, mirrored
 * from the server (`/api/local/settings`) into localStorage so every page +
 * api caller reads the same value without an async hop.
 */
export function resolveLocalOrgId(): string {
  try {
    const stored = localStorage.getItem(ORG_ID_KEY);
    if (stored && stored.trim()) return padOrgId(stored.trim());
  } catch { /* localStorage unavailable */ }
  return DEFAULT_ORG_ID;
}

export function setLocalOrgId(orgId: string) {
  try { localStorage.setItem(ORG_ID_KEY, padOrgId(orgId)); } catch { /* */ }
}

/** Pull the configured org id from the server and mirror to localStorage. */
export async function syncOrgIdFromServer(): Promise<string | null> {
  try {
    const res = await fetch("/api/local/settings", {
      headers: { "X-Session-ID": localStorage.getItem("mindfultext_session_id") || "" },
    });
    if (!res.ok) return null;
    const j = await res.json() as { orgId?: string };
    if (j.orgId) {
      setLocalOrgId(j.orgId);
      return j.orgId;
    }
  } catch { /* */ }
  return null;
}

export async function localGet<T>(path: string): Promise<T> {
  const res = await fetch(path, { credentials: "include" });
  if (!res.ok) throw new Error(`${res.status}: ${res.statusText}`);
  return res.json() as Promise<T>;
}

export async function localPatch<T>(path: string, data: Record<string, unknown>): Promise<T> {
  const res = await fetch(path, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error(`${res.status}: ${res.statusText}`);
  return res.json() as Promise<T>;
}
