import { authService } from './auth';
import { resolveLocalOrgId } from './localApi';

export interface Contact {
  id: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  phoneNumber?: string;
  company?: string;
  companyName?: string;
  title?: string;
  tags?: string[];
  location?: string;
  timezone?: string;
  preferredConnection?: any[];
  status?: string;
  organizationId?: number;
}

export interface Journey {
  id: string;
  name: string;
  description?: string;
  tags?: string[];
  launchDays?: string[];
  schedule?: string[];
  time?: string;
  modules?: any[];
  moduleIds?: string[];
  moduleIDs?: string[];   // API returns this casing
  subscriberCount?: number;
  completionRate?: number;
  status?: string;
  isArchived?: boolean;
}

export interface Action {
  id: string;
  name: string;
  description?: string;
  tags?: string[];
  automations?: any[];
  type: string;
  status?: string;
  moduleId?: string;
  moduleIds?: string[];
}

export interface Subscription {
  id: string;
  contactId?: string;
  journeyId?: string;
  status?: string;
}

export interface Message {
  id: string;
  content?: string;
  status?: string;
  sentAt?: string;
  recipientCount?: number;
}

export interface Module {
  id: string;
  name: string;
  description?: string;
  tags?: string[];
  messages?: any[];
  texts?: unknown[];
  actionIds?: string[];
  isPublic?: boolean;
  isArchived?: boolean;
  organizationID?: string;
  createdAt?: number;   // Unix timestamp (seconds)
  updatedAt?: number;   // Unix timestamp (seconds)
}

export interface Integration {
  id: string;
  integrationId?: string;
  name: string;
  description?: string;
  integrationType?: string;
  type?: string;
  selectedActions?: any[];
  status?: string;
}

export interface TeamMember {
  email: string;
  id?: string;
  userId?: number;
  role?: string;
  roles?: string[];
  createdAt?: string;
}

export interface AnalyticsData {
  newContacts: number;
  journeysLaunched: number;
  messagesSent: number;
  messagesReceived: number;
}

export interface DashboardMetric {
  value: number;
  previous: number | null;
  changePct: number | null;
  supportsTrend: boolean;
  isNewActivity?: boolean;
  /** How to render the headline value (default: number). */
  format?: 'number' | 'percent';
}

export interface DashboardStatsResponse {
  period: 'day' | 'week' | 'month' | 'year' | 'all' | 'custom';
  start: string | null;
  end: string | null;
  metrics: {
    contacts: DashboardMetric;
    journeys: DashboardMetric;
    journeysLaunched: DashboardMetric;
    modules: DashboardMetric;
    actions: DashboardMetric;
    texts: DashboardMetric;
    replies: DashboardMetric;
    sends: DashboardMetric;
    stops: DashboardMetric;
    unsubscribeRate: DashboardMetric;
  };
  messagesNote?: string;
  /** ISO timestamp of when the server computed these numbers. */
  cachedAt?: string;
  /** True when served from cache while a fresh copy is fetched in the background. */
  stale?: boolean;
}

export type RevenueResponse =
  | {
      connected: true;
      currency: string;
      mrr: number;
      activeSubscriptions: number;
      newRevenue: number;
      churnedSubscriptions: number;
      cachedAt?: string;
      stale?: boolean;
    }
  | { connected: false; reason: string; cachedAt?: string; stale?: boolean };

export interface AttributionSummary {
  total: number;
  bySource: { key: string; count: number }[];
  byCampaign: { key: string; count: number }[];
  cachedAt?: string;
  stale?: boolean;
}

export interface AttritionContact {
  contactId: string;
  name: string;
  tags: string[];
  unsubscribedAt: string | null;
  textsBeforeUnsub: number;
  moduleId: string | null;
  moduleName: string | null;
  journeyId: string | null;
  journeyName: string | null;
}

export interface AttritionResponse {
  summary: {
    currentlyUnsubscribed: number;
    stopEvents: number;
    messagedContacts: number;
    totalContacts: number;
    unsubscribeRatePct: number;
    avgTextsBeforeUnsub: number;
  };
  timeline: { month: string; count: number }[];
  contacts: AttritionContact[];
  cachedAt?: string;
  stale?: boolean;
}

export interface FounderInsight {
  title: string;
  detail: string;
  sentiment: 'positive' | 'negative' | 'neutral';
}

export interface InsightsResponse {
  insights: FounderInsight[];
  summary: Record<string, unknown>;
  model: string;
  generatedAt: string;
  cachedAt?: string;
  stale?: boolean;
}

const DEFAULT_ORG_ID = '00000022';

export class MindfulTextAPI {
  private auth: typeof authService;

  constructor() {
    this.auth = authService;
  }

  private formatOrgId(orgId: string | number): string {
    if (typeof orgId === 'number') {
      return orgId.toString().padStart(8, '0');
    }
    if (/^\d+$/.test(orgId)) {
      return orgId.padStart(8, '0');
    }
    return orgId;
  }

  private resolveOrgId(preferredOrgId?: string | number): string {
    if (preferredOrgId !== undefined && preferredOrgId !== null) {
      return this.formatOrgId(preferredOrgId);
    }
    // Single-user mode: the configured org id (mirrored from
    // /api/local/settings into localStorage) is the source of truth.
    return resolveLocalOrgId() || DEFAULT_ORG_ID;
  }

  private ensureArray(result: any): any[] {
    if (Array.isArray(result)) return result;
    if (result === null || result === undefined) return [];
    if (typeof result === 'object' && Array.isArray(result.items)) return result.items;
    if (typeof result === 'object' && Array.isArray(result.list)) return result.list;
    if (typeof result === 'object' && result.data) {
      // { data: [...] }
      if (Array.isArray(result.data)) return result.data;
      // { data: { results: [...] } }  — search endpoint shape
      if (typeof result.data === 'object' && Array.isArray(result.data.results)) return result.data.results;
    }
    return [];
  }

  async getModules(orgId?: string | number): Promise<Module[]> {
    const result = await this.auth.makeAuthenticatedRequest('GET', `/api/modules/byOrganization/${this.resolveOrgId(orgId)}`);
    return this.ensureArray(result);
  }

  async getModule(moduleId: string): Promise<Module> {
    return await this.auth.makeAuthenticatedRequest('GET', `/api/modules/${moduleId}`);
  }

  async createModule(moduleData: Partial<Module>, orgId?: string | number): Promise<Module> {
    return await this.auth.makeAuthenticatedRequest('POST', `/api/modules/${this.resolveOrgId(orgId)}`, moduleData);
  }

  async updateModule(moduleId: string, moduleData: Partial<Module>): Promise<Module> {
    return this.safeUpdate('module', moduleId, moduleData, () => this.getModule(moduleId), `/api/modules/${moduleId}`);
  }

  async getContacts(orgId?: string | number): Promise<Contact[]> {
    // pageSize=500 ensures we get all contacts in one shot.
    // Without it the API defaults to ~25-50 per page.
    const result = await this.auth.makeAuthenticatedRequest(
      'GET',
      `/api/contacts/byOrganization/${this.resolveOrgId(orgId)}?page=1&pageSize=500`,
    );
    const all = this.ensureArray(result);
    // Filter out archived contacts client-side.
    return all.filter((c: any) => !c.isArchived);
  }

  async searchContacts(query: any, orgId?: string | number): Promise<Contact[]> {
    const result = await this.auth.makeAuthenticatedRequest('POST', `/api/contacts/${this.resolveOrgId(orgId)}/search`, query);
    return this.ensureArray(result);
  }

  async getContact(contactId: string): Promise<Contact> {
    return await this.auth.makeAuthenticatedRequest('GET', `/api/contacts/${contactId}`);
  }

  async updateContact(contactId: string, contactData: Partial<Contact>): Promise<Contact> {
    return this.safeUpdate('contact', contactId, contactData, () => this.getContact(contactId), `/api/contacts/${contactId}`);
  }

  async createContact(
    orgIdOrContact: string | number | Partial<Contact>,
    maybeContact?: Partial<Contact>,
  ): Promise<Contact> {
    if (typeof orgIdOrContact === 'string' || typeof orgIdOrContact === 'number') {
      return await this.auth.makeAuthenticatedRequest(
        'POST',
        `/api/contacts/${this.resolveOrgId(orgIdOrContact)}`,
        maybeContact ?? {},
      );
    }

    return await this.auth.makeAuthenticatedRequest(
      'POST',
      `/api/contacts/${this.resolveOrgId()}`,
      orgIdOrContact,
    );
  }

  async createJourney(journeyData: Partial<Journey>, orgId?: string | number): Promise<Journey> {
    return await this.auth.makeAuthenticatedRequest('POST', `/api/journeys/${this.resolveOrgId(orgId)}`, journeyData);
  }

  async updateJourney(journeyId: string, journeyData: Partial<Journey>): Promise<Journey> {
    return this.safeUpdate('journey', journeyId, journeyData, () => this.getJourney(journeyId), `/api/journeys/${journeyId}`);
  }

  /**
   * Shared safe-update pipeline used by all entity update methods.
   *
   * Three safeguards happen here, every time:
   *   1. Snapshot — POST the current MindfulText record to our local DB so it
   *      can be restored later (one-click undo).
   *   2. Fetch-then-merge — MindfulText PUT is a full replace, so we overlay
   *      the changes on top of the live record.
   *   3. Pre-flight validation — refuse to send if any known array field would
   *      go from non-empty to empty (and the user didn't explicitly pass that
   *      key). This catches the bug that wiped module 00000550 dead in its
   *      tracks: a small payload should never accidentally clear large arrays.
   */
  private async safeUpdate<T>(
    entityType: 'module' | 'contact' | 'action' | 'journey',
    entityId: string,
    changes: Partial<T>,
    fetchCurrent: () => Promise<any>,
    putPath: string,
  ): Promise<T> {
    const current: any = await fetchCurrent();
    const orgId = this.resolveOrgId();

    // Snapshot — best-effort; never block the save on this.
    try {
      await fetch('/api/local/snapshots', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          organizationId: orgId,
          entityType,
          entityId,
          entityName: current?.name ?? `${current?.firstName ?? ''} ${current?.lastName ?? ''}`.trim() ?? null,
          snapshot: current,
          reason: 'before_edit',
        }),
      });
    } catch (snapErr) {
      console.warn(`[safeUpdate] snapshot failed for ${entityType} ${entityId}:`, snapErr);
    }

    const merged: any = { ...current, ...changes, organizationID: orgId };

    // Coerce nulls on known array fields — MindfulText rejects null arrays.
    const arrayFields = ['texts', 'messages', 'actionIds', 'actionIDs', 'tags', 'moduleIDs', 'moduleIds'];
    for (const k of arrayFields) {
      if (merged[k] === null) merged[k] = [];
    }

    // Pre-flight validation: surface a non-blocking warning rather than
    // refusing the save. Single-user mode prefers letting the save through
    // so the user isn't stuck — the entity-snapshot above still allows undo.
    const changedKeys = new Set(Object.keys(changes as object));
    for (const k of arrayFields) {
      const before = Array.isArray(current?.[k]) ? current[k].length : 0;
      const after = Array.isArray(merged[k]) ? merged[k].length : 0;
      if (before > 0 && after === 0 && !changedKeys.has(k)) {
        const msg = `Saving ${entityType} ${entityId} would clear "${k}" (${before} item${before !== 1 ? 's' : ''}). Proceeding — use the pre-edit snapshot to undo if needed.`;
        console.warn(`[safeUpdate] ${msg}`);
        // Surface to the UI as a non-blocking toast via a global event so we
        // don't have to thread `useToast` through every caller of safeUpdate.
        try {
          window.dispatchEvent(new CustomEvent("safe-update-warning", { detail: { message: msg, entityType, entityId, field: k } }));
        } catch { /* non-browser env */ }
      }
    }

    return await this.auth.makeAuthenticatedRequest('PUT', putPath, merged);
  }

  async getJourneys(orgId?: string | number): Promise<Journey[]> {
    const result = await this.auth.makeAuthenticatedRequest('GET', `/api/journeys/byOrganization/${this.resolveOrgId(orgId)}`);
    return this.ensureArray(result);
  }

  async getJourney(journeyId: string): Promise<Journey> {
    return await this.auth.makeAuthenticatedRequest('GET', `/api/journeys/${journeyId}`);
  }

  async searchJourneys(query: any, orgId?: string | number): Promise<Journey[]> {
    const result = await this.auth.makeAuthenticatedRequest('POST', `/api/journeys/${this.resolveOrgId(orgId)}/search`, query);
    return this.ensureArray(result);
  }

  async getActions(orgId?: string | number): Promise<Action[]> {
    const result = await this.auth.makeAuthenticatedRequest('GET', `/api/actions/byOrganization/${this.resolveOrgId(orgId)}`);
    return this.ensureArray(result);
  }

  async getAction(actionId: string): Promise<Action> {
    return await this.auth.makeAuthenticatedRequest('GET', `/api/actions/${actionId}`);
  }

  async createAction(actionData: Partial<Action>, orgId?: string | number): Promise<Action> {
    return await this.auth.makeAuthenticatedRequest('POST', `/api/actions/${this.resolveOrgId(orgId)}`, actionData);
  }

  async updateAction(actionId: string, actionData: Partial<Action>): Promise<Action> {
    return this.safeUpdate('action', actionId, actionData, () => this.getAction(actionId), `/api/actions/${actionId}`);
  }

  async getMessages(orgId?: string | number): Promise<Message[]> {
    const result = await this.auth.makeAuthenticatedRequest('GET', `/api/messages/byOrganization/${this.resolveOrgId(orgId)}`);
    return this.ensureArray(result);
  }

  async getIntegrations(orgId?: string | number): Promise<Integration[]> {
    const result = await this.auth.makeAuthenticatedRequest('GET', `/api/integrations/byOrganization/${this.resolveOrgId(orgId)}`);
    return this.ensureArray(result);
  }

  async getIntegration(integrationId: string): Promise<Integration> {
    return await this.auth.makeAuthenticatedRequest('GET', `/api/integrations/${integrationId}`);
  }

  async getTeamMembers(orgId?: string | number): Promise<TeamMember[]> {
    const result = await this.auth.makeAuthenticatedRequest('GET', `/api/team/byOrganization/${this.resolveOrgId(orgId)}`);
    return this.ensureArray(result);
  }

  async getAnalytics(orgId?: string | number): Promise<AnalyticsData> {
    try {
      const result = await this.auth.makeAuthenticatedRequest('GET', `/api/analytics/byOrganization/${this.resolveOrgId(orgId)}`);
      if (result && typeof result === 'object') {
        return {
          newContacts: result.newContacts || 0,
          journeysLaunched: result.journeysLaunched || 0,
          messagesSent: result.messagesSent || 0,
          messagesReceived: result.messagesReceived || 0,
        };
      }
    } catch {}
    return { newContacts: 0, journeysLaunched: 0, messagesSent: 0, messagesReceived: 0 };
  }

  async getSubscriptions(orgId?: string | number): Promise<Subscription[]> {
    // Use the local server endpoint, which fetches subscriptions via the
    // server-side auto-session. This works even in a fresh browser tab that
    // hasn't logged in to MindfulText through the per-tab cookie proxy.
    const id = this.resolveOrgId(orgId);
    const res = await fetch(`/api/local/subscriptions/${id}`);
    if (!res.ok) {
      let detail = '';
      try {
        const body = await res.json();
        detail = typeof body?.error === 'string' ? `: ${body.error}` : '';
      } catch {
        /* non-json error body */
      }
      throw new Error(`Failed to load subscriptions (HTTP ${res.status})${detail}`);
    }
    return this.ensureArray(await res.json());
  }

  async getSubscriptionCounts(orgId?: string | number): Promise<Record<string, number>> {
    // Server-side aggregation: returns `{ journeyId -> uniqueContactCount }`
    // so the Workbench doesn't have to pull thousands of subscription rows
    // just to render count badges.
    const id = this.resolveOrgId(orgId);
    const res = await fetch(`/api/local/subscription-counts/${id}`);
    if (!res.ok) {
      let detail = '';
      try {
        const body = await res.json();
        detail = typeof body?.error === 'string' ? `: ${body.error}` : '';
      } catch {
        /* non-json error body */
      }
      throw new Error(`Failed to load subscription counts (HTTP ${res.status})${detail}`);
    }
    const j = await res.json();
    return j && typeof j === 'object' && !Array.isArray(j) ? j as Record<string, number> : {};
  }

  async getUniqueContactCountAcrossJourneys(
    journeyIds: string[],
    orgId?: string | number,
  ): Promise<number> {
    // Server-side dedupe across multiple journeys. Used by the Workbench
    // module pivot so we don't double-count contacts who subscribe to more
    // than one parent journey of the selected module.
    const id = this.resolveOrgId(orgId);
    const res = await fetch(
      `/api/local/subscription-counts/${id}/unique-contacts`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ journeyIds }),
      },
    );
    if (!res.ok) {
      let detail = '';
      try {
        const body = await res.json();
        detail = typeof body?.error === 'string' ? `: ${body.error}` : '';
      } catch {
        /* non-json error body */
      }
      throw new Error(`Failed to load unique contact count (HTTP ${res.status})${detail}`);
    }
    const j = await res.json();
    return typeof j?.uniqueContactCount === 'number' ? j.uniqueContactCount : 0;
  }

  async getDashboardStats(params: {
    period: 'day' | 'week' | 'month' | 'year' | 'all' | 'custom';
    /** YYYY-MM-DD; required when period === 'custom' */
    start?: string;
    /** YYYY-MM-DD, inclusive; required when period === 'custom' */
    end?: string;
    /** Bypass the server cache and recompute from upstream. */
    force?: boolean;
  }): Promise<DashboardStatsResponse> {
    // The server now derives orgId from the session — don't send it.
    // Always send the user's tz so day/week/month/year/custom windows line up
    // with their local midnight, not the server's.
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    const qs = new URLSearchParams({ period: params.period, tz });
    if (params.period === 'custom') {
      if (params.start) qs.set('start', params.start);
      if (params.end) qs.set('end', params.end);
    }
    if (params.force) qs.set('refresh', '1');
    const sessionId = localStorage.getItem('mindfultext_session_id') || '';
    const res = await fetch(`/api/local/dashboard-stats?${qs.toString()}`, {
      headers: sessionId ? { 'X-Session-ID': sessionId } : {},
    });
    if (!res.ok) throw new Error(`dashboard-stats ${res.status}`);
    return res.json();
  }

  async getRevenue(range: string = 'month', force = false): Promise<RevenueResponse> {
    const sessionId = localStorage.getItem('mindfultext_session_id') || '';
    const qs = new URLSearchParams({ range });
    if (force) qs.set('refresh', '1');
    const res = await fetch(`/api/local/revenue?${qs.toString()}`, {
      headers: sessionId ? { 'X-Session-ID': sessionId } : {},
    });
    if (!res.ok) throw new Error(`revenue ${res.status}`);
    return res.json();
  }

  async getAttribution(sinceDays?: number, force = false): Promise<AttributionSummary> {
    const sessionId = localStorage.getItem('mindfultext_session_id') || '';
    const qs = new URLSearchParams();
    if (sinceDays) qs.set('sinceDays', String(sinceDays));
    if (force) qs.set('refresh', '1');
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    const res = await fetch(`/api/local/attribution${suffix}`, {
      headers: sessionId ? { 'X-Session-ID': sessionId } : {},
    });
    if (!res.ok) throw new Error(`attribution ${res.status}`);
    return res.json();
  }

  async getAttrition(force = false): Promise<AttritionResponse> {
    const sessionId = localStorage.getItem('mindfultext_session_id') || '';
    const suffix = force ? '?refresh=1' : '';
    const res = await fetch(`/api/local/attrition${suffix}`, {
      headers: sessionId ? { 'X-Session-ID': sessionId } : {},
    });
    if (!res.ok) throw new Error(`attrition ${res.status}`);
    return res.json();
  }

  async getInsights(force = false): Promise<InsightsResponse> {
    const sessionId = localStorage.getItem('mindfultext_session_id') || '';
    const suffix = force ? '?refresh=1' : '';
    const res = await fetch(`/api/local/insights${suffix}`, {
      headers: sessionId ? { 'X-Session-ID': sessionId } : {},
    });
    if (!res.ok) throw new Error(`insights ${res.status}`);
    return res.json();
  }

  isAuthenticated(): boolean {
    return this.auth.isAuthenticated();
  }

  async logout(): Promise<void> {
    await this.auth.logout();
  }
}

export const apiService = new MindfulTextAPI();
