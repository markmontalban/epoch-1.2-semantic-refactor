import { QueryClient, QueryFunction } from "@tanstack/react-query";
import { config, getApiUrl } from "./config";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

// Dispatch a browser event so AutoSessionGate can silently re-check the
// server-side auto-session when a proxy call returns 401.
let _sessionRecheckPending = false;
function notifySessionExpired() {
  if (_sessionRecheckPending) return; // deduplicate rapid 401s
  _sessionRecheckPending = true;
  window.dispatchEvent(new CustomEvent("mindfultext:session-expired"));
  // Allow another notification after 10 s in case the first recheck failed.
  setTimeout(() => { _sessionRecheckPending = false; }, 10_000);
}

function isProxyUrl(url: string): boolean {
  return url.includes("/api/proxy/");
}

// Routes implemented by our own Express server. These must stay same-origin
// (no API_BASE_URL prefix) so that POSTs from the browser hit our backend
// instead of being mis-routed to the MindfulText host.
const LOCAL_ROUTE_PREFIXES = [
  "/api/local/",
  "/api/auto-session",
  "/api/webhooks/",
] as const;

function isLocalRoute(url: string): boolean {
  return LOCAL_ROUTE_PREFIXES.some((p) => url.startsWith(p));
}

function resolveUrl(url: string): string {
  if (url.startsWith("http")) return url;
  if (isLocalRoute(url)) return url;
  return getApiUrl(url);
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  const fullUrl = resolveUrl(url);
  
  try {
    const res = await fetch(fullUrl, {
      method,
      headers: data ? { "Content-Type": "application/json" } : {},
      body: data ? JSON.stringify(data) : undefined,
      credentials: "include",
    });

    if (res.status === 401 && isProxyUrl(fullUrl)) {
      notifySessionExpired();
    }

    await throwIfResNotOk(res);
    return res;
  } catch (error) {
    console.warn(`API request failed for ${fullUrl}:`, error);
    throw error;
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const url = queryKey.join("/") as string;
    const normalized = url.startsWith("/") || url.startsWith("http") ? url : `/${url}`;
    const fullUrl = resolveUrl(normalized);
    
    try {
      const res = await fetch(fullUrl, {
        credentials: "include",
      });

      if (res.status === 401) {
        if (isProxyUrl(fullUrl)) {
          notifySessionExpired();
        }
        if (unauthorizedBehavior === "returnNull") {
          return null;
        }
      }

      await throwIfResNotOk(res);
      return await res.json();
    } catch (error) {
      console.warn(`Query failed for ${fullUrl}:`, error);
      throw error;
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
