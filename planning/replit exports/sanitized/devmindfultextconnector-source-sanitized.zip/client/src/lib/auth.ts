export interface User {
  id: number;
  email: string;
  name?: string;
  role?: string;
  organizationID?: string;
}

export interface LoginResponse {
  success: boolean;
  user?: User;
  error?: string;
}

/**
 * Returns a stable UUID for this browser session.
 * Stored in localStorage so it survives page refreshes and server restarts.
 * Sent as X-Session-ID on every proxy request so the server can reliably
 * key its session-cookie store without relying on req.ip.
 */
function getOrCreateSessionId(): string {
  const key = "mindfultext_session_id";
  let sid = localStorage.getItem(key);
  if (!sid) {
    sid = crypto.randomUUID();
    localStorage.setItem(key, sid);
  }
  return sid;
}

export class MindfulTextAuth {
  private user: User | null = null;

  /** Build headers that every proxy request must include. */
  private proxyHeaders(): Record<string, string> {
    return {
      Accept: "application/json",
      "X-Session-ID": getOrCreateSessionId(),
    };
  }

  async login(identifier: string, password: string): Promise<LoginResponse> {
    const isEmail = identifier.includes("@");

    const credentialPayloads = isEmail
      ? [{ email: identifier, password }]
      : [
          { username: identifier, password },
          { email: identifier, password },
        ];

    const contentTypes = [
      "application/x-www-form-urlencoded",
      "application/json",
    ] as const;

    for (const credentials of credentialPayloads) {
      for (const contentType of contentTypes) {
        try {
          const searchParams = new URLSearchParams();
          for (const [key, value] of Object.entries(credentials)) {
            if (typeof value === "string") searchParams.append(key, value);
          }

          const body =
            contentType === "application/x-www-form-urlencoded"
              ? searchParams.toString()
              : JSON.stringify(credentials);

          console.log("🔐 Login attempt:", {
            endpoint: "/api/proxy/mindfultext/api/login",
            contentType,
            credentials: { ...credentials, password: "***" },
          });

          const response = await fetch("/api/proxy/mindfultext/api/login", {
            method: "POST",
            headers: {
              ...this.proxyHeaders(),
              "Content-Type": contentType,
            },
            body,
          });

          const rawText = await response.text();
          console.log("📡 Response:", {
            status: response.status,
            contentType,
            body: rawText.substring(0, 500),
          });

          if (!response.ok) {
            console.warn(`❌ Failed (${response.status}):`, rawText);
            continue;
          }

          let responseData: any;
          try {
            responseData = JSON.parse(rawText);
          } catch {
            console.warn("Response is not JSON:", rawText);
            continue;
          }

          // Parse whichever shape MindfulText returns.
          if (responseData.data && responseData.data.email) {
            const raw = responseData.data;
            this.user = {
              id: parseInt(raw.id) || 0,
              email: raw.email,
              name: raw.name || raw.email,
              role: raw.role || "user",
              // organizationID is not in the login response; resolved below.
              organizationID: raw.organizationID
                ? String(raw.organizationID)
                : undefined,
            };
          } else if (responseData.user) {
            this.user = responseData.user;
          } else if (responseData.email || responseData.id) {
            this.user = responseData;
          }

          if (!this.user) {
            // 200 OK but no parseable user — treat as logged-in with minimal info.
            this.user = { id: 0, email: identifier };
          }

          // Attempt to resolve organizationID from the API if not in login payload.
          if (!this.user.organizationID) {
            try {
              const orgRes = await this.makeAuthenticatedRequest(
                "GET",
                "/api/organizations/byUser"
              );
              const orgs = Array.isArray(orgRes) ? orgRes : orgRes?.data ?? [];
              if (orgs.length > 0) {
                this.user.organizationID = String(orgs[0].id);
              }
            } catch {
              // Non-fatal: we will fall back to DEFAULT_ORG_ID in api.ts.
            }
          }

          localStorage.setItem("mindfultext_user", JSON.stringify(this.user));
          console.log("✅ Login successful:", this.user);
          return { success: true, user: this.user };
        } catch (error) {
          console.warn("Login attempt failed:", error);
          continue;
        }
      }
    }

    return {
      success: false,
      error: "Login failed. Please check your credentials and try again.",
    };
  }

  async makeAuthenticatedRequest(
    method: string,
    endpoint: string,
    data: any = null
  ): Promise<any> {
    const headers: Record<string, string> = { ...this.proxyHeaders() };

    const config: RequestInit = {
      method: method.toUpperCase(),
      headers,
      credentials: "include",
    };

    if (data !== null && (method === "POST" || method === "PUT")) {
      headers["Content-Type"] = "application/json";
      config.body = JSON.stringify(data);
    }

    const response = await fetch(
      `/api/proxy/mindfultext${endpoint}`,
      config
    );

    if (!response.ok) {
      const errorText = await response
        .text()
        .catch(() => response.statusText);
      throw new Error(
        `API request failed: ${response.status} ${errorText}`
      );
    }

    const json = await response.json();
    if (json && typeof json === "object" && "data" in json) {
      return json.data;
    }
    return json;
  }

  getCurrentUser(): User | null {
    if (this.user) return this.user;
    try {
      const userStr = localStorage.getItem("mindfultext_user");
      if (userStr) {
        this.user = JSON.parse(userStr);
        return this.user;
      }
    } catch (error) {
      console.error("Error parsing user data:", error);
    }
    return null;
  }

  isAuthenticated(): boolean {
    return !!this.getCurrentUser();
  }

  async logout(): Promise<void> {
    try {
      await fetch("/api/proxy/mindfultext/api/logout", {
        method: "POST",
        headers: this.proxyHeaders(),
        credentials: "include",
      });
    } catch (error) {
      console.warn("Logout API call failed:", error);
    } finally {
      this.user = null;
      localStorage.removeItem("mindfultext_user");
    }
  }
}

export const authService = new MindfulTextAuth();
