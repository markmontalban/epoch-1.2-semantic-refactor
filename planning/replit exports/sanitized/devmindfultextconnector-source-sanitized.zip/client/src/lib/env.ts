// Environment configuration for MindfulText API
// Based on the Frontend Development Guide

export const env = {
  // MindfulText API Configuration
  API_BASE_URL: import.meta.env.VITE_API_BASE_URL || 'https://dev.mindfultext.com',
  
  // MindfulText Credentials (for automatic login)
  MINDFULTEXT_EMAIL: import.meta.env.VITE_MINDFULTEXT_EMAIL || '',
  MINDFULTEXT_PASSWORD: import.meta.env.VITE_MINDFULTEXT_PASSWORD || '',
  
  // Environment detection
  ENVIRONMENT: import.meta.env.VITE_ENVIRONMENT || import.meta.env.MODE || 'development',
  isDevelopment: import.meta.env.DEV,
  isProduction: import.meta.env.PROD,
  isTest: import.meta.env.MODE === 'test',
  
  // Feature flags
  features: {
    enableDebugLogging: import.meta.env.DEV,
    enableErrorReporting: import.meta.env.PROD,
  },
} as const;

// Helper to get environment-specific API URL
export function getApiBaseUrl(): string {
  return env.API_BASE_URL;
}

// Log environment info in development
if (env.isDevelopment) {
  console.log('MindfulText API Configuration:', {
    API_BASE_URL: getApiBaseUrl(),
    HAS_EMAIL: !!env.MINDFULTEXT_EMAIL,
    HAS_PASSWORD: !!env.MINDFULTEXT_PASSWORD,
  });
} 