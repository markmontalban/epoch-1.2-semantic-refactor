export interface ParsedActionRef {
  name: string;
  keywords: string[];
}

export interface ParsedText {
  content: string;
  actions: ParsedActionRef[];
  keywords: string[];
}

export interface ParsedModule {
  name: string;
  description?: string;
  tags: string[];
  actions: ParsedActionRef[];
  texts: ParsedText[];
}

// ---- Export (serialize) types ----

export interface ExportText {
  content?: string;
  keywords?: string[];
  actions?: { actionId?: string; actionID?: string; keywords?: string[] }[];
}

export interface ExportModule {
  id: string;
  name: string;
  description?: string;
  tags?: string[];
  texts?: ExportText[];
  actionIds?: string[];
}

export interface ExportJourney {
  id: string;
  name: string;
  description?: string;
  tags?: string[];
  launchDays?: string[];
  schedule?: string[];
  time?: string;
  moduleIds?: string[];
  moduleIDs?: string[];
}

export interface ExportContact {
  id: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  phoneNumber?: string;
  company?: string;
  tags?: string[];
  activeJourneys?: string[];
}

export interface ExportInput {
  // Single-journey mode (legacy — used when only ONE journey is being
  // exported and we want a "Journey: …" header at the top of the markdown).
  journey?: ExportJourney;
  // Multi-journey mode — when supplied, takes precedence over `journey`.
  journeys?: ExportJourney[];
  modules: ExportModule[];
  actionsById: Map<string, { id: string; name: string }>;
  // Optional — only emitted in JSON output. Markdown ignores contacts.
  contacts?: ExportContact[];
}

export interface ParsedImport {
  journey: {
    name: string;
    description?: string;
    tags: string[];
    schedule: string[];
    time?: string;
  };
  modules: ParsedModule[];
  warnings: string[];
}

const DAY_MAP: Record<string, string> = {
  sun: "Sunday", sunday: "Sunday",
  mon: "Monday", monday: "Monday",
  tue: "Tuesday", tues: "Tuesday", tuesday: "Tuesday",
  wed: "Wednesday", weds: "Wednesday", wednesday: "Wednesday",
  thu: "Thursday", thur: "Thursday", thurs: "Thursday", thursday: "Thursday",
  fri: "Friday", friday: "Friday",
  sat: "Saturday", saturday: "Saturday",
};

function normalizeDays(raw: string): string[] {
  return raw
    .split(/[,/&|]+|\s+and\s+/i)
    .map((s) => s.trim().toLowerCase().replace(/[.\s]/g, ""))
    .filter(Boolean)
    .map((s) => DAY_MAP[s] || s)
    .filter((s, i, a) => a.indexOf(s) === i);
}

/**
 * Parse an "Actions:" value that may include inline keywords:
 *   "send_followup on: yes, y, sure"
 *   "send_followup, log_optin on: yes"
 *   "send_followup"
 */
function parseActionsValue(raw: string): ParsedActionRef[] {
  const suffixMatch = /\s+(?:on|keywords?|triggers?)\s*:\s*(.+)$/i.exec(raw);
  let namesPart = raw;
  let kws: string[] = [];
  if (suffixMatch) {
    namesPart = raw.slice(0, suffixMatch.index);
    kws = splitList(suffixMatch[1]);
  }
  return splitList(namesPart).map((name) => ({ name, keywords: [...kws] }));
}

function splitList(raw: string): string[] {
  return raw
    .split(/,|\||;/)
    .map((s) => s.trim())
    .filter(Boolean);
}

/**
 * Parse a markdown file describing a journey and its modules.
 *
 * Format:
 *
 *   Journey: Welcome Series
 *   Schedule: Mon, Wed, Fri
 *   Time: 9:00 AM
 *   Description: Optional description
 *   Tags: welcome, onboarding
 *
 *   ## Module Name
 *   Tags: tag1, tag2
 *   Actions: action_a, action_b
 *   Description: optional
 *
 *   First text body. Multi-line allowed.
 *   [Action: action_c]
 *
 *   ---
 *
 *   Second text body.
 */
export function parseImportMarkdown(input: string): ParsedImport {
  const warnings: string[] = [];
  const result: ParsedImport = {
    journey: { name: "", tags: [], schedule: [] },
    modules: [],
    warnings,
  };

  // Split into header (everything before the first ## ) and module sections.
  const moduleRegex = /^##\s+(.+?)\s*$/gm;
  const headerEnd = (() => {
    const m = moduleRegex.exec(input);
    return m ? m.index : input.length;
  })();

  const headerBlock = input.slice(0, headerEnd);
  const moduleBlocks: { name: string; body: string }[] = [];

  // Reset and walk all module headings.
  moduleRegex.lastIndex = 0;
  const matches: { name: string; start: number; end: number }[] = [];
  let m: RegExpExecArray | null;
  while ((m = moduleRegex.exec(input)) !== null) {
    matches.push({ name: m[1].trim(), start: m.index + m[0].length, end: input.length });
  }
  for (let i = 0; i < matches.length; i++) {
    if (i + 1 < matches.length) matches[i].end = input.lastIndexOf("\n##", matches[i + 1].start);
    moduleBlocks.push({ name: matches[i].name, body: input.slice(matches[i].start, matches[i].end).trim() });
  }

  // ---- Parse header ----
  const headerLines = headerBlock.split(/\r?\n/);
  for (const line of headerLines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) {
      // A leading "# Title" line is allowed but ignored.
      continue;
    }
    const kv = /^([A-Za-z][A-Za-z ]*?)\s*:\s*(.+)$/.exec(trimmed);
    if (!kv) continue;
    const key = kv[1].trim().toLowerCase();
    const value = kv[2].trim();
    switch (key) {
      case "journey":
      case "journey name":
      case "name":
        result.journey.name = value;
        break;
      case "description":
      case "desc":
        result.journey.description = value;
        break;
      case "tags":
        result.journey.tags = splitList(value);
        break;
      case "schedule":
      case "days":
      case "launch days":
        result.journey.schedule = normalizeDays(value);
        break;
      case "time":
      case "launch time":
        result.journey.time = value;
        break;
    }
  }

  if (!result.journey.name) {
    warnings.push("No 'Journey: <name>' header found at top of file.");
  }
  if (moduleBlocks.length === 0) {
    warnings.push("No '## Module' sections found.");
  }

  // ---- Parse each module ----
  for (const mb of moduleBlocks) {
    const mod: ParsedModule = {
      name: mb.name,
      tags: [],
      actions: [],
      texts: [],
    };

    // Pull leading metadata lines (Tags:, Actions:, Description:) until we
    // hit a blank line or the first text line.
    const lines = mb.body.split(/\r?\n/);
    let cursor = 0;
    while (cursor < lines.length) {
      const line = lines[cursor];
      const trimmed = line.trim();
      if (!trimmed) { cursor++; continue; }
      const kv = /^([A-Za-z][A-Za-z ]*?)\s*:\s*(.+)$/.exec(trimmed);
      if (!kv) break;
      const key = kv[1].trim().toLowerCase();
      const value = kv[2].trim();
      let consumed = true;
      switch (key) {
        case "tags": mod.tags = splitList(value); break;
        case "actions":
        case "action": mod.actions = parseActionsValue(value); break;
        case "description":
        case "desc": mod.description = value; break;
        default: consumed = false;
      }
      if (!consumed) break;
      cursor++;
    }

    const remainder = lines.slice(cursor).join("\n").trim();
    if (!remainder) {
      warnings.push(`Module "${mod.name}" has no text content.`);
      result.modules.push(mod);
      continue;
    }

    // Split texts on horizontal rules: --- or *** on their own line.
    const textBlocks = remainder
      .split(/^[\s]*(?:---|\*\*\*)[\s]*$/m)
      .map((s) => s.trim())
      .filter(Boolean);

    for (const block of textBlocks) {
      const actionRefs: ParsedActionRef[] = [];
      const textKeywords: string[] = [];

      // [Action: name on: kw1, kw2]  or  [Actions: a, b]
      // Optional "on:" / "keywords:" / "trigger:" clause at the end.
      let cleaned = block.replace(
        /\[\s*Actions?\s*:\s*([^\]]+)\]/gi,
        (_full, inner: string) => {
          // Split off an "on:" / "keywords:" / "trigger:" suffix.
          const suffixMatch = /\s+(?:on|keywords?|triggers?)\s*:\s*(.+)$/i.exec(inner);
          let namesPart = inner;
          let kws: string[] = [];
          if (suffixMatch) {
            namesPart = inner.slice(0, suffixMatch.index);
            kws = splitList(suffixMatch[1]);
          }
          for (const name of splitList(namesPart)) {
            actionRefs.push({ name, keywords: [...kws] });
          }
          return "";
        },
      );

      // Standalone [Keywords: kw1, kw2] / [Triggers: ...] line — applies to all
      // actions on this text and is also surfaced as text-level keywords.
      cleaned = cleaned.replace(
        /\[\s*(?:Keywords?|Triggers?)\s*:\s*([^\]]+)\]/gi,
        (_full, list: string) => {
          const kws = splitList(list);
          textKeywords.push(...kws);
          for (const a of actionRefs) {
            for (const k of kws) if (!a.keywords.includes(k)) a.keywords.push(k);
          }
          return "";
        },
      );

      mod.texts.push({
        content: cleaned.trim(),
        actions: actionRefs,
        keywords: Array.from(new Set(textKeywords)),
      });
    }

    if (mod.texts.length === 0) {
      warnings.push(`Module "${mod.name}" has no text blocks after parsing.`);
    }

    result.modules.push(mod);
  }

  return result;
}

// =====================================================================
// Export serializers — counterpart to parseImportMarkdown above.
// =====================================================================

function actionRefName(
  ref: { actionId?: string; actionID?: string },
  actionsById: Map<string, { id: string; name: string }>,
): string | null {
  const id = ref.actionId ?? ref.actionID;
  if (!id) return null;
  const found = actionsById.get(id);
  return found?.name || id;
}

function joinList(items: string[]): string {
  return items.filter(Boolean).join(", ");
}

/**
 * Serialize a journey + its modules into the same markdown format that
 * parseImportMarkdown understands. The output round-trips through the
 * importer — module names, tags, descriptions, texts, action references
 * and per-action keywords are all preserved.
 */
export function serializeExportMarkdown(input: ExportInput): string {
  const { journey, journeys, modules, actionsById } = input;
  const lines: string[] = [];

  // Multi-journey mode: emit one block per journey, listing only the modules
  // that belong to it. Stand-alone modules (not in any journey) are appended
  // at the end under an "All Modules" header.
  if (journeys && journeys.length > 0) {
    const claimed = new Set<string>();
    for (const j of journeys) {
      lines.push(`Journey: ${j.name || "Untitled Journey"}`);
      const days = j.launchDays || j.schedule || [];
      if (days.length) lines.push(`Schedule: ${joinList(days)}`);
      if (j.time) lines.push(`Time: ${j.time}`);
      if (j.description) lines.push(`Description: ${j.description}`);
      if (j.tags && j.tags.length) lines.push(`Tags: ${joinList(j.tags)}`);
      lines.push("");

      const ids = j.moduleIds || j.moduleIDs || [];
      const journeyModules: ExportModule[] = [];
      for (const id of ids) {
        // Skip modules already emitted under a previous journey — re-importing
        // a multi-journey file with duplicate `## Module` blocks would create
        // duplicate modules in MindfulText. The journey's moduleIds list (if
        // serialised in JSON) still records the linkage; the markdown form
        // relies on the first journey to "own" the module section.
        if (claimed.has(id)) continue;
        const found = modules.find((m) => m.id === id);
        if (found) {
          journeyModules.push(found);
          claimed.add(found.id);
        }
      }
      for (const mod of journeyModules) appendModule(lines, mod, actionsById);
      lines.push("");
    }
    const orphans = modules.filter((m) => !claimed.has(m.id));
    if (orphans.length) {
      lines.push(`Journey: All Modules (not attached to a journey)`);
      lines.push("");
      for (const mod of orphans) appendModule(lines, mod, actionsById);
    }
    return lines.join("\n").replace(/\n{3,}/g, "\n\n").trimEnd() + "\n";
  }

  if (journey) {
    lines.push(`Journey: ${journey.name || "Untitled Journey"}`);
    const days = journey.launchDays || journey.schedule || [];
    if (days.length) lines.push(`Schedule: ${joinList(days)}`);
    if (journey.time) lines.push(`Time: ${journey.time}`);
    if (journey.description) lines.push(`Description: ${journey.description}`);
    if (journey.tags && journey.tags.length) lines.push(`Tags: ${joinList(journey.tags)}`);
    lines.push("");
  } else {
    lines.push(`Journey: All Modules Export`);
    lines.push("");
  }

  for (const mod of modules) {
    lines.push(`## ${mod.name || "Untitled Module"}`);
    if (mod.tags && mod.tags.length) lines.push(`Tags: ${joinList(mod.tags)}`);

    // Module-level actions: just by name (no per-action keywords at module level).
    if (mod.actionIds && mod.actionIds.length) {
      const names = mod.actionIds
        .map((id) => actionsById.get(id)?.name || id)
        .filter(Boolean);
      if (names.length) lines.push(`Actions: ${joinList(names)}`);
    }
    if (mod.description) lines.push(`Description: ${mod.description}`);
    lines.push("");

    const texts = mod.texts || [];
    if (texts.length === 0) {
      // Keep an empty placeholder so the parser still creates the module.
      lines.push("");
    }

    texts.forEach((t, i) => {
      const body = (t.content || "").trim();
      if (body) lines.push(body);

      const actions = t.actions || [];
      const sharedKeywords = t.keywords || [];

      // Emit each action with its inline keywords (de-duped).
      for (const a of actions) {
        const name = actionRefName(a, actionsById);
        if (!name) continue;
        const kws = Array.from(new Set([...(a.keywords || [])]));
        if (kws.length) {
          lines.push(`[Action: ${name} on: ${joinList(kws)}]`);
        } else {
          lines.push(`[Action: ${name}]`);
        }
      }

      // Always emit a [Keywords: ...] line if text-level keywords exist, so
      // the exact text.keywords array rehydrates on re-parse. (Action "on:"
      // clauses keep per-action keywords intact regardless.)
      if (sharedKeywords.length) {
        lines.push(`[Keywords: ${joinList(sharedKeywords)}]`);
      }

      if (i < texts.length - 1) {
        lines.push("");
        lines.push("---");
        lines.push("");
      }
    });

    lines.push("");
  }

  return lines.join("\n").replace(/\n{3,}/g, "\n\n").trimEnd() + "\n";
}

// Internal helper used by both single- and multi-journey serializers.
function appendModule(
  lines: string[],
  mod: ExportModule,
  actionsById: Map<string, { id: string; name: string }>,
): void {
  lines.push(`## ${mod.name || "Untitled Module"}`);
  if (mod.tags && mod.tags.length) lines.push(`Tags: ${joinList(mod.tags)}`);

  if (mod.actionIds && mod.actionIds.length) {
    const names = mod.actionIds
      .map((id) => actionsById.get(id)?.name || id)
      .filter(Boolean);
    if (names.length) lines.push(`Actions: ${joinList(names)}`);
  }
  if (mod.description) lines.push(`Description: ${mod.description}`);
  lines.push("");

  const texts = mod.texts || [];
  if (texts.length === 0) lines.push("");

  texts.forEach((t, i) => {
    const body = (t.content || "").trim();
    if (body) lines.push(body);

    const actions = t.actions || [];
    const sharedKeywords = t.keywords || [];

    for (const a of actions) {
      const name = actionRefName(a, actionsById);
      if (!name) continue;
      const kws = Array.from(new Set([...(a.keywords || [])]));
      if (kws.length) {
        lines.push(`[Action: ${name} on: ${joinList(kws)}]`);
      } else {
        lines.push(`[Action: ${name}]`);
      }
    }

    if (sharedKeywords.length) {
      lines.push(`[Keywords: ${joinList(sharedKeywords)}]`);
    }

    if (i < texts.length - 1) {
      lines.push("");
      lines.push("---");
      lines.push("");
    }
  });

  lines.push("");
}

/**
 * Serialize to a JSON shape that's self-contained: includes module records,
 * the journey metadata (when scoped to a journey), and the action definitions
 * referenced by either modules or texts.
 */
export function serializeExportJson(input: ExportInput): string {
  const { journey, journeys, modules, actionsById, contacts } = input;

  const referencedActionIds = new Set<string>();
  for (const mod of modules) {
    for (const id of mod.actionIds || []) referencedActionIds.add(id);
    for (const t of mod.texts || []) {
      for (const a of t.actions || []) {
        const id = a.actionId ?? a.actionID;
        if (id) referencedActionIds.add(id);
      }
    }
  }

  const referencedActions = Array.from(referencedActionIds)
    .map((id) => actionsById.get(id))
    .filter((a): a is { id: string; name: string } => !!a)
    .map((a) => ({ id: a.id, name: a.name }));

  const out: Record<string, unknown> = {
    exportedAt: new Date().toISOString(),
    modules: modules.map((m) => ({
      id: m.id,
      name: m.name,
      description: m.description ?? "",
      tags: m.tags ?? [],
      actionIds: m.actionIds ?? [],
      texts: (m.texts || []).map((t) => ({
        content: t.content ?? "",
        keywords: t.keywords ?? [],
        actions: (t.actions || []).map((a) => ({
          actionId: a.actionId ?? a.actionID ?? "",
          keywords: a.keywords ?? [],
        })),
      })),
    })),
    actions: referencedActions,
  };

  const serializeJourney = (j: ExportJourney) => ({
    id: j.id,
    name: j.name,
    description: j.description ?? "",
    tags: j.tags ?? [],
    launchDays: j.launchDays || j.schedule || [],
    time: j.time ?? "",
    moduleIds: j.moduleIds || j.moduleIDs || [],
  });

  if (journeys && journeys.length > 0) {
    out.journeys = journeys.map(serializeJourney);
  } else if (journey) {
    out.journey = serializeJourney(journey);
  }

  if (contacts && contacts.length > 0) {
    out.contacts = contacts.map((c) => ({
      id: c.id,
      firstName: c.firstName ?? "",
      lastName: c.lastName ?? "",
      email: c.email ?? "",
      phoneNumber: c.phoneNumber ?? "",
      company: c.company ?? "",
      tags: c.tags ?? [],
      activeJourneys: c.activeJourneys ?? [],
    }));
  }

  return JSON.stringify(out, null, 2);
}
