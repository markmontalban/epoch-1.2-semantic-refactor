// Best-effort first-party attribution capture. Records UTM params + a stable
// visitor id to /api/track so revenue/source attribution has a foundation.
// Safe to call on every app load; it only POSTs once per session unless new
// UTM params are present (a fresh campaign click).

const VISITOR_KEY = "mt_visitor_id";
const SENT_KEY = "mt_attribution_sent";

function getVisitorId(): string {
  let id = localStorage.getItem(VISITOR_KEY);
  if (!id) {
    id =
      typeof crypto !== "undefined" && crypto.randomUUID
        ? crypto.randomUUID()
        : `v_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    localStorage.setItem(VISITOR_KEY, id);
    document.cookie = `mt_visitor_id=${id};path=/;max-age=${60 * 60 * 24 * 365};samesite=lax`;
  }
  return id;
}

export function captureAttribution(): void {
  try {
    const params = new URLSearchParams(window.location.search);
    const utm = {
      utmSource: params.get("utm_source"),
      utmMedium: params.get("utm_medium"),
      utmCampaign: params.get("utm_campaign"),
      utmTerm: params.get("utm_term"),
      utmContent: params.get("utm_content"),
    };
    const hasUtm = Object.values(utm).some(Boolean);
    if (!hasUtm && sessionStorage.getItem(SENT_KEY)) return;

    const body = {
      visitorId: getVisitorId(),
      ...utm,
      referrer: document.referrer || null,
      landingPath: window.location.pathname + window.location.search,
    };
    void fetch("/api/track", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      keepalive: true,
    }).catch(() => {});
    sessionStorage.setItem(SENT_KEY, "1");
  } catch {
    /* attribution is best-effort; never block the app */
  }
}
