import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  apiService,
  type DashboardMetric,
  type DashboardStatsResponse,
  type RevenueResponse,
  type AttributionSummary,
  type InsightsResponse,
  type AttritionResponse,
} from "@/lib/api";
import { Link } from "wouter";
import { ArrowUp, ArrowDown, CalendarIcon, Sparkles, RefreshCw, MessageSquare } from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import type { DateRange } from "react-day-picker";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from "recharts";
import ReplyAnalytics from "./ReplyAnalytics";
import TokenUsage from "./TokenUsage";

type Period = "day" | "week" | "month" | "year" | "all" | "custom";

const PERIOD_BUTTONS: { key: Exclude<Period, "custom">; label: string }[] = [
  { key: "day", label: "Daily" },
  { key: "week", label: "Weekly" },
  { key: "month", label: "Monthly" },
  { key: "year", label: "Yearly" },
  { key: "all", label: "All time" },
];

function FreshnessControls({
  cachedAt,
  stale,
  onRefresh,
  isRefreshing,
}: {
  cachedAt?: string;
  stale?: boolean;
  onRefresh: () => void;
  isRefreshing: boolean;
}) {
  return (
    <div className="flex items-center gap-3 ml-auto">
      {cachedAt && (
        <span className="text-xs text-gray-400" data-testid="freshness-label">
          Updated {formatDistanceToNow(new Date(cachedAt), { addSuffix: true })}
          {stale ? " · refreshing…" : ""}
        </span>
      )}
      <Button variant="outline" size="sm" onClick={onRefresh} disabled={isRefreshing}>
        <RefreshCw className={`w-4 h-4 mr-1.5 ${isRefreshing ? "animate-spin" : ""}`} />
        Refresh
      </Button>
    </div>
  );
}

type MetricKey = keyof DashboardStatsResponse["metrics"];

const TILE_ORDER: {
  key: MetricKey;
  label: string;
  format?: "number" | "percent";
}[] = [
  { key: "contacts", label: "Contacts" },
  { key: "sends", label: "Messages Sent" },
  { key: "replies", label: "Messages Received" },
  { key: "journeysLaunched", label: "Journeys Launched" },
  { key: "journeys", label: "Journeys" },
  { key: "modules", label: "Modules" },
  { key: "texts", label: "Total Messages" },
  { key: "actions", label: "Actions" },
  { key: "stops", label: "Opt-outs" },
  { key: "unsubscribeRate", label: "Unsubscribe rate" },
];

function formatMetricValue(m: DashboardMetric, tileFormat?: "number" | "percent"): string {
  const fmt = m.format ?? tileFormat ?? "number";
  if (fmt === "percent") {
    return `${m.value.toLocaleString(undefined, { maximumFractionDigits: 1 })}%`;
  }
  return m.value.toLocaleString();
}

function DeltaLine({ metric, period }: { metric: DashboardMetric; period: Period }) {
  if (!metric.supportsTrend || period === "all") {
    return <p className="text-[9px] sm:text-xs text-transparent select-none">·</p>;
  }
  if (metric.value === 0 && (metric.previous ?? 0) === 0) {
    return <p className="text-[9px] sm:text-xs mt-0.5 sm:mt-1 text-gray-500">—</p>;
  }
  if (metric.isNewActivity) {
    return (
      <p className="text-[9px] sm:text-xs mt-0.5 sm:mt-1 flex items-center text-green-600">
        <ArrowUp className="w-2 h-2 sm:w-3 sm:h-3 mr-0.5" />
        New
      </p>
    );
  }
  if (metric.changePct === null) {
    return <p className="text-[9px] sm:text-xs text-transparent select-none">·</p>;
  }
  const pct = metric.changePct;
  const isUp = pct > 0;
  const isDown = pct < 0;
  const cls = isUp ? "text-green-600" : isDown ? "text-red-600" : "text-gray-500";
  const Icon = isUp ? ArrowUp : isDown ? ArrowDown : null;
  const sign = pct > 0 ? "+" : "";
  return (
    <p className={`text-[9px] sm:text-xs mt-0.5 sm:mt-1 flex items-center ${cls}`}>
      {Icon && <Icon className="w-2 h-2 sm:w-3 sm:h-3 mr-0.5" />}
      {sign}{pct}% vs. prior period
    </p>
  );
}

function KpiTile({
  label,
  metric,
  isLoading,
  period,
  format: fmt,
}: {
  label: string;
  metric?: DashboardMetric;
  isLoading: boolean;
  period: Period;
  format?: "number" | "percent";
}) {
  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200 p-1.5 sm:p-6">
      <CardContent className="p-0">
        {isLoading || !metric ? (
          <div className="animate-pulse">
            <div className="h-1.5 sm:h-3 bg-gray-200 rounded mb-1 sm:mb-2 w-10 sm:w-16" />
            <div className="h-3 sm:h-7 bg-gray-200 rounded mb-1 sm:mb-2 w-12 sm:w-20" />
            <div className="h-1.5 sm:h-3 bg-gray-200 rounded w-14 sm:w-24" />
          </div>
        ) : (
          <>
            <p className="text-[9px] sm:text-xs text-gray-600 leading-tight">{label}</p>
            <p className="text-sm sm:text-2xl font-bold text-gray-900 mt-0 sm:mt-0.5 leading-tight">
              {formatMetricValue(metric, fmt)}
            </p>
            <DeltaLine metric={metric} period={period} />
          </>
        )}
      </CardContent>
    </Card>
  );
}

function OverviewSection({
  data,
  isLoading,
  period,
}: {
  data?: DashboardStatsResponse;
  isLoading: boolean;
  period: Period;
}) {
  const m = data?.metrics;
  // Current vs prior comparison (only meaningful when a trend window exists).
  const comparison =
    period !== "all" && m
      ? [
          { name: "Sent", current: m.sends.value, prior: m.sends.previous ?? 0 },
          { name: "Received", current: m.replies.value, prior: m.replies.previous ?? 0 },
          { name: "New Contacts", current: m.contacts.value, prior: m.contacts.previous ?? 0 },
          { name: "Launches", current: m.journeysLaunched.value, prior: m.journeysLaunched.previous ?? 0 },
        ]
      : [];
  const hasComparison = comparison.some((c) => c.current > 0 || c.prior > 0);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-1.5 sm:gap-3">
        {TILE_ORDER.map((tile) => (
          <KpiTile
            key={tile.key}
            label={tile.label}
            metric={m?.[tile.key]}
            isLoading={isLoading}
            period={period}
            format={tile.format}
          />
        ))}
      </div>

      {hasComparison && (
        <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
          <CardContent className="p-4 sm:p-6">
            <h3 className="text-sm font-semibold text-gray-900 mb-1">
              This period vs. prior period
            </h3>
            <p className="text-xs text-gray-500 mb-4">
              Message activity is counted by calendar period in your local timezone.
            </p>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={comparison} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} stroke="#9ca3af" />
                  <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" allowDecimals={false} />
                  <Tooltip
                    formatter={(v: number) => v.toLocaleString()}
                    contentStyle={{ borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 12 }}
                  />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="prior" name="Prior" fill="#c7d2fe" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="current" name="Current" fill="#4f46e5" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

const SUGGESTED_QUESTIONS = [
  "Why did my reply rate change this week, and which module drove it?",
  "Which journeys are driving the most launches and replies this month?",
  "Where is my AI spend going, and what's the cost per reply?",
  "What should I focus on next week to grow contacts and engagement?",
];

function InsightsSection() {
  const { data, isLoading, isFetching, isError } = useQuery<InsightsResponse>({
    queryKey: ["insights"],
    queryFn: () => apiService.getInsights(),
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: false,
  });
  const [refreshing, setRefreshing] = useState(false);
  const refresh = async () => {
    setRefreshing(true);
    try {
      await queryClient.fetchQuery({
        queryKey: ["insights"],
        queryFn: () => apiService.getInsights(true),
        staleTime: 0,
      });
    } finally {
      setRefreshing(false);
    }
  };

  const sentimentColor = (s: string) =>
    s === "positive"
      ? "border-l-green-500"
      : s === "negative"
        ? "border-l-red-500"
        : "border-l-gray-300";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-indigo-600" />
          <h3 className="text-sm font-semibold text-gray-900">AI highlights</h3>
        </div>
        <FreshnessControls
          cachedAt={data?.cachedAt}
          stale={data?.stale}
          onRefresh={refresh}
          isRefreshing={refreshing || isFetching}
        />
      </div>

      {isLoading || isFetching ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-16 bg-gray-100 rounded animate-pulse" />
          ))}
        </div>
      ) : isError ? (
        <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
          <CardContent className="p-6 text-sm text-gray-500">
            Couldn't generate insights right now. Try refreshing.
          </CardContent>
        </Card>
      ) : data && data.insights.length > 0 ? (
        <div className="space-y-3">
          {data.insights.map((ins, i) => (
            <Card
              key={i}
              className={`bg-white rounded-xl shadow-sm border border-gray-200 border-l-4 ${sentimentColor(ins.sentiment)}`}
            >
              <CardContent className="p-4">
                <p className="text-sm font-semibold text-gray-900">{ins.title}</p>
                <p className="text-sm text-gray-600 mt-1">{ins.detail}</p>
              </CardContent>
            </Card>
          ))}
          <p className="text-xs text-gray-400">
            Generated by {data.model} · {new Date(data.generatedAt).toLocaleString()}
          </p>
        </div>
      ) : (
        <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
          <CardContent className="p-6 text-sm text-gray-500">
            No insights yet — once there's enough activity they'll appear here.
          </CardContent>
        </Card>
      )}

      <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CardContent className="p-4 sm:p-6">
          <div className="flex items-center gap-2 mb-3">
            <MessageSquare className="w-4 h-4 text-gray-500" />
            <h3 className="text-sm font-semibold text-gray-900">Ask about your data</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {SUGGESTED_QUESTIONS.map((q) => (
              <Link
                key={q}
                href={`/ask?q=${encodeURIComponent(q)}`}
                className="text-xs px-3 py-1.5 rounded-full border border-gray-200 text-gray-700 hover:bg-gray-50 transition-colors"
              >
                {q}
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function AttritionSection() {
  const { data, isLoading, isError } = useQuery<AttritionResponse>({
    queryKey: ["attrition"],
    queryFn: () => apiService.getAttrition(),
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: false,
  });
  const [refreshing, setRefreshing] = useState(false);
  const refresh = async () => {
    setRefreshing(true);
    try {
      await queryClient.fetchQuery({
        queryKey: ["attrition"],
        queryFn: () => apiService.getAttrition(true),
        staleTime: 0,
      });
    } finally {
      setRefreshing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-3">
        <div className="h-24 bg-gray-100 rounded animate-pulse" />
        <div className="h-64 bg-gray-100 rounded animate-pulse" />
      </div>
    );
  }
  if (isError || !data) {
    return (
      <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CardContent className="p-6 text-sm text-gray-500">
          Couldn't load attrition data. Make sure you're signed in under Settings.
        </CardContent>
      </Card>
    );
  }

  const s = data.summary;
  const cards = [
    { label: "Currently unsubscribed", value: s.currentlyUnsubscribed.toLocaleString() },
    { label: "Unsubscribe rate", value: `${s.unsubscribeRatePct}%`, hint: "of messaged contacts" },
    { label: "STOP events (all-time)", value: s.stopEvents.toLocaleString(), hint: "incl. resubscribed" },
    { label: "Avg texts before opt-out", value: s.avgTextsBeforeUnsub.toLocaleString() },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <FreshnessControls
          cachedAt={data.cachedAt}
          stale={data.stale}
          onRefresh={refresh}
          isRefreshing={refreshing}
        />
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {cards.map((c) => (
          <Card key={c.label} className="bg-white rounded-xl shadow-sm border border-gray-200">
            <CardContent className="p-4">
              <p className="text-xs text-gray-600 leading-tight">{c.label}</p>
              <p className="text-xl sm:text-2xl font-bold text-gray-900 mt-1">{c.value}</p>
              {c.hint && <p className="text-[10px] text-gray-400 mt-0.5">{c.hint}</p>}
            </CardContent>
          </Card>
        ))}
      </div>

      {data.timeline.length > 0 && (
        <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
          <CardContent className="p-4 sm:p-6">
            <h3 className="text-sm font-semibold text-gray-900 mb-1">STOP events over time</h3>
            <p className="text-xs text-gray-500 mb-4">Opt-out messages by month, from the message feed.</p>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.timeline} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="#9ca3af" />
                  <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" allowDecimals={false} />
                  <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 12 }} />
                  <Bar dataKey="count" name="Opt-outs" fill="#f87171" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
        <CardContent className="p-4 sm:p-6">
          <h3 className="text-sm font-semibold text-gray-900 mb-4">
            Unsubscribed contacts ({data.contacts.length})
          </h3>
          {data.contacts.length === 0 ? (
            <p className="text-sm text-gray-500">No unsubscribed contacts. 🎉</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs text-gray-500 border-b border-gray-200">
                    <th className="py-2 pr-3 font-medium">Contact</th>
                    <th className="py-2 pr-3 font-medium">Tags</th>
                    <th className="py-2 pr-3 font-medium">Unsubscribed</th>
                    <th className="py-2 pr-3 font-medium text-right">Texts before</th>
                    <th className="py-2 pr-3 font-medium">Module</th>
                    <th className="py-2 pr-3 font-medium">Journey</th>
                  </tr>
                </thead>
                <tbody>
                  {data.contacts.map((c) => (
                    <tr key={c.contactId} className="border-b border-gray-100">
                      <td className="py-2 pr-3 text-gray-900">{c.name}</td>
                      <td className="py-2 pr-3">
                        <div className="flex flex-wrap gap-1">
                          {c.tags.length === 0 ? (
                            <span className="text-gray-400">—</span>
                          ) : (
                            c.tags.map((t) => (
                              <span key={t} className="px-1.5 py-0.5 rounded bg-gray-100 text-gray-600 text-[10px]">
                                {t}
                              </span>
                            ))
                          )}
                        </div>
                      </td>
                      <td className="py-2 pr-3 text-gray-600 whitespace-nowrap">
                        {c.unsubscribedAt ? new Date(c.unsubscribedAt).toLocaleDateString() : "—"}
                      </td>
                      <td className="py-2 pr-3 text-right text-gray-900 font-medium">{c.textsBeforeUnsub}</td>
                      <td className="py-2 pr-3 text-gray-600">{c.moduleName || "—"}</td>
                      <td className="py-2 pr-3 text-gray-600">{c.journeyName || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function SubscriberPagesCard() {
  const { data } = useQuery<{ totalViews: number; uniqueContacts: number }>({
    queryKey: ["page-stats"],
    queryFn: () => fetch("/api/local/page-stats").then((r) => r.json()),
  });
  const cards = [
    { label: "Profile page views", value: (data?.totalViews ?? 0).toLocaleString() },
    { label: "Subscribers reached", value: (data?.uniqueContacts ?? 0).toLocaleString() },
  ];
  return (
    <Card className="bg-white rounded-xl shadow-sm border border-gray-200 mb-6">
      <CardContent className="p-4 sm:p-6">
        <h3 className="text-sm font-semibold text-gray-900 mb-1">Subscriber pages</h3>
        <p className="text-xs text-gray-500 mb-4">
          Visits to the tokenized <code className="text-xs bg-gray-100 px-1 py-0.5 rounded">/p/</code> profile links you share.
        </p>
        <div className="grid grid-cols-2 gap-3">
          {cards.map((c) => (
            <div key={c.label}>
              <p className="text-xs text-gray-600 leading-tight">{c.label}</p>
              <p className="text-xl sm:text-2xl font-bold text-gray-900 mt-1">{c.value}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function RevenueSection() {
  const { data: revenue, isLoading } = useQuery<RevenueResponse>({
    queryKey: ["revenue", "month"],
    queryFn: () => apiService.getRevenue("month"),
  });
  const { data: attribution } = useQuery<AttributionSummary>({
    queryKey: ["attribution"],
    queryFn: () => apiService.getAttribution(),
  });
  const [refreshing, setRefreshing] = useState(false);
  const refresh = async () => {
    setRefreshing(true);
    try {
      await Promise.all([
        queryClient.fetchQuery({
          queryKey: ["revenue", "month"],
          queryFn: () => apiService.getRevenue("month", true),
          staleTime: 0,
        }),
        queryClient.fetchQuery({
          queryKey: ["attribution"],
          queryFn: () => apiService.getAttribution(undefined, true),
          staleTime: 0,
        }),
      ]);
    } finally {
      setRefreshing(false);
    }
  };

  const money = (n: number, currency: string) =>
    new Intl.NumberFormat(undefined, {
      style: "currency",
      currency: currency.toUpperCase(),
      maximumFractionDigits: 0,
    }).format(n);

  if (isLoading) {
    return <div className="h-40 bg-gray-100 rounded animate-pulse" />;
  }

  if (!revenue?.connected) {
    return (
      <div className="space-y-6">
        <div className="flex items-center">
          <FreshnessControls
            cachedAt={revenue?.cachedAt}
            stale={revenue?.stale}
            onRefresh={refresh}
            isRefreshing={refreshing}
          />
        </div>
        <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
          <CardContent className="p-6 text-center space-y-2">
            <h3 className="text-sm font-semibold text-gray-900">Revenue not connected</h3>
            <p className="text-sm text-gray-500 max-w-md mx-auto">
              Connect Stripe (add the Stripe integration or set
              {" "}<code className="text-xs bg-gray-100 px-1 py-0.5 rounded">STRIPE_SECRET_KEY</code>)
              to see MRR, new revenue, and churn here. Attribution capture is
              already running in the background.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const cards = [
    { label: "MRR", value: money(revenue.mrr, revenue.currency) },
    { label: "Active subscriptions", value: revenue.activeSubscriptions.toLocaleString() },
    { label: "New revenue (30d)", value: money(revenue.newRevenue, revenue.currency) },
    { label: "Churned (30d)", value: revenue.churnedSubscriptions.toLocaleString() },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <FreshnessControls
          cachedAt={revenue.cachedAt}
          stale={revenue.stale}
          onRefresh={refresh}
          isRefreshing={refreshing}
        />
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {cards.map((c) => (
          <Card key={c.label} className="bg-white rounded-xl shadow-sm border border-gray-200">
            <CardContent className="p-4">
              <p className="text-xs text-gray-600 leading-tight">{c.label}</p>
              <p className="text-xl sm:text-2xl font-bold text-gray-900 mt-1">{c.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {attribution && attribution.total > 0 && (
        <Card className="bg-white rounded-xl shadow-sm border border-gray-200">
          <CardContent className="p-4 sm:p-6">
            <h3 className="text-sm font-semibold text-gray-900 mb-1">Traffic attribution</h3>
            <p className="text-xs text-gray-500 mb-4">
              {attribution.total.toLocaleString()} tracked visits by UTM source / campaign.
            </p>
            <div className="grid md:grid-cols-2 gap-6">
              <AttributionList title="Top sources" rows={attribution.bySource} />
              <AttributionList title="Top campaigns" rows={attribution.byCampaign} />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function AttributionList({
  title,
  rows,
}: {
  title: string;
  rows: { key: string; count: number }[];
}) {
  return (
    <div>
      <p className="text-xs font-medium text-gray-700 mb-2">{title}</p>
      <div className="space-y-1.5">
        {rows.map((r) => (
          <div key={r.key} className="flex justify-between text-sm">
            <span className="text-gray-600 truncate mr-2">{r.key}</span>
            <span className="font-medium text-gray-900">{r.count.toLocaleString()}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [period, setPeriod] = useState<Period>("month");
  const [range, setRange] = useState<DateRange | undefined>();
  const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";

  const customReady = period === "custom" && range?.from && range?.to;
  const enabled = period !== "custom" || !!customReady;

  const fmtDay = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const customStartDay =
    period === "custom" && range?.from ? fmtDay(range.from) : undefined;
  const customEndDay =
    period === "custom" && range?.to ? fmtDay(range.to) : undefined;

  const { data, isLoading } = useQuery<DashboardStatsResponse>({
    queryKey: ["dashboard-stats", period, customStartDay ?? null, customEndDay ?? null],
    queryFn: () =>
      apiService.getDashboardStats({
        period,
        start: customStartDay,
        end: customEndDay,
      }),
    enabled,
  });
  const [refreshing, setRefreshing] = useState(false);
  const refresh = async () => {
    setRefreshing(true);
    try {
      await queryClient.fetchQuery({
        queryKey: ["dashboard-stats", period, customStartDay ?? null, customEndDay ?? null],
        queryFn: () =>
          apiService.getDashboardStats({
            period,
            start: customStartDay,
            end: customEndDay,
            force: true,
          }),
        staleTime: 0,
      });
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <Tabs defaultValue="overview" className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="engagement">Engagement</TabsTrigger>
          <TabsTrigger value="attrition">Attrition</TabsTrigger>
          <TabsTrigger value="cost">Cost</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>
      </div>

      <TabsContent value="overview" className="space-y-6">
        <div className="flex flex-wrap items-center gap-3">
          <PeriodBar
            period={period}
            setPeriod={setPeriod}
            range={range}
            setRange={setRange}
            tz={tz}
          />
        </div>
        <div className="flex items-center">
          <FreshnessControls
            cachedAt={data?.cachedAt}
            stale={data?.stale}
            onRefresh={refresh}
            isRefreshing={refreshing}
          />
        </div>
        <OverviewSection data={data} isLoading={isLoading} period={period} />
      </TabsContent>

      <TabsContent value="engagement">
        <SubscriberPagesCard />
        <ReplyAnalytics />
      </TabsContent>

      <TabsContent value="attrition">
        <AttritionSection />
      </TabsContent>

      <TabsContent value="cost">
        <TokenUsage />
      </TabsContent>

      <TabsContent value="revenue">
        <RevenueSection />
      </TabsContent>

      <TabsContent value="insights">
        <InsightsSection />
      </TabsContent>
    </Tabs>
  );
}

function PeriodBar({
  period,
  setPeriod,
  range,
  setRange,
  tz,
}: {
  period: Period;
  setPeriod: (p: Period) => void;
  range: DateRange | undefined;
  setRange: (r: DateRange | undefined) => void;
  tz: string;
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="inline-flex rounded-md border bg-white p-0.5">
        {PERIOD_BUTTONS.map((b) => (
          <button
            key={b.key}
            onClick={() => setPeriod(b.key)}
            className={`px-3 py-1.5 text-sm rounded-sm transition-colors ${
              period === b.key
                ? "bg-indigo-600 text-white"
                : "text-gray-700 hover:bg-gray-100"
            }`}
          >
            {b.label}
          </button>
        ))}
      </div>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant={period === "custom" ? "default" : "outline"}
            size="sm"
            className="h-9"
            onClick={() => setPeriod("custom")}
          >
            <CalendarIcon className="w-4 h-4 mr-1.5" />
            {period === "custom" && range?.from && range?.to
              ? `${format(range.from, "MMM d")} – ${format(range.to, "MMM d, yyyy")}`
              : "Custom…"}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="range"
            selected={range}
            onSelect={(r) => {
              setRange(r);
              setPeriod("custom");
            }}
            numberOfMonths={2}
          />
        </PopoverContent>
      </Popover>
      <span
        className="text-xs text-gray-500 ml-auto"
        title="Day boundaries are computed in this timezone (from your browser)."
        data-testid="dashboard-timezone"
      >
        Timezone: <span className="font-medium text-gray-700">{tz}</span>
      </span>
    </div>
  );
}
