import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, RefreshCw, ChevronDown, ChevronUp } from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import { formatDistanceToNow, parseISO, isValid } from "date-fns";

// ─── Types ──────────────────────────────────────────────────────────────────

interface ContactRow {
  id: string;
  name: string;
  tags: string[];
  currentModuleIndex: number;
  nextSendAt: string | null;
  state: string;
}

interface JourneyData {
  id: string;
  name: string;
  modules: { id: string; name: string }[];
  contacts: ContactRow[];
}

interface JourneyProgressPayload {
  journeys: JourneyData[];
  cachedAt: number;
}

type Density = "detailed" | "condensed" | "overview";

// ─── Density presets ─────────────────────────────────────────────────────────

interface DensityStyle {
  cellH: string;
  colMin: string;
  rowPad: string;
  fontSize: string;
  showModuleName: boolean;
}

const DENSITY_STYLE: Record<"detailed" | "condensed", DensityStyle> = {
  detailed: {
    cellH: "h-7",
    colMin: "min-w-20",
    rowPad: "py-1.5",
    fontSize: "text-xs",
    showModuleName: true,
  },
  condensed: {
    cellH: "h-3.5",
    colMin: "min-w-6",
    rowPad: "py-0.5",
    fontSize: "text-[11px]",
    showModuleName: false,
  },
};

// ─── Helpers ─────────────────────────────────────────────────────────────────

function cellBg(moduleIdx: number, contact: ContactRow): string {
  if (moduleIdx < contact.currentModuleIndex) return "bg-emerald-400";
  if (moduleIdx === contact.currentModuleIndex) return "bg-blue-500";
  return "bg-gray-200";
}

function cellLabel(moduleIdx: number, contact: ContactRow): string {
  if (moduleIdx < contact.currentModuleIndex) return "Completed";
  if (moduleIdx === contact.currentModuleIndex) return "Current";
  return "Upcoming";
}

function formatNextSend(nextSendAt: string | null): string {
  if (!nextSendAt) return "–";
  try {
    const n = Number(nextSendAt);
    const d = !isNaN(n) && n > 0
      ? new Date(n < 1e12 ? n * 1000 : n)
      : parseISO(nextSendAt);
    if (!isValid(d)) return "–";
    return formatDistanceToNow(d, { addSuffix: true });
  } catch {
    return "–";
  }
}

function stateColor(state: string): string {
  switch (state.toLowerCase()) {
    case "active": return "bg-green-100 text-green-700";
    case "sending": return "bg-blue-100 text-blue-700";
    case "paused": return "bg-yellow-100 text-yellow-700";
    default: return "bg-gray-100 text-gray-600";
  }
}

// Returns true if the contact is relevant to the search term.
// A contact is relevant when:
//   - Their name matches, OR
//   - One of their tags matches, OR
//   - Any module from their CURRENT position onward (current + upcoming) matches.
// This intentionally includes upcoming modules so "who will receive X?" also works.
function contactMatchesSearch(
  contact: ContactRow,
  modules: { id: string; name: string }[],
  lcSearch: string,
): boolean {
  if (!lcSearch) return true;
  if (contact.name.toLowerCase().includes(lcSearch)) return true;
  if (contact.tags.some((t) => t.toLowerCase().includes(lcSearch))) return true;
  for (let i = contact.currentModuleIndex; i < modules.length; i++) {
    if (modules[i].name.toLowerCase().includes(lcSearch)) return true;
  }
  return false;
}

// ─── Per-contact Gantt (detailed / condensed) ────────────────────────────────

interface GanttProps {
  journey: JourneyData;
  search: string;
  showPaused: boolean;
  density: "detailed" | "condensed";
}

function JourneyGantt({ journey, search, showPaused, density }: GanttProps) {
  const [collapsed, setCollapsed] = useState(false);
  const style = DENSITY_STYLE[density];

  const lcSearch = search.toLowerCase().trim();

  // All contacts to render (respects paused toggle, no further filtering)
  const displayRows = useMemo(() => {
    if (!showPaused) return journey.contacts.filter((c) => c.state !== "paused");
    return journey.contacts;
  }, [journey.contacts, showPaused]);

  // Which contacts match the search — non-matching rows are dimmed, not removed.
  const matchSet = useMemo(() => {
    if (!lcSearch) return null;
    const s = new Set<string>();
    for (const c of displayRows) {
      if (contactMatchesSearch(c, journey.modules, lcSearch)) s.add(c.id);
    }
    return s;
  }, [displayRows, journey.modules, lcSearch]);

  const matchCount = matchSet?.size ?? displayRows.length;

  const activeCount = journey.contacts.filter((c) => c.state !== "paused").length;
  const pausedCount = journey.contacts.filter((c) => c.state === "paused").length;

  return (
    <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
      {/* Journey header */}
      <div
        className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b border-gray-200 cursor-pointer select-none"
        onClick={() => setCollapsed((v) => !v)}
      >
        <div className="flex items-center gap-3 min-w-0">
          <span className="font-semibold text-gray-900 truncate">{journey.name}</span>
          <span className="text-xs text-gray-500">{journey.modules.length} modules</span>
          <span className="text-xs text-gray-500">
            {activeCount} active{pausedCount > 0 ? `, ${pausedCount} paused` : ""}
          </span>
          {lcSearch && (
            <Badge variant="secondary" className="text-xs">
              {matchCount} / {displayRows.length} match
            </Badge>
          )}
        </div>
        <button className="text-gray-400 hover:text-gray-600 shrink-0">
          {collapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
        </button>
      </div>

      {!collapsed && (
        <div className="overflow-x-auto">
          <table className={`min-w-full ${style.fontSize} border-collapse`}>
            <thead>
              <tr>
                {/* Sticky contact name column */}
                <th className="sticky left-0 z-10 bg-gray-50 border-b border-r border-gray-200 px-3 py-2 text-left font-medium text-gray-600 w-40 min-w-40">
                  Contact
                </th>
                <th className="sticky left-40 z-10 bg-gray-50 border-b border-r border-gray-200 px-2 py-2 text-left font-medium text-gray-600 w-20 min-w-20">
                  Status
                </th>
                <th className="sticky left-60 z-10 bg-gray-50 border-b border-r border-gray-200 px-2 py-2 text-left font-medium text-gray-600 w-24 min-w-24">
                  Next send
                </th>
                {journey.modules.map((mod, i) => (
                  <th
                    key={mod.id}
                    className={`border-b border-r border-gray-100 px-1 py-2 text-center font-medium text-gray-500 ${style.colMin} max-w-28`}
                    title={`${mod.name} (module ${i + 1} of ${journey.modules.length})`}
                  >
                    {style.showModuleName && (
                      <div className="truncate max-w-24 mx-auto">{mod.name}</div>
                    )}
                    <div className="text-gray-400 font-normal">#{i + 1}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {displayRows.length === 0 && (
                <tr>
                  <td colSpan={3 + journey.modules.length} className="px-4 py-6 text-center text-gray-400">
                    No contacts.
                  </td>
                </tr>
              )}
              {displayRows.map((contact) => {
                // Non-matching contacts are dimmed (still visible) — matching ones are full opacity.
                const dimmed = matchSet !== null && !matchSet.has(contact.id);
                return (
                  <tr
                    key={contact.id}
                    className={`border-b border-gray-100 hover:bg-blue-50/30 transition-colors ${dimmed ? "opacity-25" : ""}`}
                  >
                    <td
                      className={`sticky left-0 z-10 bg-white border-r border-gray-100 px-3 ${style.rowPad} font-medium text-gray-800 truncate max-w-40 w-40`}
                      title={contact.tags.length ? `${contact.name} — tags: ${contact.tags.join(", ")}` : contact.name}
                    >
                      {contact.name}
                    </td>
                    <td className={`sticky left-40 z-10 bg-white border-r border-gray-100 px-2 ${style.rowPad} w-20`}>
                      <span className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${stateColor(contact.state)}`}>
                        {contact.state}
                      </span>
                    </td>
                    <td className={`sticky left-60 z-10 bg-white border-r border-gray-100 px-2 ${style.rowPad} text-gray-500 w-24`}>
                      {formatNextSend(contact.nextSendAt)}
                    </td>
                    {journey.modules.map((mod, modIdx) => {
                      const label = cellLabel(modIdx, contact);
                      const scheduledSend = modIdx === contact.currentModuleIndex
                        ? formatNextSend(contact.nextSendAt)
                        : "–";
                      // Tooltip: contact name, module name, status label, journey name, scheduled send date
                      const tooltip = [
                        `Contact: ${contact.name}`,
                        `Module: ${mod.name} (#${modIdx + 1})`,
                        `Status: ${label}`,
                        `Journey: ${journey.name}`,
                        `Scheduled: ${scheduledSend}`,
                      ].join("\n");
                      return (
                        <td
                          key={mod.id}
                          className={`border-r border-gray-100 px-1 ${style.rowPad} ${style.colMin}`}
                          title={tooltip}
                        >
                          <div className={`${style.cellH} w-full rounded transition-colors ${cellBg(modIdx, contact)}`} />
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── Tag-grouped overview ─────────────────────────────────────────────────────

interface TagGroup {
  tag: string;
  count: number;
  perModule: number[]; // how many contacts are currently AT each module index
  avgPct: number;      // average progress through the journey (0..1)
}

function buildTagGroups(journey: JourneyData, contacts: ContactRow[]): TagGroup[] {
  const map = new Map<string, ContactRow[]>();
  for (const c of contacts) {
    const tags = c.tags.length ? c.tags : ["Untagged"];
    for (const t of tags) {
      let arr = map.get(t);
      if (!arr) { arr = []; map.set(t, arr); }
      arr.push(c);
    }
  }
  const n = journey.modules.length;
  const groups: TagGroup[] = [];
  for (const [tag, rows] of Array.from(map.entries())) {
    const perModule = new Array(n).fill(0);
    let sumPct = 0;
    for (const c of rows) {
      const idx = Math.min(Math.max(0, c.currentModuleIndex), n - 1);
      perModule[idx]++;
      sumPct += n > 1 ? idx / (n - 1) : 1;
    }
    groups.push({ tag, count: rows.length, perModule, avgPct: rows.length ? sumPct / rows.length : 0 });
  }
  groups.sort((a, b) => b.count - a.count);
  return groups;
}

// Color intensity for the overview heatmap: more contacts at a module → darker.
function heatBg(count: number, max: number): string {
  if (count === 0) return "bg-gray-50";
  const ratio = max > 0 ? count / max : 0;
  if (ratio > 0.75) return "bg-indigo-600";
  if (ratio > 0.5) return "bg-indigo-500";
  if (ratio > 0.25) return "bg-indigo-400";
  return "bg-indigo-200";
}

interface OverviewProps {
  journey: JourneyData;
  search: string;
  showPaused: boolean;
}

function JourneyTagOverview({ journey, search, showPaused }: OverviewProps) {
  const [collapsed, setCollapsed] = useState(false);
  const lcSearch = search.toLowerCase().trim();

  const contacts = useMemo(() => {
    let rows = showPaused ? journey.contacts : journey.contacts.filter((c) => c.state !== "paused");
    if (lcSearch) rows = rows.filter((c) => contactMatchesSearch(c, journey.modules, lcSearch));
    return rows;
  }, [journey.contacts, journey.modules, showPaused, lcSearch]);

  const groups = useMemo(() => buildTagGroups(journey, contacts), [journey, contacts]);
  const maxCell = useMemo(() => {
    let m = 0;
    for (const g of groups) for (const v of g.perModule) if (v > m) m = v;
    return m;
  }, [groups]);

  const n = journey.modules.length;
  // Show a module number every few columns so the condensed track stays readable.
  const labelEvery = n > 30 ? 10 : n > 15 ? 5 : n > 8 ? 2 : 1;

  return (
    <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
      <div
        className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b border-gray-200 cursor-pointer select-none"
        onClick={() => setCollapsed((v) => !v)}
      >
        <div className="flex items-center gap-3 min-w-0">
          <span className="font-semibold text-gray-900 truncate">{journey.name}</span>
          <span className="text-xs text-gray-500">{journey.modules.length} modules</span>
          <span className="text-xs text-gray-500">{contacts.length} contacts · {groups.length} tag groups</span>
        </div>
        <button className="text-gray-400 hover:text-gray-600 shrink-0">
          {collapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
        </button>
      </div>

      {!collapsed && (
        <div className="overflow-x-auto">
          <table className="min-w-full text-[11px] border-collapse">
            <thead>
              <tr>
                <th className="sticky left-0 z-10 bg-gray-50 border-b border-r border-gray-200 px-3 py-2 text-left font-medium text-gray-600 w-40 min-w-40">
                  Tag
                </th>
                <th className="sticky left-40 z-10 bg-gray-50 border-b border-r border-gray-200 px-2 py-2 text-left font-medium text-gray-600 w-28 min-w-28">
                  Avg progress
                </th>
                {journey.modules.map((mod, i) => (
                  <th
                    key={mod.id}
                    className="border-b border-r border-gray-100 px-0.5 py-2 text-center font-normal text-gray-400 min-w-5 max-w-5"
                    title={`${mod.name} (#${i + 1})`}
                  >
                    {i % labelEvery === 0 ? i + 1 : ""}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {groups.length === 0 && (
                <tr>
                  <td colSpan={2 + n} className="px-4 py-6 text-center text-gray-400">
                    No contacts.
                  </td>
                </tr>
              )}
              {groups.map((g) => (
                <tr key={g.tag} className="border-b border-gray-100 hover:bg-indigo-50/30">
                  <td
                    className="sticky left-0 z-10 bg-white border-r border-gray-100 px-3 py-1.5 font-medium text-gray-800 truncate max-w-40 w-40"
                    title={g.tag}
                  >
                    <span className={g.tag === "Untagged" ? "text-gray-400 italic" : ""}>{g.tag}</span>
                    <span className="ml-1.5 text-gray-400">({g.count})</span>
                  </td>
                  <td className="sticky left-40 z-10 bg-white border-r border-gray-100 px-2 py-1.5 w-28">
                    <div className="flex items-center gap-1.5">
                      <div className="flex-1 h-1.5 rounded-full bg-gray-100 overflow-hidden">
                        <div className="h-full bg-emerald-400" style={{ width: `${Math.round(g.avgPct * 100)}%` }} />
                      </div>
                      <span className="text-gray-500 tabular-nums w-8 text-right">{Math.round(g.avgPct * 100)}%</span>
                    </div>
                  </td>
                  {g.perModule.map((cnt, modIdx) => {
                    const mod = journey.modules[modIdx];
                    const tooltip = [
                      `Tag: ${g.tag}`,
                      `Module: ${mod.name} (#${modIdx + 1})`,
                      `${cnt} contact${cnt === 1 ? "" : "s"} currently here`,
                    ].join("\n");
                    return (
                      <td key={mod.id} className="border-r border-gray-100 px-0.5 py-1.5 min-w-5" title={tooltip}>
                        <div className={`h-4 w-full rounded-sm flex items-center justify-center ${heatBg(cnt, maxCell)}`}>
                          {cnt > 0 && (
                            <span className={`text-[9px] font-semibold ${cnt / (maxCell || 1) > 0.5 ? "text-white" : "text-indigo-700"}`}>
                              {cnt}
                            </span>
                          )}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── Legend ──────────────────────────────────────────────────────────────────

function Legend({ overview }: { overview: boolean }) {
  if (overview) {
    return (
      <div className="flex items-center gap-3 text-xs text-gray-500">
        <span className="text-gray-400">Contacts at each module:</span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block w-4 h-3 rounded-sm bg-indigo-200" /> few
        </span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block w-4 h-3 rounded-sm bg-indigo-600" /> many
        </span>
      </div>
    );
  }
  return (
    <div className="flex items-center gap-4 text-xs text-gray-500">
      <span className="flex items-center gap-1.5">
        <span className="inline-block w-4 h-3 rounded bg-emerald-400" /> Completed
      </span>
      <span className="flex items-center gap-1.5">
        <span className="inline-block w-4 h-3 rounded bg-blue-500" /> Current
      </span>
      <span className="flex items-center gap-1.5">
        <span className="inline-block w-4 h-3 rounded bg-gray-200" /> Upcoming
      </span>
    </div>
  );
}

// ─── Density control ──────────────────────────────────────────────────────────

const DENSITY_OPTIONS: { value: Density; label: string }[] = [
  { value: "detailed", label: "Detailed" },
  { value: "condensed", label: "Condensed" },
  { value: "overview", label: "By tag" },
];

function DensityControl({ value, onChange }: { value: Density; onChange: (d: Density) => void }) {
  return (
    <div className="inline-flex rounded-full border border-gray-300 bg-white p-0.5">
      {DENSITY_OPTIONS.map((opt) => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          className={`text-xs px-3 py-1 rounded-full transition-colors ${
            value === opt.value
              ? "bg-indigo-500 text-white"
              : "text-gray-600 hover:bg-gray-100"
          }`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

// ─── Main page ───────────────────────────────────────────────────────────────

export default function JourneyProgress() {
  const [search, setSearch] = useState("");
  const [showPaused, setShowPaused] = useState(false);
  const [density, setDensity] = useState<Density>("detailed");

  const { data, isLoading, isError, dataUpdatedAt, refetch, isFetching } = useQuery<JourneyProgressPayload>({
    queryKey: ["/api/local/journey-progress"],
    queryFn: async () => {
      const sessionId = localStorage.getItem("mindfultext_session_id") || "";
      const res = await fetch("/api/local/journey-progress", {
        headers: { "X-Session-ID": sessionId },
      });
      if (!res.ok) throw new Error((await res.json()).error || `HTTP ${res.status}`);
      return res.json();
    },
    refetchInterval: 5 * 60 * 1000,
    staleTime: 2 * 60 * 1000,
  });

  const journeys = data?.journeys ?? [];

  // Filter journeys that contain at least one contact relevant to the search.
  // We keep all journey cards visible even if some contacts are dimmed, but
  // journeys with zero relevant contacts across all rows are hidden entirely.
  const lcSearch = search.toLowerCase().trim();
  const filteredJourneys = useMemo(() => {
    if (!lcSearch) return journeys;
    return journeys.filter((j) => {
      const journeyNameMatch = j.name.toLowerCase().includes(lcSearch);
      const anyModuleMatch = j.modules.some((m) => m.name.toLowerCase().includes(lcSearch));
      const anyContactMatch = j.contacts.some((c) =>
        contactMatchesSearch(c, j.modules, lcSearch),
      );
      return journeyNameMatch || anyModuleMatch || anyContactMatch;
    });
  }, [journeys, lcSearch]);

  const totalContacts = useMemo(
    () => journeys.reduce((sum, j) => sum + j.contacts.length, 0),
    [journeys],
  );

  const lastUpdated = dataUpdatedAt
    ? formatDistanceToNow(new Date(dataUpdatedAt), { addSuffix: true })
    : null;

  const isOverview = density === "overview";

  return (
    <div className="p-6 space-y-5 max-w-full">
      {/* Page header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Journey Progress</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            {journeys.length} active {journeys.length === 1 ? "journey" : "journeys"} · {totalContacts} contacts
            {lastUpdated && <span className="ml-2 text-gray-400">· Updated {lastUpdated}</span>}
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            queryClient.invalidateQueries({ queryKey: ["/api/local/journey-progress"] });
            refetch();
          }}
          disabled={isFetching}
          className="flex items-center gap-1.5"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isFetching ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      {/* Search + controls */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-56 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder='Find contacts by name, tag, or module'
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 text-sm"
          />
        </div>
        <DensityControl value={density} onChange={setDensity} />
        <button
          onClick={() => setShowPaused((v) => !v)}
          className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
            showPaused
              ? "bg-yellow-100 text-yellow-700 border-yellow-300"
              : "bg-white text-gray-600 border-gray-300 hover:bg-gray-50"
          }`}
        >
          {showPaused ? "Hiding paused" : "Show paused"}
        </button>
        <Legend overview={isOverview} />
      </div>

      {/* Loading */}
      {isLoading && (
        <div className="flex items-center gap-3 py-12 justify-center text-gray-400">
          <div className="w-5 h-5 border-2 border-gray-300 border-t-indigo-500 rounded-full animate-spin" />
          <span className="text-sm">Loading journey data…</span>
        </div>
      )}

      {/* Error */}
      {isError && !isLoading && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          Failed to load journey progress data. Make sure you're signed in to MindfulText in Settings.
        </div>
      )}

      {/* Empty state */}
      {!isLoading && !isError && journeys.length === 0 && (
        <div className="text-center py-16 text-gray-400">
          <p className="text-lg font-medium mb-1">No active journeys found</p>
          <p className="text-sm">Active and sending subscriptions will appear here.</p>
        </div>
      )}

      {/* Search empty state */}
      {!isLoading && !isError && journeys.length > 0 && filteredJourneys.length === 0 && (
        <div className="text-center py-10 text-gray-400">
          <p className="text-sm">
            No journeys or contacts match <strong className="text-gray-600">"{search}"</strong>
          </p>
          <button onClick={() => setSearch("")} className="mt-2 text-xs text-indigo-500 hover:underline">
            Clear search
          </button>
        </div>
      )}

      {/* Charts */}
      <div className="space-y-5">
        {filteredJourneys.map((journey) =>
          isOverview ? (
            <JourneyTagOverview
              key={journey.id}
              journey={journey}
              search={search}
              showPaused={showPaused}
            />
          ) : (
            <JourneyGantt
              key={journey.id}
              journey={journey}
              search={search}
              showPaused={showPaused}
              density={density}
            />
          ),
        )}
      </div>
    </div>
  );
}
