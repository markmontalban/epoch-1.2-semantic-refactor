import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { resolveLocalOrgId } from "@/lib/localApi";
import {
  ArrowLeft,
  Loader2,
  Users,
  MessageSquare,
  Eye,
  Route as RouteIcon,
  Sparkles,
  Link2,
  Copy,
} from "lucide-react";

interface GroupDetailStats {
  contactCount: number;
  sends: number;
  replies: number;
  replyRate: number;
  pageViews: number;
  activeJourneys: number;
  pausedJourneys: number;
  completedJourneys: number;
}

interface GroupMember {
  id: string;
  name: string;
  tags: string[];
  sends: number;
  replies: number;
  pageViews: number;
  journeyStatus: "none" | "active" | "paused" | "completed";
}

interface GroupDetail {
  kind: "tag" | "segment";
  tag?: string;
  segment?: {
    id: number;
    name: string;
    includeTags: string[];
    excludeTags: string[];
    matchMode: string;
  };
  brief?: string;
  briefUpdatedAt: string | null;
  stats: GroupDetailStats;
  members: GroupMember[];
}

interface JourneyTemplate {
  id: number;
  tag: string | null;
  moduleIds: string[];
}

interface SubscriberLinkRow {
  contactId: string;
  name: string;
  url: string;
}

function journeyBadge(status: GroupMember["journeyStatus"]) {
  switch (status) {
    case "active":
      return "bg-green-100 text-green-700";
    case "paused":
      return "bg-amber-100 text-amber-700";
    case "completed":
      return "bg-gray-100 text-gray-600";
    default:
      return "bg-gray-50 text-gray-400";
  }
}

function StatCard({
  label,
  value,
  sub,
  icon: Icon,
}: {
  label: string;
  value: string | number;
  sub?: string;
  icon: React.ComponentType<{ className?: string }>;
}) {
  return (
    <Card className="border border-gray-100 shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-lg bg-indigo-50 flex items-center justify-center shrink-0">
            <Icon className="w-4 h-4 text-indigo-600" />
          </div>
          <div>
            <p className="text-xs text-gray-500">{label}</p>
            <p className="text-xl font-semibold text-gray-900">{value}</p>
            {sub && <p className="text-xs text-gray-400 mt-0.5">{sub}</p>}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function TagGroupDetail({ tag }: { tag: string }) {
  const orgId = resolveLocalOrgId();
  const detailUrl = `/api/local/audiences/${orgId}/${encodeURIComponent(tag)}/detail`;
  const enrollUrl = `/api/local/audiences/${orgId}/${encodeURIComponent(tag)}/enroll`;
  const linksUrl = `/api/local/audiences/${orgId}/${encodeURIComponent(tag)}/subscriber-links`;
  const title = tag;
  const backHref = "/audiences";
  const draftsHref = `/drafts?audienceTag=${encodeURIComponent(tag)}&create=1`;

  return (
    <GroupDetailView
      title={title}
      subtitle="Contact tag group"
      backHref={backHref}
      draftsHref={draftsHref}
      detailQueryKey={["/api/local/audiences/detail", orgId, tag]}
      detailUrl={detailUrl}
      enrollUrl={enrollUrl}
      linksUrl={linksUrl}
      orgId={orgId}
    />
  );
}

export function SegmentGroupDetail({ segmentId }: { segmentId: string }) {
  const orgId = resolveLocalOrgId();
  const detailUrl = `/api/local/segments/${orgId}/${segmentId}/detail`;
  const enrollUrl = `/api/local/segments/${orgId}/${segmentId}/enroll`;
  const linksUrl = `/api/local/segments/${orgId}/${segmentId}/subscriber-links`;

  return (
    <GroupDetailView
      title={`Segment #${segmentId}`}
      subtitle="Saved segment"
      backHref="/audiences"
      draftsHref={null}
      detailQueryKey={["/api/local/segments/detail", orgId, segmentId]}
      detailUrl={detailUrl}
      enrollUrl={enrollUrl}
      linksUrl={linksUrl}
      orgId={orgId}
    />
  );
}

function GroupDetailView({
  title: titleFallback,
  subtitle,
  backHref,
  draftsHref,
  detailQueryKey,
  detailUrl,
  enrollUrl,
  linksUrl,
  orgId,
}: {
  title: string;
  subtitle: string;
  backHref: string;
  draftsHref: string | null;
  detailQueryKey: unknown[];
  detailUrl: string;
  enrollUrl: string;
  linksUrl: string;
  orgId: string;
}) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [enrollOpen, setEnrollOpen] = useState(false);
  const [linksOpen, setLinksOpen] = useState(false);
  const [templateId, setTemplateId] = useState("");
  const [generatedLinks, setGeneratedLinks] = useState<SubscriberLinkRow[] | null>(null);

  const sessionHeaders = (): Record<string, string> => {
    const sessionId = localStorage.getItem("mindfultext_session_id") || "";
    return sessionId ? { "X-Session-ID": sessionId } : {};
  };

  const { data, isLoading, isError, error } = useQuery<GroupDetail>({
    queryKey: detailQueryKey,
    queryFn: async () => {
      const res = await fetch(detailUrl, { headers: sessionHeaders() });
      if (!res.ok) throw new Error((await res.json()).error || "Failed to load group");
      return res.json();
    },
  });

  const { data: templates = [] } = useQuery<JourneyTemplate[]>({
    queryKey: ["/api/local/journey-templates", orgId],
    queryFn: () => fetch(`/api/local/journey-templates/${orgId}`).then((r) => r.json()),
    enabled: enrollOpen,
  });

  const enrollMut = useMutation({
    mutationFn: async () => {
      const res = await fetch(enrollUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...sessionHeaders() },
        body: JSON.stringify({ templateId: Number(templateId) }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || `HTTP ${res.status}`);
      return json as { enrolled: number };
    },
    onSuccess: (result) => {
      toast({ title: "Journey enrolled", description: `${result.enrolled} contact(s) updated.` });
      setEnrollOpen(false);
      queryClient.invalidateQueries({ queryKey: detailQueryKey });
    },
    onError: (e: Error) =>
      toast({ title: "Enroll failed", description: e.message, variant: "destructive" }),
  });

  const linksMut = useMutation({
    mutationFn: async () => {
      const res = await fetch(linksUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...sessionHeaders() },
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || `HTTP ${res.status}`);
      return json.links as SubscriberLinkRow[];
    },
    onSuccess: (links) => {
      setGeneratedLinks(links);
      setLinksOpen(true);
      toast({ title: "Links ready", description: `${links.length} subscriber link(s).` });
    },
    onError: (e: Error) =>
      toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const title =
    data?.kind === "segment" && data.segment
      ? data.segment.name
      : data?.tag ?? titleFallback;

  const copyAllLinks = async () => {
    if (!generatedLinks?.length) return;
    const text = generatedLinks.map((l) => `${l.name}: ${l.url}`).join("\n");
    try {
      await navigator.clipboard.writeText(text);
      toast({ title: "Copied all links" });
    } catch {
      toast({ title: "Copy failed", variant: "destructive" });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  if (isError || !data) {
    return (
      <div className="p-6 max-w-3xl mx-auto">
        <Link href={backHref} className="text-sm text-indigo-600 hover:underline inline-flex items-center gap-1 mb-4">
          <ArrowLeft className="w-4 h-4" /> Back
        </Link>
        <p className="text-red-600">{error instanceof Error ? error.message : "Failed to load"}</p>
      </div>
    );
  }

  const { stats, members } = data;

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <div>
        <Link href={backHref} className="text-sm text-indigo-600 hover:underline inline-flex items-center gap-1 mb-3">
          <ArrowLeft className="w-4 h-4" /> Audiences
        </Link>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
            <p className="text-sm text-gray-500 mt-0.5">{subtitle}</p>
            {data.kind === "segment" && data.segment && (
              <p className="text-xs text-gray-400 mt-2 font-mono">
                {data.segment.matchMode}: [{data.segment.includeTags.join(", ")}]
                {data.segment.excludeTags.length > 0 &&
                  ` · exclude [${data.segment.excludeTags.join(", ")}]`}
              </p>
            )}
            {data.brief?.trim() && (
              <p className="text-sm text-gray-600 mt-3 whitespace-pre-wrap border-l-2 border-indigo-200 pl-3">
                {data.brief}
              </p>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {draftsHref && (
              <Button variant="outline" size="sm" onClick={() => setLocation(draftsHref)}>
                <Sparkles className="w-4 h-4 mr-1.5" />
                Generate content
              </Button>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setEnrollOpen(true)}
              disabled={stats.contactCount === 0}
            >
              <RouteIcon className="w-4 h-4 mr-1.5" />
              Enroll in journey
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => linksMut.mutate()}
              disabled={stats.contactCount === 0 || linksMut.isPending}
            >
              {linksMut.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin mr-1.5" />
              ) : (
                <Link2 className="w-4 h-4 mr-1.5" />
              )}
              Subscriber links
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Contacts" value={stats.contactCount} icon={Users} />
        <StatCard
          label="Sends / replies"
          value={`${stats.sends} / ${stats.replies}`}
          sub={stats.sends > 0 ? `${stats.replyRate}% reply rate` : undefined}
          icon={MessageSquare}
        />
        <StatCard label="Page views" value={stats.pageViews} icon={Eye} />
        <StatCard
          label="Journeys"
          value={stats.activeJourneys}
          sub={`${stats.pausedJourneys} paused · ${stats.completedJourneys} done`}
          icon={RouteIcon}
        />
      </div>

      <Card className="border border-gray-100 shadow-sm overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-100 bg-gray-50/80">
          <h2 className="font-semibold text-gray-900">Members</h2>
        </div>
        {members.length === 0 ? (
          <CardContent className="py-10 text-center text-sm text-gray-500">
            No contacts match this group.
          </CardContent>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-gray-500 border-b border-gray-100">
                  <th className="px-4 py-2 font-medium">Name</th>
                  <th className="px-4 py-2 font-medium">Tags</th>
                  <th className="px-4 py-2 font-medium text-right">Sends</th>
                  <th className="px-4 py-2 font-medium text-right">Replies</th>
                  <th className="px-4 py-2 font-medium text-right">Views</th>
                  <th className="px-4 py-2 font-medium">Journey</th>
                  <th className="px-4 py-2 font-medium" />
                </tr>
              </thead>
              <tbody>
                {members.map((m) => (
                  <tr key={m.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                    <td className="px-4 py-2.5 font-medium text-gray-900">{m.name}</td>
                    <td className="px-4 py-2.5 text-xs text-gray-500 max-w-[180px] truncate">
                      {m.tags.join(", ") || "—"}
                    </td>
                    <td className="px-4 py-2.5 text-right tabular-nums">{m.sends}</td>
                    <td className="px-4 py-2.5 text-right tabular-nums">{m.replies}</td>
                    <td className="px-4 py-2.5 text-right tabular-nums">{m.pageViews}</td>
                    <td className="px-4 py-2.5">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${journeyBadge(m.journeyStatus)}`}>
                        {m.journeyStatus}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      <Link href={`/contact/${m.id}`} className="text-indigo-600 hover:underline text-xs">
                        Panel
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Dialog open={enrollOpen} onOpenChange={setEnrollOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Enroll {stats.contactCount} contact(s) in journey</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-gray-500">
            Replaces each contact&apos;s personal journey queue with the selected template.
            This cannot be undone automatically — review carefully.
          </p>
          <Select value={templateId} onValueChange={setTemplateId}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a journey template" />
            </SelectTrigger>
            <SelectContent>
              {templates.map((t) => (
                <SelectItem key={t.id} value={String(t.id)}>
                  {t.tag ? `Tag: ${t.tag}` : "Org default"} ({t.moduleIds.length} modules)
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEnrollOpen(false)}>Cancel</Button>
            <Button
              className="btn-mindful"
              disabled={!templateId || enrollMut.isPending}
              onClick={() => enrollMut.mutate()}
            >
              {enrollMut.isPending && <Loader2 className="w-4 h-4 animate-spin mr-1.5" />}
              Confirm enroll
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={linksOpen} onOpenChange={setLinksOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Subscriber page links</DialogTitle>
          </DialogHeader>
          {generatedLinks && generatedLinks.length > 0 ? (
            <div className="space-y-2 max-h-72 overflow-y-auto">
              {generatedLinks.map((l) => (
                <div key={l.contactId} className="flex gap-2 items-center text-xs">
                  <span className="font-medium text-gray-800 shrink-0 w-24 truncate">{l.name}</span>
                  <input
                    readOnly
                    value={l.url}
                    className="flex-1 border rounded px-2 py-1 font-mono bg-gray-50 min-w-0"
                    onFocus={(e) => e.currentTarget.select()}
                  />
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={async () => {
                      try {
                        await navigator.clipboard.writeText(l.url);
                        toast({ title: "Copied" });
                      } catch {
                        toast({ title: "Copy failed", variant: "destructive" });
                      }
                    }}
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500">No links generated.</p>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setLinksOpen(false)}>Close</Button>
            {generatedLinks && generatedLinks.length > 0 && (
              <Button onClick={copyAllLinks}>Copy all</Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function AudienceDetailPage({ tag }: { tag: string }) {
  return <TagGroupDetail tag={tag} />;
}

export function SegmentDetailPage({ segmentId }: { segmentId: string }) {
  return <SegmentGroupDetail segmentId={segmentId} />;
}
