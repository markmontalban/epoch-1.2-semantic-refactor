import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { resolveLocalOrgId } from "@/lib/localApi";
import {
  FileText, Upload, CheckCircle2, AlertCircle, Clock, Loader2, ExternalLink, Sparkles, BookOpen,
} from "lucide-react";

function resolveOrgId(): string {
  return resolveLocalOrgId();
}

interface ContentDraft {
  id: number;
  organizationId: string;
  title: string;
  moduleType: string;
  status: string;
  mindfulTextModuleId: string | null;
  audienceTag: string | null;
  generatedTexts: unknown;
  contentPlan: unknown;
  metadata: Record<string, unknown> | null;
  createdAt: string;
  updatedAt: string;
}

/** Pull the draft's generated SMS bodies out of the various stored shapes. */
function extractTexts(generatedTexts: unknown): string[] {
  const pickStrings = (arr: unknown[]): string[] =>
    arr
      .map((t) => (typeof t === "string" ? t : typeof (t as { text?: unknown })?.text === "string" ? (t as { text: string }).text : ""))
      .filter((s) => s.trim().length > 0);
  if (Array.isArray(generatedTexts)) return pickStrings(generatedTexts);
  if (typeof generatedTexts === "object" && generatedTexts !== null) {
    const rec = generatedTexts as Record<string, unknown>;
    if (Array.isArray(rec.texts)) return pickStrings(rec.texts);
    if (Array.isArray(rec.messages)) return pickStrings(rec.messages);
  }
  return [];
}

function statusColor(status: string) {
  switch (status) {
    case "pushed":    return "bg-green-100 text-green-700";
    case "draft":     return "bg-blue-100 text-blue-700";
    case "approved":  return "bg-indigo-100 text-indigo-700";
    case "review":    return "bg-yellow-100 text-yellow-700";
    case "generating": return "bg-purple-100 text-purple-700";
    case "planning":  return "bg-gray-100 text-gray-600";
    default:          return "bg-gray-100 text-gray-600";
  }
}

function StatusIcon({ status }: { status: string }) {
  if (status === "pushed")   return <CheckCircle2 className="w-4 h-4 text-green-600" />;
  if (status === "draft" || status === "approved") return <FileText className="w-4 h-4 text-blue-600" />;
  return <Clock className="w-4 h-4 text-gray-400" />;
}

function generatedTextCount(generatedTexts: unknown): number {
  if (!generatedTexts) return 0;
  if (Array.isArray(generatedTexts)) return generatedTexts.length;
  if (typeof generatedTexts === "object" && generatedTexts !== null) {
    const rec = generatedTexts as Record<string, unknown>;
    if (Array.isArray(rec.texts))    return (rec.texts as unknown[]).length;
    if (Array.isArray(rec.messages)) return (rec.messages as unknown[]).length;
  }
  return 0;
}

function DraftCard({ draft, onPush, isPushing, onPublish, isPublishing }: {
  draft: ContentDraft;
  onPush: (id: number) => void;
  isPushing: boolean;
  onPublish: (draft: ContentDraft) => void;
  isPublishing: boolean;
}) {
  const canPush = draft.status !== "pushed" && !!draft.generatedTexts;
  const textCount = generatedTextCount(draft.generatedTexts);
  const canPublish = textCount > 0;

  return (
    <Card className="border border-gray-100 shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-indigo-50 flex items-center justify-center shrink-0 mt-0.5">
              <StatusIcon status={draft.status} />
            </div>
            <div className="min-w-0">
              <p className="font-semibold text-gray-900 truncate">{draft.title}</p>
              <div className="flex flex-wrap items-center gap-2 mt-1">
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${statusColor(draft.status)}`}>
                  {draft.status}
                </span>
                <span className="text-xs text-gray-400 capitalize">{draft.moduleType}</span>
                {textCount > 0 && (
                  <span className="text-xs text-gray-400">{textCount} text{textCount !== 1 ? "s" : ""}</span>
                )}
              </div>
              {draft.mindfulTextModuleId && (
                <p className="text-xs text-green-700 mt-1 flex items-center gap-1">
                  <ExternalLink className="w-3 h-3" />
                  Module ID: {draft.mindfulTextModuleId}
                </p>
              )}
              {!draft.generatedTexts && draft.status !== "pushed" && (
                <p className="text-xs text-amber-600 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  No generated texts yet — run the generate step first
                </p>
              )}
              <p className="text-xs text-gray-400 mt-1">
                {new Date(draft.createdAt).toLocaleDateString("en-US", {
                  month: "short", day: "numeric", year: "numeric",
                })}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <Button
              size="sm"
              variant="secondary"
              disabled={!canPublish || isPublishing}
              onClick={() => onPublish(draft)}
              title={
                canPublish
                  ? "Publish these texts to the subscriber library (local only — no texts sent)"
                  : "Generate texts before publishing"
              }
            >
              {isPublishing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <BookOpen className="w-4 h-4" />
              )}
              <span className="ml-1.5 hidden sm:inline">Publish</span>
            </Button>

            <Button
              size="sm"
              disabled={!canPush || isPushing}
              onClick={() => onPush(draft.id)}
              className={canPush ? "btn-mindful" : ""}
              variant={canPush ? "default" : "secondary"}
              title={
                draft.status === "pushed"
                  ? "Already pushed to MindfulText"
                  : !draft.generatedTexts
                  ? "Generate texts before pushing"
                  : "Push this draft to MindfulText as a module"
              }
            >
              {isPushing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : draft.status === "pushed" ? (
                <CheckCircle2 className="w-4 h-4" />
              ) : (
                <Upload className="w-4 h-4" />
              )}
              <span className="ml-1.5 hidden sm:inline">
                {draft.status === "pushed" ? "Pushed" : "Push"}
              </span>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface AudienceOption {
  tag: string;
  contactCount: number;
  brief: string;
}

interface SegmentOption {
  id: number;
  name: string;
  includeTags: string[];
  excludeTags: string[];
  matchMode: string;
}

function NewDraftDialog({
  orgId,
  initialAudienceTag,
  initialOpen,
}: {
  orgId: string;
  initialAudienceTag?: string;
  initialOpen?: boolean;
}) {
  const { toast } = useToast();
  const [open, setOpen] = useState(initialOpen ?? false);
  const [topic, setTopic] = useState("");
  const [audienceTag, setAudienceTag] = useState<string>(initialAudienceTag ?? "");
  const [selectedSegmentId, setSelectedSegmentId] = useState<string>("");
  const [textCount, setTextCount] = useState<number>(5);
  const [goals, setGoals] = useState("");
  const [additionalContext, setAdditionalContext] = useState("");
  const [phase, setPhase] = useState<"idle" | "planning" | "generating">("idle");

  useEffect(() => {
    if (initialOpen) setOpen(true);
    if (initialAudienceTag) setAudienceTag(initialAudienceTag);
  }, [initialOpen, initialAudienceTag]);

  const { data: audData } = useQuery<{ audiences: AudienceOption[] }>({
    queryKey: ["/api/local/audiences", orgId],
    queryFn: async () => {
      const sessionId = localStorage.getItem("mindfultext_session_id") || "";
      const res = await fetch(`/api/local/audiences/${orgId}`, {
        headers: { "X-Session-ID": sessionId },
      });
      if (!res.ok) return { audiences: [] };
      return res.json();
    },
    enabled: open,
  });

  const { data: segData } = useQuery<{ segments: SegmentOption[] }>({
    queryKey: ["/api/local/segments", orgId],
    queryFn: () => fetch(`/api/local/segments/${orgId}`).then((r) => r.json()),
    enabled: open,
  });

  const audiences = audData?.audiences ?? [];
  const segments = segData?.segments ?? [];
  const selectedSegment = segments.find((s) => String(s.id) === selectedSegmentId);

  async function runPipeline() {
    if (!topic.trim()) {
      toast({ title: "Topic required", variant: "destructive" });
      return;
    }
    if (selectedSegmentId && !audienceTag) {
      toast({
        title: "Pick a tag for SMS push",
        description:
          "Segments are multi-tag — choose a single tag below for module delivery, or clear the segment.",
        variant: "destructive",
      });
      return;
    }
    try {
      setPhase("planning");
      const planRes = await fetch("/api/local/ai/plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          organizationId: orgId,
          topic: topic.trim(),
          textCount,
          goals: goals.trim() || undefined,
          additionalContext: additionalContext.trim() || undefined,
          audienceTag: audienceTag || undefined,
        }),
      });
      const planJson = await planRes.json();
      if (!planRes.ok) throw new Error(planJson.error || `Plan failed (${planRes.status})`);
      const draftId = planJson.draft?.id;
      if (!draftId) throw new Error("Plan returned no draft id");

      setPhase("generating");
      const genRes = await fetch(`/api/local/ai/generate/${draftId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const genJson = await genRes.json();
      if (!genRes.ok) throw new Error(genJson.error || `Generate failed (${genRes.status})`);

      queryClient.invalidateQueries({ queryKey: ["/api/local/drafts", orgId] });
      toast({ title: "Draft ready", description: `Plan + texts generated for "${topic.trim()}"` });
      setOpen(false);
      setTopic(""); setGoals(""); setAdditionalContext(""); setAudienceTag(""); setSelectedSegmentId(""); setTextCount(5);
    } catch (e) {
      toast({
        title: "Pipeline failed",
        description: e instanceof Error ? e.message : String(e),
        variant: "destructive",
      });
    } finally {
      setPhase("idle");
    }
  }

  const busy = phase !== "idle";

  return (
    <Dialog open={open} onOpenChange={(o) => !busy && setOpen(o)}>
      <DialogTrigger asChild>
        <Button size="sm" className="btn-mindful">
          <Sparkles className="w-4 h-4 mr-1.5" />
          New draft
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Plan + generate a new draft</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label htmlFor="topic">Topic *</Label>
            <Input
              id="topic"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. 5-day morning ritual"
              disabled={busy}
            />
          </div>

          <div>
            <Label>Audience tag (for SMS push)</Label>
            <Select
              value={audienceTag || "__none__"}
              onValueChange={(v) => {
                setAudienceTag(v === "__none__" ? "" : v);
                if (v !== "__none__") setSelectedSegmentId("");
              }}
              disabled={busy}
            >
              <SelectTrigger>
                <SelectValue placeholder="No specific audience" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__none__">No specific audience</SelectItem>
                {audiences.map((a) => (
                  <SelectItem key={a.tag} value={a.tag}>
                    {a.tag} — {a.contactCount} contact{a.contactCount !== 1 ? "s" : ""}
                    {a.brief?.trim() ? " · brief" : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-gray-500 mt-1">
              When set, the audience brief is added to the AI prompt and the tag is attached to the pushed module.
            </p>
          </div>

          {segments.length > 0 && (
            <div>
              <Label>Segment (library / context only)</Label>
              <Select
                value={selectedSegmentId || "__none__"}
                onValueChange={(v) => {
                  setSelectedSegmentId(v === "__none__" ? "" : v);
                  if (v !== "__none__") setAudienceTag("");
                }}
                disabled={busy}
              >
                <SelectTrigger>
                  <SelectValue placeholder="No segment" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">No segment</SelectItem>
                  {segments.map((s) => (
                    <SelectItem key={s.id} value={String(s.id)}>
                      {s.name} ({s.matchMode}: {s.includeTags.join(", ")})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedSegment && (
                <p className="text-xs text-amber-700 mt-1">
                  Segments combine multiple tags — use Audiences → segment for bulk journey enroll and subscriber links.
                  For SMS delivery, pick a single tag above.
                </p>
              )}
            </div>
          )}

          <div>
            <Label htmlFor="textCount">Number of texts</Label>
            <Input
              id="textCount"
              type="number"
              min={1}
              max={50}
              value={textCount}
              onChange={(e) => setTextCount(Math.max(1, Math.min(50, Number(e.target.value) || 1)))}
              disabled={busy}
            />
          </div>

          <div>
            <Label htmlFor="goals">Goals (optional)</Label>
            <Textarea
              id="goals"
              value={goals}
              onChange={(e) => setGoals(e.target.value)}
              placeholder="What should the recipient feel or do?"
              disabled={busy}
              className="min-h-[60px]"
            />
          </div>

          <div>
            <Label htmlFor="ctx">Additional context (optional)</Label>
            <Textarea
              id="ctx"
              value={additionalContext}
              onChange={(e) => setAdditionalContext(e.target.value)}
              placeholder="Any specific facts, references, or constraints"
              disabled={busy}
              className="min-h-[60px]"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)} disabled={busy}>Cancel</Button>
          <Button onClick={runPipeline} disabled={busy} className="btn-mindful">
            {busy && <Loader2 className="w-4 h-4 animate-spin mr-1.5" />}
            {phase === "planning" ? "Planning…" : phase === "generating" ? "Generating…" : "Plan + generate"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function ContentDrafts() {
  const { toast } = useToast();
  const orgId = resolveOrgId();
  const [pushingId, setPushingId] = useState<number | null>(null);
  const [publishingId, setPublishingId] = useState<number | null>(null);
  const [draftPreset, setDraftPreset] = useState<{ audienceTag?: string; open: boolean } | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("create") === "1") {
      setDraftPreset({
        audienceTag: params.get("audienceTag") ?? undefined,
        open: true,
      });
      window.history.replaceState({}, "", "/drafts");
    }
  }, []);

  const { data: drafts = [], isLoading } = useQuery<ContentDraft[]>({
    queryKey: ["/api/local/drafts", orgId],
    queryFn: async () => {
      const res = await fetch(`/api/local/drafts/${orgId}`);
      if (!res.ok) throw new Error("Failed to load drafts");
      return res.json();
    },
  });

  const pushMutation = useMutation({
    mutationFn: async (id: number) => {
      const sessionId = localStorage.getItem("mindfultext_session_id") || "";
      const res = await fetch(`/api/local/drafts/${id}/push`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Session-ID": sessionId,
        },
      });
      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || `HTTP ${res.status}`);
      }
      return json;
    },
    onMutate: (id) => setPushingId(id),
    onSettled: () => setPushingId(null),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/drafts", orgId] });
      queryClient.invalidateQueries({ queryKey: ["modules"] });
      toast({
        title: "Draft pushed!",
        description: data.moduleId
          ? `Module created in MindfulText (ID: ${data.moduleId})`
          : "Module created in MindfulText.",
      });
    },
    onError: (err: Error) => {
      toast({
        title: "Push failed",
        description: err.message,
        variant: "destructive",
      });
    },
  });

  const publishMutation = useMutation({
    mutationFn: async (draft: ContentDraft) => {
      const texts = extractTexts(draft.generatedTexts);
      if (texts.length === 0) throw new Error("No generated texts to publish");
      const res = await fetch("/api/local/library", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: draft.title,
          body: texts.join("\n\n"),
          topic: draft.audienceTag || null,
          sourceType: "draft",
          sourceId: draft.id,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || `HTTP ${res.status}`);
      return json;
    },
    onMutate: (draft) => setPublishingId(draft.id),
    onSettled: () => setPublishingId(null),
    onSuccess: () => {
      toast({
        title: "Published to library",
        description: "Subscribers will see this on their profile pages. Nothing was sent.",
      });
    },
    onError: (err: Error) =>
      toast({ title: "Publish failed", description: err.message, variant: "destructive" }),
  });

  const pushed  = drafts.filter((d) => d.status === "pushed");
  const pending = drafts.filter((d) => d.status !== "pushed");

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2 flex-wrap">
        {!isLoading && (
          <span className="text-sm text-gray-400">{drafts.length} draft{drafts.length !== 1 ? "s" : ""}</span>
        )}
        <div className="ml-auto">
          <NewDraftDialog
            orgId={orgId}
            initialAudienceTag={draftPreset?.audienceTag}
            initialOpen={draftPreset?.open}
          />
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="border border-gray-100 shadow-sm animate-pulse">
              <CardContent className="p-4">
                <div className="flex gap-3">
                  <div className="w-9 h-9 bg-gray-200 rounded-lg shrink-0" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-48" />
                    <div className="h-3 bg-gray-100 rounded w-24" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : drafts.length === 0 ? (
        <Card className="border border-dashed border-gray-200">
          <CardContent className="py-16 text-center">
            <FileText className="w-10 h-10 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">No drafts yet</p>
            <p className="text-sm text-gray-400 mt-1">
              Use the AI pipeline to plan and generate content — drafts will appear here ready to push.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-5">
          {pending.length > 0 && (
            <section className="space-y-3">
              <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide">
                Ready to push ({pending.length})
              </h3>
              {pending.map((d) => (
                <DraftCard
                  key={d.id}
                  draft={d}
                  onPush={(id) => pushMutation.mutate(id)}
                  isPushing={pushingId === d.id}
                  onPublish={(draft) => publishMutation.mutate(draft)}
                  isPublishing={publishingId === d.id}
                />
              ))}
            </section>
          )}

          {pushed.length > 0 && (
            <section className="space-y-3">
              <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide">
                Already pushed ({pushed.length})
              </h3>
              {pushed.map((d) => (
                <DraftCard
                  key={d.id}
                  draft={d}
                  onPush={(id) => pushMutation.mutate(id)}
                  isPushing={pushingId === d.id}
                  onPublish={(draft) => publishMutation.mutate(draft)}
                  isPublishing={publishingId === d.id}
                />
              ))}
            </section>
          )}
        </div>
      )}
    </div>
  );
}
