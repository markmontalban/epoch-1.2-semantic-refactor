import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MessageSquare, Send, ChevronDown, Bot, User, Loader2, Trash2, Square, ChevronRight } from "lucide-react";

const DEFAULT_ORG_ID = "00000022";
const MAX_HISTORY = 100;
const WIDTH_KEY = "ask_column_width";
const MIN_WIDTH = 480;
const MAX_WIDTH = 900;
const DEFAULT_WIDTH = 768;

function getHistoryKey() {
  const orgId = localStorage.getItem("mindfultext_org_id") || DEFAULT_ORG_ID;
  return `ask_history_${orgId}`;
}

function loadHistory(): Message[] {
  try {
    const raw = localStorage.getItem(getHistoryKey());
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) return parsed.slice(-MAX_HISTORY);
  } catch {
    // ignore parse errors
  }
  return [];
}

function saveHistory(messages: Message[]) {
  // Only persist role + content (not transient streaming state)
  const toSave = messages
    .filter((m) => m.role === "user" || m.content)
    .map(({ role, content }) => ({ role, content }));
  try {
    localStorage.setItem(getHistoryKey(), JSON.stringify(toSave.slice(-MAX_HISTORY)));
  } catch {
    // ignore storage errors (e.g. private browsing quota)
  }
}

function loadWidth(): number {
  try {
    const raw = localStorage.getItem(WIDTH_KEY);
    if (raw) {
      const n = parseInt(raw, 10);
      if (!isNaN(n)) return Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, n));
    }
  } catch {
    // ignore
  }
  return DEFAULT_WIDTH;
}

const MODEL_STORAGE_KEY = "ask_selected_model";
const DEFAULT_MODEL_ID = "openai/gpt-oss-20b:free";

interface Model {
  id: string;
  label: string;
  description?: string;
  /** Whether this model surfaces chain-of-thought reasoning tokens */
  reasoning?: boolean;
}

const MODEL_GROUPS: Array<{ label: string; models: Model[] }> = [
  {
    label: "Free",
    models: [
      { id: "openai/gpt-oss-20b:free", label: "Free", description: "GPT OSS 20B · no cost · fast" },
    ],
  },
  {
    label: "Auto",
    models: [
      { id: "openrouter/auto", label: "Auto", description: "Best model per request" },
    ],
  },
  {
    label: "Models",
    models: [
      { id: "moonshotai/kimi-k2.6", label: "Kimi K2.6", description: "Moonshot AI · capable", reasoning: true },
      { id: "openai/gpt-oss-120b", label: "GPT OSS 120B", description: "OpenAI · large open model" },
      { id: "anthropic/claude-sonnet-4.6", label: "Claude Sonnet 4.6", description: "Anthropic · balanced" },
    ],
  },
];

function loadSavedModel(): string {
  try {
    const saved = localStorage.getItem(MODEL_STORAGE_KEY);
    if (saved && MODEL_GROUPS.some((g) => g.models.some((m) => m.id === saved))) {
      return saved;
    }
  } catch {
    // ignore storage errors
  }
  return DEFAULT_MODEL_ID;
}

function findModel(id: string): Model {
  for (const group of MODEL_GROUPS) {
    const m = group.models.find((m) => m.id === id);
    if (m) return m;
  }
  return { id, label: id };
}

interface Message {
  role: "user" | "assistant";
  content: string;
  streaming?: boolean;
  /** Accumulated reasoning / chain-of-thought content */
  thinking?: string;
  /** Whether the thinking block is expanded */
  thinkingOpen?: boolean;
  /** Loading status line shown before first content token */
  statusText?: string;
  /** True when the error came from the upstream model API — show retry button */
  modelError?: boolean;
}

/** Collapsible "Thinking…" block that auto-expands while streaming */
function ThinkingBlock({ thinking, streaming, open, onToggle }: {
  thinking: string;
  streaming?: boolean;
  open?: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="mb-2 rounded-lg border border-violet-100 bg-violet-50 text-xs overflow-hidden">
      <button
        onClick={onToggle}
        className="w-full flex items-center gap-1.5 px-3 py-1.5 text-left text-violet-600 font-medium hover:bg-violet-100 transition-colors"
      >
        <ChevronRight
          className={`w-3 h-3 shrink-0 transition-transform ${open ? "rotate-90" : ""}`}
        />
        <span>Thinking{streaming ? "…" : " (done)"}</span>
        {streaming && (
          <span className="ml-1 inline-block w-1 h-3 bg-violet-400 animate-pulse rounded-full" />
        )}
      </button>
      {open && (
        <div className="px-3 pb-2 pt-0.5 max-h-48 overflow-y-auto">
          <pre className="whitespace-pre-wrap text-violet-700 leading-relaxed font-mono text-[11px]">
            {thinking}
          </pre>
        </div>
      )}
    </div>
  );
}

export default function Ask() {
  const [selectedModelId, setSelectedModelId] = useState(() => loadSavedModel());
  const [messages, setMessages] = useState<Message[]>(() => loadHistory());
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [colWidth, setColWidth] = useState<number>(() => loadWidth());
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const dragState = useRef<{ startX: number; startWidth: number } | null>(null);

  // Prefill from a ?q= param (e.g. a suggested question from the dashboard
  // Insights tab). Read once on mount; the user reviews before sending.
  useEffect(() => {
    try {
      const q = new URLSearchParams(window.location.search).get("q");
      if (q) {
        setInput(q);
        textareaRef.current?.focus();
      }
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  useEffect(() => {
    saveHistory(messages);
  }, [messages]);

  useEffect(() => {
    try {
      localStorage.setItem(MODEL_STORAGE_KEY, selectedModelId);
    } catch {
      // ignore storage errors
    }
  }, [selectedModelId]);

  const onMouseMove = useCallback((e: MouseEvent) => {
    if (!dragState.current) return;
    const delta = (e.clientX - dragState.current.startX) * 2;
    const next = Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, dragState.current.startWidth + delta));
    setColWidth(next);
  }, []);

  const onMouseUp = useCallback(() => {
    if (!dragState.current) return;
    dragState.current = null;
    document.removeEventListener("mousemove", onMouseMove);
    document.removeEventListener("mouseup", onMouseUp);
    document.body.style.cursor = "";
    document.body.style.userSelect = "";
    setColWidth((w) => {
      try { localStorage.setItem(WIDTH_KEY, String(w)); } catch { /* ignore */ }
      return w;
    });
  }, [onMouseMove]);

  useEffect(() => {
    return () => {
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [onMouseMove, onMouseUp]);

  function startDrag(e: React.MouseEvent) {
    e.preventDefault();
    dragState.current = { startX: e.clientX, startWidth: colWidth };
    document.addEventListener("mousemove", onMouseMove);
    document.addEventListener("mouseup", onMouseUp);
    document.body.style.cursor = "ew-resize";
    document.body.style.userSelect = "none";
  }

  function clearHistory() {
    setMessages([]);
    localStorage.removeItem(getHistoryKey());
  }

  const selectedModel = findModel(selectedModelId);

  function stop() {
    abortRef.current?.abort();
  }

  function toggleThinking(idx: number) {
    setMessages((prev) => {
      const next = [...prev];
      next[idx] = { ...next[idx], thinkingOpen: !next[idx].thinkingOpen };
      return next;
    });
  }

  async function send(prefillQuestion?: string, baseMessages?: Message[], modelOverride?: string) {
    const question = (prefillQuestion ?? input).trim();
    if (!question || loading) return;

    const modelId = modelOverride ?? selectedModelId;
    const userMessages: Message[] = [...(baseMessages ?? messages), { role: "user", content: question }];
    setMessages(userMessages);
    if (!prefillQuestion) setInput("");
    setLoading(true);
    setError(null);

    const controller = new AbortController();
    abortRef.current = controller;

    const assistantIndex = userMessages.length;
    // Seed the assistant slot so status updates have somewhere to land
    setMessages([...userMessages, {
      role: "assistant",
      content: "",
      streaming: true,
      statusText: "Connecting…",
    }]);

    try {
      const sessionId = localStorage.getItem("mindfultext_session_id") || "";

      const res = await fetch("/api/local/ask", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Session-ID": sessionId,
        },
        body: JSON.stringify({ question, model: modelId }),
        signal: controller.signal,
      });

      if (!res.ok) {
        const err = (await res.json().catch(() => ({ error: "Request failed" }))) as { error?: string };
        throw new Error(err.error || `HTTP ${res.status}`);
      }

      if (!res.body) throw new Error("No response body");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let accumulated = "";
      let accThinking = "";
      let hasContent = false;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith("data:")) continue;
          const dataStr = trimmed.slice(5).trim();
          if (!dataStr) continue;

          try {
            const chunk = JSON.parse(dataStr) as {
              type: "delta" | "done" | "error" | "thinking" | "status";
              content?: string;
              text?: string;
              error?: string;
              modelError?: boolean;
            };

            if (chunk.type === "status") {
              // Update the status line until real content arrives
              setMessages((prev) => {
                const next = [...prev];
                if (next[assistantIndex]) {
                  next[assistantIndex] = { ...next[assistantIndex], statusText: chunk.text };
                }
                return next;
              });

            } else if (chunk.type === "thinking" && chunk.content) {
              accThinking += chunk.content;
              setMessages((prev) => {
                const next = [...prev];
                if (next[assistantIndex]) {
                  next[assistantIndex] = {
                    ...next[assistantIndex],
                    thinking: accThinking,
                    // Auto-expand while streaming
                    thinkingOpen: true,
                  };
                }
                return next;
              });

            } else if (chunk.type === "delta" && chunk.content) {
              accumulated += chunk.content;
              if (!hasContent) {
                hasContent = true;
              }
              setMessages((prev) => {
                const next = [...prev];
                if (next[assistantIndex]) {
                  next[assistantIndex] = {
                    ...next[assistantIndex],
                    content: accumulated,
                    streaming: true,
                    // Clear the loading status line once content starts flowing
                    statusText: undefined,
                    // Leave thinkingOpen unchanged — it stays expanded while streaming
                  };
                }
                return next;
              });

            } else if (chunk.type === "done") {
              setMessages((prev) => {
                const next = [...prev];
                if (next[assistantIndex]) {
                  next[assistantIndex] = {
                    ...next[assistantIndex],
                    content: accumulated,
                    streaming: false,
                    statusText: undefined,
                    // Collapse thinking block once the answer is complete
                    thinkingOpen: false,
                  };
                }
                return next;
              });

            } else if (chunk.type === "error") {
              const isModelError = !!chunk.modelError;
              const msg = chunk.error || "Streaming error";
              setMessages((prev) => {
                const next = [...prev];
                next[assistantIndex] = {
                  role: "assistant",
                  content: `Sorry, I encountered an error: ${msg}`,
                  streaming: false,
                  thinkingOpen: false,
                  modelError: isModelError,
                };
                return next;
              });
              setLoading(false);
              abortRef.current = null;
              setTimeout(() => textareaRef.current?.focus(), 50);
              return;
            }
          } catch (parseErr) {
            if (parseErr instanceof SyntaxError) continue;
            throw parseErr;
          }
        }
      }

      // Finalize — ensure streaming flag is cleared and thinking block collapses
      setMessages((prev) => {
        const next = [...prev];
        if (next[assistantIndex]) {
          next[assistantIndex] = {
            ...next[assistantIndex],
            streaming: false,
            statusText: undefined,
            thinkingOpen: false,
          };
        }
        return next;
      });

    } catch (e: unknown) {
      const isAbort = e instanceof Error && e.name === "AbortError";
      if (isAbort) {
        setMessages((prev) => {
          const next = [...prev];
          if (next[assistantIndex]) {
            next[assistantIndex] = {
              ...next[assistantIndex],
              streaming: false,
              statusText: undefined,
              thinkingOpen: false,
            };
          }
          return next;
        });
      } else {
        const msg = e instanceof Error ? e.message : "Unknown error";
        setError(msg);
        setMessages((prev) => {
          const next = [...prev];
          next[assistantIndex] = {
            role: "assistant",
            content: `Sorry, I encountered an error: ${msg}`,
            streaming: false,
            thinkingOpen: false,
          };
          return next;
        });
      }
    } finally {
      setLoading(false);
      abortRef.current = null;
      setTimeout(() => textareaRef.current?.focus(), 50);
    }
  }

  function retryWithAutoModel() {
    // Find the last user question and the trimmed history before the error
    const lastUserIdx = [...messages].reverse().findIndex((m) => m.role === "user");
    if (lastUserIdx === -1) return;
    const userMsgIdx = messages.length - 1 - lastUserIdx;
    const lastQuestion = messages[userMsgIdx].content;
    // Strip everything from the last user message onward — send() will re-add the user turn
    const trimmedBase = messages.slice(0, userMsgIdx);
    setSelectedModelId("openrouter/auto");
    send(lastQuestion, trimmedBase, "openrouter/auto");
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  const colStyle: React.CSSProperties = {
    width: colWidth,
    maxWidth: "100%",
  };

  return (
    <div className="flex flex-col h-full">
      {/* Message list */}
      <div className="flex-1 overflow-y-auto py-4">
        <div className="mx-auto w-full px-4 space-y-4 relative" style={colStyle}>
          {messages.length > 0 && (
            <div className="flex justify-end">
              <Button
                variant="ghost"
                size="sm"
                onClick={clearHistory}
                className="text-xs text-gray-400 hover:text-red-500 gap-1.5 h-7 px-2"
                title="Clear history"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Clear history
              </Button>
            </div>
          )}
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-center py-16 space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-indigo-50 flex items-center justify-center">
                <MessageSquare className="w-7 h-7 text-indigo-500" />
              </div>
              <p className="text-base font-medium text-gray-800">Ask anything about your data</p>
              <p className="text-sm text-gray-400 max-w-xs">
                Try: "How many contacts do I have?" or "What journeys are active?" or "Summarize my recent drafts."
              </p>
            </div>
          )}

          {messages.map((msg, idx) => (
            <div key={idx} className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
              <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                msg.role === "user" ? "bg-indigo-500" : "bg-gray-100"
              }`}>
                {msg.role === "user"
                  ? <User className="w-4 h-4 text-white" />
                  : <Bot className="w-4 h-4 text-gray-600" />
                }
              </div>
              <div className="max-w-[75%] flex flex-col gap-0">
                {/* Reasoning / thinking block */}
                {msg.thinking && (
                  <ThinkingBlock
                    thinking={msg.thinking}
                    streaming={msg.streaming}
                    open={msg.thinkingOpen}
                    onToggle={() => toggleThinking(idx)}
                  />
                )}

                {/* Status line — shown before first content token */}
                {msg.statusText && !msg.content && (
                  <div className="flex items-center gap-1.5 text-xs text-gray-400 py-1.5 px-1">
                    <Loader2 className="w-3 h-3 animate-spin shrink-0" />
                    <span>{msg.statusText}</span>
                  </div>
                )}

                {/* Message bubble — only shown once there's content */}
                {(msg.content || msg.role === "user") && (
                  <div className={`rounded-2xl px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap ${
                    msg.role === "user"
                      ? "bg-indigo-600 text-white rounded-tr-sm"
                      : "bg-white border border-gray-100 text-gray-800 rounded-tl-sm shadow-sm"
                  }`}>
                    {msg.content}
                    {msg.streaming && msg.content && (
                      <span className="inline-block w-0.5 h-4 ml-0.5 bg-indigo-400 animate-pulse align-text-bottom" />
                    )}
                  </div>
                )}

                {/* Retry button — shown only on model API errors */}
                {msg.role === "assistant" && msg.modelError && !msg.streaming && !loading && (
                  <button
                    onClick={retryWithAutoModel}
                    className="mt-1.5 self-start text-xs text-indigo-500 hover:text-indigo-700 hover:underline flex items-center gap-1"
                  >
                    Try Auto model →
                  </button>
                )}
              </div>
            </div>
          ))}

          {loading && messages[messages.length - 1]?.role !== "assistant" && (
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center shrink-0 mt-0.5">
                <Bot className="w-4 h-4 text-gray-600" />
              </div>
              <div className="bg-white border border-gray-100 rounded-2xl rounded-tl-sm shadow-sm px-4 py-3">
                <Loader2 className="w-4 h-4 text-indigo-500 animate-spin" />
              </div>
            </div>
          )}

          <div ref={bottomRef} />

          {/* Right drag handle */}
          <div
            onMouseDown={startDrag}
            title="Drag to resize"
            className="absolute top-0 bottom-0 right-0 w-3 flex items-center justify-center cursor-ew-resize group"
            style={{ right: "-12px" }}
          >
            <div className="w-0.5 h-8 rounded-full bg-gray-200 group-hover:bg-indigo-400 transition-colors" />
          </div>
        </div>
      </div>

      {/* Input bar */}
      <div className="shrink-0 border-t border-gray-100 bg-white py-3">
        <div className="mx-auto w-full px-4" style={colStyle}>
          {error && (
            <p className="text-xs text-red-500 mb-2">{error}</p>
          )}
          <div className="flex items-end gap-2">
            {/* Model selector */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="shrink-0 h-9 px-3 text-xs font-medium gap-1.5 border-gray-200"
                  disabled={loading}
                >
                  <span>{selectedModel.label}</span>
                  {selectedModel.reasoning && (
                    <span className="text-[10px] bg-violet-100 text-violet-600 rounded px-1 leading-tight">thinking</span>
                  )}
                  <ChevronDown className="w-3 h-3 text-gray-400" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-60">
                {MODEL_GROUPS.map((group, gIdx) => (
                  <div key={group.label}>
                    {gIdx > 0 && <DropdownMenuSeparator />}
                    <DropdownMenuGroup>
                      <DropdownMenuLabel className="text-xs text-gray-400 uppercase tracking-wide px-2 py-1">
                        {group.label}
                      </DropdownMenuLabel>
                      {group.models.map((model) => (
                        <DropdownMenuItem
                          key={model.id + model.label}
                          onClick={() => setSelectedModelId(model.id)}
                          className={`flex flex-col items-start gap-0 cursor-pointer ${
                            selectedModelId === model.id ? "bg-indigo-50 text-indigo-700" : ""
                          }`}
                        >
                          <div className="flex items-center gap-1.5">
                            <span className="font-medium text-sm">{model.label}</span>
                            {model.reasoning && (
                              <span className="text-[10px] bg-violet-100 text-violet-600 rounded px-1 leading-tight font-normal">
                                thinking
                              </span>
                            )}
                          </div>
                          {model.description && (
                            <span className="text-xs text-gray-400">{model.description}</span>
                          )}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuGroup>
                  </div>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Text input */}
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask a question… (Enter to send, Shift+Enter for newline)"
              className="flex-1 min-h-[2.25rem] max-h-32 resize-none text-sm border-gray-200 focus-visible:ring-indigo-500"
              rows={1}
              disabled={loading}
            />

            {/* Stop / Send button */}
            {loading ? (
              <Button
                onClick={stop}
                size="sm"
                variant="outline"
                className="shrink-0 h-9 w-9 p-0 border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600"
                title="Stop generating"
              >
                <Square className="w-4 h-4 fill-current" />
              </Button>
            ) : (
              <Button
                onClick={() => send()}
                disabled={!input.trim()}
                size="sm"
                className="btn-mindful shrink-0 h-9 w-9 p-0"
              >
                <Send className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
