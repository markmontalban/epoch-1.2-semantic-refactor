import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { setLocalOrgId } from "@/lib/localApi";
import AgentPromptsCard from "@/components/AgentPromptsCard";
import { LogIn, Building2, AlertCircle, CheckCircle2 } from "lucide-react";

type SettingsResponse = {
  orgId: string;
  orgName: string | null;
  email: string | null;
  hasPassword: boolean;
  signedIn: boolean;
};

type OrgsResponse = {
  orgs: { id: string; name: string }[];
  orgId: string;
  code?: string;
};

function sessionHeader(): Record<string, string> {
  return { "X-Session-ID": localStorage.getItem("mindfultext_session_id") || "" };
}

export default function Settings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [selectedOrgId, setSelectedOrgId] = useState("");

  const settingsQuery = useQuery<SettingsResponse>({
    queryKey: ["/api/local/settings"],
    queryFn: async () => {
      const r = await fetch("/api/local/settings", { headers: sessionHeader() });
      if (!r.ok) throw new Error(`Failed to load settings (HTTP ${r.status})`);
      return r.json();
    },
  });

  const orgsQuery = useQuery<OrgsResponse, Error>({
    queryKey: ["/api/local/settings/orgs"],
    queryFn: async () => {
      const r = await fetch("/api/local/settings/orgs", { headers: sessionHeader() });
      if (r.status === 401) {
        const body = await r.json().catch(() => ({}));
        const err = new Error(body.error || "Sign in to MindfulText to see your organizations.") as Error & { code?: string };
        err.code = body.code || "not_signed_in";
        throw err;
      }
      if (!r.ok) throw new Error(`Failed to load organizations (HTTP ${r.status})`);
      return r.json();
    },
    retry: false,
    enabled: settingsQuery.data?.signedIn === true,
  });

  useEffect(() => {
    if (settingsQuery.data?.email) setEmail(settingsQuery.data.email);
  }, [settingsQuery.data?.email]);

  useEffect(() => {
    if (settingsQuery.data?.orgId) setSelectedOrgId(settingsQuery.data.orgId);
  }, [settingsQuery.data?.orgId]);

  const loginMutation = useMutation({
    mutationFn: async (creds: { email: string; password: string }) => {
      const r = await fetch("/api/local/settings/login", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...sessionHeader() },
        body: JSON.stringify(creds),
      });
      const body = (await r.json().catch(() => ({}))) as Record<string, unknown>;
      if (!r.ok) {
        const msg = typeof body.error === "string" ? body.error : `Sign-in failed (HTTP ${r.status})`;
        throw new Error(msg);
      }
      return body as { ok?: true; email?: string; orgs?: { id: string; name: string }[]; orgId?: string; sessionId?: string };
    },
    onSuccess: (data) => {
      // Defensive: any of these fields could theoretically be missing if the
      // server response shape ever drifts. Don't let a missing field throw
      // inside onSuccess (TanStack Query v5 surfaces those errors awkwardly
      // and the user sees a confusing "Sign-in failed: cannot read length" toast
      // even though sign-in actually succeeded).
      const orgs = Array.isArray(data?.orgs) ? data.orgs : [];
      const orgId = typeof data?.orgId === "string" ? data.orgId : "";
      const email = typeof data?.email === "string" ? data.email : "";
      const sessionId = typeof data?.sessionId === "string" ? data.sessionId : "";

      if (sessionId) {
        const have = localStorage.getItem("mindfultext_session_id");
        if (!have) localStorage.setItem("mindfultext_session_id", sessionId);
      }
      setPassword("");
      if (orgId) {
        setLocalOrgId(orgId);
        setSelectedOrgId(orgId);
      }
      queryClient.invalidateQueries();
      toast({
        title: "Signed in",
        description: orgs.length > 0
          ? `${email} — ${orgs.length} organization${orgs.length === 1 ? "" : "s"} available.`
          : `${email} — signed in.`,
      });
    },
    onError: (err: Error) => {
      toast({ title: "Sign-in failed", description: err.message, variant: "destructive" });
    },
  });

  const saveOrgMutation = useMutation({
    mutationFn: async (orgId: string) => {
      const r = await fetch("/api/local/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json", ...sessionHeader() },
        body: JSON.stringify({ orgId }),
      });
      const body = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(body.error || `HTTP ${r.status}`);
      return body as { orgId: string };
    },
    onSuccess: (saved) => {
      setLocalOrgId(saved.orgId);
      queryClient.invalidateQueries();
      toast({
        title: "Organization saved",
        description: `Now using ${orgLabel(saved.orgId)} for every request.`,
      });
    },
    onError: (err: Error) => {
      toast({ title: "Save failed", description: err.message, variant: "destructive" });
    },
  });

  function orgLabel(id: string): string {
    const match = orgsQuery.data?.orgs.find((o) => o.id === id);
    if (match) return `${match.name} (${match.id})`;
    if (settingsQuery.data?.orgId === id && settingsQuery.data?.orgName) {
      return `${settingsQuery.data.orgName} (${id})`;
    }
    return id;
  }

  const expired = (orgsQuery.error as (Error & { code?: string }) | null)?.code === "credentials_expired";
  const signedIn = settingsQuery.data?.signedIn === true;
  const orgs = orgsQuery.data?.orgs || [];
  // MindfulText returns 403 from /api/organizations/byUser for some accounts
  // (e.g. service accounts). Login is still valid — we just can't populate
  // a dropdown, so fall back to a manual org-id text input.
  const byUserForbidden = orgsQuery.data?.code === "byuser_forbidden";

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Card className="card-mindful">
        <CardHeader>
          <CardTitle className="flex items-center">
            <LogIn className="w-5 h-5 mr-2" />
            MindfulText sign-in
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {signedIn && !expired ? (
            <div className="flex items-start gap-2 text-sm text-green-700 bg-green-50 border border-green-200 rounded-md p-3">
              <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" />
              <span>
                Signed in as <strong>{settingsQuery.data?.email || "(unknown)"}</strong>.
                {orgs.length > 0 && ` ${orgs.length} organization${orgs.length === 1 ? "" : "s"} available.`}
              </span>
            </div>
          ) : expired ? (
            <div className="flex items-start gap-2 text-sm text-amber-800 bg-amber-50 border border-amber-200 rounded-md p-3">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>Your MindfulText session expired. Sign in again to refresh it.</span>
            </div>
          ) : (
            <div className="flex items-start gap-2 text-sm text-gray-600 bg-gray-50 border border-gray-200 rounded-md p-3">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>Not signed in yet. Enter your MindfulText credentials below.</span>
            </div>
          )}

          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              data-testid="input-email"
              type="email"
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              data-testid="input-password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={settingsQuery.data?.hasPassword ? "•••••••• (saved)" : ""}
              className="mt-1"
            />
            <p className="text-xs text-gray-500 mt-2">
              Stored locally in <code>.org-settings.json</code> (gitignored, single-user mode)
              so this app can auto-login on restart.
            </p>
          </div>
          <div className="flex justify-end">
            <Button
              data-testid="button-sign-in"
              className="btn-mindful"
              disabled={!email.trim() || !password || loginMutation.isPending}
              onClick={() => loginMutation.mutate({ email: email.trim(), password })}
            >
              {loginMutation.isPending ? "Signing in…" : signedIn ? "Update credentials" : "Sign in"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="card-mindful">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Building2 className="w-5 h-5 mr-2" />
            Organization
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!signedIn ? (
            <p className="text-sm text-gray-600">Sign in above to load the list of organizations you can access.</p>
          ) : orgsQuery.isLoading ? (
            <p className="text-sm text-gray-600">Loading organizations…</p>
          ) : expired ? (
            <p className="text-sm text-amber-800">Sign in again to refresh the org list.</p>
          ) : byUserForbidden ? (
            <div className="space-y-3">
              <div className="flex items-start gap-2 text-sm text-amber-800 bg-amber-50 border border-amber-200 rounded-md p-3">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <span>
                  Signed in, but MindfulText didn't share an org list for this
                  account. Enter the 8-digit organization ID manually — every
                  request will use it.
                </span>
              </div>
              {settingsQuery.data?.orgName && selectedOrgId === settingsQuery.data?.orgId && (
                <div className="text-sm text-gray-700">
                  Currently active: <strong>{settingsQuery.data.orgName}</strong>
                  <span className="text-xs text-gray-500 ml-2 font-mono">{settingsQuery.data.orgId}</span>
                </div>
              )}
              <div>
                <Label htmlFor="org-manual">Organization ID</Label>
                <Input
                  id="org-manual"
                  data-testid="input-org-id"
                  value={selectedOrgId}
                  onChange={(e) => setSelectedOrgId(e.target.value.trim())}
                  placeholder="e.g. 00000030"
                  className="mt-1 font-mono"
                />
              </div>
            </div>
          ) : orgs.length === 0 ? (
            <p className="text-sm text-gray-600">No organizations returned by MindfulText for this account.</p>
          ) : (
            <div>
              <Label htmlFor="org-select">Active organization</Label>
              <Select value={selectedOrgId} onValueChange={setSelectedOrgId}>
                <SelectTrigger id="org-select" data-testid="select-org" className="mt-1">
                  <SelectValue placeholder="Select an organization" />
                </SelectTrigger>
                <SelectContent>
                  {orgs.map((o) => (
                    <SelectItem key={o.id} value={o.id} data-testid={`option-org-${o.id}`}>
                      <span>{o.name}</span>
                      <span className="text-xs text-gray-500 ml-2 font-mono">{o.id}</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500 mt-2">
                Changing this takes effect immediately for every tab and request — no restart needed.
              </p>
            </div>
          )}
          <div className="flex justify-end">
            <Button
              data-testid="button-save-org"
              className="btn-mindful"
              disabled={
                !selectedOrgId ||
                saveOrgMutation.isPending ||
                selectedOrgId === settingsQuery.data?.orgId ||
                (orgs.length === 0 && !byUserForbidden)
              }
              onClick={() => saveOrgMutation.mutate(selectedOrgId)}
            >
              {saveOrgMutation.isPending ? "Saving…" : "Save organization"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <AgentPromptsCard />
    </div>
  );
}
