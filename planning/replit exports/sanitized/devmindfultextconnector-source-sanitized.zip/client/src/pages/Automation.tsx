import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, ToggleLeft, ToggleRight, ArrowUp, ArrowDown, Edit3, Beaker } from "lucide-react";
import { resolveLocalOrgId } from "@/lib/localApi";

interface ReshapeRule {
  id: number;
  name: string;
  triggerType: "keyword" | "intent" | "any_reply";
  triggerValue: string | null;
  actionType: "insert" | "skip" | "reorder" | "pause" | "resume" | "ai_decide";
  actionParams: Record<string, unknown> | null;
  approvalMode: "auto" | "review";
  enabled: boolean;
  priority: number;
  continueAfter: boolean;
}

interface JourneyTemplate {
  id: number;
  tag: string | null;
  moduleIds: string[];
}

interface Draft {
  name: string;
  triggerType: string;
  triggerValue: string;
  actionType: string;
  actionParams: string;
  approvalMode: string;
  priority: number;
  continueAfter: boolean;
  enabled: boolean;
}

const emptyDraft = (): Draft => ({
  name: "", triggerType: "keyword", triggerValue: "",
  actionType: "skip", actionParams: "{}", approvalMode: "auto",
  priority: 100, continueAfter: false, enabled: true,
});

function defaultModeFor(actionType: string): "auto" | "review" {
  return actionType === "skip" || actionType === "pause" || actionType === "resume" ? "auto" : "review";
}

export default function Automation() {
  const { toast } = useToast();
  const ORG_ID = resolveLocalOrgId();
  const [editingId, setEditingId] = useState<number | "new" | null>(null);
  const [draft, setDraft] = useState<Draft>(emptyDraft());
  const [testInput, setTestInput] = useState("");
  const [testResult, setTestResult] = useState<any>(null);

  const { data: rules = [], isLoading } = useQuery<ReshapeRule[]>({
    queryKey: ["/api/local/reshape-rules", ORG_ID],
    queryFn: () => fetch(`/api/local/reshape-rules/${ORG_ID}`).then(r => r.json()),
  });

  const saveMut = useMutation({
    mutationFn: async () => {
      let parsedParams: Record<string, unknown> = {};
      try { parsedParams = JSON.parse(draft.actionParams || "{}"); } catch {}
      const body = {
        organizationId: ORG_ID,
        name: draft.name,
        triggerType: draft.triggerType,
        triggerValue: draft.triggerValue,
        actionType: draft.actionType,
        actionParams: parsedParams,
        approvalMode: draft.approvalMode,
        priority: Number(draft.priority),
        continueAfter: draft.continueAfter,
        enabled: draft.enabled,
      };
      if (editingId === "new" || editingId === null) {
        return apiRequest("POST", "/api/local/reshape-rules", body);
      }
      return apiRequest("PATCH", `/api/local/reshape-rules/${editingId}`, body);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/reshape-rules", ORG_ID] });
      setEditingId(null);
      setDraft(emptyDraft());
      toast({ title: "Rule saved" });
    },
    onError: (e: any) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const toggleMut = useMutation({
    mutationFn: (rule: ReshapeRule) =>
      apiRequest("PATCH", `/api/local/reshape-rules/${rule.id}`, { enabled: !rule.enabled }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/local/reshape-rules", ORG_ID] }),
  });

  const priorityMut = useMutation({
    mutationFn: ({ id, priority }: { id: number; priority: number }) =>
      apiRequest("PATCH", `/api/local/reshape-rules/${id}`, { priority }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/local/reshape-rules", ORG_ID] }),
  });

  const deleteMut = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/local/reshape-rules/${id}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/local/reshape-rules", ORG_ID] }),
  });

  // -------------------- Journey templates (starting sequences) --------------------
  const { data: templates = [] } = useQuery<JourneyTemplate[]>({
    queryKey: ["/api/local/journey-templates", ORG_ID],
    queryFn: () => fetch(`/api/local/journey-templates/${ORG_ID}`).then(r => r.json()),
  });

  const [tplTag, setTplTag] = useState("");
  const [tplModules, setTplModules] = useState("");

  const tplCreateMut = useMutation({
    mutationFn: () => apiRequest("POST", "/api/local/journey-templates", {
      organizationId: ORG_ID,
      tag: tplTag.trim() || null,
      moduleIds: tplModules.split("\n").map(s => s.trim()).filter(Boolean),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/journey-templates", ORG_ID] });
      setTplTag(""); setTplModules("");
      toast({ title: "Template saved" });
    },
    onError: (e: any) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const tplDeleteMut = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/local/journey-templates/${id}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/local/journey-templates", ORG_ID] }),
  });

  const testMut = useMutation({
    mutationFn: () =>
      apiRequest("POST", `/api/local/reshape-rules/${ORG_ID}/test`, { content: testInput }),
    onSuccess: async (res: any) => {
      const json = typeof res.json === "function" ? await res.json() : res;
      setTestResult(json);
    },
  });

  function startEdit(r: ReshapeRule) {
    setEditingId(r.id);
    setDraft({
      name: r.name,
      triggerType: r.triggerType,
      triggerValue: r.triggerValue ?? "",
      actionType: r.actionType,
      actionParams: JSON.stringify(r.actionParams ?? {}, null, 2),
      approvalMode: r.approvalMode,
      priority: r.priority,
      continueAfter: r.continueAfter,
      enabled: r.enabled,
    });
  }

  function changePriority(rule: ReshapeRule, delta: number) {
    priorityMut.mutate({ id: rule.id, priority: Math.max(0, rule.priority + delta) });
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => { setEditingId("new"); setDraft(emptyDraft()); }}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
          data-testid="button-new-rule"
        >
          <Plus className="w-4 h-4" /> New rule
        </button>
      </div>

      {/* Test affordance */}
      <div className="bg-white border border-gray-200 rounded-lg p-4 mb-4" data-testid="rule-tester">
        <div className="flex items-center gap-2 mb-2 text-sm font-medium text-gray-700">
          <Beaker className="w-4 h-4 text-indigo-600" /> Test rules against a sample message
        </div>
        <div className="flex gap-2">
          <input className="flex-1 border rounded px-3 py-2 text-sm" placeholder="Type a sample contact reply…"
            value={testInput} onChange={e => setTestInput(e.target.value)} data-testid="input-test-content" />
          <button onClick={() => testMut.mutate()} disabled={!testInput || testMut.isPending}
            className="bg-gray-900 hover:bg-gray-800 text-white px-4 py-2 rounded text-sm" data-testid="button-test-rules">
            {testMut.isPending ? "Testing…" : "Run test"}
          </button>
        </div>
        {testResult && (
          <div className="mt-3 text-xs" data-testid="test-result">
            {testResult.matchedRules?.length ? (
              <ul className="space-y-1">
                {testResult.matchedRules.map((m: any) => (
                  <li key={m.ruleId} className="bg-indigo-50 border border-indigo-200 rounded px-2 py-1">
                    <b>{m.ruleName}</b> would <b>{m.actionType}</b> ({m.approvalMode}) — {m.reason}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500">No rules would match this message.</p>
            )}
          </div>
        )}
      </div>

      {editingId !== null && (
        <div className="bg-white border border-gray-200 rounded-lg p-5 mb-6 space-y-3" data-testid="form-rule">
          <input className="w-full border rounded px-3 py-2" placeholder="Rule name"
            value={draft.name} onChange={e => setDraft({ ...draft, name: e.target.value })} />
          <div className="grid grid-cols-2 gap-3">
            <label className="text-sm">Trigger type
              <select className="w-full border rounded px-2 py-2 mt-1" value={draft.triggerType}
                onChange={e => setDraft({ ...draft, triggerType: e.target.value })}>
                <option value="keyword">Keyword match</option>
                <option value="intent">Intent</option>
                <option value="any_reply">Any reply</option>
              </select>
            </label>
            <label className="text-sm">Trigger value
              <input className="w-full border rounded px-2 py-2 mt-1"
                placeholder={draft.triggerType === "any_reply" ? "(unused)" : "stop, help, …"}
                value={draft.triggerValue}
                onChange={e => setDraft({ ...draft, triggerValue: e.target.value })} />
            </label>
            <label className="text-sm">Action
              <select className="w-full border rounded px-2 py-2 mt-1" value={draft.actionType}
                onChange={e => {
                  const at = e.target.value;
                  setDraft({ ...draft, actionType: at, approvalMode: defaultModeFor(at) });
                }}>
                <option value="skip">Skip next module</option>
                <option value="insert">Insert module</option>
                <option value="reorder">Reorder queue</option>
                <option value="pause">Pause journey</option>
                <option value="resume">Resume journey</option>
                <option value="ai_decide">AI decides</option>
              </select>
            </label>
            <label className="text-sm">Approval
              <select className="w-full border rounded px-2 py-2 mt-1" value={draft.approvalMode}
                onChange={e => setDraft({ ...draft, approvalMode: e.target.value })}>
                <option value="auto">Apply automatically</option>
                <option value="review">Send to review queue</option>
              </select>
            </label>
            <label className="text-sm">Priority (lower = first)
              <input type="number" className="w-full border rounded px-2 py-2 mt-1" value={draft.priority}
                onChange={e => setDraft({ ...draft, priority: Number(e.target.value) })} />
            </label>
            <label className="text-sm">Continue after match
              <select className="w-full border rounded px-2 py-2 mt-1" value={String(draft.continueAfter)}
                onChange={e => setDraft({ ...draft, continueAfter: e.target.value === "true" })}>
                <option value="false">Stop after match</option>
                <option value="true">Continue evaluating</option>
              </select>
            </label>
          </div>
          {(draft.actionType === "insert" || draft.actionType === "reorder") && (
            <label className="text-sm block">Action params (JSON)
              <textarea className="w-full border rounded px-2 py-2 mt-1 font-mono text-xs" rows={3}
                placeholder={draft.actionType === "insert" ? '{ "moduleId": "00001234" }' : '{ "newQueue": ["…"] }'}
                value={draft.actionParams}
                onChange={e => setDraft({ ...draft, actionParams: e.target.value })} />
            </label>
          )}
          <div className="flex gap-2">
            <button onClick={() => saveMut.mutate()} disabled={!draft.name || saveMut.isPending}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded" data-testid="button-save-rule">
              {saveMut.isPending ? "Saving…" : editingId === "new" ? "Create rule" : "Save changes"}
            </button>
            <button onClick={() => { setEditingId(null); setDraft(emptyDraft()); }} className="px-4 py-2 text-gray-600 hover:text-gray-900">Cancel</button>
          </div>
        </div>
      )}

      {isLoading ? (
        <p className="text-gray-500">Loading rules…</p>
      ) : rules.length === 0 ? (
        <div className="bg-white border border-dashed border-gray-300 rounded-lg p-8 text-center text-gray-500">
          No reshape rules yet. Click "New rule" to create one.
        </div>
      ) : (
        <ul className="space-y-2" data-testid="list-rules">
          {rules.map(r => (
            <li key={r.id} className="bg-white border border-gray-200 rounded-lg p-4 flex items-start gap-3">
              <button onClick={() => toggleMut.mutate(r)} title={r.enabled ? "Disable" : "Enable"}>
                {r.enabled ? <ToggleRight className="w-6 h-6 text-indigo-600" /> : <ToggleLeft className="w-6 h-6 text-gray-400" />}
              </button>
              <div className="flex flex-col items-center gap-0.5 pt-0.5">
                <button onClick={() => changePriority(r, -10)} className="text-gray-400 hover:text-indigo-600" data-testid={`button-priority-up-${r.id}`} title="Higher priority">
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>
                <span className="text-[10px] text-gray-500 font-mono">{r.priority}</span>
                <button onClick={() => changePriority(r, 10)} className="text-gray-400 hover:text-indigo-600" data-testid={`button-priority-down-${r.id}`} title="Lower priority">
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-gray-900">{r.name}</span>
                  <span className={`text-xs px-2 py-0.5 rounded ${r.approvalMode === "auto" ? "bg-green-100 text-green-700" : "bg-amber-100 text-amber-700"}`}>
                    {r.approvalMode}
                  </span>
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  When <b>{r.triggerType}</b>{r.triggerValue ? ` "${r.triggerValue}"` : ""} → <b>{r.actionType}</b>
                </p>
              </div>
              <button onClick={() => startEdit(r)} className="text-gray-400 hover:text-indigo-600" data-testid={`button-edit-${r.id}`} title="Edit">
                <Edit3 className="w-4 h-4" />
              </button>
              <button onClick={() => deleteMut.mutate(r.id)} className="text-gray-400 hover:text-red-600" data-testid={`button-delete-${r.id}`}>
                <Trash2 className="w-4 h-4" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {/* Journey templates */}
      <div className="mt-10">
        <h2 className="text-lg font-semibold text-gray-900 mb-1">Starting sequences</h2>
        <p className="text-sm text-gray-500 mb-4">Default queue for new contacts. Add a tag to target a specific cohort; the untagged template is the org default.</p>

        {templates.length === 0 ? (
          <div className="bg-white border border-dashed border-gray-300 rounded-lg p-6 text-center text-gray-500 mb-4" data-testid="empty-templates">
            No templates yet. Add one below — new contacts without a journey will use it.
          </div>
        ) : (
          <ul className="space-y-2 mb-4" data-testid="list-templates">
            {templates.map(t => (
              <li key={t.id} className="bg-white border border-gray-200 rounded-lg p-4 flex items-start gap-3">
                <div className="flex-1 min-w-0">
                  <span className="text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-700">
                    {t.tag ? `tag: ${t.tag}` : "default (no tag)"}
                  </span>
                  <p className="text-xs text-gray-500 mt-1 font-mono break-all">{t.moduleIds.join(" → ") || "(empty)"}</p>
                </div>
                <button onClick={() => tplDeleteMut.mutate(t.id)} className="text-gray-400 hover:text-red-600" data-testid={`button-delete-template-${t.id}`}>
                  <Trash2 className="w-4 h-4" />
                </button>
              </li>
            ))}
          </ul>
        )}

        <div className="bg-white border border-gray-200 rounded-lg p-4 space-y-2" data-testid="form-template">
          <input className="w-full border rounded px-2 py-1.5 text-sm" placeholder="Tag (blank = org default template)"
            value={tplTag} onChange={e => setTplTag(e.target.value)} data-testid="input-template-tag" />
          <textarea className="w-full border rounded px-2 py-1.5 text-xs font-mono" rows={3}
            placeholder="One moduleId per line — e.g.&#10;mod-welcome&#10;mod-day-1&#10;mod-day-2"
            value={tplModules} onChange={e => setTplModules(e.target.value)} data-testid="input-template-modules" />
          <button onClick={() => tplCreateMut.mutate()} disabled={!tplModules.trim() || tplCreateMut.isPending}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-1.5 rounded text-sm" data-testid="button-create-template">
            {tplCreateMut.isPending ? "Saving…" : "Add template"}
          </button>
        </div>
      </div>
    </div>
  );
}
