import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";

interface ReceivedItem {
  moduleId: string;
  title: string;
  note?: string;
  sentAt: string | null;
  variantCount?: number;
}

interface LibraryItem {
  id: number;
  title: string;
  body: string;
  topic: string | null;
  theme?: string | null;
  complexity?: string | null;
  url?: string | null;
}

interface PageSettingsView {
  brandName: string;
  tagline: string;
  accentColor: string;
  footerText: string;
  showTopics: boolean;
  topicsLabel: string;
  showReceived: boolean;
  receivedLabel: string;
  showLibrary: boolean;
  libraryLabel: string;
}

interface ProfileResponse {
  firstName: string;
  topics: string[];
  received: ReceivedItem[];
  library: LibraryItem[];
  settings: PageSettingsView;
  personalNote: string | null;
}

const FALLBACK_SETTINGS: PageSettingsView = {
  brandName: "MindfulText",
  tagline: "Your space to revisit and explore.",
  accentColor: "#6366f1",
  footerText: "MindfulText",
  showTopics: true,
  topicsLabel: "Your topics",
  showReceived: true,
  receivedLabel: "Messages you’ve received",
  showLibrary: true,
  libraryLabel: "More for you",
};

async function fetchProfile(token: string): Promise<ProfileResponse> {
  const res = await fetch(`/api/public/profile/${encodeURIComponent(token)}`);
  if (res.status === 404) throw new Error("not_found");
  if (!res.ok) throw new Error(`profile ${res.status}`);
  return res.json();
}

function formatDate(iso: string | null): string {
  if (!iso) return "";
  try {
    return new Date(iso).toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
    });
  } catch {
    return "";
  }
}

export default function SubscriberPage({ token }: { token: string }) {
  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["public-profile", token],
    queryFn: () => fetchProfile(token),
    retry: false,
  });

  const [search, setSearch] = useState("");
  const [themeFilter, setThemeFilter] = useState<string | null>(null);
  const [levelFilter, setLevelFilter] = useState<string | null>(null);

  const library = data?.library ?? [];

  const themes = useMemo(
    () =>
      Array.from(
        new Set(library.map((i) => i.theme).filter((t): t is string => !!t)),
      ).sort(),
    [library],
  );
  const levels = useMemo(
    () =>
      Array.from(
        new Set(library.map((i) => i.complexity).filter((c): c is string => !!c)),
      ).sort(),
    [library],
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return library.filter((i) => {
      if (themeFilter && i.theme !== themeFilter) return false;
      if (levelFilter && i.complexity !== levelFilter) return false;
      if (!q) return true;
      return `${i.title} ${i.body} ${i.theme ?? ""} ${i.topic ?? ""}`
        .toLowerCase()
        .includes(q);
    });
  }, [library, search, themeFilter, levelFilter]);

  // Record a single page view (best-effort, fire-and-forget).
  useEffect(() => {
    if (!data) return;
    void fetch(`/api/public/profile/${encodeURIComponent(token)}/view`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path: `/p/${token}` }),
    }).catch(() => {});
  }, [data, token]);

  const logOpen = (item: LibraryItem) => {
    void fetch(`/api/public/profile/${encodeURIComponent(token)}/view`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        eventType: "content_open",
        path: item.url ?? `library:${item.id}`,
      }),
    }).catch(() => {});
  };

  if (isLoading || (!data && !isError)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-white">
        <div
          className="w-8 h-8 border-4 rounded-full animate-spin"
          style={{
            borderColor: "rgba(0,0,0,0.1)",
            borderTopColor: FALLBACK_SETTINGS.accentColor,
          }}
        />
      </div>
    );
  }

  if (isError) {
    const notFound = error instanceof Error && error.message === "not_found";
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-white px-6">
        <div className="max-w-sm text-center">
          <h1 className="text-xl font-semibold text-gray-800">
            {notFound ? "This link isn’t active" : "Something went wrong"}
          </h1>
          <p className="mt-2 text-sm text-gray-500">
            {notFound
              ? "The link may have expired or been turned off. Reach out if you think this is a mistake."
              : "Please try again in a moment."}
          </p>
        </div>
      </div>
    );
  }

  const profile = data;
  if (!profile) return null;
  const s = { ...FALLBACK_SETTINGS, ...(profile.settings ?? {}) };
  const accent = s.accentColor || FALLBACK_SETTINGS.accentColor;
  const greeting = profile.firstName ? `Hi, ${profile.firstName}` : "Welcome";

  const showTopics = s.showTopics && profile.topics.length > 0;
  const showReceived = s.showReceived && profile.received.length > 0;

  return (
    <div
      className="min-h-screen"
      style={{
        background: `linear-gradient(to bottom, ${accent}12, #ffffff)`,
      }}
    >
      <div className="mx-auto w-full max-w-md px-5 pb-16 pt-10">
        <header className="mb-6">
          <p className="text-sm font-medium" style={{ color: accent }}>
            {s.brandName}
          </p>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight text-gray-900">
            {greeting}
          </h1>
          {s.tagline && (
            <p className="mt-1 text-sm text-gray-500">{s.tagline}</p>
          )}
        </header>

        {profile.personalNote && (
          <section className="mb-8">
            <div
              className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-gray-100"
              style={{ borderLeft: `3px solid ${accent}` }}
            >
              <p className="whitespace-pre-line text-sm leading-relaxed text-gray-700">
                {profile.personalNote}
              </p>
            </div>
          </section>
        )}

        {showTopics && (
          <section className="mb-8">
            <h2 className="mb-2 text-xs font-semibold uppercase tracking-wide text-gray-400">
              {s.topicsLabel}
            </h2>
            <div className="flex flex-wrap gap-2">
              {profile.topics.map((t) => (
                <span
                  key={t}
                  className="rounded-full px-3 py-1 text-sm font-medium"
                  style={{ backgroundColor: `${accent}1a`, color: accent }}
                >
                  {t}
                </span>
              ))}
            </div>
          </section>
        )}

        {showReceived && (
          <section className="mb-8">
            <h2 className="mb-3 text-xs font-semibold uppercase tracking-wide text-gray-400">
              {s.receivedLabel}
            </h2>
            <ul className="space-y-2">
              {profile.received.map((r) => (
                <li
                  key={r.moduleId}
                  className="rounded-xl bg-white px-4 py-3 shadow-sm ring-1 ring-gray-100"
                >
                  <div className="flex items-center justify-between">
                    <span className="pr-3 text-sm font-medium text-gray-800">
                      {r.title}
                      {(r.variantCount ?? 1) > 1 && (
                        <span
                          className="ml-2 rounded-full px-2 py-0.5 text-[11px] font-medium align-middle"
                          style={{ backgroundColor: `${accent}14`, color: accent }}
                        >
                          {r.variantCount} versions
                        </span>
                      )}
                    </span>
                    {r.sentAt && (
                      <span className="shrink-0 text-xs text-gray-400">
                        {formatDate(r.sentAt)}
                      </span>
                    )}
                  </div>
                  {r.note && (
                    <p className="mt-1 text-xs leading-relaxed text-gray-500">
                      {r.note}
                    </p>
                  )}
                </li>
              ))}
            </ul>
          </section>
        )}

        {s.showLibrary && (
          <section>
            <h2 className="mb-3 text-xs font-semibold uppercase tracking-wide text-gray-400">
              {profile.topics.length > 0 ? s.libraryLabel : "Explore"}
            </h2>

            {library.length === 0 ? (
              <p className="rounded-xl bg-white px-4 py-6 text-center text-sm text-gray-400 shadow-sm ring-1 ring-gray-100">
                New content is on the way. Check back soon.
              </p>
            ) : (
              <>
                <input
                  type="search"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search meditations…"
                  className="mb-3 w-full rounded-xl border-0 bg-white px-4 py-2.5 text-sm text-gray-800 shadow-sm ring-1 ring-gray-200 placeholder:text-gray-400 focus:outline-none focus:ring-2"
                  style={{ ["--tw-ring-color" as string]: accent }}
                  data-testid="input-search"
                />

                {(themes.length > 0 || levels.length > 0) && (
                  <div className="mb-4 space-y-2">
                    {themes.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {themes.map((t) => {
                          const active = themeFilter === t;
                          return (
                            <button
                              key={t}
                              onClick={() => setThemeFilter(active ? null : t)}
                              className="rounded-full px-3 py-1 text-xs font-medium capitalize transition-colors"
                              style={
                                active
                                  ? { backgroundColor: accent, color: "#fff" }
                                  : { backgroundColor: `${accent}14`, color: accent }
                              }
                              data-testid={`chip-theme-${t}`}
                            >
                              {t}
                            </button>
                          );
                        })}
                      </div>
                    )}
                    {levels.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {levels.map((c) => {
                          const active = levelFilter === c;
                          return (
                            <button
                              key={c}
                              onClick={() => setLevelFilter(active ? null : c)}
                              className={`rounded-full px-3 py-1 text-xs font-medium capitalize transition-colors ${
                                active
                                  ? "bg-gray-800 text-white"
                                  : "bg-gray-100 text-gray-600"
                              }`}
                              data-testid={`chip-level-${c}`}
                            >
                              {c}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}

                {filtered.length === 0 ? (
                  <p className="rounded-xl bg-white px-4 py-6 text-center text-sm text-gray-400 shadow-sm ring-1 ring-gray-100">
                    Nothing matches. Try a different search or clear the filters.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {filtered.map((item) => {
                      const inner = (
                        <>
                          <div className="flex flex-wrap gap-1.5">
                            {item.theme && (
                              <span
                                className="inline-block rounded-full px-2.5 py-0.5 text-xs font-medium capitalize"
                                style={{ backgroundColor: `${accent}14`, color: accent }}
                              >
                                {item.theme}
                              </span>
                            )}
                            {item.complexity && (
                              <span className="inline-block rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium capitalize text-gray-600">
                                {item.complexity}
                              </span>
                            )}
                          </div>
                          <h3 className="mt-2 text-base font-semibold text-gray-900">
                            {item.title}
                          </h3>
                          {item.body && (
                            <p className="mt-1.5 whitespace-pre-line text-sm leading-relaxed text-gray-600">
                              {item.body}
                            </p>
                          )}
                          {item.url && (
                            <p
                              className="mt-2 text-sm font-medium"
                              style={{ color: accent }}
                            >
                              Listen now →
                            </p>
                          )}
                        </>
                      );
                      return item.url ? (
                        <a
                          key={item.id}
                          href={item.url}
                          target="_blank"
                          rel="noreferrer"
                          onClick={() => logOpen(item)}
                          className="block rounded-2xl bg-white p-5 shadow-sm ring-1 ring-gray-100 transition-shadow hover:shadow-md active:shadow-md"
                          data-testid={`card-meditation-${item.id}`}
                        >
                          {inner}
                        </a>
                      ) : (
                        <article
                          key={item.id}
                          className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-gray-100"
                        >
                          {inner}
                        </article>
                      );
                    })}
                  </div>
                )}
              </>
            )}
          </section>
        )}

        <footer className="mt-10 text-center text-xs text-gray-300">
          {s.footerText}
        </footer>
      </div>
    </div>
  );
}
