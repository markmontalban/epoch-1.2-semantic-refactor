import { useState } from "react";
import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle2, XCircle, Edit3 } from "lucide-react";
import { resolveLocalOrgId } from "@/lib/localApi";
import { SequenceDiff } from "@/components/SequenceDiff";

interface PendingChange {
  id: number;
  contactId: string;
  ruleId: number | null;
  ruleName: string | null;
  ruleActionType: string | null;
  inboundContent: string | null;
  draftReplyContent: string | null;
  draftReplyStatus: string | null;
  currentSequence: string[];
  proposedSequence: string[];
  proposedOps: unknown;
  aiReason: string | null;
  sendRequired?: boolean;
  status: string;
  createdAt: string;
}

export default function Changes() {
  const { toast } = useToast();
  const ORG_ID = resolveLocalOrgId();
  const [editing, setEditing] = useState<Record<number, string>>({});

  const { data: changes = [], isLoading } = useQuery<PendingChange[]>({
    queryKey: ["/api/local/pending-changes", ORG_ID, "pending"],
    queryFn: () => fetch(`/api/local/pending-changes/${ORG_ID}?status=pending`).then(r => r.json()),
  });

  const approveMut = useMutation({
    mutationFn: ({ id, edited }: { id: number; edited?: string[] }) =>
      apiRequest("POST", `/api/local/pending-changes/${id}/approve`, edited ? { proposedSequence: edited } : {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/pending-changes", ORG_ID, "pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/local/pending-changes", ORG_ID, "count"] });
      toast({ title: "Change applied" });
    },
    onError: (e: any) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const rejectMut = useMutation({
    mutationFn: (id: number) => apiRequest("POST", `/api/local/pending-changes/${id}/reject`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/pending-changes", ORG_ID, "pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/local/pending-changes", ORG_ID, "count"] });
      toast({ title: "Change rejected" });
    },
  });

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {isLoading ? (
        <p className="text-gray-500">Loading…</p>
      ) : changes.length === 0 ? (
        <div className="bg-white border border-dashed border-gray-300 rounded-lg p-8 text-center text-gray-500" data-testid="empty-changes">
          No changes pending review.
        </div>
      ) : (
        <ul className="space-y-3" data-testid="list-pending">
          {changes.map(c => {
            const editedRaw = editing[c.id];
            const editedArr = editedRaw !== undefined
              ? editedRaw.split("\n").map(s => s.trim()).filter(Boolean)
              : null;
            return (
              <li key={c.id} className="bg-white border border-gray-200 rounded-lg p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-gray-900 flex items-center gap-2">
                      Contact <span className="font-mono text-xs">{c.contactId}</span>
                      {c.sendRequired && (
                        <span className="text-[10px] uppercase tracking-wide font-semibold px-1.5 py-0.5 rounded bg-purple-100 text-purple-700" data-testid={`badge-send-${c.id}`}>
                          Send pending
                        </span>
                      )}
                    </p>
                    {c.ruleName && (
                      <p className="text-xs text-gray-600 mt-0.5">
                        Rule: <b>{c.ruleName}</b>{c.ruleActionType ? ` — ${c.ruleActionType}` : ""}
                      </p>
                    )}
                    {c.aiReason && <p className="text-xs text-gray-500 mt-0.5">{c.aiReason}</p>}
                  </div>
                  <span className="text-xs text-gray-400 whitespace-nowrap ml-3">{new Date(c.createdAt).toLocaleString()}</span>
                </div>
                {c.inboundContent && (
                  <div className="mb-3 text-xs bg-blue-50 border border-blue-100 rounded p-2" data-testid={`inbound-${c.id}`}>
                    <span className="text-blue-700 font-medium">Contact said:</span>
                    <span className="text-gray-700 ml-2">"{c.inboundContent}"</span>
                  </div>
                )}
                {c.draftReplyContent && (
                  <div className="mb-3 text-xs bg-indigo-50 border border-indigo-100 rounded p-2" data-testid={`draft-${c.id}`}>
                    <span className="text-indigo-700 font-medium">
                      Suggested reply{c.draftReplyStatus ? ` (${c.draftReplyStatus})` : ""}:
                    </span>
                    <span className="text-gray-700 ml-2">"{c.draftReplyContent}"</span>
                    <Link href="/replies" className="block mt-1 text-indigo-600 hover:underline">
                      Review in Replies →
                    </Link>
                  </div>
                )}

                {editedRaw === undefined ? (
                  <div className="mb-3">
                    <SequenceDiff
                      currentSequence={c.currentSequence}
                      proposedSequence={c.proposedSequence}
                      testIdPrefix={`diff-${c.id}`}
                      gap={3}
                    />
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-3 mb-3 text-xs">
                    <div>
                      <p className="text-gray-500 mb-1">Current</p>
                      <div className="bg-gray-50 border border-gray-200 rounded p-2 font-mono space-y-0.5" data-testid={`diff-${c.id}-current`}>
                        {c.currentSequence.length === 0 && <div className="text-gray-400">(empty)</div>}
                        {c.currentSequence.map((m, i) => (
                          <div key={i}>{m}</div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="text-gray-500 mb-1">Proposed</p>
                      <textarea
                        className="w-full bg-yellow-50 border border-yellow-300 rounded p-2 font-mono text-xs"
                        rows={Math.max(3, editedArr?.length ?? 3)}
                        value={editedRaw}
                        onChange={e => setEditing({ ...editing, [c.id]: e.target.value })}
                      />
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  <button onClick={() => approveMut.mutate({ id: c.id, edited: editedArr ?? undefined })}
                    className="bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded text-sm flex items-center gap-1.5"
                    data-testid={`button-approve-${c.id}`}>
                    <CheckCircle2 className="w-4 h-4" /> {editedRaw ? "Approve edited" : c.sendRequired ? "Approve & send" : "Approve"}
                  </button>
                  <button onClick={() => rejectMut.mutate(c.id)}
                    className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-3 py-1.5 rounded text-sm flex items-center gap-1.5"
                    data-testid={`button-reject-${c.id}`}>
                    <XCircle className="w-4 h-4" /> Reject
                  </button>
                  <button onClick={() => setEditing({ ...editing, [c.id]: c.proposedSequence.join("\n") })}
                    className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-3 py-1.5 rounded text-sm flex items-center gap-1.5"
                    disabled={editedRaw !== undefined}>
                    <Edit3 className="w-4 h-4" /> Edit
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
