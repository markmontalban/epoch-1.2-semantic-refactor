import { useState, useMemo, useEffect, useRef } from "react";
import { Link } from "wouter";
import { useQuery, useQueries, useQueryClient, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { SequenceDiff } from "@/components/SequenceDiff";
import {
  AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogFooter,
  AlertDialogTitle, AlertDialogDescription, AlertDialogCancel, AlertDialogAction,
} from "@/components/ui/alert-dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { apiService, type Module, type Contact, type Action, type Journey, type Subscription } from "@/lib/api";
import { resolveLocalOrgId } from "@/lib/localApi";
import {
  Loader2, Search, X, LayoutGrid, Undo2, History, ChevronDown, ChevronRight,
  CheckCircle2, XCircle,
} from "lucide-react";

// ---------------------------------------------------------------------------
// Types & constants
// ---------------------------------------------------------------------------

type EntityType = "journeys" | "modules" | "actions" | "contacts" | "rules" | "pending";
const ALL_TYPES: EntityType[] = ["journeys", "modules", "actions", "contacts", "rules", "pending"];
const TYPE_LABELS: Record<EntityType, string> = {
  journeys: "Journeys", modules: "Modules", actions: "Actions",
  contacts: "Contacts", rules: "Rules", pending: "Pending",
};
const TYPE_TAG: Record<EntityType, string> = {
  journeys: "J", modules: "M", actions: "A", contacts: "C", rules: "R", pending: "P",
};
const TYPE_TAG_COLOR: Record<EntityType, string> = {
  journeys: "bg-violet-100 text-violet-700",
  modules: "bg-indigo-100 text-indigo-700",
  actions: "bg-purple-100 text-purple-700",
  contacts: "bg-blue-100 text-blue-700",
  rules: "bg-emerald-100 text-emerald-700",
  pending: "bg-amber-100 text-amber-700",
};

const UNCHANGED = "__UNCHANGED__";

interface RuleActionParams {
  moduleId?: string;
  [key: string]: unknown;
}
interface ReshapeRule {
  id: number;
  name: string;
  triggerType: string;
  triggerValue: string | null;
  actionType: string;
  actionParams: RuleActionParams | null;
  approvalMode: "auto" | "review";
  enabled: boolean;
  priority: number;
  continueAfter: boolean;
}

interface JourneyTemplate {
  id: number;
  organizationId: string;
  name?: string | null;
  moduleIds: string[];
}

type PriorityMode = "unchanged" | "set" | "shift";
function isPriorityMode(v: string): v is PriorityMode {
  return v === "unchanged" || v === "set" || v === "shift";
}

interface PendingChange {
  id: number;
  contactId: string;
  ruleId: number | null;
  ruleName: string | null;
  ruleActionType: string | null;
  inboundContent: string | null;
  currentSequence: string[];
  proposedSequence: string[];
  proposedOps: unknown;
  aiReason: string | null;
  status: string;
  createdAt: string;
}

interface SnapshotRow {
  id: number;
  organizationId: string;
  entityType: string;
  entityId: string;
  entityName: string | null;
  reason: string;
  createdAt: string;
}

function journeyModuleIds(j: { moduleIds?: string[]; moduleIDs?: string[] }): string[] {
  return j.moduleIDs ?? j.moduleIds ?? [];
}

function describeBefore(value: unknown): string {
  if (value == null) return "—";
  if (Array.isArray(value)) return value.length === 0 ? "—" : value.join(", ");
  if (typeof value === "boolean") return value ? "true" : "false";
  return String(value);
}

function getCurrentValue(record: any, field: string): string {
  if (!record) return "—";
  const aliases: Record<string, string[]> = {
    company: ["company", "companyName"],
    location: ["location", "city"],
  };
  const candidates = aliases[field] ?? [field];
  for (const k of candidates) {
    if (k in record) return describeBefore(record[k]);
  }
  return "—";
}

// ---------------------------------------------------------------------------
// Field shapes
// ---------------------------------------------------------------------------

interface NameDescTagsArchive {
  name: string; description: string; tags: string; isArchived: string;
}
const emptyNDA: NameDescTagsArchive = { name: "", description: "", tags: "", isArchived: UNCHANGED };

interface ContactFields {
  firstName: string; lastName: string; company: string; title: string;
  location: string; timezone: string; tags: string; status: string;
}
const emptyContact: ContactFields = {
  firstName: "", lastName: "", company: "", title: "",
  location: "", timezone: "", tags: "", status: "",
};

interface ActionFields {
  name: string; description: string; tags: string; type: string; status: string;
}
const emptyAction: ActionFields = { name: "", description: "", tags: "", type: "", status: "" };

interface RuleFields {
  enabled: string;          // "" | "true" | "false"
  approvalMode: string;     // "" | "auto" | "review"
  priorityMode: PriorityMode;
  priorityValue: string;
}
const emptyRule: RuleFields = {
  enabled: UNCHANGED, approvalMode: UNCHANGED, priorityMode: "unchanged", priorityValue: "",
};

type AnyFields = NameDescTagsArchive | ContactFields | ActionFields | RuleFields;
type FieldEntry = [string, string];

function getChangedNDA(f: NameDescTagsArchive): FieldEntry[] {
  return Object.entries(f).filter(([, v]) => v !== "" && v !== UNCHANGED);
}
function getChangedContact(f: ContactFields): FieldEntry[] {
  return Object.entries(f).filter(([, v]) => v !== "");
}
function getChangedAction(f: ActionFields): FieldEntry[] {
  return Object.entries(f).filter(([, v]) => v !== "");
}
function getChangedRule(f: RuleFields): FieldEntry[] {
  const out: FieldEntry[] = [];
  if (f.enabled !== UNCHANGED && f.enabled !== "") out.push(["enabled", f.enabled]);
  if (f.approvalMode !== UNCHANGED && f.approvalMode !== "") out.push(["approvalMode", f.approvalMode]);
  if (f.priorityMode !== "unchanged" && f.priorityValue !== "") {
    out.push(["priority", `${f.priorityMode}:${f.priorityValue}`]);
  }
  return out;
}

function buildNDAPayload(f: NameDescTagsArchive): Record<string, unknown> {
  const p: Record<string, unknown> = {};
  for (const [k, v] of getChangedNDA(f)) {
    if (k === "tags") p.tags = v.split(",").map((t) => t.trim()).filter(Boolean);
    else if (k === "isArchived") p.isArchived = v === "true";
    else p[k] = v;
  }
  return p;
}
function buildContactPayload(f: ContactFields): Record<string, unknown> {
  const p: Record<string, unknown> = {};
  for (const [k, v] of getChangedContact(f)) {
    if (k === "tags") p.tags = v.split(",").map((t) => t.trim()).filter(Boolean);
    else p[k] = v;
  }
  return p;
}
function buildActionPayload(f: ActionFields): Record<string, unknown> {
  const p: Record<string, unknown> = {};
  for (const [k, v] of getChangedAction(f)) {
    if (k === "tags") p.tags = v.split(",").map((t) => t.trim()).filter(Boolean);
    else p[k] = v;
  }
  return p;
}
function buildRulePayloadFor(rule: ReshapeRule, f: RuleFields): Record<string, unknown> {
  const p: Record<string, unknown> = {};
  if (f.enabled !== UNCHANGED && f.enabled !== "") p.enabled = f.enabled === "true";
  if (f.approvalMode !== UNCHANGED && f.approvalMode !== "") p.approvalMode = f.approvalMode;
  if (f.priorityMode === "set" && f.priorityValue !== "") {
    p.priority = Math.max(0, Number(f.priorityValue));
  } else if (f.priorityMode === "shift" && f.priorityValue !== "") {
    p.priority = Math.max(0, rule.priority + Number(f.priorityValue));
  }
  return p;
}

// ---------------------------------------------------------------------------
// Small UI helpers
// ---------------------------------------------------------------------------

function TagBadges({ raw }: { raw: string[] | undefined }) {
  if (!raw || raw.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-1 mt-1">
      {raw.map((t) => (<Badge key={t} variant="secondary" className="text-xs">{t}</Badge>))}
    </div>
  );
}

function TypeTag({ type }: { type: EntityType }) {
  return (
    <span className={`text-[10px] font-bold rounded-full w-5 h-5 inline-flex items-center justify-center shrink-0 ${TYPE_TAG_COLOR[type]}`}>
      {TYPE_TAG[type]}
    </span>
  );
}

function FieldRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1">
      <Label className="text-xs text-gray-600">{label}</Label>
      {children}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Recent backups (multi-type)
// ---------------------------------------------------------------------------

const BACKUP_TYPES: EntityType[] = ["journeys", "modules", "actions", "contacts"];

function RecentBackups({ types, orgId }: { types: EntityType[]; orgId: string }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const singularize = (t: EntityType): string => t.slice(0, -1);
  const visibleSet = new Set(types.filter((t) => BACKUP_TYPES.includes(t)));

  // Always run the same fixed list of queries so hook counts/order are stable.
  const results = useQueries({
    queries: BACKUP_TYPES.map((t) => ({
      queryKey: ["snapshots", orgId, singularize(t)],
      queryFn: async (): Promise<SnapshotRow[]> => {
        const res = await fetch(`/api/local/snapshots/${orgId}?entityType=${singularize(t)}&limit=5`);
        if (!res.ok) return [];
        return res.json();
      },
      refetchInterval: 15000,
    })),
  });
  const queries = BACKUP_TYPES.map((t, i) => ({
    type: t,
    entityType: singularize(t),
    q: results[i] as { data?: SnapshotRow[] },
    show: visibleSet.has(t),
  }));

  const restoreMutation = useMutation({
    mutationFn: async (snapshotId: number) => apiRequest("POST", `/api/local/snapshots/${snapshotId}/restore`),
    onSuccess: () => {
      toast({ title: "Restored", description: "Item restored to its earlier state." });
      queryClient.invalidateQueries({ queryKey: ["snapshots"] });
      queryClient.invalidateQueries({ queryKey: ["modules"] });
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
      queryClient.invalidateQueries({ queryKey: ["actions"] });
      queryClient.invalidateQueries({ queryKey: ["journeys"] });
    },
    onError: (e: unknown) => toast({
      title: "Restore failed",
      description: e instanceof Error ? e.message : "Unknown error",
      variant: "destructive",
    }),
  });

  const total = queries.reduce((acc, q) => acc + (q.show ? (q.q.data?.length ?? 0) : 0), 0);
  if (total === 0) return null;

  return (
    <div className="border border-amber-200 bg-amber-50 rounded-lg p-3">
      <div className="flex items-center gap-2 mb-2">
        <History className="w-4 h-4 text-amber-700" />
        <span className="text-sm font-medium text-amber-900">Recent backups</span>
        <span className="text-xs text-amber-700 ml-auto">Click Restore to undo</span>
      </div>
      <div className="space-y-3 max-h-48 overflow-y-auto">
        {queries.map(({ type, entityType, q, show }) => {
          const rows = show ? (q.data ?? []) : [];
          if (rows.length === 0) return null;
          return (
            <div key={entityType}>
              <p className="text-[11px] uppercase tracking-wide text-amber-800 mb-1 flex items-center gap-1.5">
                <TypeTag type={type} /> {TYPE_LABELS[type]} ({rows.length})
              </p>
              <div className="space-y-1">
                {rows.map((s) => (
                  <div key={s.id} className="flex items-center gap-2 text-xs bg-white rounded px-2 py-1.5 border border-amber-100">
                    <span className="text-gray-500 shrink-0">
                      {new Date(s.createdAt).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                    </span>
                    <span className="font-medium text-gray-800 truncate">{s.entityName ?? s.entityId}</span>
                    <span className="text-gray-400 ml-auto shrink-0 font-mono">{s.entityId}</span>
                    <Button
                      size="sm" variant="outline" className="h-6 px-2 text-xs"
                      onClick={() => restoreMutation.mutate(s.id)}
                      disabled={restoreMutation.isPending}
                    >
                      {restoreMutation.isPending && restoreMutation.variables === s.id
                        ? <Loader2 className="w-3 h-3 animate-spin" />
                        : <><Undo2 className="w-3 h-3 mr-1" />Restore</>}
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main page
// ---------------------------------------------------------------------------

export default function Workbench() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isMobile = useIsMobile();
  const ORG_ID = resolveLocalOrgId();

  // ----- Filter strip state -----
  const [journeyFilter, setJourneyFilter] = useState<string>("__all__");
  const [moduleFilter, setModuleFilter] = useState<string>("__all__");
  const [search, setSearch] = useState<string>("");
  const [visible, setVisible] = useState<Set<EntityType>>(new Set(ALL_TYPES));

  // ----- Selection state per type -----
  const [selJourneys, setSelJourneys] = useState<Set<string>>(new Set());
  const [selModules, setSelModules] = useState<Set<string>>(new Set());
  const [selActions, setSelActions] = useState<Set<string>>(new Set());
  const [selContacts, setSelContacts] = useState<Set<string>>(new Set());
  const [selRules, setSelRules] = useState<Set<number>>(new Set());
  const [selPending, setSelPending] = useState<Set<number>>(new Set());

  // ----- Field state per editable type -----
  const [journeyFields, setJourneyFields] = useState<NameDescTagsArchive>(emptyNDA);
  const [moduleFields, setModuleFields] = useState<NameDescTagsArchive>(emptyNDA);
  const [actionFields, setActionFields] = useState<ActionFields>(emptyAction);
  const [contactFields, setContactFields] = useState<ContactFields>(emptyContact);
  const [ruleFields, setRuleFields] = useState<RuleFields>(emptyRule);

  // ----- Confirm dialog state -----
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmMode, setConfirmMode] = useState<"apply" | "pendingApprove" | "pendingReject">("apply");
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);

  // ----- Mobile bottom-sheet state -----
  const [sheetOpen, setSheetOpen] = useState(false);

  // ----- Section refs for scrollIntoView -----
  const sectionRefs = useRef<Record<EntityType, HTMLDivElement | null>>({
    journeys: null, modules: null, actions: null, contacts: null, rules: null, pending: null,
  });

  // ===== Data =====
  const { data: modules = [], isLoading: modulesLoading } = useQuery<Module[]>({
    queryKey: ["modules"], queryFn: () => apiService.getModules(),
  });
  const { data: contacts = [], isLoading: contactsLoading } = useQuery<Contact[]>({
    queryKey: ["contacts"], queryFn: () => apiService.getContacts(),
  });
  const { data: actions = [], isLoading: actionsLoading } = useQuery<Action[]>({
    queryKey: ["actions"], queryFn: () => apiService.getActions(),
  });
  const { data: journeys = [], isLoading: journeysLoading } = useQuery<Journey[]>({
    queryKey: ["journeys"], queryFn: () => apiService.getJourneys(),
  });
  // Per-journey unique contact counts come from a small server-side
  // aggregation endpoint so we don't have to download the entire
  // subscriptions list (~thousands of rows) just to render count badges.
  const {
    data: subscriptionCounts = {},
    isError: countsError,
    isLoading: countsLoading,
  } = useQuery<Record<string, number>>({
    queryKey: ["subscription-counts"], queryFn: () => apiService.getSubscriptionCounts(),
    retry: false,
  });
  // The full subscriptions list is only needed to map journey → contact ids
  // (used by the journey/module filters on Contacts and Pending). Load it
  // lazily — only when one of those filters is actually engaged.
  const needSubscriptions = journeyFilter !== "__all__" || moduleFilter !== "__all__";
  const {
    data: subscriptions = [],
    isError: subscriptionsError,
    isLoading: subscriptionsLoading,
  } = useQuery<Subscription[]>({
    queryKey: ["subscriptions"], queryFn: () => apiService.getSubscriptions(),
    retry: false,
    enabled: needSubscriptions,
  });
  const { data: rules = [], isLoading: rulesLoading } = useQuery<ReshapeRule[]>({
    queryKey: ["/api/local/reshape-rules", ORG_ID],
    queryFn: () => fetch(`/api/local/reshape-rules/${ORG_ID}`).then((r) => r.json()),
  });
  const { data: pending = [], isLoading: pendingLoading } = useQuery<PendingChange[]>({
    queryKey: ["/api/local/pending-changes", ORG_ID, "pending"],
    queryFn: () => fetch(`/api/local/pending-changes/${ORG_ID}?status=pending`).then((r) => r.json()),
  });
  const { data: templates = [] } = useQuery<JourneyTemplate[]>({
    queryKey: ["/api/local/journey-templates", ORG_ID],
    queryFn: () => fetch(`/api/local/journey-templates/${ORG_ID}`).then((r) => r.json()),
  });

  const decideOne = useMutation({
    mutationFn: async ({ id, mode }: { id: number; mode: "approve" | "reject" }) =>
      apiRequest("POST", `/api/local/pending-changes/${id}/${mode}`, {}),
    onSuccess: (_d, vars) => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/pending-changes", ORG_ID, "pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/local/pending-changes", ORG_ID, "count"] });
      toast({ title: vars.mode === "approve" ? "Approved" : "Rejected" });
    },
    onError: (e) => toast({ title: "Action failed", description: (e as Error).message, variant: "destructive" }),
  });

  // ===== Derived maps =====
  const modulesById = useMemo(() => new Map(modules.map((m) => [m.id, m])), [modules]);
  const contactsById = useMemo(() => new Map(contacts.map((c) => [c.id, c])), [contacts]);
  const actionsById = useMemo(() => new Map(actions.map((a) => [a.id, a])), [actions]);
  const journeysById = useMemo(() => new Map(journeys.map((j) => [j.id, j])), [journeys]);
  const rulesById = useMemo(() => new Map(rules.map((r) => [r.id, r])), [rules]);

  // Module → journeys it appears in
  const journeysContainingModule = useMemo(() => {
    const m = new Map<string, Journey[]>();
    for (const j of journeys) {
      for (const mid of journeyModuleIds(j)) {
        if (!m.has(mid)) m.set(mid, []);
        m.get(mid)!.push(j);
      }
    }
    return m;
  }, [journeys]);

  // Journey → contact ids (via subscriptions). Only count operationally-live
  // subscriptions (active / paused / sending); exclude cancelled & completed
  // so the displayed counts represent people currently being messaged.
  const ACTIVE_SUB_STATUSES = new Set(["active", "paused", "sending"]);
  const journeyContactIds = useMemo(() => {
    const m = new Map<string, Set<string>>();
    for (const s of subscriptions) {
      if (!s.journeyId || !s.contactId) continue;
      const status = (s.status ?? "").toLowerCase();
      if (status && !ACTIVE_SUB_STATUSES.has(status)) continue;
      if (!m.has(s.journeyId)) m.set(s.journeyId, new Set());
      m.get(s.journeyId)!.add(s.contactId);
    }
    return m;
  }, [subscriptions]);

  // Resolved per-journey subscriber count. Priority:
  //   1. Filtered active-only count from the full subscriptions list, but
  //      only when that list has actually been fetched (it's lazy-loaded
  //      now to avoid the multi-thousand-row payload on every visit).
  //      This is the most accurate source — excludes cancelled/completed.
  //   2. Server-side aggregation (`subscriptionCounts`): a small JSON map
  //      that gives us per-journey counts without the bulk download.
  //   3. The journey's own API-provided total as a last resort.
  const subscriptionsLoaded = needSubscriptions && !subscriptionsLoading && !subscriptionsError;
  const journeySubscriberCount = (j: Journey): number => {
    if (subscriptionsLoaded) return journeyContactIds.get(j.id)?.size ?? 0;
    const aggregated = subscriptionCounts[j.id];
    if (typeof aggregated === "number") return aggregated;
    if (typeof j.subscriberCount === "number" && j.subscriberCount > 0) return j.subscriberCount;
    return 0;
  };

  // Action → parent modules
  const actionParentModules = useMemo(() => {
    const m = new Map<string, Module[]>();
    const seen = new Map<string, Set<string>>();
    const add = (aid: string, mod: Module) => {
      let s = seen.get(aid);
      if (!s) { s = new Set(); seen.set(aid, s); m.set(aid, []); }
      if (!s.has(mod.id)) { s.add(mod.id); m.get(aid)!.push(mod); }
    };
    const collect = (mod: Module): string[] => {
      const ids: string[] = [];
      if (mod.actionIds) ids.push(...mod.actionIds);
      const scan = (arr: unknown) => {
        if (!Array.isArray(arr)) return;
        for (const e of arr) {
          if (e && typeof e === "object") {
            const rec = e as Record<string, unknown>;
            const aid = rec.actionID ?? rec.actionId;
            if (typeof aid === "string" && aid) ids.push(aid);
          }
        }
      };
      scan(mod.texts); scan(mod.messages);
      return ids;
    };
    for (const mod of modules) for (const aid of collect(mod)) add(aid, mod);
    for (const a of actions) {
      const mids: string[] = [];
      if (a.moduleId) mids.push(a.moduleId);
      if (a.moduleIds) mids.push(...a.moduleIds);
      for (const mid of mids) {
        const mod = modulesById.get(mid);
        if (mod) add(a.id, mod);
      }
    }
    return m;
  }, [modules, actions, modulesById]);

  // Rule → target module id (from actionParams.moduleId)
  const ruleTargetModule = (r: ReshapeRule): string | null => {
    const m = r.actionParams?.moduleId;
    return typeof m === "string" ? m : null;
  };
  const rulesUsingModule = useMemo(() => {
    const m = new Map<string, ReshapeRule[]>();
    for (const r of rules) {
      const mid = ruleTargetModule(r);
      if (!mid) continue;
      if (!m.has(mid)) m.set(mid, []);
      m.get(mid)!.push(r);
    }
    return m;
  }, [rules]);

  // Pending grouped
  const pendingByContact = useMemo(() => {
    const m = new Map<string, PendingChange[]>();
    for (const p of pending) {
      if (!m.has(p.contactId)) m.set(p.contactId, []);
      m.get(p.contactId)!.push(p);
    }
    return m;
  }, [pending]);
  const pendingByRule = useMemo(() => {
    const m = new Map<number, PendingChange[]>();
    for (const p of pending) {
      if (p.ruleId == null) continue;
      if (!m.has(p.ruleId)) m.set(p.ruleId, []);
      m.get(p.ruleId)!.push(p);
    }
    return m;
  }, [pending]);

  // ===== Filtering =====
  const journeyFilterModuleIds = useMemo(() => {
    if (journeyFilter === "__all__") return null;
    const j = journeysById.get(journeyFilter);
    return j ? new Set(journeyModuleIds(j)) : new Set<string>();
  }, [journeyFilter, journeysById]);

  const lcSearch = search.trim().toLowerCase();
  const matchesSearch = (s: string | undefined | null) =>
    !lcSearch || (s ?? "").toLowerCase().includes(lcSearch);

  const filteredJourneys = useMemo(() => {
    let r = journeys;
    if (journeyFilter !== "__all__") r = r.filter((j) => j.id === journeyFilter);
    if (moduleFilter !== "__all__") {
      r = r.filter((j) => journeyModuleIds(j).includes(moduleFilter));
    }
    if (lcSearch) r = r.filter((j) => matchesSearch(j.name) || matchesSearch(j.description));
    return r;
  }, [journeys, journeyFilter, moduleFilter, lcSearch]);

  const filteredModules = useMemo(() => {
    let r = modules;
    if (journeyFilterModuleIds) r = r.filter((m) => journeyFilterModuleIds.has(m.id));
    if (moduleFilter !== "__all__") r = r.filter((m) => m.id === moduleFilter);
    if (lcSearch) r = r.filter((m) => matchesSearch(m.name) || matchesSearch(m.description));
    return r;
  }, [modules, journeyFilterModuleIds, moduleFilter, lcSearch]);

  const filteredActions = useMemo(() => {
    let r = actions;
    if (journeyFilterModuleIds) {
      r = r.filter((a) => {
        const parents = actionParentModules.get(a.id) ?? [];
        return parents.some((m) => journeyFilterModuleIds.has(m.id));
      });
    }
    if (moduleFilter !== "__all__") {
      r = r.filter((a) => (actionParentModules.get(a.id) ?? []).some((m) => m.id === moduleFilter));
    }
    if (lcSearch) r = r.filter((a) => matchesSearch(a.name) || matchesSearch(a.description));
    return r;
  }, [actions, journeyFilterModuleIds, moduleFilter, actionParentModules, lcSearch]);

  const filteredContacts = useMemo(() => {
    let r = contacts;
    if (journeyFilter !== "__all__") {
      const ids = journeyContactIds.get(journeyFilter) ?? new Set<string>();
      r = r.filter((c) => ids.has(c.id));
    }
    if (moduleFilter !== "__all__") {
      const journeysForModule = journeysContainingModule.get(moduleFilter) ?? [];
      const cids = new Set<string>();
      for (const j of journeysForModule) {
        const set = journeyContactIds.get(j.id);
        if (set) set.forEach((id) => cids.add(id));
      }
      r = r.filter((c) => cids.has(c.id));
    }
    if (lcSearch) {
      r = r.filter((c) => {
        const name = [c.firstName, c.lastName].filter(Boolean).join(" ");
        return matchesSearch(name) || matchesSearch(c.email) || matchesSearch(c.company);
      });
    }
    return r;
  }, [contacts, journeyFilter, moduleFilter, journeyContactIds, journeysContainingModule, lcSearch]);

  const filteredRules = useMemo(() => {
    let r = rules;
    if (moduleFilter !== "__all__") {
      r = r.filter((rl) => ruleTargetModule(rl) === moduleFilter);
    } else if (journeyFilterModuleIds) {
      r = r.filter((rl) => {
        const m = ruleTargetModule(rl);
        return m ? journeyFilterModuleIds.has(m) : false;
      });
    }
    if (lcSearch) {
      r = r.filter((rl) => matchesSearch(rl.name) || matchesSearch(rl.triggerValue) || matchesSearch(rl.actionType));
    }
    return r;
  }, [rules, moduleFilter, journeyFilterModuleIds, lcSearch]);

  const filteredPending = useMemo(() => {
    let r = pending;
    if (journeyFilter !== "__all__") {
      const ids = journeyContactIds.get(journeyFilter) ?? new Set<string>();
      r = r.filter((p) => ids.has(p.contactId));
    }
    if (moduleFilter !== "__all__") {
      r = r.filter((p) => p.proposedSequence.includes(moduleFilter) || p.currentSequence.includes(moduleFilter));
    }
    if (lcSearch) {
      r = r.filter((p) => matchesSearch(p.contactId) || matchesSearch(p.ruleName) || matchesSearch(p.aiReason) || matchesSearch(p.inboundContent));
    }
    return r;
  }, [pending, journeyFilter, moduleFilter, journeyContactIds, lcSearch]);

  // ===== Selection helpers =====
  const toggleType = (t: EntityType) => {
    const next = new Set(visible);
    next.has(t) ? next.delete(t) : next.add(t);
    setVisible(next);
  };

  const scrollToSection = (t: EntityType) => {
    const next = new Set(visible);
    if (!next.has(t)) { next.add(t); setVisible(next); }
    setTimeout(() => {
      sectionRefs.current[t]?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 50);
  };

  const clearAllSelections = () => {
    setSelJourneys(new Set()); setSelModules(new Set()); setSelActions(new Set());
    setSelContacts(new Set()); setSelRules(new Set()); setSelPending(new Set());
  };

  // ===== Counts =====
  const counts = {
    journeys: selJourneys.size, modules: selModules.size, actions: selActions.size,
    contacts: selContacts.size, rules: selRules.size, pending: selPending.size,
  };
  const totalSelections = counts.journeys + counts.modules + counts.actions + counts.contacts + counts.rules + counts.pending;
  const anyEditableSelected = counts.journeys || counts.modules || counts.actions || counts.contacts || counts.rules;

  // Apply enable: at least one editable type has both selection AND filled fields
  const canApply = (
    (counts.journeys > 0 && getChangedNDA(journeyFields).length > 0) ||
    (counts.modules > 0 && getChangedNDA(moduleFields).length > 0) ||
    (counts.actions > 0 && getChangedAction(actionFields).length > 0) ||
    (counts.contacts > 0 && getChangedContact(contactFields).length > 0) ||
    (counts.rules > 0 && getChangedRule(ruleFields).length > 0)
  );

  // Backups types: types that have selections; if none, fall back to filtered types.
  const backupsTypes: EntityType[] = useMemo(() => {
    const s: EntityType[] = [];
    if (counts.journeys) s.push("journeys");
    if (counts.modules) s.push("modules");
    if (counts.actions) s.push("actions");
    if (counts.contacts) s.push("contacts");
    if (s.length > 0) return s;
    // No selections + active filter: scope backups to the types the filter touches.
    if (moduleFilter !== "__all__") return ["modules", "actions", "contacts"];
    if (journeyFilter !== "__all__") return ["journeys", "modules", "contacts"];
    // No selections + no filter: show all editable types so undo is one click away.
    return ["journeys", "modules", "actions", "contacts"];
  }, [counts.journeys, counts.modules, counts.actions, counts.contacts, journeyFilter, moduleFilter]);

  // ===== Apply orchestration =====
  const handleApply = () => {
    if (!canApply) {
      toast({ title: "Nothing to apply", description: "Select items and fill at least one field.", variant: "destructive" });
      return;
    }
    setConfirmMode("apply");
    setConfirmOpen(true);
  };

  const runApply = async () => {
    setConfirmOpen(false);
    setSheetOpen(false);
    const totals: Record<string, { ok: number; fail: number }> = {};
    let totalCount = 0;
    if (counts.journeys && getChangedNDA(journeyFields).length) totalCount += counts.journeys;
    if (counts.modules && getChangedNDA(moduleFields).length) totalCount += counts.modules;
    if (counts.actions && getChangedAction(actionFields).length) totalCount += counts.actions;
    if (counts.contacts && getChangedContact(contactFields).length) totalCount += counts.contacts;
    if (counts.rules && getChangedRule(ruleFields).length) totalCount += counts.rules;
    setProgress({ done: 0, total: totalCount });
    let done = 0;

    const runBatch = async <T,>(
      type: string, ids: T[], fn: (id: T) => Promise<unknown>,
    ) => {
      const r = { ok: 0, fail: 0 };
      for (const id of ids) {
        try { await fn(id); r.ok++; } catch { r.fail++; }
        done++; setProgress({ done, total: totalCount });
      }
      totals[type] = r;
    };

    if (counts.journeys && getChangedNDA(journeyFields).length) {
      const payload = buildNDAPayload(journeyFields);
      await runBatch("Journeys", Array.from(selJourneys), (id) => apiService.updateJourney(id, payload));
      queryClient.invalidateQueries({ queryKey: ["journeys"] });
    }
    if (counts.modules && getChangedNDA(moduleFields).length) {
      const payload = buildNDAPayload(moduleFields);
      await runBatch("Modules", Array.from(selModules), (id) => apiService.updateModule(id, payload));
      queryClient.invalidateQueries({ queryKey: ["modules"] });
    }
    if (counts.actions && getChangedAction(actionFields).length) {
      const payload = buildActionPayload(actionFields);
      await runBatch("Actions", Array.from(selActions), (id) => apiService.updateAction(id, payload));
      queryClient.invalidateQueries({ queryKey: ["actions"] });
    }
    if (counts.contacts && getChangedContact(contactFields).length) {
      const payload = buildContactPayload(contactFields);
      await runBatch("Contacts", Array.from(selContacts), (id) => apiService.updateContact(id, payload));
      queryClient.invalidateQueries({ queryKey: ["contacts"] });
    }
    if (counts.rules && getChangedRule(ruleFields).length) {
      await runBatch("Rules", Array.from(selRules), async (id) => {
        const rule = rulesById.get(id);
        if (!rule) throw new Error("rule missing");
        await apiRequest("PATCH", `/api/local/reshape-rules/${id}`, buildRulePayloadFor(rule, ruleFields));
      });
      queryClient.invalidateQueries({ queryKey: ["/api/local/reshape-rules", ORG_ID] });
    }

    setProgress(null);
    // Reset
    if (counts.journeys) { setSelJourneys(new Set()); setJourneyFields(emptyNDA); }
    if (counts.modules) { setSelModules(new Set()); setModuleFields(emptyNDA); }
    if (counts.actions) { setSelActions(new Set()); setActionFields(emptyAction); }
    if (counts.contacts) { setSelContacts(new Set()); setContactFields(emptyContact); }
    if (counts.rules) { setSelRules(new Set()); setRuleFields(emptyRule); }

    const summary = Object.entries(totals)
      .map(([k, v]) => `${k}: ${v.ok} ok${v.fail ? `, ${v.fail} failed` : ""}`)
      .join(" · ");
    const anyFail = Object.values(totals).some((v) => v.fail > 0);
    toast({
      title: anyFail ? "Batch finished with errors" : "Batch complete",
      description: summary,
      variant: anyFail ? "destructive" : "default",
    });
  };

  const runPendingDecide = async (mode: "approve" | "reject") => {
    setConfirmOpen(false); setSheetOpen(false);
    const ids = Array.from(selPending);
    setProgress({ done: 0, total: ids.length });
    let ok = 0, fail = 0;
    for (let i = 0; i < ids.length; i++) {
      try {
        await apiRequest("POST", `/api/local/pending-changes/${ids[i]}/${mode}`, {});
        ok++;
      } catch { fail++; }
      setProgress({ done: i + 1, total: ids.length });
    }
    setProgress(null);
    setSelPending(new Set());
    queryClient.invalidateQueries({ queryKey: ["/api/local/pending-changes", ORG_ID, "pending"] });
    queryClient.invalidateQueries({ queryKey: ["/api/local/pending-changes", ORG_ID, "count"] });
    toast({
      title: fail > 0 ? "Finished with errors" : (mode === "approve" ? "Pending changes approved" : "Pending changes rejected"),
      description: `${ok} ${mode === "approve" ? "approved" : "rejected"}${fail > 0 ? `, ${fail} failed` : ""}.`,
      variant: fail > 0 ? "destructive" : "default",
    });
  };

  // ===== Render: filter strip =====
  const FilterStrip = (
    <div className="border border-gray-200 bg-white rounded-lg p-3 space-y-2.5">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        <Select value={journeyFilter} onValueChange={(v) => { setJourneyFilter(v); setModuleFilter("__all__"); }} disabled={journeysLoading}>
          <SelectTrigger className="h-9 text-sm" data-testid="filter-journey">
            <SelectValue placeholder="All journeys" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">All journeys</SelectItem>
            {journeys.map((j) => (
              <SelectItem key={j.id} value={j.id}>{j.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={moduleFilter} onValueChange={setModuleFilter} disabled={modulesLoading}>
          <SelectTrigger className="h-9 text-sm" data-testid="filter-module">
            <SelectValue placeholder="All modules" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">All modules</SelectItem>
            {(journeyFilterModuleIds
              ? modules.filter((m) => journeyFilterModuleIds.has(m.id))
              : modules
            ).map((m) => (
              <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search…"
            className="pl-9 h-9 text-sm"
            data-testid="filter-search"
          />
        </div>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {ALL_TYPES.map((t) => {
          const on = visible.has(t);
          const sel = (
            t === "journeys" ? counts.journeys :
            t === "modules" ? counts.modules :
            t === "actions" ? counts.actions :
            t === "contacts" ? counts.contacts :
            t === "rules" ? counts.rules : counts.pending
          );
          return (
            <button
              key={t}
              type="button"
              onClick={() => toggleType(t)}
              data-testid={`chip-${t}`}
              className={`text-xs px-2.5 py-1 rounded-full border transition-colors flex items-center gap-1.5 ${
                on
                  ? `${TYPE_TAG_COLOR[t]} border-transparent`
                  : "bg-white text-gray-500 border-gray-200 hover:bg-gray-50"
              }`}
            >
              <span className="font-bold">{TYPE_TAG[t]}</span>
              {TYPE_LABELS[t]}
              {sel > 0 && (
                <span className="bg-white/70 text-gray-700 rounded-full px-1.5 text-[10px] font-semibold">
                  {sel}
                </span>
              )}
            </button>
          );
        })}
        {(totalSelections > 0) && (
          <button
            type="button"
            onClick={clearAllSelections}
            className="text-xs text-gray-500 hover:text-gray-700 ml-auto"
            data-testid="button-clear-all"
          >
            Clear all selections
          </button>
        )}
      </div>
    </div>
  );

  // ===== Render: list pane sections =====
  const Section = ({ type, count, children }: { type: EntityType; count: number; children: React.ReactNode }) => {
    if (!visible.has(type)) return null;
    return (
      <div
        ref={(el) => { sectionRefs.current[type] = el; }}
        className="border border-gray-200 rounded-lg overflow-hidden bg-white"
        data-testid={`section-${type}`}
      >
        {children}
        <input type="hidden" data-count={count} />
      </div>
    );
  };

  const SectionHeader = ({
    type, count, allSelected, onToggleAll,
  }: { type: EntityType; count: number; allSelected: boolean; onToggleAll: () => void }) => (
    <div className="flex items-center gap-3 px-3 py-2 bg-gray-50 border-b border-gray-200 sticky top-0 z-10">
      <Checkbox checked={allSelected && count > 0} onCheckedChange={onToggleAll} aria-label="Select all in section" data-testid={`select-all-${type}`} />
      <TypeTag type={type} />
      <h3 className="text-sm font-semibold text-gray-800">{TYPE_LABELS[type]}</h3>
      <span className="text-xs text-gray-500">({count})</span>
    </div>
  );

  // ----- Journeys section -----
  const journeysAllSelected = filteredJourneys.length > 0 && filteredJourneys.every((j) => selJourneys.has(j.id));
  const toggleAllJourneys = () => {
    const next = new Set(selJourneys);
    if (journeysAllSelected) filteredJourneys.forEach((j) => next.delete(j.id));
    else filteredJourneys.forEach((j) => next.add(j.id));
    setSelJourneys(next);
  };

  // ----- Modules section -----
  const modulesAllSelected = filteredModules.length > 0 && filteredModules.every((m) => selModules.has(m.id));
  const toggleAllModules = () => {
    const next = new Set(selModules);
    if (modulesAllSelected) filteredModules.forEach((m) => next.delete(m.id));
    else filteredModules.forEach((m) => next.add(m.id));
    setSelModules(next);
  };

  // ----- Actions section -----
  const actionsAllSelected = filteredActions.length > 0 && filteredActions.every((a) => selActions.has(a.id));
  const toggleAllActions = () => {
    const next = new Set(selActions);
    if (actionsAllSelected) filteredActions.forEach((a) => next.delete(a.id));
    else filteredActions.forEach((a) => next.add(a.id));
    setSelActions(next);
  };

  // ----- Contacts section -----
  const contactsAllSelected = filteredContacts.length > 0 && filteredContacts.every((c) => selContacts.has(c.id));
  const toggleAllContacts = () => {
    const next = new Set(selContacts);
    if (contactsAllSelected) filteredContacts.forEach((c) => next.delete(c.id));
    else filteredContacts.forEach((c) => next.add(c.id));
    setSelContacts(next);
  };

  // ----- Rules section -----
  const rulesAllSelected = filteredRules.length > 0 && filteredRules.every((r) => selRules.has(r.id));
  const toggleAllRules = () => {
    const next = new Set(selRules);
    if (rulesAllSelected) filteredRules.forEach((r) => next.delete(r.id));
    else filteredRules.forEach((r) => next.add(r.id));
    setSelRules(next);
  };

  // ----- Pending section -----
  const pendingAllSelected = filteredPending.length > 0 && filteredPending.every((p) => selPending.has(p.id));
  const toggleAllPending = () => {
    const next = new Set(selPending);
    if (pendingAllSelected) filteredPending.forEach((p) => next.delete(p.id));
    else filteredPending.forEach((p) => next.add(p.id));
    setSelPending(next);
  };

  const contactName = (c: Contact) =>
    [c.firstName, c.lastName].filter(Boolean).join(" ") || c.email || c.id;

  // ===== Editor Cards =====
  // Helper for collapsible card wrapper
  const EditorCard = ({
    type, count, onClear, children, defaultOpen = true,
  }: { type: EntityType; count: number; onClear: () => void; children: React.ReactNode; defaultOpen?: boolean }) => {
    const [open, setOpen] = useState(defaultOpen);
    if (count === 0) return null;
    return (
      <div className="border border-gray-200 rounded-lg bg-white" data-testid={`editor-${type}`}>
        <button
          type="button"
          onClick={() => setOpen(!open)}
          className="w-full flex items-center gap-2 px-3 py-2 border-b border-gray-100"
        >
          {open ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronRight className="w-4 h-4 text-gray-400" />}
          <TypeTag type={type} />
          <span className="text-sm font-semibold text-gray-800">{TYPE_LABELS[type]}</span>
          <span className="text-xs text-gray-500">({count} selected)</span>
          <span
            role="button"
            tabIndex={0}
            onClick={(e) => { e.stopPropagation(); onClear(); }}
            onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.stopPropagation(); onClear(); } }}
            className="ml-auto text-xs text-gray-400 hover:text-gray-600 flex items-center gap-1 cursor-pointer"
            data-testid={`clear-${type}`}
          >
            <X className="w-3 h-3" /> Clear
          </span>
        </button>
        {open && <div className="p-3 space-y-3">{children}</div>}
      </div>
    );
  };

  // Journey editor pivot: counts when 1 journey selected
  const journeyPivot = (() => {
    if (counts.journeys !== 1) return null;
    const j = journeysById.get(Array.from(selJourneys)[0]);
    if (!j) return null;
    const mids = journeyModuleIds(j);
    const subs = journeySubscriberCount(j);
    const rulesRefs = rules.filter((r) => {
      const m = ruleTargetModule(r);
      return m ? mids.includes(m) : false;
    });
    const hasApiCount = typeof j.subscriberCount === "number" && j.subscriberCount > 0;
    const hasAggregated = typeof subscriptionCounts[j.id] === "number";
    return (
      <div className="text-xs text-gray-600 space-y-0.5 border-t pt-2">
        <p>
          <b>{mids.length}</b> modules ·{" "}
          {countsError && !hasApiCount
            ? <span className="text-amber-600">active subscribers unavailable</span>
            : countsLoading && !hasApiCount && !hasAggregated
              ? "loading subscribers…"
              : <><b>{subs}</b> active subscribers</>}
        </p>
        <p>
          <button
            className="text-indigo-600 hover:underline"
            onClick={() => { setJourneyFilter(j.id); scrollToSection("modules"); }}
          >Show modules</button>
          {" · "}
          <button
            className="text-indigo-600 hover:underline"
            onClick={() => { setJourneyFilter(j.id); scrollToSection("contacts"); }}
          >Show subscribers</button>
          {rulesRefs.length > 0 && <>
            {" · "}
            <button
              className="text-indigo-600 hover:underline"
              onClick={() => { setSelRules(new Set(rulesRefs.map((r) => r.id))); scrollToSection("rules"); }}
            >{rulesRefs.length} rules reference its modules</button>
          </>}
        </p>
      </div>
    );
  })();

  // Module editor pivot — server-side dedupe across parent journeys when the
  // full subscriptions list isn't loaded yet, so we don't double-count
  // contacts that subscribe to multiple parent journeys of the selected
  // module. Hoisted above the pivot so the hook order stays stable.
  const singleSelectedModuleId = counts.modules === 1 ? Array.from(selModules)[0] : null;
  const modulePivotJourneyIds = useMemo(() => {
    if (!singleSelectedModuleId) return [] as string[];
    return (journeysContainingModule.get(singleSelectedModuleId) ?? [])
      .map((j) => j.id)
      .filter((id): id is string => typeof id === "string" && id.length > 0)
      .sort();
  }, [singleSelectedModuleId, journeysContainingModule]);
  const modulePivotNeedsServerDedupe =
    !!singleSelectedModuleId && !subscriptionsLoaded && modulePivotJourneyIds.length > 0;
  const {
    data: modulePivotUniqueCount,
    isLoading: modulePivotUniqueLoading,
    isError: modulePivotUniqueError,
  } = useQuery<number>({
    queryKey: ["module-pivot-unique-contacts", modulePivotJourneyIds],
    queryFn: () => apiService.getUniqueContactCountAcrossJourneys(modulePivotJourneyIds),
    enabled: modulePivotNeedsServerDedupe,
    retry: false,
  });

  const modulePivot = (() => {
    if (!singleSelectedModuleId) return null;
    const id = singleSelectedModuleId;
    const usedRules = rulesUsingModule.get(id) ?? [];
    const inJourneys = journeysContainingModule.get(id) ?? [];
    const uniqueContacts = new Set<string>();
    for (const j of inJourneys) {
      const ids = journeyContactIds.get(j.id);
      if (ids && ids.size > 0) ids.forEach((c) => uniqueContacts.add(c));
    }
    // Pick the most accurate source available without forcing a bulk download:
    //   1. The full subscriptions list (loaded), deduped locally.
    //   2. The new server-side dedupe endpoint (single deduped count).
    //   3. Per-journey aggregation summed (may double-count) as a last resort.
    let subs = uniqueContacts.size;
    let usedServerDedupe = false;
    let usedSummedFallback = false;
    if (!subscriptionsLoaded) {
      if (typeof modulePivotUniqueCount === "number") {
        subs = modulePivotUniqueCount;
        usedServerDedupe = true;
      } else if (modulePivotUniqueError) {
        // Server dedupe failed — fall back to summing per-journey counts /
        // API totals. May over-count contacts shared across parent journeys.
        let summed = 0;
        for (const j of inJourneys) {
          const aggCount = subscriptionCounts[j.id];
          if (typeof aggCount === "number") summed += aggCount;
          else if (typeof j.subscriberCount === "number" && j.subscriberCount > 0) {
            summed += j.subscriberCount;
          }
        }
        subs = summed;
        usedSummedFallback = summed > 0;
      }
    }
    const inTemplates = templates.filter((t) => Array.isArray(t.moduleIds) && t.moduleIds.includes(id));
    const stillLoading =
      (modulePivotNeedsServerDedupe && modulePivotUniqueLoading && typeof modulePivotUniqueCount !== "number") ||
      (subscriptionsLoading && uniqueContacts.size === 0);
    const showError =
      (countsError || subscriptionsError || modulePivotUniqueError) &&
      !usedServerDedupe && !usedSummedFallback && uniqueContacts.size === 0 && subs === 0;
    return (
      <div className="text-xs text-gray-600 space-y-0.5 border-t pt-2">
        <p>
          In <b>{inJourneys.length}</b> journeys ·{" "}
          {showError
            ? <span className="text-amber-600">subscribers via parent journeys unavailable</span>
            : stillLoading && subs === 0
              ? "loading subscribers…"
              : <><b>{subs}</b> subscribers via parent journeys</>}
        </p>
        <p>In <b>{inTemplates.length}</b> template{inTemplates.length === 1 ? "" : "s"}
          {inTemplates.length > 0 && (
            <>: {inTemplates.map((t, i) => (
              <span key={t.id}>{t.name ?? `Template #${t.id}`}{i < inTemplates.length - 1 ? ", " : ""}</span>
            ))}</>
          )}
        </p>
        {usedRules.length > 0 && (
          <p>
            <button
              className="text-indigo-600 hover:underline"
              onClick={() => { setSelRules(new Set(usedRules.map((r) => r.id))); scrollToSection("rules"); }}
            >Used in {usedRules.length} rule{usedRules.length === 1 ? "" : "s"}</button>
          </p>
        )}
      </div>
    );
  })();

  // Action editor pivot
  const actionPivot = (() => {
    if (counts.actions !== 1) return null;
    const id = Array.from(selActions)[0];
    const parents = actionParentModules.get(id) ?? [];
    if (parents.length === 0) return null;
    return (
      <div className="text-xs text-gray-600 space-y-0.5 border-t pt-2">
        <p>Lives in:{" "}
          {parents.map((m, i) => (
            <span key={m.id}>
              <button
                className="text-indigo-600 hover:underline"
                onClick={() => { setModuleFilter(m.id); scrollToSection("modules"); }}
              >{m.name}</button>
              {i < parents.length - 1 ? ", " : ""}
            </span>
          ))}
        </p>
      </div>
    );
  })();

  // Rule editor pivot
  const rulePivot = (() => {
    if (counts.rules !== 1) return null;
    const r = rulesById.get(Array.from(selRules)[0]);
    if (!r) return null;
    const mid = ruleTargetModule(r);
    const targetMod = mid ? modulesById.get(mid) : null;
    const ruleP = pendingByRule.get(r.id) ?? [];
    return (
      <div className="text-xs text-gray-600 space-y-0.5 border-t pt-2">
        {targetMod && (
          <p>Targets:{" "}
            <button
              className="text-indigo-600 hover:underline"
              onClick={() => { setModuleFilter(targetMod.id); scrollToSection("modules"); }}
            >{targetMod.name}</button>
          </p>
        )}
        {ruleP.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap">
            <button
              className="text-indigo-600 hover:underline"
              onClick={() => { setSelPending(new Set(ruleP.map((p) => p.id))); scrollToSection("pending"); }}
            >{ruleP.length} pending change{ruleP.length === 1 ? "" : "s"} from this rule</button>
            <Button
              size="sm"
              variant="outline"
              className="h-6 px-2 text-xs"
              data-testid="button-rule-pivot-approve-all"
              disabled={decideOne.isPending}
              onClick={() => { for (const p of ruleP) decideOne.mutate({ id: p.id, mode: "approve" }); }}
            >Approve all</Button>
            <Button
              size="sm"
              variant="outline"
              className="h-6 px-2 text-xs"
              data-testid="button-rule-pivot-reject-all"
              disabled={decideOne.isPending}
              onClick={() => { for (const p of ruleP) decideOne.mutate({ id: p.id, mode: "reject" }); }}
            >Reject all</Button>
          </div>
        )}
      </div>
    );
  })();

  // Contact editor pivot
  const contactPivot = (() => {
    if (counts.contacts !== 1) return null;
    const cid = Array.from(selContacts)[0];
    const cP = pendingByContact.get(cid) ?? [];
    return (
      <div className="text-xs text-gray-600 space-y-0.5 border-t pt-2">
        <p>
          <Link href={`/contact/${cid}`} className="text-indigo-600 hover:underline">View personal journey</Link>
        </p>
        {cP.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap">
            <button
              className="text-indigo-600 hover:underline"
              onClick={() => { setSelPending(new Set(cP.map((p) => p.id))); scrollToSection("pending"); }}
            >{cP.length} pending change{cP.length === 1 ? "" : "s"} for this contact</button>
            <Button
              size="sm"
              variant="outline"
              className="h-6 px-2 text-xs"
              data-testid="button-contact-pivot-approve-all"
              disabled={decideOne.isPending}
              onClick={() => { for (const p of cP) decideOne.mutate({ id: p.id, mode: "approve" }); }}
            >Approve all</Button>
            <Button
              size="sm"
              variant="outline"
              className="h-6 px-2 text-xs"
              data-testid="button-contact-pivot-reject-all"
              disabled={decideOne.isPending}
              onClick={() => { for (const p of cP) decideOne.mutate({ id: p.id, mode: "reject" }); }}
            >Reject all</Button>
          </div>
        )}
      </div>
    );
  })();

  // ===== Editor pane =====
  const EditorPane = (
    <div className="space-y-3">
      {totalSelections === 0 && (
        <div className="text-sm text-gray-500 italic border border-dashed border-gray-200 rounded-lg p-6 text-center">
          Select items from the list to edit them here.
        </div>
      )}

      <EditorCard type="journeys" count={counts.journeys} onClear={() => { setSelJourneys(new Set()); setJourneyFields(emptyNDA); }}>
        <FieldRow label="Name">
          <Input value={journeyFields.name} onChange={(e) => setJourneyFields({ ...journeyFields, name: e.target.value })} placeholder="Keep unchanged" data-testid="input-journey-name" />
        </FieldRow>
        <FieldRow label="Description">
          <Textarea value={journeyFields.description} onChange={(e) => setJourneyFields({ ...journeyFields, description: e.target.value })} placeholder="Keep unchanged" className="min-h-[60px]" />
        </FieldRow>
        <FieldRow label="Tags (comma-separated)">
          <Input value={journeyFields.tags} onChange={(e) => setJourneyFields({ ...journeyFields, tags: e.target.value })} placeholder="tag1, tag2, …" />
        </FieldRow>
        <FieldRow label="Archive status">
          <Select value={journeyFields.isArchived} onValueChange={(v) => setJourneyFields({ ...journeyFields, isArchived: v })}>
            <SelectTrigger><SelectValue placeholder="Keep unchanged" /></SelectTrigger>
            <SelectContent>
              <SelectItem value={UNCHANGED}>Keep unchanged</SelectItem>
              <SelectItem value="false">Active</SelectItem>
              <SelectItem value="true">Archived</SelectItem>
            </SelectContent>
          </Select>
        </FieldRow>
        {journeyPivot}
      </EditorCard>

      <EditorCard type="modules" count={counts.modules} onClear={() => { setSelModules(new Set()); setModuleFields(emptyNDA); }}>
        <FieldRow label="Name">
          <Input value={moduleFields.name} onChange={(e) => setModuleFields({ ...moduleFields, name: e.target.value })} placeholder="Keep unchanged" />
        </FieldRow>
        <FieldRow label="Description">
          <Textarea value={moduleFields.description} onChange={(e) => setModuleFields({ ...moduleFields, description: e.target.value })} placeholder="Keep unchanged" className="min-h-[60px]" />
        </FieldRow>
        <FieldRow label="Tags (comma-separated)">
          <Input value={moduleFields.tags} onChange={(e) => setModuleFields({ ...moduleFields, tags: e.target.value })} placeholder="tag1, tag2, …" />
        </FieldRow>
        <FieldRow label="Archive status">
          <Select value={moduleFields.isArchived} onValueChange={(v) => setModuleFields({ ...moduleFields, isArchived: v })}>
            <SelectTrigger><SelectValue placeholder="Keep unchanged" /></SelectTrigger>
            <SelectContent>
              <SelectItem value={UNCHANGED}>Keep unchanged</SelectItem>
              <SelectItem value="false">Active</SelectItem>
              <SelectItem value="true">Archived</SelectItem>
            </SelectContent>
          </Select>
        </FieldRow>
        {modulePivot}
      </EditorCard>

      <EditorCard type="actions" count={counts.actions} onClear={() => { setSelActions(new Set()); setActionFields(emptyAction); }}>
        <FieldRow label="Name">
          <Input value={actionFields.name} onChange={(e) => setActionFields({ ...actionFields, name: e.target.value })} placeholder="Keep unchanged" />
        </FieldRow>
        <FieldRow label="Description">
          <Textarea value={actionFields.description} onChange={(e) => setActionFields({ ...actionFields, description: e.target.value })} placeholder="Keep unchanged" className="min-h-[60px]" />
        </FieldRow>
        <FieldRow label="Tags (comma-separated)">
          <Input value={actionFields.tags} onChange={(e) => setActionFields({ ...actionFields, tags: e.target.value })} placeholder="tag1, tag2, …" />
        </FieldRow>
        <FieldRow label="Type">
          <Input value={actionFields.type} onChange={(e) => setActionFields({ ...actionFields, type: e.target.value })} placeholder="Keep unchanged" />
        </FieldRow>
        <FieldRow label="Status">
          <Input value={actionFields.status} onChange={(e) => setActionFields({ ...actionFields, status: e.target.value })} placeholder="Keep unchanged" />
        </FieldRow>
        {actionPivot}
      </EditorCard>

      <EditorCard type="contacts" count={counts.contacts} onClear={() => { setSelContacts(new Set()); setContactFields(emptyContact); }}>
        <div className="grid grid-cols-2 gap-2">
          <FieldRow label="First name">
            <Input value={contactFields.firstName} onChange={(e) => setContactFields({ ...contactFields, firstName: e.target.value })} placeholder="Keep unchanged" />
          </FieldRow>
          <FieldRow label="Last name">
            <Input value={contactFields.lastName} onChange={(e) => setContactFields({ ...contactFields, lastName: e.target.value })} placeholder="Keep unchanged" />
          </FieldRow>
        </div>
        <FieldRow label="Company">
          <Input value={contactFields.company} onChange={(e) => setContactFields({ ...contactFields, company: e.target.value })} placeholder="Keep unchanged" />
        </FieldRow>
        <FieldRow label="Title">
          <Input value={contactFields.title} onChange={(e) => setContactFields({ ...contactFields, title: e.target.value })} placeholder="Keep unchanged" />
        </FieldRow>
        <div className="grid grid-cols-2 gap-2">
          <FieldRow label="Location">
            <Input value={contactFields.location} onChange={(e) => setContactFields({ ...contactFields, location: e.target.value })} placeholder="Keep unchanged" />
          </FieldRow>
          <FieldRow label="Timezone">
            <Input value={contactFields.timezone} onChange={(e) => setContactFields({ ...contactFields, timezone: e.target.value })} placeholder="Keep unchanged" />
          </FieldRow>
        </div>
        <FieldRow label="Tags (comma-separated)">
          <Input value={contactFields.tags} onChange={(e) => setContactFields({ ...contactFields, tags: e.target.value })} placeholder="tag1, tag2, …" />
        </FieldRow>
        <FieldRow label="Status">
          <Input value={contactFields.status} onChange={(e) => setContactFields({ ...contactFields, status: e.target.value })} placeholder="Keep unchanged" />
        </FieldRow>
        {contactPivot}
      </EditorCard>

      <EditorCard type="rules" count={counts.rules} onClear={() => { setSelRules(new Set()); setRuleFields(emptyRule); }}>
        <FieldRow label="Enabled">
          <Select value={ruleFields.enabled} onValueChange={(v) => setRuleFields({ ...ruleFields, enabled: v })}>
            <SelectTrigger data-testid="select-rule-enabled"><SelectValue placeholder="Keep unchanged" /></SelectTrigger>
            <SelectContent>
              <SelectItem value={UNCHANGED}>Keep unchanged</SelectItem>
              <SelectItem value="true">Enabled</SelectItem>
              <SelectItem value="false">Disabled</SelectItem>
            </SelectContent>
          </Select>
        </FieldRow>
        <FieldRow label="Approval mode">
          <Select value={ruleFields.approvalMode} onValueChange={(v) => setRuleFields({ ...ruleFields, approvalMode: v })}>
            <SelectTrigger data-testid="select-rule-mode"><SelectValue placeholder="Keep unchanged" /></SelectTrigger>
            <SelectContent>
              <SelectItem value={UNCHANGED}>Keep unchanged</SelectItem>
              <SelectItem value="auto">Apply automatically</SelectItem>
              <SelectItem value="review">Send to review</SelectItem>
            </SelectContent>
          </Select>
        </FieldRow>
        <div className="grid grid-cols-2 gap-2">
          <FieldRow label="Priority change">
            <Select value={ruleFields.priorityMode} onValueChange={(v) => { if (isPriorityMode(v)) setRuleFields({ ...ruleFields, priorityMode: v }); }}>
              <SelectTrigger data-testid="select-priority-mode"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="unchanged">Keep unchanged</SelectItem>
                <SelectItem value="set">Set to N</SelectItem>
                <SelectItem value="shift">Shift by ±N</SelectItem>
              </SelectContent>
            </Select>
          </FieldRow>
          <FieldRow label="Value">
            <div className="flex items-center gap-1">
              {ruleFields.priorityMode === "shift" && (
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  className="h-9 px-2"
                  data-testid="button-priority-nudge-down"
                  onClick={() => {
                    const n = parseInt(ruleFields.priorityValue, 10);
                    const next = (Number.isFinite(n) ? n : 0) - 1;
                    setRuleFields({ ...ruleFields, priorityValue: String(next) });
                  }}
                >−</Button>
              )}
              <Input
                type="number"
                value={ruleFields.priorityValue}
                onChange={(e) => setRuleFields({ ...ruleFields, priorityValue: e.target.value })}
                disabled={ruleFields.priorityMode === "unchanged"}
                placeholder={ruleFields.priorityMode === "shift" ? "e.g. -10" : "e.g. 50"}
                data-testid="input-priority-value"
              />
              {ruleFields.priorityMode === "shift" && (
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  className="h-9 px-2"
                  data-testid="button-priority-nudge-up"
                  onClick={() => {
                    const n = parseInt(ruleFields.priorityValue, 10);
                    const next = (Number.isFinite(n) ? n : 0) + 1;
                    setRuleFields({ ...ruleFields, priorityValue: String(next) });
                  }}
                >+</Button>
              )}
            </div>
          </FieldRow>
        </div>
        {rulePivot}
      </EditorCard>

      {counts.pending > 0 && (
        <div className="border border-gray-200 rounded-lg bg-white" data-testid="editor-pending">
          <div className="flex items-center gap-2 px-3 py-2 border-b border-gray-100">
            <TypeTag type="pending" />
            <span className="text-sm font-semibold text-gray-800">Pending</span>
            <span className="text-xs text-gray-500">({counts.pending} selected)</span>
            <button
              type="button"
              onClick={() => setSelPending(new Set())}
              className="ml-auto text-xs text-gray-400 hover:text-gray-600 flex items-center gap-1"
            >
              <X className="w-3 h-3" /> Clear
            </button>
          </div>
          <div className="p-3 space-y-2">
            {(() => {
              const selected = pending.filter((p) => selPending.has(p.id));
              const withEdits = selected.filter((p) => {
                const cs = p.currentSequence ?? [];
                const ps = p.proposedSequence ?? [];
                if (cs.length !== ps.length) return true;
                return cs.some((m, i) => m !== ps[i]);
              }).length;
              const noOps = selected.length - withEdits;
              return (
                <p className="text-xs text-gray-500" data-testid="text-pending-summary">
                  <b>{withEdits}</b> with edits to apply
                  {noOps > 0 && <> · <b>{noOps}</b> no-op{noOps === 1 ? "" : "s"}</>}
                  {" "}({counts.pending} selected)
                </p>
              );
            })()}
            <div className="flex gap-2">
              <Button
                size="sm"
                onClick={() => { setConfirmMode("pendingApprove"); setConfirmOpen(true); }}
                className="bg-green-600 hover:bg-green-700 text-white"
                data-testid="button-pending-approve"
              >
                <CheckCircle2 className="w-4 h-4 mr-1.5" /> Approve all
              </Button>
              <Button
                size="sm" variant="outline"
                onClick={() => { setConfirmMode("pendingReject"); setConfirmOpen(true); }}
                data-testid="button-pending-reject"
              >
                <XCircle className="w-4 h-4 mr-1.5" /> Reject all
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  // ===== List pane =====
  const ListPane = (
    <div className="space-y-4">
      <Section type="journeys" count={filteredJourneys.length}>
        <SectionHeader type="journeys" count={filteredJourneys.length} allSelected={journeysAllSelected} onToggleAll={toggleAllJourneys} />
        <div className="divide-y divide-gray-100">
          {journeysLoading && <div className="p-6 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-indigo-500" /></div>}
          {!journeysLoading && filteredJourneys.length === 0 && (
            <p className="text-xs text-gray-400 text-center py-6">No journeys</p>
          )}
          {filteredJourneys.map((j) => {
            const mids = journeyModuleIds(j);
            return (
              <label key={j.id} className="flex items-start gap-3 px-3 py-2.5 hover:bg-gray-50 cursor-pointer">
                <Checkbox
                  checked={selJourneys.has(j.id)}
                  onCheckedChange={() => {
                    const n = new Set(selJourneys);
                    n.has(j.id) ? n.delete(j.id) : n.add(j.id);
                    setSelJourneys(n);
                  }}
                  className="mt-0.5"
                />
                <TypeTag type="journeys" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-gray-900 truncate">{j.name}</p>
                  <p className="text-xs text-gray-500">
                    {mids.length} modules ·{" "}
                    {countsError && typeof j.subscriberCount !== "number"
                      ? <span className="text-amber-600">subscriber count unavailable</span>
                      : countsLoading && typeof j.subscriberCount !== "number" && !(j.id in subscriptionCounts)
                        ? "loading subscribers…"
                        : `${journeySubscriberCount(j)} subscribers`}
                  </p>
                </div>
                {j.isArchived === true && (
                  <span className="text-xs px-1.5 py-0.5 rounded-full shrink-0 bg-gray-100 text-gray-500">Archived</span>
                )}
              </label>
            );
          })}
        </div>
      </Section>

      <Section type="modules" count={filteredModules.length}>
        <SectionHeader type="modules" count={filteredModules.length} allSelected={modulesAllSelected} onToggleAll={toggleAllModules} />
        <div className="divide-y divide-gray-100">
          {modulesLoading && <div className="p-6 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-indigo-500" /></div>}
          {!modulesLoading && filteredModules.length === 0 && (
            <p className="text-xs text-gray-400 text-center py-6">No modules</p>
          )}
          {filteredModules.map((m) => {
            const inJ = journeysContainingModule.get(m.id) ?? [];
            return (
              <label key={m.id} className="flex items-start gap-3 px-3 py-2.5 hover:bg-gray-50 cursor-pointer">
                <Checkbox
                  checked={selModules.has(m.id)}
                  onCheckedChange={() => {
                    const n = new Set(selModules);
                    n.has(m.id) ? n.delete(m.id) : n.add(m.id);
                    setSelModules(n);
                  }}
                  className="mt-0.5"
                />
                <TypeTag type="modules" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-gray-900 truncate">{m.name}</p>
                  {m.description && <p className="text-xs text-gray-500 truncate">{m.description}</p>}
                  {inJ.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-0.5">
                      {inJ.map((j) => (
                        <Badge key={j.id} variant="outline" className="text-xs border-indigo-200 text-indigo-700 bg-indigo-50">{j.name}</Badge>
                      ))}
                    </div>
                  )}
                  <TagBadges raw={m.tags} />
                </div>
                {m.isArchived === true && (
                  <span className="text-xs px-1.5 py-0.5 rounded-full shrink-0 bg-gray-100 text-gray-500">Archived</span>
                )}
              </label>
            );
          })}
        </div>
      </Section>

      <Section type="actions" count={filteredActions.length}>
        <SectionHeader type="actions" count={filteredActions.length} allSelected={actionsAllSelected} onToggleAll={toggleAllActions} />
        <div className="divide-y divide-gray-100">
          {actionsLoading && <div className="p-6 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-indigo-500" /></div>}
          {!actionsLoading && filteredActions.length === 0 && (
            <p className="text-xs text-gray-400 text-center py-6">No actions</p>
          )}
          {filteredActions.map((a) => {
            const parents = actionParentModules.get(a.id) ?? [];
            return (
              <label key={a.id} className="flex items-start gap-3 px-3 py-2.5 hover:bg-gray-50 cursor-pointer">
                <Checkbox
                  checked={selActions.has(a.id)}
                  onCheckedChange={() => {
                    const n = new Set(selActions);
                    n.has(a.id) ? n.delete(a.id) : n.add(a.id);
                    setSelActions(n);
                  }}
                  className="mt-0.5"
                />
                <TypeTag type="actions" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-gray-900 truncate">{a.name}</p>
                  {parents.length > 0 && (
                    <p className="text-xs text-gray-500 truncate">
                      in{" "}
                      {parents.map((m, i) => (
                        <span key={m.id}>
                          <button
                            type="button"
                            className="text-indigo-600 hover:underline"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setModuleFilter(m.id);
                              scrollToSection("modules");
                            }}
                            data-testid={`link-action-module-${m.id}`}
                          >{m.name}</button>
                          {i < parents.length - 1 ? ", " : ""}
                        </span>
                      ))}
                    </p>
                  )}
                  <TagBadges raw={a.tags} />
                </div>
                {a.type && (
                  <span className="text-xs px-1.5 py-0.5 rounded-full bg-purple-100 text-purple-700 shrink-0 capitalize">{a.type}</span>
                )}
              </label>
            );
          })}
        </div>
      </Section>

      <Section type="contacts" count={filteredContacts.length}>
        <SectionHeader type="contacts" count={filteredContacts.length} allSelected={contactsAllSelected} onToggleAll={toggleAllContacts} />
        <div className="divide-y divide-gray-100">
          {(contactsLoading || (needSubscriptions && subscriptionsLoading)) && (
            <div className="p-6 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-indigo-500" /></div>
          )}
          {!contactsLoading && !(needSubscriptions && subscriptionsLoading) && filteredContacts.length === 0 && (
            <p className="text-xs text-gray-400 text-center py-6">No contacts</p>
          )}
          {filteredContacts.map((c) => (
            <label key={c.id} className="flex items-start gap-3 px-3 py-2.5 hover:bg-gray-50 cursor-pointer">
              <Checkbox
                checked={selContacts.has(c.id)}
                onCheckedChange={() => {
                  const n = new Set(selContacts);
                  n.has(c.id) ? n.delete(c.id) : n.add(c.id);
                  setSelContacts(n);
                }}
                className="mt-0.5"
              />
              <TypeTag type="contacts" />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-gray-900 truncate">{contactName(c)}</p>
                {c.company && <p className="text-xs text-gray-400 truncate">{c.company}</p>}
                <TagBadges raw={c.tags} />
                {(() => {
                  const cJourneys = journeys.filter((j) =>
                    (journeyContactIds.get(j.id) ?? new Set<string>()).has(c.id),
                  );
                  if (cJourneys.length === 0) return null;
                  return (
                    <div className="flex flex-wrap gap-1 mt-1">
                      {cJourneys.slice(0, 3).map((j) => (
                        <span
                          key={j.id}
                          className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200"
                          data-testid={`badge-contact-journey-${c.id}-${j.id}`}
                        >{j.name}</span>
                      ))}
                      {cJourneys.length > 3 && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-gray-50 text-gray-500 border border-gray-200">
                          +{cJourneys.length - 3}
                        </span>
                      )}
                    </div>
                  );
                })()}
              </div>
              {c.status && (
                <span className="text-xs px-1.5 py-0.5 rounded-full bg-blue-100 text-blue-700 shrink-0">{c.status}</span>
              )}
            </label>
          ))}
        </div>
      </Section>

      <Section type="rules" count={filteredRules.length}>
        <SectionHeader type="rules" count={filteredRules.length} allSelected={rulesAllSelected} onToggleAll={toggleAllRules} />
        <div className="divide-y divide-gray-100">
          {rulesLoading && <div className="p-6 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-indigo-500" /></div>}
          {!rulesLoading && filteredRules.length === 0 && (
            <p className="text-xs text-gray-400 text-center py-6">No rules</p>
          )}
          {filteredRules.map((r) => (
            <label key={r.id} className="flex items-start gap-3 px-3 py-2.5 hover:bg-gray-50 cursor-pointer">
              <Checkbox
                checked={selRules.has(r.id)}
                onCheckedChange={() => {
                  const n = new Set(selRules);
                  n.has(r.id) ? n.delete(r.id) : n.add(r.id);
                  setSelRules(n);
                }}
                className="mt-0.5"
              />
              <TypeTag type="rules" />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-gray-900 truncate flex items-center gap-2">
                  {r.enabled ? (
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  ) : (
                    <span className="w-2 h-2 rounded-full bg-gray-300" />
                  )}
                  {r.name}
                  <span className={`text-[10px] px-1.5 py-0.5 rounded ${r.approvalMode === "auto" ? "bg-green-100 text-green-700" : "bg-amber-100 text-amber-700"}`}>
                    {r.approvalMode}
                  </span>
                </p>
                <p className="text-xs text-gray-600 truncate">
                  When <b>{r.triggerType}</b>{r.triggerValue ? ` "${r.triggerValue}"` : ""} → <b>{r.actionType}</b>
                </p>
              </div>
              <span className="text-[10px] text-gray-500 font-mono shrink-0">p{r.priority}</span>
            </label>
          ))}
        </div>
      </Section>

      <Section type="pending" count={filteredPending.length}>
        <SectionHeader type="pending" count={filteredPending.length} allSelected={pendingAllSelected} onToggleAll={toggleAllPending} />
        <div className="divide-y divide-gray-100">
          {(pendingLoading || (needSubscriptions && subscriptionsLoading)) && (
            <div className="p-6 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-indigo-500" /></div>
          )}
          {!pendingLoading && !(needSubscriptions && subscriptionsLoading) && filteredPending.length === 0 && (
            <p className="text-xs text-gray-400 text-center py-6">No pending changes</p>
          )}
          {filteredPending.map((p) => <PendingRow key={p.id} change={p} selected={selPending.has(p.id)} onToggle={() => {
            const n = new Set(selPending);
            n.has(p.id) ? n.delete(p.id) : n.add(p.id);
            setSelPending(n);
          }} />)}
        </div>
      </Section>
    </div>
  );

  // ===== Confirm dialog content =====
  const renderConfirmContent = () => {
    if (confirmMode === "pendingApprove" || confirmMode === "pendingReject") {
      const ids = Array.from(selPending);
      const items = ids.map((id) => pending.find((p) => p.id === id)).filter(Boolean) as PendingChange[];
      return (
        <div className="space-y-3">
          <p className="text-sm text-gray-600">
            {confirmMode === "pendingApprove" ? "Approve" : "Reject"} {items.length} pending change{items.length === 1 ? "" : "s"}.
          </p>
          {confirmMode === "pendingApprove" && items.map((c) => (
            <div key={c.id} className="border border-gray-200 rounded-lg p-3 text-xs">
              <p className="font-medium text-gray-800 mb-2">Contact <span className="font-mono">{c.contactId}</span>{c.ruleName && <> · rule <b>{c.ruleName}</b></>}</p>
              <SequenceDiff currentSequence={c.currentSequence} proposedSequence={c.proposedSequence} />
            </div>
          ))}
        </div>
      );
    }
    // Apply mode
    const sections: Array<{ type: EntityType; items: { id: string; name: string; changes: FieldEntry[]; current: any }[] }> = [];
    if (counts.journeys && getChangedNDA(journeyFields).length) {
      sections.push({
        type: "journeys",
        items: Array.from(selJourneys).map((id) => {
          const j = journeysById.get(id);
          return { id, name: j?.name ?? id, changes: getChangedNDA(journeyFields), current: j };
        }),
      });
    }
    if (counts.modules && getChangedNDA(moduleFields).length) {
      sections.push({
        type: "modules",
        items: Array.from(selModules).map((id) => {
          const m = modulesById.get(id);
          return { id, name: m?.name ?? id, changes: getChangedNDA(moduleFields), current: m };
        }),
      });
    }
    if (counts.actions && getChangedAction(actionFields).length) {
      sections.push({
        type: "actions",
        items: Array.from(selActions).map((id) => {
          const a = actionsById.get(id);
          return { id, name: a?.name ?? id, changes: getChangedAction(actionFields), current: a };
        }),
      });
    }
    if (counts.contacts && getChangedContact(contactFields).length) {
      sections.push({
        type: "contacts",
        items: Array.from(selContacts).map((id) => {
          const c = contactsById.get(id);
          return { id, name: c ? contactName(c) : id, changes: getChangedContact(contactFields), current: c };
        }),
      });
    }
    if (counts.rules && getChangedRule(ruleFields).length) {
      sections.push({
        type: "rules",
        items: Array.from(selRules).map((id) => {
          const r = rulesById.get(id);
          return { id: String(id), name: r?.name ?? String(id), changes: getChangedRule(ruleFields), current: r };
        }),
      });
    }
    return (
      <div className="space-y-4">
        {sections.map((sec) => (
          <div key={sec.type}>
            <p className="text-xs font-semibold uppercase text-gray-600 mb-2 flex items-center gap-2">
              <TypeTag type={sec.type} /> {TYPE_LABELS[sec.type]} ({sec.items.length})
            </p>
            <div className="space-y-2">
              {sec.items.map((item) => (
                <div key={item.id} className="border border-gray-200 rounded p-2 text-xs">
                  <p className="font-medium text-gray-900 mb-1">{item.name}</p>
                  <div className="space-y-0.5">
                    {item.changes.map(([field, value]) => {
                      let after: string = value;
                      let before: string;
                      if (sec.type === "rules" && field === "priority") {
                        const [mode, v] = value.split(":");
                        after = mode === "set" ? v : `${(item.current as ReshapeRule).priority} ${Number(v) >= 0 ? "+" : ""}${v} = ${Math.max(0, (item.current as ReshapeRule).priority + Number(v))}`;
                        before = String((item.current as ReshapeRule).priority);
                      } else if (sec.type === "rules" && field === "enabled") {
                        before = (item.current as ReshapeRule)?.enabled ? "true" : "false";
                        after = value;
                      } else if (sec.type === "rules" && field === "approvalMode") {
                        before = (item.current as ReshapeRule)?.approvalMode ?? "—";
                        after = value;
                      } else {
                        before = getCurrentValue(item.current, field);
                        if (field === "tags") after = value.split(",").map((t) => t.trim()).filter(Boolean).join(", ") || "—";
                      }
                      return (
                        <div key={field} className="grid grid-cols-[8rem_1fr_auto_1fr] gap-1 items-start">
                          <span className="text-gray-500">{field}</span>
                          <span className="text-gray-500 line-through break-all">{before}</span>
                          <span className="text-gray-400">→</span>
                          <span className="text-emerald-700 font-medium break-all">{after}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  };

  const applySummaryParts: string[] = [];
  if (counts.journeys && getChangedNDA(journeyFields).length) applySummaryParts.push(`${counts.journeys} journeys`);
  if (counts.modules && getChangedNDA(moduleFields).length) applySummaryParts.push(`${counts.modules} modules`);
  if (counts.actions && getChangedAction(actionFields).length) applySummaryParts.push(`${counts.actions} actions`);
  if (counts.contacts && getChangedContact(contactFields).length) applySummaryParts.push(`${counts.contacts} contacts`);
  if (counts.rules && getChangedRule(ruleFields).length) applySummaryParts.push(`${counts.rules} rules`);
  const applySummary = applySummaryParts.join(" · ");

  // ===== Layout =====
  const ApplyButton = (
    <Button
      onClick={handleApply}
      disabled={!canApply || !!progress}
      className="bg-indigo-600 hover:bg-indigo-700 text-white"
      data-testid="button-apply"
    >
      Apply changes
      {applySummary && <Badge variant="secondary" className="ml-2 bg-white/20 text-white text-xs">{applySummary}</Badge>}
    </Button>
  );

  return (
    <div className="space-y-4 h-full flex flex-col min-h-0">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          {progress && (
            <span className="text-sm text-gray-500 flex items-center gap-1.5">
              <Loader2 className="w-4 h-4 animate-spin" />
              {progress.done} of {progress.total}…
            </span>
          )}
          {!isMobile && ApplyButton}
        </div>
      </div>

      {FilterStrip}

      {backupsTypes.length > 0 && <RecentBackups types={backupsTypes} orgId={ORG_ID} />}

      {/* Two-pane layout */}
      <div className="flex-1 min-h-0 flex flex-col md:flex-row gap-4">
        <div className={`flex-1 min-h-0 overflow-y-auto pr-1 md:basis-[55%] lg:basis-[60%] xl:basis-[60%]`}>
          {ListPane}
        </div>
        {!isMobile && (
          <aside className="md:basis-[45%] lg:basis-[40%] xl:basis-[40%] min-h-0 overflow-y-auto pl-1 border-l border-gray-200 md:pl-4">
            {EditorPane}
          </aside>
        )}
      </div>

      {/* Mobile sticky bar */}
      {isMobile && totalSelections > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-3 z-30 shadow-lg flex items-center gap-2">
          <span className="text-sm font-medium text-gray-700">{totalSelections} selected</span>
          <Button
            size="sm" className="ml-auto bg-indigo-600 hover:bg-indigo-700 text-white"
            onClick={() => setSheetOpen(true)}
            data-testid="button-open-sheet"
          >
            Edit
          </Button>
        </div>
      )}

      {/* Mobile bottom sheet */}
      <Sheet open={isMobile && sheetOpen} onOpenChange={setSheetOpen}>
        <SheetContent side="bottom" className="max-h-[85vh] overflow-y-auto">
          <SheetHeader>
            <SheetTitle>Edit selected items</SheetTitle>
          </SheetHeader>
          <div className="mt-3 space-y-3">
            {EditorPane}
            <div className="pt-2 border-t border-gray-200">{ApplyButton}</div>
          </div>
        </SheetContent>
      </Sheet>

      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirmMode === "apply" && "Confirm bulk update"}
              {confirmMode === "pendingApprove" && "Approve pending changes"}
              {confirmMode === "pendingReject" && "Reject pending changes"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirmMode === "apply" && (applySummary ? `${applySummary} will be updated.` : "Review the changes below.")}
              {confirmMode === "pendingApprove" && "Each change will be applied immediately."}
              {confirmMode === "pendingReject" && "Each change will be discarded."}
            </AlertDialogDescription>
          </AlertDialogHeader>

          <div className="rounded-md bg-blue-50 border border-blue-200 p-2 text-xs text-blue-900 my-2">
            A backup of each editable item is saved automatically before changes are applied.
          </div>

          {renderConfirmContent()}

          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (confirmMode === "apply") runApply();
                else if (confirmMode === "pendingApprove") runPendingDecide("approve");
                else runPendingDecide("reject");
              }}
              className="bg-indigo-600 hover:bg-indigo-700 text-white"
              data-testid="button-confirm"
            >
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Pending row with collapsible diff
// ---------------------------------------------------------------------------

function PendingRow({ change, selected, onToggle }: { change: PendingChange; selected: boolean; onToggle: () => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="px-3 py-2 hover:bg-gray-50">
      <label className="flex items-start gap-3 cursor-pointer">
        <Checkbox checked={selected} onCheckedChange={onToggle} className="mt-0.5" />
        <TypeTag type="pending" />
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-gray-900 truncate">
            <span className="font-mono text-xs text-gray-600">{change.contactId}</span>
            {change.ruleName && <span className="ml-2 text-xs text-gray-500">· {change.ruleName}</span>}
          </p>
          {change.aiReason && <p className="text-xs text-gray-500 truncate">{change.aiReason}</p>}
        </div>
        <button
          type="button"
          onClick={(e) => { e.preventDefault(); setOpen(!open); }}
          className="text-xs text-indigo-600 hover:text-indigo-800 shrink-0"
        >
          {open ? "Hide" : "Diff"}
        </button>
      </label>
      {open && (
        <div className="mt-2 ml-9">
          <SequenceDiff currentSequence={change.currentSequence} proposedSequence={change.proposedSequence} />
        </div>
      )}
    </div>
  );
}

