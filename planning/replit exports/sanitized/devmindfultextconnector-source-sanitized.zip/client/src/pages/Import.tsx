import React, { useState, useMemo, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { apiService, type Action, type Module, type Journey, type Contact, type Subscription } from "@/lib/api";
import {
  parseImportMarkdown, serializeExportMarkdown, serializeExportJson,
  type ParsedImport, type ParsedModule, type ParsedActionRef,
  type ExportModule, type ExportJourney, type ExportContact,
} from "@/lib/markdownImport";
import {
  Upload, FileText, AlertTriangle, CheckCircle2, X, Plus, Trash2, Loader2,
  ChevronUp, ChevronDown, Download, Copy, FileDown,
} from "lucide-react";

const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

const SAMPLE = `Journey: Welcome Series
Schedule: Mon, Wed, Fri
Time: 9:00 AM
Description: 3-week onboarding for new subscribers
Tags: welcome, onboarding

## Day 1 — Greeting
Tags: welcome
Actions: send_followup on: yes, y, sure

Welcome aboard! We're so glad you're here.
Reply YES to confirm.
[Action: send_followup on: yes, y, sure]

---

A quick tip: reply STOP at any time to opt out.
[Action: log_optout]
[Keywords: stop, end, quit]

## Day 2 — Tips & Tricks
Tags: tips

Here's how to get the most out of your first week...

---

Bonus tip — check your settings page for personalization.
`;

export default function Import() {
  const { toast } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);

  const [rawText, setRawText] = useState("");
  const [parsed, setParsed] = useState<ParsedImport | null>(null);
  const [targetJourneyId, setTargetJourneyId] = useState<string>("__new__");
  const [importing, setImporting] = useState(false);
  const [importLog, setImportLog] = useState<string[]>([]);

  const { data: journeys = [] } = useQuery<Journey[]>({
    queryKey: ["journeys"],
    queryFn: () => apiService.getJourneys(),
  });

  const { data: actions = [] } = useQuery<Action[]>({
    queryKey: ["actions"],
    queryFn: () => apiService.getActions(),
  });

  const actionByKey = useMemo(() => {
    const map = new Map<string, Action>();
    for (const a of actions) {
      map.set(a.id, a);
      map.set(a.name.toLowerCase(), a);
    }
    return map;
  }, [actions]);

  const lookupAction = (name: string): Action | undefined =>
    actionByKey.get(name) || actionByKey.get(name.toLowerCase());

  const resolveActionRefs = (refs: ParsedActionRef[]) => {
    const resolved: { id: string; name: string; keywords: string[] }[] = [];
    const missing: string[] = [];
    for (const r of refs) {
      const found = lookupAction(r.name);
      if (found) resolved.push({ id: found.id, name: r.name, keywords: r.keywords });
      else missing.push(r.name);
    }
    return { resolved, missing };
  };

  const handleFile = async (file: File) => {
    const txt = await file.text();
    setRawText(txt);
    setParsed(parseImportMarkdown(txt));
    setImportLog([]);
  };

  const handleParseText = () => {
    setParsed(parseImportMarkdown(rawText));
    setImportLog([]);
  };

  const updateModule = (idx: number, patch: Partial<ParsedModule>) => {
    if (!parsed) return;
    const next = { ...parsed, modules: [...parsed.modules] };
    next.modules[idx] = { ...next.modules[idx], ...patch };
    setParsed(next);
  };

  const removeModule = (idx: number) => {
    if (!parsed) return;
    const next = { ...parsed, modules: parsed.modules.filter((_, i) => i !== idx) };
    setParsed(next);
  };

  const toggleScheduleDay = (day: string) => {
    if (!parsed) return;
    const has = parsed.journey.schedule.includes(day);
    setParsed({
      ...parsed,
      journey: {
        ...parsed.journey,
        schedule: has
          ? parsed.journey.schedule.filter((d) => d !== day)
          : [...parsed.journey.schedule, day],
      },
    });
  };

  const importMutation = useMutation({
    mutationFn: async () => {
      if (!parsed) throw new Error("Nothing to import");
      const log: string[] = [];
      const createdModuleIds: string[] = [];
      let moduleFailures = 0;
      let journeyFailed = false;

      // 0. Pre-pass: collect every unique action name referenced across all modules/texts.
      //    Auto-create any that don't exist yet so they're available when we build the payload.
      const allActionNames = new Set<string>();
      for (const mod of parsed.modules) {
        for (const a of mod.actions) allActionNames.add(a.name);
        for (const t of mod.texts) {
          for (const a of t.actions) allActionNames.add(a.name);
        }
      }

      // name (lower) → id for actions we just created
      const extraActions = new Map<string, string>();
      for (const name of Array.from(allActionNames)) {
        if (!lookupAction(name)) {
          try {
            const created = await apiService.createAction({ name });
            if (created?.id) {
              extraActions.set(name.toLowerCase(), created.id);
              log.push(`✓ Auto-created action "${name}" (id: ${created.id})`);
            } else {
              log.push(`⚠ Could not auto-create action "${name}" — references will be skipped`);
            }
          } catch (err: any) {
            log.push(`⚠ Could not auto-create action "${name}": ${err?.message || "unknown error"} — references will be skipped`);
          }
        }
      }
      if (allActionNames.size > 0) setImportLog([...log]);

      // Enhanced resolve: checks existing actions first, then newly created ones.
      const resolveWithExtras = (refs: ParsedActionRef[]) => {
        const resolved: { id: string; name: string; keywords: string[] }[] = [];
        const missing: string[] = [];
        for (const r of refs) {
          const existing = lookupAction(r.name);
          if (existing) {
            resolved.push({ id: existing.id, name: r.name, keywords: r.keywords });
          } else {
            const extraId = extraActions.get(r.name.toLowerCase());
            if (extraId) {
              resolved.push({ id: extraId, name: r.name, keywords: r.keywords });
            } else {
              missing.push(r.name);
            }
          }
        }
        return { resolved, missing };
      };

      // 1. Create modules
      for (const mod of parsed.modules) {
        const modActions = resolveWithExtras(mod.actions);
        if (modActions.missing.length) {
          log.push(`⚠ Module "${mod.name}": could not resolve action(s) — ${modActions.missing.join(", ")}`);
        }

        const texts = mod.texts.map((t) => {
          const r = resolveWithExtras(t.actions);
          if (r.missing.length) {
            log.push(`⚠ Module "${mod.name}" text: could not resolve action(s) — ${r.missing.join(", ")}`);
          }
          return {
            content: t.content,
            keywords: t.keywords,
            actions: r.resolved.map((a) => ({ actionId: a.id, keywords: a.keywords })),
          };
        });

        const payload: Partial<Module> & {
          actions?: { actionId: string; keywords: string[] }[];
        } = {
          name: mod.name,
          description: mod.description,
          tags: mod.tags,
          texts,
        };
        if (modActions.resolved.length) {
          payload.actions = modActions.resolved.map((a) => ({ actionId: a.id, keywords: a.keywords }));
        }

        try {
          const created = await apiService.createModule(payload);
          if (created?.id) {
            createdModuleIds.push(created.id);
            log.push(`✓ Created module "${mod.name}" (id: ${created.id})`);
          } else {
            moduleFailures++;
            log.push(`⚠ Module "${mod.name}" — API returned no id`);
          }
        } catch (err: any) {
          moduleFailures++;
          log.push(`✗ Failed to create module "${mod.name}": ${err?.message || "unknown error"}`);
        }
        setImportLog([...log]);
      }

      // 2. Attach to journey (existing or new) — only if at least one module landed
      if (createdModuleIds.length > 0) {
        try {
          if (targetJourneyId === "__new__") {
            const created = await apiService.createJourney({
              name: parsed.journey.name || "Imported Journey",
              description: parsed.journey.description,
              tags: parsed.journey.tags,
              launchDays: parsed.journey.schedule,
              time: parsed.journey.time,
              moduleIds: createdModuleIds,
            });
            log.push(`✓ Created journey "${created?.name || parsed.journey.name}" with ${createdModuleIds.length} module(s)`);
          } else {
            // Re-fetch to avoid clobbering changes made since the journeys list loaded.
            const fresh = await apiService.getJourney(targetJourneyId);
            const merged = Array.from(new Set([...(fresh?.moduleIds || []), ...createdModuleIds]));
            await apiService.updateJourney(targetJourneyId, { moduleIds: merged });
            log.push(`✓ Added ${createdModuleIds.length} module(s) to journey "${fresh?.name}"`);
          }
        } catch (err: any) {
          journeyFailed = true;
          log.push(`✗ Failed to update journey: ${err?.message || "unknown error"}`);
          log.push(`  ↳ ${createdModuleIds.length} module(s) were created but not attached. They are visible on the Modules page.`);
        }
        setImportLog([...log]);
      } else if (parsed.modules.length > 0) {
        log.push("✗ No modules were created — journey was not touched.");
        setImportLog([...log]);
      }

      const result = { created: createdModuleIds.length, moduleFailures, journeyFailed, attempted: parsed.modules.length };
      // Throw on hard failure so onError fires with an accurate toast.
      if (parsed.modules.length > 0 && createdModuleIds.length === 0) {
        throw new Error("All module creations failed. See log for details.");
      }
      if (journeyFailed) {
        throw new Error("Modules created, but journey attach failed. See log.");
      }
      return result;
    },
    onSuccess: (res) => {
      queryClient.invalidateQueries({ queryKey: ["modules"] });
      queryClient.invalidateQueries({ queryKey: ["journeys"] });
      queryClient.invalidateQueries({ queryKey: ["actions"] });
      const partial = res.moduleFailures > 0;
      toast({
        title: partial ? "Import finished with issues" : "Import complete",
        description: `Created ${res.created}/${res.attempted} module(s)${partial ? `, ${res.moduleFailures} failed` : ""}.`,
        variant: partial ? "destructive" : "default",
      });
    },
    onError: (err: any) => {
      queryClient.invalidateQueries({ queryKey: ["modules"] });
      queryClient.invalidateQueries({ queryKey: ["journeys"] });
      queryClient.invalidateQueries({ queryKey: ["actions"] });
      toast({ title: "Import failed", description: err?.message || "Unknown error", variant: "destructive" });
    },
    onSettled: () => setImporting(false),
  });

  const startImport = () => {
    setImporting(true);
    setImportLog([]);
    importMutation.mutate();
  };

  const totalTexts = parsed?.modules.reduce((s, m) => s + m.texts.length, 0) ?? 0;

  return (
    <div className="space-y-6 max-w-5xl">
      <Tabs defaultValue="import" className="space-y-6">
        <TabsList>
          <TabsTrigger value="import" data-testid="tab-import">Import</TabsTrigger>
          <TabsTrigger value="export" data-testid="tab-export">Export</TabsTrigger>
        </TabsList>

        <TabsContent value="import" className="space-y-6 mt-0">
      {/* Step 1: input */}
      <Card className="card-mindful">
        <CardContent className="p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">1. Provide your file</h3>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => { setRawText(SAMPLE); setParsed(parseImportMarkdown(SAMPLE)); }}
              >
                Load sample
              </Button>
              <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
                <Upload className="w-4 h-4 mr-1.5" /> Upload .md
              </Button>
              <input
                ref={fileRef}
                type="file"
                accept=".md,.markdown,.txt,text/markdown,text/plain"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
              />
            </div>
          </div>

          <Textarea
            value={rawText}
            onChange={(e) => setRawText(e.target.value)}
            placeholder="Paste markdown here, or upload a file above…"
            className="font-mono text-xs min-h-[180px]"
          />

          <div className="flex justify-end">
            <Button onClick={handleParseText} disabled={!rawText.trim()}>
              <FileText className="w-4 h-4 mr-1.5" />
              Parse
            </Button>
          </div>

          <details className="text-xs text-gray-500">
            <summary className="cursor-pointer hover:text-gray-700">Format guide</summary>
            <pre className="mt-2 p-3 bg-gray-50 rounded text-[11px] overflow-x-auto whitespace-pre-wrap">{`Journey: Welcome Series
Schedule: Mon, Wed, Fri
Time: 9:00 AM
Description: optional
Tags: welcome, onboarding

## Module Name
Tags: optional, tags
Actions: action_name_or_id
Description: optional

First text body.
[Action: send_followup on: yes, y, sure]

---

Second text body.
[Action: log_optout]
[Keywords: stop, end, quit]`}</pre>
            <p className="mt-2 text-[11px] text-gray-500">
              Keywords are the reply words that trigger the action. Use either the inline form
              <code className="mx-1 px-1 bg-gray-100 rounded">[Action: name on: kw1, kw2]</code>
              or a separate <code className="mx-1 px-1 bg-gray-100 rounded">[Keywords: kw1, kw2]</code> line
              (which applies to all actions on that text).
            </p>
          </details>
        </CardContent>
      </Card>

      {/* Step 2: preview / edit */}
      {parsed && (
        <Card className="card-mindful">
          <CardContent className="p-5 space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-gray-900">2. Review &amp; adjust</h3>
              <div className="text-xs text-gray-500">
                {parsed.modules.length} module(s) · {totalTexts} text(s)
              </div>
            </div>

            {parsed.warnings.length > 0 && (
              <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800 space-y-1">
                {parsed.warnings.map((w, i) => (
                  <div key={i} className="flex items-start gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                    <span>{w}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Journey block */}
            <div className="space-y-3 border border-gray-200 rounded-lg p-4 bg-gray-50/50">
              <div className="text-xs font-semibold uppercase tracking-wide text-gray-500">Journey</div>

              <div>
                <Label className="text-xs">Attach to</Label>
                <Select value={targetJourneyId} onValueChange={setTargetJourneyId}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__new__">+ Create new journey</SelectItem>
                    {journeys.map((j) => (
                      <SelectItem key={j.id} value={j.id}>{j.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {targetJourneyId === "__new__" && (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs">Journey name</Label>
                      <Input
                        className="mt-1"
                        value={parsed.journey.name}
                        onChange={(e) => setParsed({ ...parsed, journey: { ...parsed.journey, name: e.target.value } })}
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Time</Label>
                      <Input
                        className="mt-1"
                        placeholder="9:00 AM"
                        value={parsed.journey.time || ""}
                        onChange={(e) => setParsed({ ...parsed, journey: { ...parsed.journey, time: e.target.value } })}
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="text-xs">Description</Label>
                    <Input
                      className="mt-1"
                      value={parsed.journey.description || ""}
                      onChange={(e) => setParsed({ ...parsed, journey: { ...parsed.journey, description: e.target.value } })}
                    />
                  </div>

                  <div>
                    <Label className="text-xs">Schedule (launch days)</Label>
                    <div className="flex flex-wrap gap-2 mt-1.5">
                      {DAYS.map((d) => {
                        const on = parsed.journey.schedule.includes(d);
                        return (
                          <button
                            key={d}
                            type="button"
                            onClick={() => toggleScheduleDay(d)}
                            className={`text-xs px-2.5 py-1 rounded-full border transition ${
                              on
                                ? "bg-indigo-600 text-white border-indigo-600"
                                : "bg-white text-gray-700 border-gray-300 hover:bg-gray-50"
                            }`}
                          >
                            {d.slice(0, 3)}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Modules */}
            <div className="space-y-3">
              <div className="text-xs font-semibold uppercase tracking-wide text-gray-500">
                Modules to create
              </div>

              {parsed.modules.map((mod, idx) => (
                <div key={idx} className="border border-gray-200 rounded-lg p-4 space-y-3 bg-white">
                  <div className="flex items-start gap-2">
                    <Input
                      className="flex-1 font-medium"
                      value={mod.name}
                      onChange={(e) => updateModule(idx, { name: e.target.value })}
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeModule(idx)}
                      className="text-gray-400 hover:text-red-600"
                      title="Remove from import"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs">Tags (comma-separated)</Label>
                      <Input
                        className="mt-1"
                        value={mod.tags.join(", ")}
                        onChange={(e) =>
                          updateModule(idx, {
                            tags: e.target.value.split(",").map((s) => s.trim()).filter(Boolean),
                          })
                        }
                      />
                    </div>
                    <div>
                      <Label className="text-xs">
                        Module-level actions
                        <span className="text-gray-400 font-normal"> (name or id, optional "on: kw1, kw2")</span>
                      </Label>
                      <Input
                        className="mt-1"
                        placeholder="send_followup on: yes, y"
                        value={mod.actions
                          .map((a) => (a.keywords.length ? `${a.name} on: ${a.keywords.join(", ")}` : a.name))
                          .join(", ")}
                        onChange={(e) => {
                          // Light parser: split by commas at top level; each chunk may have "on:" suffix.
                          const chunks = e.target.value
                            .split(/,(?![^[]*\])/)
                            .map((s) => s.trim())
                            .filter(Boolean);
                          const next: ParsedActionRef[] = chunks.map((c) => {
                            const m = /^(.+?)\s+on\s*:\s*(.+)$/i.exec(c);
                            if (m) {
                              return {
                                name: m[1].trim(),
                                keywords: m[2].split(",").map((s) => s.trim()).filter(Boolean),
                              };
                            }
                            return { name: c, keywords: [] };
                          });
                          updateModule(idx, { actions: next });
                        }}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs">Texts ({mod.texts.length})</Label>
                    {mod.texts.map((t, ti) => {
                      const setText = (patch: Partial<typeof t>) => {
                        const nextTexts = [...mod.texts];
                        nextTexts[ti] = { ...t, ...patch };
                        updateModule(idx, { texts: nextTexts });
                      };
                      const moveText = (dir: -1 | 1) => {
                        const target = ti + dir;
                        if (target < 0 || target >= mod.texts.length) return;
                        const nextTexts = [...mod.texts];
                        [nextTexts[ti], nextTexts[target]] = [nextTexts[target], nextTexts[ti]];
                        updateModule(idx, { texts: nextTexts });
                      };
                      const removeText = () => {
                        updateModule(idx, { texts: mod.texts.filter((_, i) => i !== ti) });
                      };
                      const updateActionAt = (ai: number, patch: Partial<ParsedActionRef>) => {
                        const nextActions = [...t.actions];
                        nextActions[ai] = { ...nextActions[ai], ...patch };
                        setText({ actions: nextActions });
                      };
                      const removeActionAt = (ai: number) => {
                        setText({ actions: t.actions.filter((_, i) => i !== ai) });
                      };
                      return (
                        <div key={ti} className="border border-gray-100 rounded p-2.5 bg-gray-50 space-y-2">
                          <div className="flex items-center justify-between text-[11px] text-gray-500">
                            <span>Text {ti + 1}</span>
                            <div className="flex items-center gap-0.5">
                              <Button variant="ghost" size="sm" className="h-6 w-6 p-0" disabled={ti === 0} onClick={() => moveText(-1)} title="Move up">
                                <ChevronUp className="w-3.5 h-3.5" />
                              </Button>
                              <Button variant="ghost" size="sm" className="h-6 w-6 p-0" disabled={ti === mod.texts.length - 1} onClick={() => moveText(1)} title="Move down">
                                <ChevronDown className="w-3.5 h-3.5" />
                              </Button>
                              <Button variant="ghost" size="sm" className="h-6 w-6 p-0 text-gray-400 hover:text-red-600" onClick={removeText} title="Remove text">
                                <Trash2 className="w-3.5 h-3.5" />
                              </Button>
                            </div>
                          </div>

                          <Textarea
                            value={t.content}
                            onChange={(e) => setText({ content: e.target.value })}
                            className="text-sm min-h-[60px] bg-white"
                          />

                          {/* Per-action keyword editor */}
                          {t.actions.map((a, ai) => {
                            const known = !!lookupAction(a.name);
                            return (
                              <div key={ai} className="flex flex-col sm:flex-row gap-1.5 items-start sm:items-center bg-white border border-gray-100 rounded p-1.5">
                                <Badge
                                  variant={known ? "secondary" : "outline"}
                                  className={`shrink-0 ${known ? "" : "border-blue-300 text-blue-700"}`}
                                  title={known ? "Action found in your account" : "Action not found — will be auto-created on import"}
                                >
                                  {a.name}{!known && " (new)"}
                                </Badge>
                                <span className="text-[11px] text-gray-400 shrink-0">on:</span>
                                <Input
                                  className="h-7 text-xs flex-1"
                                  placeholder="yes, y, sure"
                                  value={a.keywords.join(", ")}
                                  onChange={(e) =>
                                    updateActionAt(ai, {
                                      keywords: e.target.value.split(",").map((s) => s.trim()).filter(Boolean),
                                    })
                                  }
                                />
                                <Button
                                  variant="ghost" size="sm"
                                  className="h-6 w-6 p-0 text-gray-400 hover:text-red-600"
                                  onClick={() => removeActionAt(ai)}
                                  title="Remove action"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </Button>
                              </div>
                            );
                          })}

                          {/* Add action */}
                          <div className="flex flex-wrap items-center gap-1.5">
                            <Select
                              value=""
                              onValueChange={(name) => {
                                if (!name) return;
                                setText({ actions: [...t.actions, { name, keywords: [] }] });
                              }}
                            >
                              <SelectTrigger className="h-7 text-xs w-auto min-w-[140px]">
                                <SelectValue placeholder="+ Add action" />
                              </SelectTrigger>
                              <SelectContent>
                                {actions.length === 0 && (
                                  <SelectItem value="__none__" disabled>No actions exist yet</SelectItem>
                                )}
                                {actions.map((a) => (
                                  <SelectItem key={a.id} value={a.name}>{a.name}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <span className="text-[11px] text-gray-400">
                              Actions marked <span className="text-blue-600 font-medium">(new)</span> will be auto-created on import.
                            </span>
                          </div>
                        </div>
                      );
                    })}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        updateModule(idx, {
                          texts: [...mod.texts, { content: "", actions: [], keywords: [] }],
                        })
                      }
                    >
                      <Plus className="w-3.5 h-3.5 mr-1" /> Add text
                    </Button>
                  </div>
                </div>
              ))}

              {parsed.modules.length === 0 && (
                <div className="text-sm text-gray-500 italic text-center py-6">
                  No modules parsed.
                </div>
              )}
            </div>

            {/* Action button */}
            <div className="flex items-center justify-between pt-2 border-t border-gray-100">
              <div className="text-xs text-gray-500">
                Will create {parsed.modules.length} module(s)
                {targetJourneyId === "__new__"
                  ? ` and a new journey "${parsed.journey.name || "Imported Journey"}"`
                  : ` and attach to "${journeys.find((j) => j.id === targetJourneyId)?.name || ""}"`}
                .
              </div>
              <Button
                onClick={startImport}
                disabled={importing || parsed.modules.length === 0}
                className="btn-mindful"
              >
                {importing ? (
                  <><Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> Importing…</>
                ) : (
                  <><CheckCircle2 className="w-4 h-4 mr-1.5" /> Run import</>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Import log */}
      {importLog.length > 0 && (
        <Card className="card-mindful">
          <CardContent className="p-5 space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-gray-900">Import log</h3>
              <Button variant="ghost" size="sm" onClick={() => setImportLog([])}>
                <X className="w-4 h-4" />
              </Button>
            </div>
            <div className="font-mono text-xs space-y-1 max-h-72 overflow-y-auto">
              {importLog.map((line, i) => (
                <div
                  key={i}
                  className={
                    line.startsWith("✓") ? "text-green-700"
                    : line.startsWith("✗") ? "text-red-700"
                    : line.startsWith("⚠") ? "text-amber-700"
                    : "text-gray-600"
                  }
                >
                  {line}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
        </TabsContent>

        <TabsContent value="export" className="space-y-6 mt-0">
          <ExportPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// =====================================================================
// Export panel — three independent multi-select sections (journeys,
// modules, contacts). Each section can be toggled on/off and individually
// selected from. Format auto-locks to JSON when contacts are included
// because markdown can't represent contacts.
// =====================================================================

type ExportFormat = "markdown" | "json";

function ExportPanel() {
  const { toast } = useToast();
  const [format, setFormat] = useState<ExportFormat>("markdown");

  // Per-section "include" toggles + selection sets.
  const [includeJourneys, setIncludeJourneys] = useState(false);
  const [includeModules, setIncludeModules] = useState(true);
  const [includeContacts, setIncludeContacts] = useState(false);
  const [selectedJourneyIds, setSelectedJourneyIds] = useState<Set<string>>(new Set());
  const [selectedModuleIds, setSelectedModuleIds] = useState<Set<string>>(new Set());
  const [selectedContactIds, setSelectedContactIds] = useState<Set<string>>(new Set());

  // Per-section search filters.
  const [journeySearch, setJourneySearch] = useState("");
  const [moduleSearch, setModuleSearch] = useState("");
  const [contactSearch, setContactSearch] = useState("");

  const modulesQuery = useQuery<Module[]>({
    queryKey: ["modules"],
    queryFn: () => apiService.getModules(),
  });
  const journeysQuery = useQuery<Journey[]>({
    queryKey: ["journeys"],
    queryFn: () => apiService.getJourneys(),
  });
  const actionsQuery = useQuery<Action[]>({
    queryKey: ["actions"],
    queryFn: () => apiService.getActions(),
  });
  const contactsQuery = useQuery<Contact[]>({
    queryKey: ["contacts"],
    queryFn: () => apiService.getContacts(),
    enabled: includeContacts,
  });
  const subscriptionsQuery = useQuery<Subscription[]>({
    queryKey: ["subscriptions"],
    queryFn: () => apiService.getSubscriptions(),
    enabled: includeContacts,
  });

  const modules = modulesQuery.data ?? [];
  const journeys = journeysQuery.data ?? [];
  const actions = actionsQuery.data ?? [];
  const contacts = contactsQuery.data ?? [];
  const subscriptions = subscriptionsQuery.data ?? [];

  const isLoading =
    modulesQuery.isLoading || journeysQuery.isLoading || actionsQuery.isLoading ||
    (includeContacts && (contactsQuery.isLoading || subscriptionsQuery.isLoading));
  const loadError =
    modulesQuery.error || journeysQuery.error || actionsQuery.error ||
    (includeContacts && (contactsQuery.error || subscriptionsQuery.error));

  useEffect(() => {
    if (!loadError) return;
    toast({
      title: "Couldn't load export data",
      description: (loadError as Error)?.message || "Something went wrong fetching the export data.",
      variant: "destructive",
    });
  }, [loadError, toast]);

  // Force JSON when contacts are included — markdown has no spec for them.
  // Remember the user's preferred format so toggling contacts off restores it,
  // rather than silently leaving them stuck on JSON.
  const preContactsFormat = useRef<ExportFormat>("markdown");
  useEffect(() => {
    if (includeContacts) {
      if (format === "markdown") {
        preContactsFormat.current = "markdown";
        setFormat("json");
      }
    } else {
      if (preContactsFormat.current === "markdown" && format === "json") {
        setFormat("markdown");
      }
    }
  }, [includeContacts, format]);

  const actionsById = useMemo(() => {
    const m = new Map<string, { id: string; name: string }>();
    for (const a of actions) m.set(a.id, { id: a.id, name: a.name });
    return m;
  }, [actions]);

  const modulesById = useMemo(() => {
    const m = new Map<string, Module>();
    for (const mod of modules) m.set(mod.id, mod);
    return m;
  }, [modules]);

  const journeyNameById = useMemo(() => {
    const m = new Map<string, string>();
    for (const j of journeys) m.set(j.id, j.name);
    return m;
  }, [journeys]);

  // contactId → unique list of journey names where the subscription is active.
  // Active = anything not in {inactive, cancelled, canceled, completed}.
  const contactActiveJourneys = useMemo(() => {
    const inactive = new Set(["inactive", "cancelled", "canceled", "completed"]);
    const out = new Map<string, string[]>();
    for (const sub of subscriptions) {
      if (!sub.contactId || !sub.journeyId) continue;
      const status = (sub.status || "").toLowerCase();
      if (inactive.has(status)) continue;
      const name = journeyNameById.get(sub.journeyId);
      if (!name) continue;
      const list = out.get(sub.contactId) ?? [];
      if (!list.includes(name)) list.push(name);
      out.set(sub.contactId, list);
    }
    return out;
  }, [subscriptions, journeyNameById]);

  // Apply per-section search filter (case-insensitive substring match).
  const filteredJourneys = useMemo(() => {
    const q = journeySearch.trim().toLowerCase();
    if (!q) return journeys;
    return journeys.filter((j) => j.name.toLowerCase().includes(q));
  }, [journeys, journeySearch]);

  const filteredModules = useMemo(() => {
    const q = moduleSearch.trim().toLowerCase();
    if (!q) return modules;
    return modules.filter((m) => m.name.toLowerCase().includes(q));
  }, [modules, moduleSearch]);

  const filteredContacts = useMemo(() => {
    const q = contactSearch.trim().toLowerCase();
    if (!q) return contacts;
    return contacts.filter((c) => {
      const name = `${c.firstName ?? ""} ${c.lastName ?? ""}`.toLowerCase();
      const email = (c.email ?? "").toLowerCase();
      const tags = (c.tags ?? []).join(" ").toLowerCase();
      return name.includes(q) || email.includes(q) || tags.includes(q);
    });
  }, [contacts, contactSearch]);

  // Build the export payload from the active selections.
  const { exportJourneys, exportModules, exportContacts, missingModuleWarnings } = useMemo(() => {
    const eJourneys: ExportJourney[] = includeJourneys
      ? Array.from(selectedJourneyIds)
          .map((id) => journeys.find((j) => j.id === id))
          .filter((j): j is Journey => !!j)
          .map((j) => ({
            id: j.id,
            name: j.name,
            description: j.description,
            tags: j.tags,
            launchDays: j.launchDays || j.schedule,
            time: j.time,
            moduleIds: j.moduleIds || j.moduleIDs || [],
          }))
      : [];

    // Modules to ship: explicit module selection + every module belonging
    // to a selected journey (so journeys are self-contained on import).
    const moduleIdSet = new Set<string>();
    if (includeModules) {
      for (const id of Array.from(selectedModuleIds)) moduleIdSet.add(id);
    }
    for (const ej of eJourneys) {
      for (const mid of ej.moduleIds || []) moduleIdSet.add(mid);
    }

    // Track journey→missing-module references so we can warn the user.
    const warnings: string[] = [];
    for (const ej of eJourneys) {
      const missing = (ej.moduleIds || []).filter((mid) => !modulesById.has(mid));
      if (missing.length > 0) {
        warnings.push(`Journey "${ej.name}" references ${missing.length} module(s) that no longer exist — they'll be skipped.`);
      }
    }

    const eModules: ExportModule[] = Array.from(moduleIdSet)
      .map((id) => modulesById.get(id))
      .filter((m): m is Module => !!m)
      .map((m) => ({
        id: m.id,
        name: m.name,
        description: m.description,
        tags: m.tags,
        actionIds: m.actionIds,
        texts: (m.texts as ExportModule["texts"]) || [],
      }));

    const eContacts: ExportContact[] = includeContacts
      ? Array.from(selectedContactIds)
          .map((id) => contacts.find((c) => c.id === id))
          .filter((c): c is Contact => !!c)
          .map((c) => ({
            id: c.id,
            firstName: c.firstName,
            lastName: c.lastName,
            email: c.email,
            phoneNumber: c.phoneNumber,
            company: c.company || c.companyName,
            tags: c.tags ?? [],
            activeJourneys: contactActiveJourneys.get(c.id) ?? [],
          }))
      : [];

    return { exportJourneys: eJourneys, exportModules: eModules, exportContacts: eContacts, missingModuleWarnings: warnings };
  }, [
    includeJourneys, includeModules, includeContacts,
    selectedJourneyIds, selectedModuleIds, selectedContactIds,
    journeys, modulesById, contacts, contactActiveJourneys,
  ]);

  const totalSelected =
    exportJourneys.length + exportModules.length + exportContacts.length;

  const preview = useMemo(() => {
    if (totalSelected === 0) return "";
    const input = {
      journeys: exportJourneys.length > 0 ? exportJourneys : undefined,
      modules: exportModules,
      contacts: exportContacts.length > 0 ? exportContacts : undefined,
      actionsById,
    };
    return format === "markdown"
      ? serializeExportMarkdown(input)
      : serializeExportJson(input);
  }, [exportJourneys, exportModules, exportContacts, actionsById, format, totalSelected]);

  const filename = useMemo(() => {
    const date = new Date().toISOString().slice(0, 10);
    const ext = format === "markdown" ? "md" : "json";
    const parts: string[] = [];
    if (exportJourneys.length) parts.push(`${exportJourneys.length}j`);
    if (exportModules.length) parts.push(`${exportModules.length}m`);
    if (exportContacts.length) parts.push(`${exportContacts.length}c`);
    const tag = parts.length ? parts.join("-") : "empty";
    return `mindfultext-export-${tag}-${date}.${ext}`;
  }, [exportJourneys.length, exportModules.length, exportContacts.length, format]);

  const handleCopy = async () => {
    if (!preview) return;
    try {
      await navigator.clipboard.writeText(preview);
      toast({ title: "Copied to clipboard", description: `${preview.length.toLocaleString()} characters.` });
    } catch (err: any) {
      toast({ title: "Copy failed", description: err?.message || "Clipboard unavailable", variant: "destructive" });
    }
  };

  const handleDownload = () => {
    if (!preview) return;
    const mime = format === "markdown" ? "text/markdown" : "application/json";
    const blob = new Blob([preview], { type: `${mime};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({ title: "Download started", description: filename });
  };

  const totalTexts = exportModules.reduce(
    (n, m) => n + ((m.texts as { length?: number }[])?.length || 0),
    0,
  );

  return (
    <>
      <Card className="card-mindful">
        <CardContent className="p-5 space-y-5">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <h3 className="font-semibold text-gray-900">1. Choose what to export</h3>
            <div className="flex items-center gap-2">
              <Label className="text-xs">Format</Label>
              <Select
                value={format}
                onValueChange={(v) => setFormat(v as ExportFormat)}
                disabled={includeContacts}
              >
                <SelectTrigger className="w-[260px]" data-testid="select-export-format">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="markdown" disabled={includeContacts}>
                    Markdown (round-trippable with importer)
                  </SelectItem>
                  <SelectItem value="json">JSON (full fidelity, includes ids)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {includeContacts && (
            <div className="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-md p-2">
              Contacts can only be exported as JSON.
            </div>
          )}

          <ExportSection
            title="Journeys (with schedule, time, tags, and their modules)"
            include={includeJourneys}
            onToggle={setIncludeJourneys}
            search={journeySearch}
            onSearchChange={setJourneySearch}
            allItems={journeys}
            filteredItems={filteredJourneys}
            selectedIds={selectedJourneyIds}
            onSelectionChange={setSelectedJourneyIds}
            renderItem={(j) => (
              <>
                <span className="flex-1 truncate">{j.name}</span>
                <span className="text-xs text-gray-400 shrink-0">
                  {(j.moduleIds || j.moduleIDs || []).length} module(s)
                </span>
              </>
            )}
            getId={(j) => j.id}
            isLoading={journeysQuery.isLoading}
            emptyText="No journeys yet."
            testIdPrefix="export-journey"
          />

          <ExportSection
            title="Modules (with texts and all linked actions)"
            include={includeModules}
            onToggle={setIncludeModules}
            search={moduleSearch}
            onSearchChange={setModuleSearch}
            allItems={modules}
            filteredItems={filteredModules}
            selectedIds={selectedModuleIds}
            onSelectionChange={setSelectedModuleIds}
            renderItem={(m) => (
              <>
                <span className="flex-1 truncate">{m.name}</span>
                <span className="text-xs text-gray-400 shrink-0">
                  {Array.isArray(m.texts) ? m.texts.length : 0} text(s)
                </span>
              </>
            )}
            getId={(m) => m.id}
            isLoading={modulesQuery.isLoading}
            emptyText="No modules yet."
            testIdPrefix="export-module"
          />

          <ExportSection
            title="Contacts (with tags and active journey names)"
            include={includeContacts}
            onToggle={setIncludeContacts}
            search={contactSearch}
            onSearchChange={setContactSearch}
            allItems={contacts}
            filteredItems={filteredContacts}
            selectedIds={selectedContactIds}
            onSelectionChange={setSelectedContactIds}
            renderItem={(c) => {
              const name = `${c.firstName ?? ""} ${c.lastName ?? ""}`.trim() || c.email || c.id;
              const tags = c.tags ?? [];
              const journeyNames = contactActiveJourneys.get(c.id) ?? [];
              return (
                <>
                  <div className="flex-1 min-w-0">
                    <div className="truncate">{name}</div>
                    {(tags.length > 0 || journeyNames.length > 0) && (
                      <div className="flex flex-wrap gap-1 mt-1">
                        {tags.map((t) => (
                          <Badge key={`t-${t}`} variant="secondary" className="text-[10px] py-0 px-1.5 h-4">
                            {t}
                          </Badge>
                        ))}
                        {journeyNames.map((j) => (
                          <Badge key={`j-${j}`} variant="outline" className="text-[10px] py-0 px-1.5 h-4 border-indigo-300 text-indigo-700">
                            {j}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                </>
              );
            }}
            getId={(c) => c.id}
            isLoading={contactsQuery.isLoading || subscriptionsQuery.isLoading}
            emptyText="No contacts yet."
            testIdPrefix="export-contact"
          />
        </CardContent>
      </Card>

      <Card className="card-mindful">
        <CardContent className="p-5 space-y-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="font-semibold text-gray-900">2. Preview &amp; download</h3>
              <p className="text-xs text-gray-500 mt-0.5">
                {exportJourneys.length} journey(s) · {exportModules.length} module(s) · {totalTexts} text(s) · {exportContacts.length} contact(s)
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline" size="sm"
                onClick={handleCopy}
                disabled={!preview}
                data-testid="button-export-copy"
              >
                <Copy className="w-4 h-4 mr-1.5" /> Copy
              </Button>
              <Button
                size="sm"
                onClick={handleDownload}
                disabled={!preview}
                className="btn-mindful"
                data-testid="button-export-download"
              >
                <Download className="w-4 h-4 mr-1.5" /> Download
              </Button>
            </div>
          </div>

          {missingModuleWarnings.length > 0 && (
            <div className="rounded-md border border-amber-200 bg-amber-50 p-2.5 text-xs text-amber-800 space-y-1">
              {missingModuleWarnings.map((w, i) => (
                <div key={i} className="flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                  <span>{w}</span>
                </div>
              ))}
            </div>
          )}

          {loadError ? (
            <div className="flex flex-col items-center justify-center py-10 text-sm gap-2 text-red-700 bg-red-50 border border-red-200 rounded-md">
              <AlertTriangle className="w-5 h-5" />
              <span>Couldn't load export data — {(loadError as Error)?.message || "unknown error"}.</span>
              <Button
                variant="outline" size="sm"
                onClick={() => {
                  modulesQuery.refetch();
                  journeysQuery.refetch();
                  actionsQuery.refetch();
                  if (includeContacts) {
                    contactsQuery.refetch();
                    subscriptionsQuery.refetch();
                  }
                }}
              >
                Retry
              </Button>
            </div>
          ) : isLoading ? (
            <div className="flex items-center justify-center py-12 text-gray-500 text-sm">
              <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Loading…
            </div>
          ) : !preview ? (
            <div className="flex flex-col items-center justify-center py-12 text-gray-500 text-sm gap-2">
              <FileDown className="w-8 h-8 text-gray-300" />
              <span>
                Turn on at least one section above and pick what you want to export.
              </span>
            </div>
          ) : (
            <Textarea
              readOnly
              value={preview}
              className="font-mono text-xs min-h-[300px] max-h-[500px] bg-gray-50"
              data-testid="textarea-export-preview"
            />
          )}

          <div className="text-[11px] text-gray-400">
            File will be saved as <code className="px-1 bg-gray-100 rounded">{filename}</code>
          </div>
        </CardContent>
      </Card>
    </>
  );
}

// Reusable per-section panel — toggle, search, select-all/clear, scrollable
// checkbox list. Generic over the item type so it works for journeys,
// modules, and contacts without three near-identical copies.
interface ExportSectionProps<T> {
  title: string;
  include: boolean;
  onToggle: (v: boolean) => void;
  search: string;
  onSearchChange: (v: string) => void;
  allItems: T[];
  filteredItems: T[];
  selectedIds: Set<string>;
  onSelectionChange: (ids: Set<string>) => void;
  renderItem: (item: T) => React.ReactNode;
  getId: (item: T) => string;
  isLoading: boolean;
  emptyText: string;
  testIdPrefix: string;
}

function ExportSection<T>({
  title, include, onToggle, search, onSearchChange,
  allItems, filteredItems, selectedIds, onSelectionChange,
  renderItem, getId, isLoading, emptyText, testIdPrefix,
}: ExportSectionProps<T>) {
  const toggleOne = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id); else next.add(id);
    onSelectionChange(next);
  };

  const allFilteredSelected =
    filteredItems.length > 0 && filteredItems.every((it) => selectedIds.has(getId(it)));

  return (
    <div className="border border-gray-200 rounded-lg p-4 space-y-3">
      <label className="flex items-center gap-2 cursor-pointer">
        <Checkbox
          checked={include}
          onCheckedChange={(v) => onToggle(v === true)}
          data-testid={`checkbox-include-${testIdPrefix}`}
        />
        <span className="text-sm font-medium text-gray-900">{title}</span>
        {include && selectedIds.size > 0 && (
          <Badge variant="secondary" className="ml-1">{selectedIds.size} selected</Badge>
        )}
      </label>

      {include && (
        <>
          <div className="flex items-center gap-2">
            <Input
              value={search}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search…"
              className="h-8 text-sm flex-1"
              data-testid={`input-search-${testIdPrefix}`}
            />
            <Button
              variant="ghost" size="sm"
              onClick={() => {
                if (allFilteredSelected) {
                  const next = new Set(selectedIds);
                  for (const it of filteredItems) next.delete(getId(it));
                  onSelectionChange(next);
                } else {
                  const next = new Set(selectedIds);
                  for (const it of filteredItems) next.add(getId(it));
                  onSelectionChange(next);
                }
              }}
              disabled={filteredItems.length === 0}
              data-testid={`button-select-all-${testIdPrefix}`}
            >
              {allFilteredSelected ? "Clear" : "Select all"}
            </Button>
          </div>

          <div className="border border-gray-200 rounded-md max-h-72 overflow-y-auto divide-y divide-gray-100 bg-white">
            {isLoading ? (
              <div className="p-4 text-sm text-gray-500 text-center">
                <Loader2 className="w-4 h-4 mr-1.5 animate-spin inline" /> Loading…
              </div>
            ) : allItems.length === 0 ? (
              <div className="p-4 text-sm text-gray-500 italic text-center">{emptyText}</div>
            ) : filteredItems.length === 0 ? (
              <div className="p-4 text-sm text-gray-500 italic text-center">No matches for "{search}".</div>
            ) : (
              filteredItems.map((it) => {
                const id = getId(it);
                return (
                  <label
                    key={id}
                    className="flex items-center gap-3 px-3 py-2 hover:bg-gray-50 cursor-pointer text-sm"
                  >
                    <Checkbox
                      checked={selectedIds.has(id)}
                      onCheckedChange={() => toggleOne(id)}
                      data-testid={`checkbox-${testIdPrefix}-${id}`}
                    />
                    {renderItem(it)}
                  </label>
                );
              })
            )}
          </div>
        </>
      )}
    </div>
  );
}
