import { useState } from "react";
import { useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import { resolveLocalOrgId } from "@/lib/localApi";

interface JourneyData {
  journey: {
    id: number;
    moduleIds: string[];
    currentIndex: number;
    paused: boolean;
  };
  events: Array<{
    id: number;
    eventType: string;
    moduleId: string | null;
    source: string;
    reason: string | null;
    createdAt: string;
  }>;
}

interface ProfileData {
  profile: { memoryEnabled: boolean; pageNote: string | null };
  memory: Array<{ id: number; key: string; value: string; updatedAt: string }>;
}

export default function ContactPanel() {
  const ORG_ID = resolveLocalOrgId();
  const [, params] = useRoute("/contact/:id");
  const contactId = params?.id ?? "";
  const { toast } = useToast();
  const [insertModule, setInsertModule] = useState("");
  const [reorderText, setReorderText] = useState<string | null>(null);

  const { data: journey } = useQuery<JourneyData>({
    queryKey: ["/api/local/personal-journey", ORG_ID, contactId],
    queryFn: () => fetch(`/api/local/personal-journey/${ORG_ID}/${contactId}`).then(r => r.json()),
    enabled: !!contactId,
  });

  const { data: profileData } = useQuery<ProfileData>({
    queryKey: ["/api/local/contact-profile", ORG_ID, contactId],
    queryFn: () => fetch(`/api/local/contact-profile/${ORG_ID}/${contactId}`).then(r => r.json()),
    enabled: !!contactId,
  });

  const opMut = useMutation({
    mutationFn: (op: any) => apiRequest("POST", `/api/local/personal-journey/${ORG_ID}/${contactId}/op`, op),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/personal-journey", ORG_ID, contactId] });
      toast({ title: "Journey updated" });
    },
    onError: (e: any) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const memoryToggleMut = useMutation({
    mutationFn: (enabled: boolean) =>
      apiRequest("POST", `/api/local/contact-profile/${ORG_ID}/${contactId}/memory-toggle`, { enabled }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/contact-profile", ORG_ID, contactId] });
      toast({ title: "Memory preference updated" });
    },
  });

  const memoryClearMut = useMutation({
    mutationFn: () => apiRequest("POST", `/api/local/contact-profile/${ORG_ID}/${contactId}/memory-clear`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/contact-profile", ORG_ID, contactId] });
      toast({ title: "Memory cleared" });
    },
  });

  const [noteText, setNoteText] = useState<string | null>(null);
  const note = noteText ?? profileData?.profile.pageNote ?? "";

  const noteMut = useMutation({
    mutationFn: (value: string) =>
      apiRequest("PATCH", `/api/local/contact-profile/${ORG_ID}/${contactId}/page-note`, { note: value }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/contact-profile", ORG_ID, contactId] });
      setNoteText(null);
      toast({ title: "Personal note saved" });
    },
    onError: (e: any) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const [link, setLink] = useState<{ id: number; url: string } | null>(null);

  const linkMut = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/local/subscriber-link/${contactId}`, {});
      return res.json() as Promise<{ id: number; url: string }>;
    },
    onSuccess: (data) => setLink({ id: data.id, url: data.url }),
    onError: (e: any) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const revokeLinkMut = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/local/subscriber-link/${id}`),
    onSuccess: () => {
      setLink(null);
      toast({ title: "Link revoked" });
    },
    onError: (e: any) => toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const copyLink = async () => {
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link.url);
      toast({ title: "Link copied" });
    } catch {
      toast({ title: "Copy failed", description: "Select and copy the link manually.", variant: "destructive" });
    }
  };

  if (!contactId) return <div className="p-6 text-gray-500">No contact id in URL.</div>;

  const j = journey?.journey;
  const memOn = profileData?.profile.memoryEnabled ?? true;

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Contact panel</h1>
        <p className="text-sm text-gray-500">Contact id: <span className="font-mono">{contactId}</span></p>
      </div>

      <section className="bg-white border border-gray-200 rounded-lg p-5">
        <h2 className="font-semibold text-gray-900 mb-3">Personal journey</h2>
        {!j ? (
          <p className="text-gray-500 text-sm">Loading…</p>
        ) : (
          <>
            <div className="flex items-center gap-3 mb-3 text-sm">
              <span className="text-gray-600">Position {j.currentIndex} / {j.moduleIds.length}</span>
              <span className={`px-2 py-0.5 rounded text-xs ${j.paused ? "bg-amber-100 text-amber-700" : "bg-green-100 text-green-700"}`}>
                {j.paused ? "paused" : "active"}
              </span>
            </div>
            <ol className="space-y-1 mb-4 max-h-64 overflow-y-auto">
              {j.moduleIds.map((m, i) => (
                <li key={i} className={`text-sm font-mono px-3 py-1.5 rounded ${i < j.currentIndex ? "bg-gray-100 text-gray-400 line-through" : i === j.currentIndex ? "bg-indigo-50 text-indigo-900 font-bold" : "bg-white border"}`}>
                  {i + 1}. {m}{i === j.currentIndex && " ← next"}
                </li>
              ))}
              {j.moduleIds.length === 0 && <li className="text-sm text-gray-500">Queue is empty.</li>}
            </ol>
            <div className="flex gap-2 flex-wrap">
              <input className="border rounded px-2 py-1 text-sm flex-1 min-w-0" placeholder="moduleId to insert"
                value={insertModule} onChange={e => setInsertModule(e.target.value)} />
              <button onClick={() => { if (insertModule) { opMut.mutate({ op: "insert", moduleId: insertModule, at: j.currentIndex }); setInsertModule(""); } }}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded text-sm" data-testid="button-insert">
                Insert next
              </button>
              <button onClick={() => opMut.mutate({ op: "skip", at: j.currentIndex })}
                className="bg-white border px-3 py-1.5 rounded text-sm" data-testid="button-skip">Skip next</button>
              {j.paused ? (
                <button onClick={() => opMut.mutate({ op: "resume" })} className="bg-green-600 text-white px-3 py-1.5 rounded text-sm">Resume</button>
              ) : (
                <button onClick={() => opMut.mutate({ op: "pause" })} className="bg-amber-600 text-white px-3 py-1.5 rounded text-sm">Pause</button>
              )}
              <button
                onClick={() => setReorderText(j.moduleIds.join("\n"))}
                className="bg-white border px-3 py-1.5 rounded text-sm" data-testid="button-reorder">
                Reorder…
              </button>
            </div>
            {reorderText !== null && (
              <div className="mt-3 border border-amber-300 bg-amber-50 rounded p-3" data-testid="form-reorder">
                <p className="text-xs text-amber-900 mb-2">One moduleId per line, in the new order:</p>
                <textarea className="w-full border rounded p-2 font-mono text-xs"
                  rows={Math.max(4, reorderText.split("\n").length)}
                  value={reorderText} onChange={e => setReorderText(e.target.value)} />
                <div className="flex gap-2 mt-2">
                  <button onClick={() => {
                    const newQueue = reorderText!.split("\n").map(s => s.trim()).filter(Boolean);
                    opMut.mutate({ op: "reorder", newQueue });
                    setReorderText(null);
                  }} className="bg-amber-600 text-white px-3 py-1.5 rounded text-sm" data-testid="button-apply-reorder">
                    Apply new order
                  </button>
                  <button onClick={() => setReorderText(null)} className="text-sm text-gray-600">Cancel</button>
                </div>
              </div>
            )}
          </>
        )}

        {journey?.events && journey.events.length > 0 && (
          <details className="mt-4">
            <summary className="text-xs text-gray-600 cursor-pointer">Recent events ({journey.events.length})</summary>
            <ul className="mt-2 space-y-1 text-xs font-mono">
              {journey.events.slice(0, 10).map(e => (
                <li key={e.id} className="text-gray-600">
                  {new Date(e.createdAt).toLocaleString()} — <b>{e.eventType}</b> ({e.source}){e.moduleId ? ` ${e.moduleId}` : ""}{e.reason ? ` — ${e.reason}` : ""}
                </li>
              ))}
            </ul>
          </details>
        )}
      </section>

      <section className="bg-white border border-gray-200 rounded-lg p-5">
        <h2 className="font-semibold text-gray-900 mb-1">Subscriber page link</h2>
        <p className="text-sm text-gray-500 mb-3">
          A private, login-free page where this contact can revisit their content. Share it in a text on your schedule.
        </p>
        {!link ? (
          <button
            onClick={() => linkMut.mutate()}
            disabled={linkMut.isPending}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded text-sm disabled:opacity-60"
            data-testid="button-generate-link"
          >
            {linkMut.isPending ? "Generating…" : "Generate link"}
          </button>
        ) : (
          <div className="space-y-2">
            <div className="flex gap-2 flex-wrap items-center">
              <input
                readOnly
                value={link.url}
                onFocus={(e) => e.currentTarget.select()}
                className="border rounded px-2 py-1.5 text-sm flex-1 min-w-0 font-mono bg-gray-50"
                data-testid="input-link"
              />
              <button onClick={copyLink} className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded text-sm">
                Copy
              </button>
              <a
                href={link.url}
                target="_blank"
                rel="noreferrer"
                className="bg-white border px-3 py-1.5 rounded text-sm text-gray-700 hover:bg-gray-50"
                data-testid="button-open-page"
              >
                Open page
              </a>
              <button
                onClick={() => revokeLinkMut.mutate(link.id)}
                disabled={revokeLinkMut.isPending}
                className="bg-white border border-red-300 text-red-600 px-3 py-1.5 rounded text-sm disabled:opacity-60"
                data-testid="button-revoke-link"
              >
                Revoke
              </button>
            </div>
            <p className="text-xs text-gray-400">Revoking turns this link off immediately. Generating again issues a fresh one.</p>
          </div>
        )}

        <div className="mt-5 pt-5 border-t border-gray-100">
          <h3 className="font-medium text-gray-900 mb-1">Personal note</h3>
          <p className="text-sm text-gray-500 mb-2">
            A short message shown only at the top of this contact's page. Leave it blank to hide it.
          </p>
          <textarea
            className="w-full border rounded p-2 text-sm"
            rows={3}
            placeholder="e.g. So glad you joined, Maria — here's everything we've shared so far."
            value={note}
            onChange={(e) => setNoteText(e.target.value)}
            data-testid="input-page-note"
          />
          <div className="flex gap-2 mt-2 items-center">
            <button
              onClick={() => noteMut.mutate(note)}
              disabled={noteMut.isPending || note === (profileData?.profile.pageNote ?? "")}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded text-sm disabled:opacity-60"
              data-testid="button-save-page-note"
            >
              {noteMut.isPending ? "Saving…" : "Save note"}
            </button>
            {noteText !== null && noteText !== (profileData?.profile.pageNote ?? "") && (
              <button onClick={() => setNoteText(null)} className="text-sm text-gray-600">
                Cancel
              </button>
            )}
          </div>
        </div>
      </section>

      <section className="bg-white border border-gray-200 rounded-lg p-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-gray-900">Memory</h2>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={memOn} onChange={e => memoryToggleMut.mutate(e.target.checked)} data-testid="toggle-memory" />
            <span>{memOn ? "Memory enabled" : "Memory disabled"}</span>
          </label>
        </div>
        {memOn ? (
          <>
            {profileData?.memory.length === 0 ? (
              <p className="text-sm text-gray-500">No memory recorded yet.</p>
            ) : (
              <ul className="space-y-2">
                {profileData?.memory.map(m => (
                  <li key={m.id} className="text-sm">
                    <p className="font-medium text-gray-900">{m.key}</p>
                    <pre className="text-xs text-gray-600 whitespace-pre-wrap mt-1 bg-gray-50 p-2 rounded">{m.value}</pre>
                  </li>
                ))}
              </ul>
            )}
            <button onClick={() => memoryClearMut.mutate()}
              className="mt-3 text-xs text-red-600 hover:text-red-700">Clear all memory for this contact</button>
          </>
        ) : (
          <p className="text-sm text-gray-500">Memory writes are disabled. Existing memory has been purged.</p>
        )}
      </section>
    </div>
  );
}
