import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Search, RefreshCw, ChevronDown, ChevronUp, CheckCircle2, XCircle, Circle } from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import { formatDistanceToNow, parseISO, isValid, format } from "date-fns";

// ─── Types ──────────────────────────────────────────────────────────────────

interface Enrollment {
  subscriptionId: string;
  journeyId: string;
  state: string;
  startDate: string | null;
  startedAt: number;
  completedAt: number | null;
  currentModuleIndex: number | null;
  nextSendAt: string | null;
}

interface ContactRow {
  id: string;
  name: string;
  tags: string[];
  enrollments: Enrollment[];
}

interface JourneyInfo {
  id: string;
  name: string;
  modules: { id: string; name: string }[];
}

interface ContactJourneysPayload {
  journeys: Record<string, JourneyInfo>;
  tags: string[];
  contacts: ContactRow[];
  cachedAt: number;
}

const ALL_TAGS = "__all__";
const UNTAGGED = "__untagged__";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatUnix(seconds: number | null): string {
  if (!seconds || seconds <= 0) return "–";
  const d = new Date(seconds * 1000);
  if (!isValid(d)) return "–";
  return format(d, "MMM d, yyyy");
}

function formatStartDate(startDate: string | null, startedAt: number): string {
  if (startDate) {
    const d = parseISO(startDate);
    if (isValid(d)) return format(d, "MMM d, yyyy");
  }
  return formatUnix(startedAt);
}

function formatNextSend(nextSendAt: string | null): string {
  if (!nextSendAt) return "";
  try {
    const n = Number(nextSendAt);
    const d = !isNaN(n) && n > 0 ? new Date(n < 1e12 ? n * 1000 : n) : parseISO(nextSendAt);
    if (!isValid(d)) return "";
    return formatDistanceToNow(d, { addSuffix: true });
  } catch {
    return "";
  }
}

interface StateMeta {
  label: string;
  badge: string;
  Icon: typeof CheckCircle2;
  iconColor: string;
}

function stateMeta(state: string): StateMeta {
  switch (state.toLowerCase()) {
    case "completed":
      return { label: "Completed", badge: "bg-emerald-100 text-emerald-700", Icon: CheckCircle2, iconColor: "text-emerald-500" };
    case "cancelled":
      return { label: "Cancelled", badge: "bg-rose-100 text-rose-700", Icon: XCircle, iconColor: "text-rose-400" };
    case "active":
      return { label: "Active", badge: "bg-green-100 text-green-700", Icon: Circle, iconColor: "text-green-500" };
    case "sending":
      return { label: "Sending", badge: "bg-blue-100 text-blue-700", Icon: Circle, iconColor: "text-blue-500" };
    case "paused":
      return { label: "Paused", badge: "bg-yellow-100 text-yellow-700", Icon: Circle, iconColor: "text-yellow-600" };
    default:
      return { label: state || "Unknown", badge: "bg-gray-100 text-gray-600", Icon: Circle, iconColor: "text-gray-400" };
  }
}

// Color a single module cell within one enrollment's track.
//   completed   → every module reads as done
//   live        → done up to current, current highlighted, rest upcoming
//   cancelled   → muted (exact stopping point isn't recorded upstream)
function moduleCellBg(modIdx: number, e: Enrollment): string {
  const s = e.state.toLowerCase();
  if (s === "completed") return "bg-emerald-400";
  if (s === "cancelled") return "bg-gray-200";
  // live states
  const cur = e.currentModuleIndex ?? 0;
  if (modIdx < cur) return "bg-emerald-400";
  if (modIdx === cur) {
    if (s === "sending") return "bg-blue-500";
    if (s === "paused") return "bg-yellow-400";
    return "bg-green-500";
  }
  return "bg-gray-200";
}

function moduleCellLabel(modIdx: number, e: Enrollment): string {
  const s = e.state.toLowerCase();
  if (s === "completed") return "Completed";
  if (s === "cancelled") return "Not recorded";
  const cur = e.currentModuleIndex ?? 0;
  if (modIdx < cur) return "Completed";
  if (modIdx === cur) return "Current";
  return "Upcoming";
}

// ─── One enrollment block (journey + module track) ────────────────────────────

function EnrollmentBlock({ enrollment, journey }: { enrollment: Enrollment; journey: JourneyInfo | undefined }) {
  const meta = stateMeta(enrollment.state);
  const modules = journey?.modules ?? [];
  const s = enrollment.state.toLowerCase();
  const isLive = s === "active" || s === "sending" || s === "paused";
  const nextSend = isLive ? formatNextSend(enrollment.nextSendAt) : "";

  return (
    <div className="rounded-lg border border-gray-200 bg-white p-3">
      <div className="flex items-center justify-between gap-3 flex-wrap mb-2">
        <div className="flex items-center gap-2 min-w-0">
          <meta.Icon className={`w-4 h-4 shrink-0 ${meta.iconColor}`} />
          <span className="font-medium text-gray-900 truncate">{journey?.name ?? `Journey ${enrollment.journeyId}`}</span>
          <span className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${meta.badge}`}>{meta.label}</span>
        </div>
        <div className="text-xs text-gray-500 flex items-center gap-3 flex-wrap">
          <span>Started {formatStartDate(enrollment.startDate, enrollment.startedAt)}</span>
          {s === "completed" && enrollment.completedAt && (
            <span>Finished {formatUnix(enrollment.completedAt)}</span>
          )}
          {isLive && enrollment.currentModuleIndex != null && modules.length > 0 && (
            <span>
              Module {enrollment.currentModuleIndex + 1} of {modules.length}
              {nextSend && <span className="text-gray-400"> · next {nextSend}</span>}
            </span>
          )}
        </div>
      </div>

      {/* Module track */}
      {modules.length > 0 ? (
        <div className="flex gap-0.5 flex-wrap">
          {modules.map((mod, modIdx) => (
            <div
              key={mod.id}
              className={`h-3 flex-1 min-w-2 rounded-sm ${moduleCellBg(modIdx, enrollment)}`}
              title={`${mod.name} (#${modIdx + 1}) — ${moduleCellLabel(modIdx, enrollment)}`}
            />
          ))}
        </div>
      ) : (
        <p className="text-xs text-gray-400 italic">No modules recorded for this journey.</p>
      )}

      {s === "cancelled" && (
        <p className="text-xs text-gray-400 mt-1.5 italic">
          Cancelled — MindfulText doesn't record the exact module they stopped on.
        </p>
      )}
    </div>
  );
}

// ─── One contact card ─────────────────────────────────────────────────────────

function ContactCard({
  contact, journeys, defaultOpen,
}: { contact: ContactRow; journeys: Record<string, JourneyInfo>; defaultOpen: boolean }) {
  const [open, setOpen] = useState(defaultOpen);

  const counts = useMemo(() => {
    let live = 0, completed = 0, cancelled = 0;
    for (const e of contact.enrollments) {
      const s = e.state.toLowerCase();
      if (s === "completed") completed++;
      else if (s === "cancelled") cancelled++;
      else live++;
    }
    return { live, completed, cancelled };
  }, [contact.enrollments]);

  return (
    <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
      <div
        className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b border-gray-200 cursor-pointer select-none"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3 min-w-0 flex-wrap">
          <span className="font-semibold text-gray-900 truncate">{contact.name}</span>
          <span className="text-xs text-gray-500">
            {contact.enrollments.length} {contact.enrollments.length === 1 ? "journey" : "journeys"}
          </span>
          <span className="text-xs text-gray-400">
            {counts.live > 0 && <span className="text-green-600">{counts.live} active</span>}
            {counts.live > 0 && (counts.completed > 0 || counts.cancelled > 0) && " · "}
            {counts.completed > 0 && <span className="text-emerald-600">{counts.completed} completed</span>}
            {counts.completed > 0 && counts.cancelled > 0 && " · "}
            {counts.cancelled > 0 && <span className="text-rose-500">{counts.cancelled} cancelled</span>}
          </span>
          {contact.tags.length > 0 && (
            <div className="flex items-center gap-1 flex-wrap">
              {contact.tags.slice(0, 4).map((t) => (
                <Badge key={t} variant="secondary" className="text-[10px] px-1.5 py-0">{t}</Badge>
              ))}
              {contact.tags.length > 4 && (
                <span className="text-[10px] text-gray-400">+{contact.tags.length - 4}</span>
              )}
            </div>
          )}
        </div>
        <button className="text-gray-400 hover:text-gray-600 shrink-0">
          {open ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {open && (
        <div className="p-3 space-y-2">
          {contact.enrollments.map((e) => (
            <EnrollmentBlock key={e.subscriptionId} enrollment={e} journey={journeys[e.journeyId]} />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Main page ───────────────────────────────────────────────────────────────

export default function ContactJourneys() {
  const [tag, setTag] = useState<string>(ALL_TAGS);
  const [search, setSearch] = useState("");

  const { data, isLoading, isError, dataUpdatedAt, refetch, isFetching } = useQuery<ContactJourneysPayload>({
    queryKey: ["/api/local/contact-journeys"],
    queryFn: async () => {
      const sessionId = localStorage.getItem("mindfultext_session_id") || "";
      const res = await fetch("/api/local/contact-journeys", {
        headers: { "X-Session-ID": sessionId },
      });
      if (!res.ok) throw new Error((await res.json()).error || `HTTP ${res.status}`);
      return res.json();
    },
    refetchInterval: 5 * 60 * 1000,
    staleTime: 2 * 60 * 1000,
  });

  const journeys = data?.journeys ?? {};
  const allContacts = data?.contacts ?? [];
  const tags = data?.tags ?? [];

  const lcSearch = search.toLowerCase().trim();

  const filteredContacts = useMemo(() => {
    return allContacts.filter((c) => {
      // Tag filter
      if (tag === UNTAGGED) {
        if (c.tags.length > 0) return false;
      } else if (tag !== ALL_TAGS) {
        if (!c.tags.includes(tag)) return false;
      }
      // Search by contact name, tag, or journey name
      if (lcSearch) {
        if (c.name.toLowerCase().includes(lcSearch)) return true;
        if (c.tags.some((t) => t.toLowerCase().includes(lcSearch))) return true;
        const journeyMatch = c.enrollments.some((e) =>
          (journeys[e.journeyId]?.name ?? "").toLowerCase().includes(lcSearch),
        );
        return journeyMatch;
      }
      return true;
    });
  }, [allContacts, tag, lcSearch, journeys]);

  const lastUpdated = dataUpdatedAt
    ? formatDistanceToNow(new Date(dataUpdatedAt), { addSuffix: true })
    : null;

  // Auto-expand cards when the list is small (e.g. a narrow tag filter).
  const autoOpen = filteredContacts.length <= 5;

  return (
    <div className="p-6 space-y-5 max-w-5xl">
      {/* Page header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Contact Journeys</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Full journey history per contact, grouped by tag
            {lastUpdated && <span className="ml-2 text-gray-400">· Updated {lastUpdated}</span>}
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            queryClient.invalidateQueries({ queryKey: ["/api/local/contact-journeys"] });
            refetch();
          }}
          disabled={isFetching}
          className="flex items-center gap-1.5"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isFetching ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        <Select value={tag} onValueChange={setTag}>
          <SelectTrigger className="w-56 text-sm">
            <SelectValue placeholder="Filter by tag" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL_TAGS}>All tags</SelectItem>
            <SelectItem value={UNTAGGED}>Untagged</SelectItem>
            {tags.map((t) => (
              <SelectItem key={t} value={t}>{t}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="relative flex-1 min-w-56 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Find a contact by name, tag, or journey"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 text-sm"
          />
        </div>
        {/* Legend */}
        <div className="flex items-center gap-3 text-xs text-gray-500">
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-3 h-3 rounded-sm bg-emerald-400" /> Done
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-3 h-3 rounded-sm bg-green-500" /> Current
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-3 h-3 rounded-sm bg-gray-200" /> Upcoming
          </span>
        </div>
      </div>

      {/* Loading */}
      {isLoading && (
        <div className="flex items-center gap-3 py-12 justify-center text-gray-400">
          <div className="w-5 h-5 border-2 border-gray-300 border-t-indigo-500 rounded-full animate-spin" />
          <span className="text-sm">Loading contact histories…</span>
        </div>
      )}

      {/* Error */}
      {isError && !isLoading && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          Failed to load contact journeys. Make sure you're signed in to MindfulText in Settings.
        </div>
      )}

      {/* Empty states */}
      {!isLoading && !isError && allContacts.length === 0 && (
        <div className="text-center py-16 text-gray-400">
          <p className="text-lg font-medium mb-1">No contact history found</p>
          <p className="text-sm">Contacts that have ever been enrolled in a journey will appear here.</p>
        </div>
      )}

      {!isLoading && !isError && allContacts.length > 0 && filteredContacts.length === 0 && (
        <div className="text-center py-10 text-gray-400">
          <p className="text-sm">No contacts match the current filters.</p>
          <button
            onClick={() => { setTag(ALL_TAGS); setSearch(""); }}
            className="mt-2 text-xs text-indigo-500 hover:underline"
          >
            Clear filters
          </button>
        </div>
      )}

      {/* Result count */}
      {!isLoading && !isError && filteredContacts.length > 0 && (
        <p className="text-xs text-gray-400">
          Showing {filteredContacts.length} of {allContacts.length} contacts
          {tag !== ALL_TAGS && tag !== UNTAGGED && <span> tagged <strong className="text-gray-600">{tag}</strong></span>}
          {tag === UNTAGGED && <span> with no tags</span>}
        </p>
      )}

      {/* Contact cards */}
      <div className="space-y-3">
        {filteredContacts.map((c) => (
          <ContactCard key={c.id} contact={c} journeys={journeys} defaultOpen={autoOpen} />
        ))}
      </div>
    </div>
  );
}
