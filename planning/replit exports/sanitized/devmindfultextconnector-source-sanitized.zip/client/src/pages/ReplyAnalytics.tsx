import { useMemo, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { resolveLocalOrgId } from "@/lib/localApi";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  ArrowDown,
  ArrowUp,
  AlertTriangle,
  RefreshCw,
  Copy,
  Check,
  X,
  Reply,
} from "lucide-react";
import { Link } from "wouter";

type Range = "today" | "7d" | "30d" | "all" | "custom";
type Tab = "analytics" | "drafts";

interface AnalyticsRow {
  moduleId: string;
  moduleName: string;
  sends: number;
  replies: number;
  replyRate: number;
  lastReplyAt: string | null;
}

interface ModuleMessages {
  moduleId: string;
  messages: Array<{
    id: number;
    contactId: string | null;
    contactPhone: string | null;
    content: string | null;
    receivedAt: string | null;
    attributionSource: string | null;
    priorSendAgeMs: number | null;
    lowConfidence: boolean;
  }>;
}

interface DraftRow {
  id: number;
  contactId: string | null;
  contactPhone: string | null;
  inboundMessageId: number | null;
  inboundContent: string | null;
  inboundReceivedAt: string | null;
  draftContent: string;
  status: string;
  aiModel: string | null;
  createdAt: string;
}

type SortKey = "moduleName" | "sends" | "replies" | "replyRate" | "lastReplyAt";

function rangeToDates(range: Range, customFrom: string, customTo: string): { from: string | null; to: string | null } {
  const now = new Date();
  const end = now.toISOString();
  const dayMs = 24 * 60 * 60 * 1000;
  switch (range) {
    case "today": {
      const start = new Date(now);
      start.setHours(0, 0, 0, 0);
      return { from: start.toISOString(), to: end };
    }
    case "7d":
      return { from: new Date(now.getTime() - 7 * dayMs).toISOString(), to: end };
    case "30d":
      return { from: new Date(now.getTime() - 30 * dayMs).toISOString(), to: end };
    case "all":
      return { from: null, to: null };
    case "custom":
      return {
        from: customFrom ? new Date(customFrom).toISOString() : null,
        to: customTo ? new Date(customTo).toISOString() : null,
      };
  }
}

function fmtPct(n: number): string {
  return `${(n * 100).toFixed(1)}%`;
}

function fmtAge(ms: number | null): string {
  if (ms === null) return "—";
  const days = ms / (24 * 60 * 60 * 1000);
  if (days >= 1) return `${days.toFixed(1)}d`;
  const hours = ms / (60 * 60 * 1000);
  return `${hours.toFixed(1)}h`;
}

function statusBadge(status: string) {
  switch (status) {
    case "generated":
      return "bg-blue-100 text-blue-700";
    case "edited":
      return "bg-amber-100 text-amber-700";
    case "approved":
      return "bg-green-100 text-green-700";
    case "sent":
      return "bg-gray-100 text-gray-600";
    case "discarded":
      return "bg-red-50 text-red-600";
    default:
      return "bg-gray-100 text-gray-600";
  }
}

function DraftRepliesPanel({ orgId }: { orgId: string }) {
  const { toast } = useToast();
  const [editing, setEditing] = useState<Record<number, string>>({});

  const { data: drafts = [], isLoading, refetch } = useQuery<DraftRow[]>({
    queryKey: ["/api/local/draft-messages", orgId],
    queryFn: () => fetch(`/api/local/draft-messages/${orgId}`).then((r) => r.json()),
  });

  const patchMut = useMutation({
    mutationFn: ({ id, ...body }: { id: number; draftContent?: string; status?: string }) =>
      apiRequest("PATCH", `/api/local/draft-messages/${id}`, body).then((r) => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/draft-messages", orgId] });
      queryClient.invalidateQueries({ queryKey: ["/api/local/draft-messages", orgId, "count"] });
      toast({ title: "Draft updated" });
    },
    onError: (e: Error) =>
      toast({ title: "Update failed", description: e.message, variant: "destructive" }),
  });

  const actionable = drafts.filter((d) => !["sent", "discarded"].includes(d.status));

  const copyDraft = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({ title: "Copied to clipboard" });
    } catch {
      toast({ title: "Copy failed", variant: "destructive" });
    }
  };

  if (isLoading) {
    return <p className="text-gray-500 p-4">Loading draft replies…</p>;
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-gray-500">
        AI drafts are generated when contacts reply. Review and edit here, then copy and send manually in MindfulText.
        Nothing is sent automatically from this app.
      </p>

      {actionable.length === 0 ? (
        <div className="border border-dashed rounded-lg p-8 text-center text-gray-500 bg-white">
          No draft replies awaiting review. Use <b>Check for replies</b> on the Analytics tab to pull new messages.
        </div>
      ) : (
        <ul className="space-y-3">
          {actionable.map((d) => {
            const editText = editing[d.id] ?? d.draftContent;
            const isEditing = editing[d.id] !== undefined;
            return (
              <li key={d.id} className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="min-w-0">
                    <p className="text-xs text-gray-500">
                      Contact{" "}
                      <code className="font-mono">{d.contactId ?? d.contactPhone ?? "—"}</code>
                      {d.inboundReceivedAt && (
                        <span className="ml-2">
                          · {new Date(d.inboundReceivedAt).toLocaleString()}
                        </span>
                      )}
                    </p>
                    <span className={`inline-block mt-1 text-[10px] uppercase tracking-wide font-semibold px-1.5 py-0.5 rounded ${statusBadge(d.status)}`}>
                      {d.status}
                    </span>
                  </div>
                  {d.contactId && (
                    <Link href={`/contact/${d.contactId}`} className="text-xs text-indigo-600 hover:underline shrink-0">
                      Contact panel
                    </Link>
                  )}
                </div>

                {d.inboundContent && (
                  <div className="text-xs bg-blue-50 border border-blue-100 rounded p-2 mb-3">
                    <span className="text-blue-700 font-medium">They said:</span>
                    <span className="text-gray-700 ml-2">&quot;{d.inboundContent}&quot;</span>
                  </div>
                )}

                <label className="text-xs font-medium text-gray-600 block mb-1">Draft reply</label>
                <Textarea
                  value={editText}
                  onChange={(e) => setEditing({ ...editing, [d.id]: e.target.value })}
                  className="text-sm min-h-[72px] font-mono"
                  rows={3}
                />
                <p className="text-[10px] text-gray-400 mt-1">{editText.length} chars</p>

                <div className="flex flex-wrap gap-2 mt-3">
                  {isEditing && editText !== d.draftContent && (
                    <Button
                      size="sm"
                      onClick={() =>
                        patchMut.mutate(
                          { id: d.id, draftContent: editText, status: "edited" },
                          { onSuccess: () => setEditing((prev) => { const n = { ...prev }; delete n[d.id]; return n; }) },
                        )
                      }
                      disabled={patchMut.isPending}
                    >
                      Save edit
                    </Button>
                  )}
                  <Button size="sm" variant="outline" onClick={() => copyDraft(editText)}>
                    <Copy className="w-3.5 h-3.5 mr-1.5" /> Copy
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-green-700 border-green-200"
                    onClick={() => patchMut.mutate({ id: d.id, status: "approved" })}
                    disabled={patchMut.isPending || d.status === "approved"}
                  >
                    <Check className="w-3.5 h-3.5 mr-1.5" /> Mark approved
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => patchMut.mutate({ id: d.id, status: "sent" })}
                    disabled={patchMut.isPending}
                    title="Use after you send this text manually in MindfulText"
                  >
                    Mark sent
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-red-600"
                    onClick={() => patchMut.mutate({ id: d.id, status: "discarded" })}
                    disabled={patchMut.isPending}
                  >
                    <X className="w-3.5 h-3.5 mr-1.5" /> Discard
                  </Button>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      {drafts.some((d) => d.status === "sent" || d.status === "discarded") && (
        <details className="text-sm">
          <summary className="cursor-pointer text-gray-500">
            Show sent / discarded ({drafts.filter((d) => d.status === "sent" || d.status === "discarded").length})
          </summary>
          <ul className="mt-2 space-y-2 text-xs text-gray-500">
            {drafts
              .filter((d) => d.status === "sent" || d.status === "discarded")
              .map((d) => (
                <li key={d.id} className="border rounded p-2 bg-gray-50">
                  <span className={statusBadge(d.status)}>{d.status}</span>
                  {" "}
                  {d.inboundContent ? `"${d.inboundContent.slice(0, 60)}…"` : d.draftContent.slice(0, 60)}
                </li>
              ))}
          </ul>
        </details>
      )}

      <Button size="sm" variant="ghost" onClick={() => refetch()}>
        <RefreshCw className="w-4 h-4 mr-1.5" /> Refresh list
      </Button>
    </div>
  );
}

export default function ReplyAnalytics() {
  const ORG_ID = resolveLocalOrgId();
  const { toast } = useToast();
  const [tab, setTab] = useState<Tab>("drafts");
  const [range, setRange] = useState<Range>("30d");
  const [customFrom, setCustomFrom] = useState("");
  const [customTo, setCustomTo] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("replies");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [openModule, setOpenModule] = useState<AnalyticsRow | null>(null);

  const { from, to } = useMemo(() => rangeToDates(range, customFrom, customTo), [range, customFrom, customTo]);
  const qs = new URLSearchParams();
  if (from) qs.set("from", from);
  if (to) qs.set("to", to);
  const qsStr = qs.toString();

  const analyticsUrl = `/api/local/reply-analytics/${ORG_ID}${qsStr ? `?${qsStr}` : ""}`;
  const { data, isLoading, refetch } = useQuery<{ rows: AnalyticsRow[] }>({
    queryKey: ["/api/local/reply-analytics", ORG_ID, from, to],
    queryFn: () => fetch(analyticsUrl).then((r) => r.json()),
    enabled: tab === "analytics",
  });

  const drawerUrl = openModule
    ? `/api/local/reply-analytics/${ORG_ID}/module/${openModule.moduleId}${qsStr ? `?${qsStr}` : ""}`
    : null;
  const { data: drawerData } = useQuery<ModuleMessages>({
    queryKey: ["/api/local/reply-analytics/module", ORG_ID, openModule?.moduleId, from, to],
    queryFn: () => fetch(drawerUrl!).then((r) => r.json()),
    enabled: !!drawerUrl,
  });

  const pollMut = useMutation({
    mutationFn: () =>
      apiRequest("POST", "/api/local/inbound/poll-now", { organizationId: ORG_ID }).then((r) => r.json()),
    onSuccess: (res: { processed: number; duplicates: number; skipped: number; errors: number }) => {
      toast({
        title: "Reply check complete",
        description: `${res.processed} new, ${res.duplicates} already seen, ${res.skipped} skipped`,
      });
      refetch();
      queryClient.invalidateQueries({ queryKey: ["/api/local/draft-messages", ORG_ID] });
      queryClient.invalidateQueries({ queryKey: ["/api/local/pending-changes", ORG_ID, "pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/local/pending-changes", ORG_ID, "count"] });
    },
    onError: (e: Error) =>
      toast({ title: "Poll failed", description: e.message, variant: "destructive" }),
  });

  const backfillMut = useMutation({
    mutationFn: () =>
      apiRequest("POST", "/api/local/inbound/backfill-attribution", { organizationId: ORG_ID }).then((r) => r.json()),
    onSuccess: (res: { scanned: number; attributed: number; skipped: number }) => {
      toast({
        title: "Backfill complete",
        description: `Scanned ${res.scanned}, attributed ${res.attributed}, skipped ${res.skipped}`,
      });
      refetch();
    },
    onError: (e: Error) => toast({ title: "Backfill failed", description: e.message, variant: "destructive" }),
  });

  const rows = data?.rows ?? [];
  const sorted = useMemo(() => {
    const copy = [...rows];
    copy.sort((a, b) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      if (av === null && bv === null) return 0;
      if (av === null) return 1;
      if (bv === null) return -1;
      if (av < bv) return sortDir === "asc" ? -1 : 1;
      if (av > bv) return sortDir === "asc" ? 1 : -1;
      return 0;
    });
    return copy;
  }, [rows, sortKey, sortDir]);

  function toggleSort(k: SortKey) {
    if (sortKey === k) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortKey(k);
      setSortDir(k === "moduleName" ? "asc" : "desc");
    }
  }

  function SortIcon({ k }: { k: SortKey }) {
    if (sortKey !== k) return null;
    return sortDir === "asc" ? <ArrowUp className="inline w-3 h-3 ml-1" /> : <ArrowDown className="inline w-3 h-3 ml-1" />;
  }

  return (
    <div className="p-6 space-y-4" data-testid="page-reply-analytics">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex gap-1 bg-gray-100 p-1 rounded-lg">
          <Button
            size="sm"
            variant={tab === "drafts" ? "default" : "ghost"}
            onClick={() => setTab("drafts")}
          >
            <Reply className="w-4 h-4 mr-1.5" />
            Draft replies
          </Button>
          <Button
            size="sm"
            variant={tab === "analytics" ? "default" : "ghost"}
            onClick={() => setTab("analytics")}
          >
            Analytics
          </Button>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button
            variant="default"
            size="sm"
            onClick={() => pollMut.mutate()}
            disabled={pollMut.isPending}
            data-testid="button-poll-replies"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${pollMut.isPending ? "animate-spin" : ""}`} />
            Check for replies
          </Button>
          {tab === "analytics" && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => backfillMut.mutate()}
              disabled={backfillMut.isPending}
              data-testid="button-backfill"
            >
              Backfill historical
            </Button>
          )}
          <Link href="/automation" className="text-sm text-indigo-600 hover:underline">
            Reply rules →
          </Link>
        </div>
      </div>

      {tab === "drafts" ? (
        <DraftRepliesPanel orgId={ORG_ID} />
      ) : (
        <>
          <div className="flex items-center gap-2 flex-wrap">
            {(["today", "7d", "30d", "all", "custom"] as Range[]).map((r) => (
              <Button
                key={r}
                size="sm"
                variant={range === r ? "default" : "outline"}
                onClick={() => setRange(r)}
                data-testid={`button-range-${r}`}
              >
                {r === "today" ? "Today" : r === "7d" ? "7 days" : r === "30d" ? "30 days" : r === "all" ? "All time" : "Custom"}
              </Button>
            ))}
            {range === "custom" && (
              <div className="flex items-center gap-2 ml-2">
                <input
                  type="date"
                  value={customFrom}
                  onChange={(e) => setCustomFrom(e.target.value)}
                  className="border rounded px-2 py-1 text-sm"
                  data-testid="input-from"
                />
                <span className="text-sm text-gray-500">→</span>
                <input
                  type="date"
                  value={customTo}
                  onChange={(e) => setCustomTo(e.target.value)}
                  className="border rounded px-2 py-1 text-sm"
                  data-testid="input-to"
                />
              </div>
            )}
          </div>

          <div className="border rounded-lg overflow-hidden bg-white">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 text-left text-xs uppercase text-gray-500">
                <tr>
                  <th className="p-3 cursor-pointer" onClick={() => toggleSort("moduleName")}>
                    Module<SortIcon k="moduleName" />
                  </th>
                  <th className="p-3 cursor-pointer text-right" onClick={() => toggleSort("sends")}>
                    Sends<SortIcon k="sends" />
                  </th>
                  <th className="p-3 cursor-pointer text-right" onClick={() => toggleSort("replies")}>
                    Replies<SortIcon k="replies" />
                  </th>
                  <th className="p-3 cursor-pointer text-right" onClick={() => toggleSort("replyRate")}>
                    Reply rate<SortIcon k="replyRate" />
                  </th>
                  <th className="p-3 cursor-pointer" onClick={() => toggleSort("lastReplyAt")}>
                    Last reply<SortIcon k="lastReplyAt" />
                  </th>
                </tr>
              </thead>
              <tbody>
                {isLoading && (
                  <tr><td colSpan={5} className="p-6 text-center text-gray-400">Loading…</td></tr>
                )}
                {!isLoading && sorted.length === 0 && (
                  <tr><td colSpan={5} className="p-6 text-center text-gray-400">No module activity in this range.</td></tr>
                )}
                {sorted.map((r) => (
                  <tr
                    key={r.moduleId}
                    className="border-t hover:bg-indigo-50 cursor-pointer"
                    onClick={() => setOpenModule(r)}
                    data-testid={`row-module-${r.moduleId}`}
                  >
                    <td className="p-3 font-medium text-gray-900">{r.moduleName}</td>
                    <td className="p-3 text-right">{r.sends}</td>
                    <td className="p-3 text-right">{r.replies}</td>
                    <td className="p-3 text-right">{r.sends > 0 ? fmtPct(r.replyRate) : "—"}</td>
                    <td className="p-3 text-gray-600">{r.lastReplyAt ? new Date(r.lastReplyAt).toLocaleString() : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      <Sheet open={!!openModule} onOpenChange={(o) => !o && setOpenModule(null)}>
        <SheetContent className="w-[480px] sm:w-[640px] sm:max-w-none overflow-y-auto">
          <SheetHeader>
            <SheetTitle>{openModule?.moduleName}</SheetTitle>
          </SheetHeader>
          <p className="text-xs text-gray-500 mt-1 mb-4">
            Replies attributed to module <code className="font-mono">{openModule?.moduleId}</code>.
            Low-confidence rows arrived &gt;3 days after the prior send.
          </p>
          <div className="space-y-3">
            {(drawerData?.messages ?? []).length === 0 && (
              <p className="text-sm text-gray-400">No attributed replies yet.</p>
            )}
            {(drawerData?.messages ?? []).map((m) => (
              <div key={m.id} className="border rounded p-3 text-sm" data-testid={`drawer-msg-${m.id}`}>
                <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                  <span>{m.receivedAt ? new Date(m.receivedAt).toLocaleString() : "—"}</span>
                  <span className="flex items-center gap-2">
                    <span>after {fmtAge(m.priorSendAgeMs)}</span>
                    {m.lowConfidence && (
                      <span className="inline-flex items-center text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">
                        <AlertTriangle className="w-3 h-3 mr-1" />low confidence
                      </span>
                    )}
                  </span>
                </div>
                <p className="text-gray-900 whitespace-pre-wrap">{m.content}</p>
                <p className="text-xs text-gray-400 mt-1">
                  contact: <code className="font-mono">{m.contactId ?? m.contactPhone ?? "—"}</code>
                </p>
              </div>
            ))}
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
