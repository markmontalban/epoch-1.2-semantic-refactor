import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { resolveLocalOrgId, localGet } from "@/lib/localApi";
import { Cpu, DollarSign, Zap, BarChart3, AlertCircle } from "lucide-react";

interface TokenSummary {
  totalPromptTokens: number;
  totalCompletionTokens: number;
  totalTokens: number;
  totalCostUsd: number;
  byModel: Record<
    string,
    { promptTokens: number; completionTokens: number; costUsd: number }
  >;
  recentUsage: Array<{
    id: number;
    model: string;
    promptTokens: number | null;
    completionTokens: number | null;
    estimatedCostUsd: number | null;
    createdAt: string | null;
    operation: string | null;
  }>;
}

function fmt(n: number | null | undefined) {
  return (n ?? 0).toLocaleString();
}

function fmtCost(n: number | null | undefined) {
  return `$${(n ?? 0).toFixed(4)}`;
}

export default function TokenUsage() {
  const orgId = resolveLocalOrgId();

  const { data, isLoading, isError } = useQuery<TokenSummary>({
    queryKey: ["/api/local/tokens", orgId],
    queryFn: () => localGet(`/api/local/tokens/${orgId}`),
  });

  const byModel = data?.byModel ?? {};
  const models = Object.entries(byModel).sort(
    ([, a], [, b]) => b.costUsd - a.costUsd
  );

  const summaryCards = [
    {
      label: "Total Tokens",
      value: fmt(data?.totalTokens),
      icon: Zap,
      wrapperCls: "icon-wrapper bg-indigo-100",
      iconCls: "text-indigo-600",
    },
    {
      label: "Prompt Tokens",
      value: fmt(data?.totalPromptTokens),
      icon: Cpu,
      wrapperCls: "icon-wrapper bg-blue-100",
      iconCls: "text-blue-600",
    },
    {
      label: "Completion Tokens",
      value: fmt(data?.totalCompletionTokens),
      icon: BarChart3,
      wrapperCls: "icon-wrapper bg-purple-100",
      iconCls: "text-purple-600",
    },
    {
      label: "Total Cost",
      value: fmtCost(data?.totalCostUsd),
      icon: DollarSign,
      wrapperCls: "icon-wrapper bg-green-100",
      iconCls: "text-green-600",
    },
  ];

  return (
    <div className="space-y-8">
      {isError && (
        <div className="flex items-center gap-2 bg-red-50 border border-red-200 rounded-lg px-4 py-3 text-sm text-red-700">
          <AlertCircle className="w-4 h-4 shrink-0" />
          Failed to load token usage data. Please refresh the page to try again.
        </div>
      )}

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="stat-card">
              <CardContent className="p-6">
                <div className="animate-pulse space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-2/3" />
                  <div className="h-8 bg-gray-200 rounded w-1/2" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {summaryCards.map((card) => {
              const Icon = card.icon;
              return (
                <Card key={card.label} className="stat-card">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">{card.label}</p>
                        <p className="text-2xl font-bold text-gray-900 mt-1">
                          {card.value}
                        </p>
                      </div>
                      <div className={card.wrapperCls}>
                        <Icon className={card.iconCls} size={22} />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <Card className="card-mindful">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold text-gray-900">
                Cost by Model
              </CardTitle>
            </CardHeader>
            <CardContent>
              {models.length === 0 ? (
                <div className="py-10 text-center">
                  <Zap className="mx-auto w-10 h-10 text-gray-300 mb-3" />
                  <p className="text-gray-500 font-medium">No usage recorded yet</p>
                  <p className="text-sm text-gray-400 mt-1">
                    Token usage will appear here after AI content generation.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {models.map(([model, stats]) => {
                    const totalCostAll = data?.totalCostUsd ?? 0;
                    const pct =
                      totalCostAll > 0
                        ? Math.round((stats.costUsd / totalCostAll) * 100)
                        : 0;
                    return (
                      <div key={model}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium text-gray-800 truncate max-w-[55%]">
                            {model}
                          </span>
                          <div className="flex items-center gap-4 text-sm text-gray-600 shrink-0">
                            <span className="hidden sm:inline text-gray-400">
                              {fmt(stats.promptTokens + stats.completionTokens)} tokens
                            </span>
                            <span className="font-semibold text-gray-900">
                              {fmtCost(stats.costUsd)}
                            </span>
                            <span className="w-9 text-right text-gray-400 text-xs">
                              {pct}%
                            </span>
                          </div>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <div className="flex gap-4 mt-1">
                          <span className="text-xs text-gray-400">
                            Prompt: {fmt(stats.promptTokens)}
                          </span>
                          <span className="text-xs text-gray-400">
                            Completion: {fmt(stats.completionTokens)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {(data?.recentUsage?.length ?? 0) > 0 && (
            <Card className="card-mindful">
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-semibold text-gray-900">
                  Recent Usage
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-gray-100">
                        <th className="text-left text-xs font-semibold text-gray-500 px-6 py-3">
                          Model
                        </th>
                        <th className="text-left text-xs font-semibold text-gray-500 px-4 py-3">
                          Operation
                        </th>
                        <th className="text-right text-xs font-semibold text-gray-500 px-4 py-3">
                          Prompt
                        </th>
                        <th className="text-right text-xs font-semibold text-gray-500 px-4 py-3">
                          Completion
                        </th>
                        <th className="text-right text-xs font-semibold text-gray-500 px-4 py-3">
                          Cost
                        </th>
                        <th className="text-right text-xs font-semibold text-gray-500 px-6 py-3">
                          Date
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {data!.recentUsage.slice(0, 20).map((row) => (
                        <tr
                          key={row.id}
                          className="border-b border-gray-50 hover:bg-gray-50 transition-colors"
                        >
                          <td className="px-6 py-3 font-medium text-gray-800 max-w-[200px] truncate">
                            {row.model}
                          </td>
                          <td className="px-4 py-3 text-gray-500">
                            {row.operation ?? "—"}
                          </td>
                          <td className="px-4 py-3 text-right text-gray-600">
                            {fmt(row.promptTokens)}
                          </td>
                          <td className="px-4 py-3 text-right text-gray-600">
                            {fmt(row.completionTokens)}
                          </td>
                          <td className="px-4 py-3 text-right font-medium text-gray-900">
                            {fmtCost(row.estimatedCostUsd)}
                          </td>
                          <td className="px-6 py-3 text-right text-gray-400">
                            {row.createdAt
                              ? new Date(row.createdAt).toLocaleDateString()
                              : "—"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
