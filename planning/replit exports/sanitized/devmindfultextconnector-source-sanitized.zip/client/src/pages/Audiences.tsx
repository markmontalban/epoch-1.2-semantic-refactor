import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { resolveLocalOrgId } from "@/lib/localApi";
import { Users, FileText, Loader2, Trash2, Pencil, ChevronRight, Layers, Plus } from "lucide-react";

function resolveOrgId(): string {
  return resolveLocalOrgId();
}

interface Audience {
  tag: string;
  contactCount: number;
  brief: string;
  briefUpdatedAt: string | null;
}

interface SegmentRow {
  id: number;
  name: string;
  includeTags: string[];
  excludeTags: string[];
  matchMode: string;
}

function CreateSegmentDialog({
  orgId,
  tagOptions,
}: {
  orgId: string;
  tagOptions: string[];
}) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [includeText, setIncludeText] = useState("");
  const [excludeText, setExcludeText] = useState("");
  const [matchMode, setMatchMode] = useState<"OR" | "AND">("OR");

  const createMut = useMutation({
    mutationFn: async () => {
      const includeTags = includeText.split(",").map((t) => t.trim()).filter(Boolean);
      const excludeTags = excludeText.split(",").map((t) => t.trim()).filter(Boolean);
      const res = await fetch(`/api/local/segments/${orgId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), includeTags, excludeTags, matchMode }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || `HTTP ${res.status}`);
      return json as SegmentRow;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/segments", orgId] });
      toast({ title: "Segment created" });
      setOpen(false);
      setName("");
      setIncludeText("");
      setExcludeText("");
      setMatchMode("OR");
    },
    onError: (e: Error) =>
      toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  return (
    <>
      <Button size="sm" variant="outline" onClick={() => setOpen(true)}>
        <Plus className="w-4 h-4 mr-1.5" />
        New segment
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create segment</DialogTitle>
          </DialogHeader>
          <p className="text-xs text-gray-500">
            Combine tags into a reusable cohort. Segments work for journey enroll and subscriber links;
            SMS push still requires a single tag on a draft.
          </p>
          {tagOptions.length > 0 && (
            <p className="text-xs text-gray-400">
              Available tags: {tagOptions.join(", ")}
            </p>
          )}
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium">Name</label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. VIP morning crew" />
            </div>
            <div>
              <label className="text-sm font-medium">Include tags (comma-separated)</label>
              <Input
                value={includeText}
                onChange={(e) => setIncludeText(e.target.value)}
                placeholder="vip, morning"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Exclude tags (optional)</label>
              <Input
                value={excludeText}
                onChange={(e) => setExcludeText(e.target.value)}
                placeholder="paused, churned"
              />
            </div>
            <div className="flex gap-2">
              <Button
                type="button"
                size="sm"
                variant={matchMode === "OR" ? "default" : "outline"}
                onClick={() => setMatchMode("OR")}
              >
                Match any (OR)
              </Button>
              <Button
                type="button"
                size="sm"
                variant={matchMode === "AND" ? "default" : "outline"}
                onClick={() => setMatchMode("AND")}
              >
                Match all (AND)
              </Button>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button
              className="btn-mindful"
              disabled={createMut.isPending || !name.trim() || !includeText.trim()}
              onClick={() => createMut.mutate()}
            >
              {createMut.isPending && <Loader2 className="w-4 h-4 animate-spin mr-1.5" />}
              Create
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default function Audiences() {
  const { toast } = useToast();
  const orgId = resolveOrgId();
  const [editing, setEditing] = useState<Audience | null>(null);
  const [briefDraft, setBriefDraft] = useState("");

  const { data, isLoading } = useQuery<{ audiences: Audience[] }>({
    queryKey: ["/api/local/audiences", orgId],
    queryFn: async () => {
      const sessionId = localStorage.getItem("mindfultext_session_id") || "";
      const res = await fetch(`/api/local/audiences/${orgId}`, {
        headers: { "X-Session-ID": sessionId },
      });
      if (!res.ok) throw new Error((await res.json()).error || "Failed to load audiences");
      return res.json();
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (vars: { tag: string; brief: string }) => {
      const res = await fetch(
        `/api/local/audiences/${orgId}/${encodeURIComponent(vars.tag)}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ brief: vars.brief }),
        },
      );
      if (!res.ok) throw new Error((await res.json()).error || `HTTP ${res.status}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/audiences", orgId] });
      toast({ title: "Brief saved" });
      setEditing(null);
    },
    onError: (e: Error) => {
      toast({ title: "Save failed", description: e.message, variant: "destructive" });
    },
  });

  const clearMutation = useMutation({
    mutationFn: async (tag: string) => {
      const res = await fetch(
        `/api/local/audiences/${orgId}/${encodeURIComponent(tag)}`,
        { method: "DELETE" },
      );
      if (!res.ok) throw new Error((await res.json()).error || `HTTP ${res.status}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/audiences", orgId] });
      toast({ title: "Brief cleared" });
      setEditing(null);
    },
  });

  function openEditor(a: Audience) {
    setEditing(a);
    setBriefDraft(a.brief);
  }

  const audiences = data?.audiences ?? [];

  const { data: segData, isLoading: segLoading } = useQuery<{ segments: SegmentRow[] }>({
    queryKey: ["/api/local/segments", orgId],
    queryFn: () => fetch(`/api/local/segments/${orgId}`).then((r) => r.json()),
  });

  const deleteSegMut = useMutation({
    mutationFn: (id: number) =>
      fetch(`/api/local/segments/${orgId}/${id}`, { method: "DELETE" }).then(async (r) => {
        if (!r.ok) throw new Error((await r.json()).error || "Delete failed");
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/segments", orgId] });
      toast({ title: "Segment deleted" });
    },
    onError: (e: Error) =>
      toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const segments = segData?.segments ?? [];
  const tagOptions = audiences.map((a) => a.tag);

  return (
    <div className="space-y-8">
      <Card className="border border-indigo-100 bg-indigo-50/40">
        <CardContent className="p-3 text-xs text-gray-700 space-y-1.5">
          <p className="font-medium text-indigo-900">Webhook intake</p>
          <p>
            Outside agents can post drafts straight to this app. Send <code className="bg-white px-1 rounded">POST /api/webhooks/drafts</code>
            {" "}with header <code className="bg-white px-1 rounded">X-Webhook-Secret: $CONTENT_WEBHOOK_SECRET</code>.
            Body must include <code className="bg-white px-1 rounded">audienceTag</code> plus either <code className="bg-white px-1 rounded">topic</code> (auto-plan) or <code className="bg-white px-1 rounded">texts[]</code>.
            See README for a sample <code>curl</code>.
          </p>
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="space-y-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="border border-gray-100 animate-pulse">
              <CardContent className="p-4">
                <div className="h-4 bg-gray-200 rounded w-40 mb-2" />
                <div className="h-3 bg-gray-100 rounded w-24" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : audiences.length === 0 ? (
        <Card className="border border-dashed border-gray-200">
          <CardContent className="py-12 text-center">
            <Users className="w-10 h-10 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">No tags found on your contacts</p>
            <p className="text-sm text-gray-400 mt-1">
              Tag contacts in MindfulText, then come back here to give each tag a brief.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {audiences.map((a) => (
            <Card key={a.tag} className="border border-gray-100 shadow-sm hover:border-indigo-200 transition-colors">
              <CardContent className="p-4 flex items-start justify-between gap-3">
                <Link
                  href={`/audiences/${encodeURIComponent(a.tag)}`}
                  className="min-w-0 flex-1 group"
                >
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-gray-900 group-hover:text-indigo-700">
                      {a.tag}
                    </span>
                    <span className="text-xs text-gray-400">
                      {a.contactCount} contact{a.contactCount !== 1 ? "s" : ""}
                    </span>
                    {a.brief?.trim() ? (
                      <span className="inline-flex items-center gap-1 text-xs text-green-700 bg-green-50 px-2 py-0.5 rounded-full">
                        <FileText className="w-3 h-3" /> Brief set
                      </span>
                    ) : (
                      <span className="text-xs text-gray-400">No brief</span>
                    )}
                  </div>
                  {a.brief?.trim() && (
                    <p className="text-xs text-gray-500 mt-1.5 line-clamp-2 whitespace-pre-wrap">
                      {a.brief}
                    </p>
                  )}
                </Link>
                <div className="flex items-center gap-1 shrink-0">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => openEditor(a)}
                  >
                    <Pencil className="w-3.5 h-3.5 mr-1.5" />
                    {a.brief?.trim() ? "Edit" : "Add brief"}
                  </Button>
                  <Link href={`/audiences/${encodeURIComponent(a.tag)}`}>
                    <Button size="sm" variant="ghost" aria-label="View group">
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <section className="space-y-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div>
            <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-600" />
              Saved segments
            </h2>
            <p className="text-sm text-gray-500">
              Multi-tag cohorts for bulk journey enroll and subscriber links.
            </p>
          </div>
          <CreateSegmentDialog orgId={orgId} tagOptions={tagOptions} />
        </div>

        {segLoading ? (
          <Card className="border border-gray-100 animate-pulse">
            <CardContent className="p-4 h-16" />
          </Card>
        ) : segments.length === 0 ? (
          <Card className="border border-dashed border-gray-200">
            <CardContent className="py-8 text-center text-sm text-gray-500">
              No segments yet. Create one to combine tags with AND/OR rules.
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            {segments.map((s) => (
              <Card key={s.id} className="border border-gray-100 shadow-sm">
                <CardContent className="p-4 flex items-center justify-between gap-3">
                  <Link href={`/segments/${s.id}`} className="min-w-0 flex-1 group">
                    <p className="font-semibold text-gray-900 group-hover:text-indigo-700">{s.name}</p>
                    <p className="text-xs text-gray-500 mt-0.5 font-mono truncate">
                      {s.matchMode}: {s.includeTags.join(", ")}
                      {s.excludeTags.length > 0 && ` · not ${s.excludeTags.join(", ")}`}
                    </p>
                  </Link>
                  <div className="flex gap-1 shrink-0">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-red-600"
                      onClick={() => deleteSegMut.mutate(s.id)}
                      disabled={deleteSegMut.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    <Link href={`/segments/${s.id}`}>
                      <Button size="sm" variant="ghost">
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>

      <Dialog open={!!editing} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Audience brief — {editing?.tag}</DialogTitle>
          </DialogHeader>
          <p className="text-xs text-gray-500">
            Markdown supported. The AI sees this verbatim in its system prompt whenever
            content is generated for this audience tag.
            {editing?.contactCount === 0 && (
              <span className="text-amber-600 ml-1">
                (No contacts currently carry this tag.)
              </span>
            )}
          </p>
          <Textarea
            value={briefDraft}
            onChange={(e) => setBriefDraft(e.target.value)}
            placeholder={`e.g.\n\n- Tone: warm, direct\n- Focus: morning rituals, breath work\n- Avoid: jargon, long paragraphs`}
            className="min-h-[260px] font-mono text-xs"
          />
          <DialogFooter className="gap-2">
            {editing?.brief?.trim() && (
              <Button
                variant="outline"
                onClick={() => editing && clearMutation.mutate(editing.tag)}
                disabled={clearMutation.isPending}
                className="text-red-600 hover:text-red-700 mr-auto"
              >
                <Trash2 className="w-4 h-4 mr-1.5" />
                Clear brief
              </Button>
            )}
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
            <Button
              onClick={() =>
                editing && saveMutation.mutate({ tag: editing.tag, brief: briefDraft })
              }
              disabled={saveMutation.isPending}
              className="btn-mindful"
            >
              {saveMutation.isPending && <Loader2 className="w-4 h-4 animate-spin mr-1.5" />}
              Save brief
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
