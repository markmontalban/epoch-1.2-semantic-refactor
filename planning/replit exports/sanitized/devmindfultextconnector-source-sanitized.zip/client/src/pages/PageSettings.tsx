import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface PageSettingsForm {
  brandName: string;
  tagline: string;
  accentColor: string;
  footerText: string;
  showTopics: boolean;
  topicsLabel: string;
  showReceived: boolean;
  receivedLabel: string;
  showLibrary: boolean;
  libraryLabel: string;
}

const DEFAULTS: PageSettingsForm = {
  brandName: "MindfulText",
  tagline: "Your space to revisit and explore.",
  accentColor: "#6366f1",
  footerText: "MindfulText",
  showTopics: true,
  topicsLabel: "Your topics",
  showReceived: true,
  receivedLabel: "Messages you’ve received",
  showLibrary: true,
  libraryLabel: "More for you",
};

function pick(data: Partial<PageSettingsForm> | undefined): PageSettingsForm {
  return {
    brandName: data?.brandName ?? DEFAULTS.brandName,
    tagline: data?.tagline ?? DEFAULTS.tagline,
    accentColor: data?.accentColor ?? DEFAULTS.accentColor,
    footerText: data?.footerText ?? DEFAULTS.footerText,
    showTopics: data?.showTopics ?? DEFAULTS.showTopics,
    topicsLabel: data?.topicsLabel ?? DEFAULTS.topicsLabel,
    showReceived: data?.showReceived ?? DEFAULTS.showReceived,
    receivedLabel: data?.receivedLabel ?? DEFAULTS.receivedLabel,
    showLibrary: data?.showLibrary ?? DEFAULTS.showLibrary,
    libraryLabel: data?.libraryLabel ?? DEFAULTS.libraryLabel,
  };
}

export default function PageSettings() {
  const { toast } = useToast();
  const [tab, setTab] = useState<"appearance" | "sections">("appearance");
  const [form, setForm] = useState<PageSettingsForm>(DEFAULTS);

  const { data, isLoading } = useQuery<PageSettingsForm>({
    queryKey: ["/api/local/page-settings"],
    queryFn: () => fetch("/api/local/page-settings").then((r) => r.json()),
  });

  useEffect(() => {
    if (data) setForm(pick(data));
  }, [data]);

  const saveMut = useMutation({
    mutationFn: (value: PageSettingsForm) =>
      apiRequest("PUT", "/api/local/page-settings", value),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/local/page-settings"] });
      toast({ title: "Page settings saved" });
    },
    onError: (e: any) =>
      toast({ title: "Failed", description: e.message, variant: "destructive" }),
  });

  const set = <K extends keyof PageSettingsForm>(key: K, value: PageSettingsForm[K]) =>
    setForm((f) => ({ ...f, [key]: value }));

  const accent = form.accentColor || DEFAULTS.accentColor;

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-gray-900">Subscriber page</h1>
        <p className="text-sm text-gray-500">
          Control how your subscribers' private pages look. Changes apply to every contact's page.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Editor */}
        <div className="bg-white border border-gray-200 rounded-lg p-5">
          <div className="flex gap-1 mb-5 border-b border-gray-100">
            <button
              onClick={() => setTab("appearance")}
              className={`px-3 py-2 text-sm font-medium -mb-px border-b-2 ${
                tab === "appearance"
                  ? "border-indigo-600 text-indigo-700"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
              data-testid="tab-appearance"
            >
              Appearance
            </button>
            <button
              onClick={() => setTab("sections")}
              className={`px-3 py-2 text-sm font-medium -mb-px border-b-2 ${
                tab === "sections"
                  ? "border-indigo-600 text-indigo-700"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
              data-testid="tab-sections"
            >
              Sections
            </button>
          </div>

          {isLoading ? (
            <p className="text-sm text-gray-500">Loading…</p>
          ) : tab === "appearance" ? (
            <div className="space-y-4">
              <Field label="Brand name" hint="Shown at the top and in the footer.">
                <input
                  className="w-full border rounded px-2 py-1.5 text-sm"
                  value={form.brandName}
                  onChange={(e) => set("brandName", e.target.value)}
                  data-testid="input-brand-name"
                />
              </Field>
              <Field label="Tagline" hint="The line under the greeting.">
                <input
                  className="w-full border rounded px-2 py-1.5 text-sm"
                  value={form.tagline}
                  onChange={(e) => set("tagline", e.target.value)}
                  data-testid="input-tagline"
                />
              </Field>
              <Field label="Accent color">
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    className="h-9 w-12 border rounded cursor-pointer"
                    value={accent}
                    onChange={(e) => set("accentColor", e.target.value)}
                    data-testid="input-accent-color"
                  />
                  <input
                    className="border rounded px-2 py-1.5 text-sm font-mono w-28"
                    value={form.accentColor}
                    onChange={(e) => set("accentColor", e.target.value)}
                  />
                </div>
              </Field>
              <Field label="Footer text">
                <input
                  className="w-full border rounded px-2 py-1.5 text-sm"
                  value={form.footerText}
                  onChange={(e) => set("footerText", e.target.value)}
                  data-testid="input-footer-text"
                />
              </Field>
            </div>
          ) : (
            <div className="space-y-5">
              <SectionToggle
                label="Topics"
                desc="The tags this contact is subscribed to."
                enabled={form.showTopics}
                onToggle={(v) => set("showTopics", v)}
                labelValue={form.topicsLabel}
                onLabelChange={(v) => set("topicsLabel", v)}
                testid="topics"
              />
              <SectionToggle
                label="Messages received"
                desc="The content this contact has already been sent."
                enabled={form.showReceived}
                onToggle={(v) => set("showReceived", v)}
                labelValue={form.receivedLabel}
                onLabelChange={(v) => set("receivedLabel", v)}
                testid="received"
              />
              <SectionToggle
                label="Library"
                desc="Extra published content matched to their topics."
                enabled={form.showLibrary}
                onToggle={(v) => set("showLibrary", v)}
                labelValue={form.libraryLabel}
                onLabelChange={(v) => set("libraryLabel", v)}
                testid="library"
              />
            </div>
          )}

          <button
            onClick={() => saveMut.mutate(form)}
            disabled={saveMut.isPending}
            className="mt-6 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded text-sm disabled:opacity-60"
            data-testid="button-save-page-settings"
          >
            {saveMut.isPending ? "Saving…" : "Save changes"}
          </button>
        </div>

        {/* Live preview */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-gray-400 mb-2">
            Live preview
          </p>
          <div
            className="rounded-2xl border border-gray-200 overflow-hidden"
            style={{ background: `linear-gradient(to bottom, ${accent}12, #ffffff)` }}
          >
            <div className="px-5 pb-10 pt-8">
              <p className="text-sm font-medium" style={{ color: accent }}>
                {form.brandName || "Brand"}
              </p>
              <h2 className="mt-1 text-2xl font-semibold tracking-tight text-gray-900">
                Hi, Maria
              </h2>
              {form.tagline && (
                <p className="mt-1 text-sm text-gray-500">{form.tagline}</p>
              )}

              <div
                className="mt-5 rounded-2xl bg-white p-4 shadow-sm ring-1 ring-gray-100"
                style={{ borderLeft: `3px solid ${accent}` }}
              >
                <p className="text-sm leading-relaxed text-gray-700">
                  Your personal note to this contact shows here (set per-contact).
                </p>
              </div>

              {form.showTopics && (
                <div className="mt-6">
                  <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-gray-400">
                    {form.topicsLabel}
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {["Sleep", "Focus"].map((t) => (
                      <span
                        key={t}
                        className="rounded-full px-3 py-1 text-sm font-medium"
                        style={{ backgroundColor: `${accent}1a`, color: accent }}
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {form.showReceived && (
                <div className="mt-6">
                  <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-gray-400">
                    {form.receivedLabel}
                  </h3>
                  <div className="rounded-xl bg-white px-4 py-3 shadow-sm ring-1 ring-gray-100 text-sm font-medium text-gray-800">
                    A gentle reset for your evening
                  </div>
                </div>
              )}

              {form.showLibrary && (
                <div className="mt-6">
                  <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-gray-400">
                    {form.libraryLabel}
                  </h3>
                  <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-gray-100">
                    <h4 className="text-base font-semibold text-gray-900">
                      Three ways to wind down
                    </h4>
                    <p className="mt-1 text-sm leading-relaxed text-gray-600">
                      A short read to help you ease into rest.
                    </p>
                  </div>
                </div>
              )}

              <p className="mt-8 text-center text-xs text-gray-300">
                {form.footerText}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-900 mb-1">{label}</label>
      {hint && <p className="text-xs text-gray-500 mb-1.5">{hint}</p>}
      {children}
    </div>
  );
}

function SectionToggle({
  label,
  desc,
  enabled,
  onToggle,
  labelValue,
  onLabelChange,
  testid,
}: {
  label: string;
  desc: string;
  enabled: boolean;
  onToggle: (v: boolean) => void;
  labelValue: string;
  onLabelChange: (v: string) => void;
  testid: string;
}) {
  return (
    <div className="border border-gray-100 rounded-lg p-3">
      <label className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-gray-900">{label}</p>
          <p className="text-xs text-gray-500">{desc}</p>
        </div>
        <input
          type="checkbox"
          checked={enabled}
          onChange={(e) => onToggle(e.target.checked)}
          data-testid={`toggle-${testid}`}
        />
      </label>
      {enabled && (
        <input
          className="mt-3 w-full border rounded px-2 py-1.5 text-sm"
          value={labelValue}
          onChange={(e) => onLabelChange(e.target.value)}
          placeholder="Section heading"
          data-testid={`input-label-${testid}`}
        />
      )}
    </div>
  );
}
