import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Sparkles, ExternalLink, Trash2, Undo2, RefreshCw, BookOpen, EyeOff, Eye,
} from "lucide-react";

interface StagedLink {
  id: number;
  url: string;
  moduleId: string | null;
  moduleName: string | null;
  dayIndex: number | null;
  context: string | null;
  likelyMeditation: boolean;
  suggestedTitle: string | null;
  suggestedTheme: string | null;
  status: string;
  publishedContentId: number | null;
}

interface LibraryItem {
  id: number;
  title: string;
  body: string;
  topic: string | null;
  contentType: string;
  url: string | null;
  theme: string | null;
  complexity: string | null;
  published: boolean;
}

interface HarvestSummary {
  modulesScanned: number;
  modulesFailed: number;
  urlsFound: number;
  newStaged: number;
  alreadyKnown: number;
}

const THEMES = ["sleep", "stress", "focus", "gratitude", "breathing", "calm", "morning"];
const COMPLEXITIES = ["beginner", "intermediate", "advanced"];

function hostOf(url: string): string {
  try {
    return new URL(url).host;
  } catch {
    return url;
  }
}

function StagedRow({ link }: { link: StagedLink }) {
  const { toast } = useToast();
  const [title, setTitle] = useState(link.suggestedTitle ?? "");
  const [theme, setTheme] = useState(link.suggestedTheme ?? "");
  const [complexity, setComplexity] = useState("");

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/local/library/staged"] });
    queryClient.invalidateQueries({ queryKey: ["/api/local/library"] });
  };

  const publishMut = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/local/library/staged/${link.id}/publish`, {
        title: title.trim(),
        theme: theme.trim(),
        complexity: complexity.trim(),
      });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Published to library" });
      invalidate();
    },
    onError: (e: any) => toast({ title: "Publish failed", description: e.message, variant: "destructive" }),
  });

  const statusMut = useMutation({
    mutationFn: (status: "staged" | "discarded") =>
      apiRequest("PATCH", `/api/local/library/staged/${link.id}`, { status }),
    onSuccess: invalidate,
    onError: (e: any) => toast({ title: "Update failed", description: e.message, variant: "destructive" }),
  });

  const discarded = link.status === "discarded";

  return (
    <div className={`border rounded-lg p-4 ${discarded ? "bg-gray-50 opacity-70" : "bg-white"}`} data-testid={`staged-row-${link.id}`}>
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            {link.likelyMeditation && (
              <span className="inline-flex items-center gap-1 rounded-full bg-violet-100 text-violet-700 px-2 py-0.5 text-xs font-medium">
                <Sparkles className="w-3 h-3" /> Likely meditation
              </span>
            )}
            {link.moduleName && (
              <span className="text-xs text-gray-500">
                {link.moduleName}
                {link.dayIndex ? ` · Day ${link.dayIndex}` : ""}
              </span>
            )}
          </div>
          <a
            href={link.url}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 text-sm text-indigo-600 hover:underline break-all"
          >
            {hostOf(link.url)}
            <ExternalLink className="w-3.5 h-3.5 shrink-0" />
          </a>
          {link.context && (
            <p className="mt-1.5 text-xs text-gray-500 leading-relaxed">{link.context}</p>
          )}
        </div>
      </div>

      {!discarded ? (
        <div className="mt-3 flex flex-wrap gap-2 items-center">
          <input
            className="border rounded px-2 py-1.5 text-sm flex-1 min-w-[180px]"
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            data-testid={`input-title-${link.id}`}
          />
          <select
            className="border rounded px-2 py-1.5 text-sm bg-white"
            value={theme}
            onChange={(e) => setTheme(e.target.value)}
            data-testid={`select-theme-${link.id}`}
          >
            <option value="">Theme…</option>
            {THEMES.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
          <select
            className="border rounded px-2 py-1.5 text-sm bg-white"
            value={complexity}
            onChange={(e) => setComplexity(e.target.value)}
            data-testid={`select-complexity-${link.id}`}
          >
            <option value="">Level…</option>
            {COMPLEXITIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <button
            onClick={() => publishMut.mutate()}
            disabled={publishMut.isPending || !title.trim()}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded text-sm disabled:opacity-60"
            data-testid={`button-publish-${link.id}`}
          >
            {publishMut.isPending ? "Publishing…" : "Publish"}
          </button>
          <button
            onClick={() => statusMut.mutate("discarded")}
            disabled={statusMut.isPending}
            className="text-gray-500 hover:text-red-600 p-1.5"
            title="Discard"
            data-testid={`button-discard-${link.id}`}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <button
          onClick={() => statusMut.mutate("staged")}
          disabled={statusMut.isPending}
          className="mt-2 inline-flex items-center gap-1 text-sm text-gray-600 hover:text-gray-900"
          data-testid={`button-restore-${link.id}`}
        >
          <Undo2 className="w-3.5 h-3.5" /> Restore
        </button>
      )}
    </div>
  );
}

function PublishedRow({ item }: { item: LibraryItem }) {
  const { toast } = useToast();
  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["/api/local/library"] });

  const patchMut = useMutation({
    mutationFn: (patch: Record<string, unknown>) =>
      apiRequest("PATCH", `/api/local/library/${item.id}`, patch),
    onSuccess: invalidate,
    onError: (e: any) => toast({ title: "Update failed", description: e.message, variant: "destructive" }),
  });

  const deleteMut = useMutation({
    mutationFn: () => apiRequest("DELETE", `/api/local/library/${item.id}`),
    onSuccess: () => {
      toast({ title: "Removed from library" });
      invalidate();
      queryClient.invalidateQueries({ queryKey: ["/api/local/library/staged"] });
    },
    onError: (e: any) => toast({ title: "Delete failed", description: e.message, variant: "destructive" }),
  });

  return (
    <div className={`border rounded-lg p-4 bg-white ${!item.published ? "opacity-60" : ""}`} data-testid={`published-row-${item.id}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <p className="font-medium text-gray-900 text-sm">{item.title}</p>
          <div className="mt-1 flex items-center gap-2 flex-wrap text-xs">
            {item.theme && (
              <span className="rounded-full bg-indigo-50 text-indigo-700 px-2 py-0.5 font-medium">{item.theme}</span>
            )}
            {item.complexity && (
              <span className="rounded-full bg-gray-100 text-gray-600 px-2 py-0.5 font-medium">{item.complexity}</span>
            )}
            {item.url && (
              <a href={item.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-indigo-600 hover:underline break-all">
                {hostOf(item.url)} <ExternalLink className="w-3 h-3 shrink-0" />
              </a>
            )}
            {!item.published && <span className="text-amber-600 font-medium">hidden</span>}
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => patchMut.mutate({ published: !item.published })}
            disabled={patchMut.isPending}
            className="text-gray-500 hover:text-gray-900 p-1.5"
            title={item.published ? "Hide from page" : "Show on page"}
            data-testid={`button-toggle-${item.id}`}
          >
            {item.published ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
          <button
            onClick={() => {
              if (confirm("Remove this item from the library?")) deleteMut.mutate();
            }}
            disabled={deleteMut.isPending}
            className="text-gray-500 hover:text-red-600 p-1.5"
            title="Delete"
            data-testid={`button-delete-${item.id}`}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

export default function MeditationLibrary() {
  const { toast } = useToast();
  const [tab, setTab] = useState<"staged" | "published" | "discarded">("staged");

  const stagedQuery = useQuery<StagedLink[]>({
    queryKey: ["/api/local/library/staged"],
  });
  const libraryQuery = useQuery<LibraryItem[]>({
    queryKey: ["/api/local/library"],
  });

  const harvestMut = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/local/library/harvest", {});
      return res.json() as Promise<HarvestSummary>;
    },
    onSuccess: (s) => {
      toast({
        title: "Scan complete",
        description: `${s.modulesScanned} modules scanned · ${s.newStaged} new link${s.newStaged === 1 ? "" : "s"} staged (${s.alreadyKnown} already known)`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/local/library/staged"] });
    },
    onError: (e: any) => toast({ title: "Scan failed", description: e.message, variant: "destructive" }),
  });

  const all = stagedQuery.data ?? [];
  const staged = all.filter((l) => l.status === "staged");
  const discarded = all.filter((l) => l.status === "discarded");
  const meditations = (libraryQuery.data ?? []).filter((i) => i.contentType === "meditation");

  const tabs = [
    { key: "staged" as const, label: `To review (${staged.length})` },
    { key: "published" as const, label: `Published (${meditations.length})` },
    { key: "discarded" as const, label: `Discarded (${discarded.length})` },
  ];

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-5">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-indigo-600" /> Meditation Library
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Scan your MindfulText modules for meditation links, review them, and publish the keepers to the subscriber page.
          </p>
        </div>
        <button
          onClick={() => harvestMut.mutate()}
          disabled={harvestMut.isPending}
          className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded text-sm disabled:opacity-60"
          data-testid="button-harvest"
        >
          <RefreshCw className={`w-4 h-4 ${harvestMut.isPending ? "animate-spin" : ""}`} />
          {harvestMut.isPending ? "Scanning modules…" : "Scan modules for links"}
        </button>
      </div>

      <div className="flex gap-1 border-b border-gray-200">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-3 py-2 text-sm font-medium border-b-2 -mb-px ${
              tab === t.key
                ? "border-indigo-600 text-indigo-700"
                : "border-transparent text-gray-500 hover:text-gray-800"
            }`}
            data-testid={`tab-${t.key}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "staged" && (
        <div className="space-y-3">
          {stagedQuery.isLoading ? (
            <p className="text-sm text-gray-400">Loading…</p>
          ) : staged.length === 0 ? (
            <p className="rounded-lg border border-dashed border-gray-200 bg-gray-50 px-4 py-8 text-center text-sm text-gray-400">
              Nothing to review. Click “Scan modules for links” to pull URLs out of your module texts.
            </p>
          ) : (
            staged.map((l) => <StagedRow key={l.id} link={l} />)
          )}
        </div>
      )}

      {tab === "published" && (
        <div className="space-y-3">
          {libraryQuery.isLoading ? (
            <p className="text-sm text-gray-400">Loading…</p>
          ) : meditations.length === 0 ? (
            <p className="rounded-lg border border-dashed border-gray-200 bg-gray-50 px-4 py-8 text-center text-sm text-gray-400">
              No meditations published yet. Publish staged links to build the subscriber library.
            </p>
          ) : (
            meditations.map((i) => <PublishedRow key={i.id} item={i} />)
          )}
        </div>
      )}

      {tab === "discarded" && (
        <div className="space-y-3">
          {discarded.length === 0 ? (
            <p className="rounded-lg border border-dashed border-gray-200 bg-gray-50 px-4 py-8 text-center text-sm text-gray-400">
              Nothing discarded.
            </p>
          ) : (
            discarded.map((l) => <StagedRow key={l.id} link={l} />)
          )}
        </div>
      )}
    </div>
  );
}
