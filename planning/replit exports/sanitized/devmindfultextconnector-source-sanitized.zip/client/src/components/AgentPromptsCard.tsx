import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { resolveLocalOrgId } from "@/lib/localApi";
import { Bot, Plus, Trash2 } from "lucide-react";

function sessionHeader(): Record<string, string> {
  return { "X-Session-ID": localStorage.getItem("mindfultext_session_id") || "" };
}

interface AgentRule {
  id: number;
  name: string;
  content: string;
  scope: string;
  isActive: boolean | null;
}

const SCOPES = ["global", "content_generation", "reply_drafting", "program_creation"];

export default function AgentPromptsCard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const orgId = resolveLocalOrgId();

  // --- Base prompt (mindfultext.md) ---
  const baseQuery = useQuery<{ content: string }>({
    queryKey: ["/api/local/base-prompt"],
    queryFn: async () => {
      const r = await fetch("/api/local/base-prompt", { headers: sessionHeader() });
      if (!r.ok) throw new Error(`base-prompt ${r.status}`);
      return r.json();
    },
  });
  const [base, setBase] = useState("");
  useEffect(() => {
    if (baseQuery.data) setBase(baseQuery.data.content);
  }, [baseQuery.data]);

  const saveBase = useMutation({
    mutationFn: async (content: string) => {
      const r = await fetch("/api/local/base-prompt", {
        method: "PUT",
        headers: { "Content-Type": "application/json", ...sessionHeader() },
        body: JSON.stringify({ content }),
      });
      if (!r.ok) throw new Error(`save base-prompt ${r.status}`);
      return r.json();
    },
    onSuccess: () => {
      toast({ title: "Base prompt saved", description: "mindfultext.md updated and reloaded." });
      queryClient.invalidateQueries({ queryKey: ["/api/local/base-prompt"] });
    },
    onError: (e: unknown) =>
      toast({ title: "Save failed", description: String(e), variant: "destructive" }),
  });

  // --- Org rules ---
  const rulesQuery = useQuery<AgentRule[]>({
    queryKey: ["/api/local/rules", orgId],
    queryFn: async () => {
      const r = await fetch(`/api/local/rules/${orgId}`, { headers: sessionHeader() });
      if (!r.ok) throw new Error(`rules ${r.status}`);
      return r.json();
    },
  });

  const [newName, setNewName] = useState("");
  const [newContent, setNewContent] = useState("");
  const [newScope, setNewScope] = useState("global");

  const createRule = useMutation({
    mutationFn: async () => {
      const r = await fetch("/api/local/rules", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...sessionHeader() },
        body: JSON.stringify({
          organizationId: orgId,
          name: newName.trim(),
          content: newContent.trim(),
          scope: newScope,
        }),
      });
      if (!r.ok) throw new Error(`create rule ${r.status}`);
      return r.json();
    },
    onSuccess: () => {
      setNewName("");
      setNewContent("");
      setNewScope("global");
      queryClient.invalidateQueries({ queryKey: ["/api/local/rules", orgId] });
    },
    onError: (e: unknown) =>
      toast({ title: "Couldn't add rule", description: String(e), variant: "destructive" }),
  });

  const deleteRule = useMutation({
    mutationFn: async (id: number) => {
      const r = await fetch(`/api/local/rules/${id}`, {
        method: "DELETE",
        headers: sessionHeader(),
      });
      if (!r.ok) throw new Error(`delete rule ${r.status}`);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/local/rules", orgId] }),
  });

  const rules = rulesQuery.data ?? [];

  return (
    <Card className="card-mindful">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Bot className="w-5 h-5 mr-2" />
          Agent prompts
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <Label htmlFor="base-prompt">Base prompt (mindfultext.md)</Label>
          <p className="text-xs text-gray-500 mt-1 mb-2">
            The agent's core personality and constraints, prepended to every AI
            call. Org rules and memory are layered on top.
          </p>
          <textarea
            id="base-prompt"
            value={base}
            onChange={(e) => setBase(e.target.value)}
            spellCheck={false}
            className="w-full h-64 rounded-md border border-gray-200 p-3 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <div className="flex justify-end mt-2">
            <Button
              className="btn-mindful"
              disabled={saveBase.isPending || base === baseQuery.data?.content}
              onClick={() => saveBase.mutate(base)}
            >
              {saveBase.isPending ? "Saving…" : "Save base prompt"}
            </Button>
          </div>
        </div>

        <div className="border-t pt-6">
          <Label>Organization rules</Label>
          <p className="text-xs text-gray-500 mt-1 mb-3">
            Extra instructions layered on the base prompt for this org, optionally
            scoped to a specific task.
          </p>

          <div className="space-y-3">
            {rules.length === 0 && (
              <p className="text-sm text-gray-500">No org rules yet.</p>
            )}
            {rules.map((rule) => (
              <div key={rule.id} className="border border-gray-200 rounded-md p-3">
                <div className="flex items-center justify-between mb-1">
                  <div className="text-sm font-medium text-gray-900">
                    {rule.name}
                    <span className="ml-2 text-xs font-normal text-gray-400">{rule.scope}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-red-600 hover:text-red-700 h-7 px-2"
                    onClick={() => deleteRule.mutate(rule.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-600 whitespace-pre-wrap">{rule.content}</p>
              </div>
            ))}
          </div>

          <div className="mt-4 space-y-2 bg-gray-50 border border-gray-200 rounded-md p-3">
            <div className="flex items-center gap-2">
              <Plus className="w-4 h-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Add a rule</span>
            </div>
            <div className="grid sm:grid-cols-2 gap-2">
              <Input
                placeholder="Rule name"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
              />
              <select
                value={newScope}
                onChange={(e) => setNewScope(e.target.value)}
                className="rounded-md border border-gray-200 px-3 text-sm"
              >
                {SCOPES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
            <textarea
              placeholder="Rule content / instructions…"
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              className="w-full h-20 rounded-md border border-gray-200 p-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <div className="flex justify-end">
              <Button
                variant="outline"
                size="sm"
                disabled={!newName.trim() || !newContent.trim() || createRule.isPending}
                onClick={() => createRule.mutate()}
              >
                {createRule.isPending ? "Adding…" : "Add rule"}
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
