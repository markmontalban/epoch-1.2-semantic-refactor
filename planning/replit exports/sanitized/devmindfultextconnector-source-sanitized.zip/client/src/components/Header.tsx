import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Bell, Menu, User, Building2 } from "lucide-react";
import { authService } from "@/lib/auth";
import { LogoutButton } from "./LogoutButton";

type SettingsResponse = {
  orgId: string;
  orgName: string | null;
  email: string | null;
  hasPassword: boolean;
  signedIn: boolean;
};

function sessionHeader(): Record<string, string> {
  return { "X-Session-ID": localStorage.getItem("mindfultext_session_id") || "" };
}

const pageTitles: Record<string, { title: string; subtitle: string }> = {
  "/dashboard":        { title: "Dashboard",       subtitle: "Here's what's happening today." },
  "/drafts":           { title: "Drafts",           subtitle: "AI-generated content staged for review." },
  "/audiences":        { title: "Audiences",        subtitle: "Manage audience segments and tags." },
  "/import":           { title: "Import / Export",  subtitle: "Import contacts or export your data." },
  "/workbench":        { title: "Workbench",        subtitle: "Build and manage journeys, modules, and messages." },
  "/automation":       { title: "Automation",       subtitle: "Configure reshape rules and pending changes." },
  "/changes":          { title: "Changes",          subtitle: "Review and approve pending AI-suggested changes." },
  "/replies":          { title: "Replies",          subtitle: "Review draft replies and reply analytics." },
  "/replies/analytics":{ title: "Reply Analytics",  subtitle: "Analyse inbound reply patterns and trends." },
  "/token-usage":      { title: "Token Usage",      subtitle: "AI token consumption and cost breakdown by model." },
  "/ask":              { title: "Ask",              subtitle: "Ask natural-language questions about your data." },
  "/settings":         { title: "Settings",         subtitle: "Configure your organisation and credentials." },
  "/profile":          { title: "Profile",          subtitle: "Manage your account settings." },
};

interface HeaderProps {
  onMenuClick: () => void;
}

export default function Header({ onMenuClick }: HeaderProps) {
  const [location] = useLocation();
  const pageInfo = pageTitles[location] || { title: "MindfulText", subtitle: "" };

  const settingsQuery = useQuery<SettingsResponse>({
    queryKey: ["/api/local/settings"],
    queryFn: async () => {
      const r = await fetch("/api/local/settings", { headers: sessionHeader() });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return r.json();
    },
    retry: false,
    staleTime: 30_000,
  });
  const orgName = settingsQuery.data?.orgName;
  const orgId = settingsQuery.data?.orgId;

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 px-4 sm:px-6 py-3 sm:py-4 shrink-0">
      <div className="flex items-center gap-3">
        <button
          onClick={onMenuClick}
          className="sm:hidden p-1.5 rounded text-gray-500 hover:text-gray-800 hover:bg-gray-100 transition-colors"
          aria-label="Open menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex-1 min-w-0">
          <h1 className="text-lg sm:text-2xl font-bold text-gray-900 truncate">
            {pageInfo.title}
          </h1>
          {pageInfo.subtitle && (
            <p className="text-xs sm:text-sm text-gray-500 truncate hidden sm:block">
              {pageInfo.subtitle}
            </p>
          )}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {(orgName || orgId) && (
            <span
              className="hidden md:flex items-center gap-1.5 text-sm text-gray-700 border border-gray-200 rounded-md px-2.5 py-1 bg-gray-50"
              data-testid="header-org"
              title={orgId ? `Org ID: ${orgId}` : undefined}
            >
              <Building2 className="w-4 h-4 text-gray-500" />
              <span className="font-medium truncate max-w-[12rem]">
                {orgName || orgId}
              </span>
              {orgName && orgId && (
                <span className="text-xs text-gray-500 font-mono">{orgId}</span>
              )}
            </span>
          )}
          {authService.isAuthenticated() && <LogoutButton />}

          <Button variant="ghost" size="icon" className="relative">
            <Bell className="w-5 h-5" />
            <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full" />
          </Button>
        </div>
      </div>
    </header>
  );
}
