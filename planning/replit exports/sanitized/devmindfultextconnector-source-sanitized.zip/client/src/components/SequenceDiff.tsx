interface Props {
  currentSequence: string[];
  proposedSequence: string[];
  testIdPrefix?: string;
  gap?: 2 | 3;
}

export function SequenceDiff({ currentSequence, proposedSequence, testIdPrefix, gap = 2 }: Props) {
  const cs = new Set(currentSequence);
  const ps = new Set(proposedSequence);
  const gapClass = gap === 3 ? "gap-3" : "gap-2";
  return (
    <div className={`grid grid-cols-2 ${gapClass} text-xs`}>
      <div>
        <p className="text-gray-500 mb-1">Current</p>
        <div
          className="bg-gray-50 border border-gray-200 rounded p-2 font-mono space-y-0.5"
          data-testid={testIdPrefix ? `${testIdPrefix}-current` : undefined}
        >
          {currentSequence.length === 0 && <div className="text-gray-400">(empty)</div>}
          {currentSequence.map((m, i) => (
            <div key={i} className={ps.has(m) ? "" : "bg-red-100 text-red-800 line-through px-1 rounded"}>{m}</div>
          ))}
        </div>
      </div>
      <div>
        <p className="text-gray-500 mb-1">Proposed</p>
        <div
          className="bg-indigo-50 border border-indigo-200 rounded p-2 font-mono space-y-0.5"
          data-testid={testIdPrefix ? `${testIdPrefix}-proposed` : undefined}
        >
          {proposedSequence.length === 0 && <div className="text-gray-400">(empty)</div>}
          {proposedSequence.map((m, i) => (
            <div key={i} className={cs.has(m) ? "" : "bg-green-100 text-green-800 px-1 rounded"}>{m}</div>
          ))}
        </div>
      </div>
    </div>
  );
}
