import { useEffect, useState } from "react";
import { X, CheckCircle, AlertCircle, Info } from "lucide-react";
import { Card } from "@/components/ui/card";

interface ToastMessage {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

let toastQueue: ToastMessage[] = [];
let toastListeners: ((toasts: ToastMessage[]) => void)[] = [];

export const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
  const toast: ToastMessage = {
    id: Date.now().toString(),
    message,
    type
  };
  
  toastQueue.push(toast);
  toastListeners.forEach(listener => listener([...toastQueue]));
  
  // Auto remove after 5 seconds
  setTimeout(() => {
    removeToast(toast.id);
  }, 5000);
};

const removeToast = (id: string) => {
  toastQueue = toastQueue.filter(t => t.id !== id);
  toastListeners.forEach(listener => listener([...toastQueue]));
};

export default function Toast() {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  useEffect(() => {
    toastListeners.push(setToasts);
    return () => {
      toastListeners = toastListeners.filter(listener => listener !== setToasts);
    };
  }, []);

  const getIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-6 h-6 text-green-600" />;
      case 'error':
        return <AlertCircle className="w-6 h-6 text-red-600" />;
      default:
        return <Info className="w-6 h-6 text-blue-600" />;
    }
  };

  return (
    <div className="fixed top-4 right-4 space-y-2 z-50">
      {toasts.map((toast) => (
        <Card key={toast.id} className="p-4 max-w-sm shadow-lg">
          <div className="flex items-center">
            {getIcon(toast.type)}
            <div className="ml-3 flex-1">
              <p className="text-sm font-medium text-gray-900">{toast.message}</p>
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className="ml-4 text-gray-400 hover:text-gray-600"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </Card>
      ))}
    </div>
  );
}
