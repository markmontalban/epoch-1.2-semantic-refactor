import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { authService } from "@/lib/auth";
import { resolveLocalOrgId } from "@/lib/localApi";
import {
  Home, FileText, FileUp, MessageSquare, User, X, LayoutGrid,
  Workflow, ListChecks, Users, Settings, GanttChart, Route as RouteIcon,
  Smartphone, Reply, BookOpen,
} from "lucide-react";
import mindfulTextLogo from "@assets/mindfullt-finish---w-background---icon_500px_1778170394475.png";

// Reply Analytics and Token Usage now live as tabs inside the Dashboard
// (Engagement / Cost). Their routes stay registered so deep links keep
// working, but they're no longer separate sidebar entries.
const navItems = [
  { name: "Dashboard", href: "/dashboard", icon: Home },
  { name: "Drafts", href: "/drafts", icon: FileText },
  { name: "Audiences", href: "/audiences", icon: Users },
  { name: "Import / Export", href: "/import", icon: FileUp },
  { name: "Workbench", href: "/workbench", icon: LayoutGrid },
  { name: "Journey Progress", href: "/journey-progress", icon: GanttChart },
  { name: "Contact Journeys", href: "/contact-journeys", icon: RouteIcon },
  { name: "Automation", href: "/automation", icon: Workflow },
  { name: "Replies", href: "/replies", icon: Reply, showDraftBadge: true },
  { name: "Changes", href: "/changes", icon: ListChecks, showPendingBadge: true },
  { name: "Ask", href: "/ask", icon: MessageSquare },
  { name: "Library", href: "/library", icon: BookOpen },
  { name: "Subscriber Page", href: "/page-settings", icon: Smartphone },
  { name: "Settings", href: "/settings", icon: Settings },
];

interface SidebarProps {
  onClose: () => void;
}

function DraftBadge() {
  const orgId = resolveLocalOrgId();
  const { data } = useQuery<{ count: number }>({
    queryKey: ["/api/local/draft-messages", orgId, "count"],
    queryFn: () => fetch(`/api/local/draft-messages/${orgId}/count`).then((r) => r.json()),
    refetchInterval: 30000,
  });
  if (!data?.count) return null;
  return (
    <span className="bg-indigo-500 text-white text-xs font-semibold rounded-full px-2 py-0.5 ml-auto" data-testid="badge-drafts">
      {data.count}
    </span>
  );
}

function PendingBadge() {
  const orgId = resolveLocalOrgId();
  const { data } = useQuery<{ count: number }>({
    queryKey: ["/api/local/pending-changes", orgId, "count"],
    queryFn: () => fetch(`/api/local/pending-changes/${orgId}/count`).then(r => r.json()),
    refetchInterval: 30000,
  });
  if (!data?.count) return null;
  return (
    <span className="bg-red-500 text-white text-xs font-semibold rounded-full px-2 py-0.5 ml-auto" data-testid="badge-pending">
      {data.count}
    </span>
  );
}

export default function Sidebar({ onClose }: SidebarProps) {
  const [location] = useLocation();
  const user = authService.getCurrentUser();

  const getInitials = (name: string) => {
    return name.split(" ").map((n) => n[0]).join("").toUpperCase();
  };

  return (
    <nav className="bg-white w-64 h-full shadow-lg border-r border-gray-200 flex flex-col">
      <div className="p-5 flex-1 overflow-y-auto">
        <div className="flex items-center justify-between mb-7">
          <div className="flex items-center space-x-3">
            <img src={mindfulTextLogo} alt="MindfulText logo" className="w-9 h-9 rounded-lg shrink-0 object-cover" />
            <div>
              <h2 className="text-lg font-bold text-gray-900 leading-tight">MindfulText</h2>
              <p className="text-xs text-gray-500">Dashboard</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="sm:hidden p-1 rounded text-gray-400 hover:text-gray-600"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <ul className="space-y-0.5">
          {navItems.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            return (
              <li key={item.name}>
                <Link
                  href={item.href}
                  onClick={onClose}
                  className={`nav-link ${isActive ? "active" : ""}`}
                >
                  <Icon className="w-5 h-5 shrink-0" />
                  <span className="flex-1">{item.name}</span>
                  {item.showPendingBadge && <PendingBadge />}
                  {"showDraftBadge" in item && item.showDraftBadge && <DraftBadge />}
                </Link>
              </li>
            );
          })}
        </ul>
      </div>

      <div className="p-4 border-t border-gray-100">
        <div className="bg-gray-50 rounded-lg p-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 bg-indigo-500 rounded-full flex items-center justify-center shrink-0">
              {user?.name ? (
                <span className="text-white text-xs font-semibold">
                  {getInitials(user.name)}
                </span>
              ) : (
                <User className="text-white" size={14} />
              )}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">{user?.name || "User"}</p>
              <p className="text-xs text-gray-500 capitalize truncate">{user?.role || "User"}</p>
            </div>
          </div>
          <button
            onClick={() => authService.logout()}
            className="shrink-0 text-gray-400 hover:text-gray-600 transition-colors"
            title="Sign out"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
            </svg>
          </button>
        </div>
      </div>
    </nav>
  );
}
