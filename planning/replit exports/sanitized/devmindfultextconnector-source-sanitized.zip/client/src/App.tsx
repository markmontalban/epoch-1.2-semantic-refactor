import { Switch, Route, Redirect, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { PersistQueryClientProvider } from "@tanstack/react-query-persist-client";
import { createSyncStoragePersister } from "@tanstack/query-sync-storage-persister";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { authService } from "./lib/auth";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import ContentDrafts from "./pages/ContentDrafts";
import Audiences from "./pages/Audiences";
import AudienceDetailPage, { SegmentDetailPage } from "./pages/GroupDetail";
import Import from "./pages/Import";
import Workbench from "./pages/Workbench";
import TokenUsage from "./pages/TokenUsage";
import Ask from "./pages/Ask";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import PageSettings from "./pages/PageSettings";
import MeditationLibrary from "./pages/MeditationLibrary";
import { syncOrgIdFromServer, resolveLocalOrgId } from "./lib/localApi";
import { useToast } from "@/hooks/use-toast";
import Automation from "./pages/Automation";
import Changes from "./pages/Changes";
import ReplyAnalytics from "./pages/ReplyAnalytics";
import ContactPanel from "./pages/ContactPanel";
import JourneyProgress from "./pages/JourneyProgress";
import ContactJourneys from "./pages/ContactJourneys";
import SubscriberPage from "./pages/SubscriberPage";
import NotFound from "@/pages/not-found";
import { useState, useEffect } from "react";

const AUTO_SESSION_STORAGE_KEY = "mindfultext_session_id";
const AUTO_SESSION_USER_KEY = "mindfultext_user";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  if (!authService.isAuthenticated()) {
    return <Redirect to="/login" />;
  }
  return <Layout>{children}</Layout>;
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  if (authService.isAuthenticated()) {
    return <Redirect to="/dashboard" />;
  }
  return <>{children}</>;
}

function Router() {
  return (
    <Switch>
      <Route path="/login">
        <PublicRoute>
          <Login />
        </PublicRoute>
      </Route>

      <Route path="/dashboard">
        <ProtectedRoute>
          <Dashboard />
        </ProtectedRoute>
      </Route>

      <Route path="/drafts">
        <ProtectedRoute>
          <ContentDrafts />
        </ProtectedRoute>
      </Route>

      <Route path="/audiences">
        <ProtectedRoute>
          <Audiences />
        </ProtectedRoute>
      </Route>

      <Route path="/audiences/:tag">
        {(params) => (
          <ProtectedRoute>
            <AudienceDetailPage tag={decodeURIComponent(params.tag)} />
          </ProtectedRoute>
        )}
      </Route>

      <Route path="/segments/:id">
        {(params) => (
          <ProtectedRoute>
            <SegmentDetailPage segmentId={params.id} />
          </ProtectedRoute>
        )}
      </Route>

      <Route path="/import">
        <ProtectedRoute>
          <Import />
        </ProtectedRoute>
      </Route>

      <Route path="/workbench">
        <ProtectedRoute>
          <Workbench />
        </ProtectedRoute>
      </Route>

      <Route path="/bulk-edit">
        <Redirect to="/workbench" />
      </Route>

      <Route path="/token-usage">
        <ProtectedRoute>
          <TokenUsage />
        </ProtectedRoute>
      </Route>

      <Route path="/ask">
        <ProtectedRoute>
          <Ask />
        </ProtectedRoute>
      </Route>

      <Route path="/profile">
        <ProtectedRoute>
          <Profile />
        </ProtectedRoute>
      </Route>

      <Route path="/settings">
        <ProtectedRoute>
          <Settings />
        </ProtectedRoute>
      </Route>

      <Route path="/page-settings">
        <ProtectedRoute>
          <PageSettings />
        </ProtectedRoute>
      </Route>

      <Route path="/library">
        <ProtectedRoute>
          <MeditationLibrary />
        </ProtectedRoute>
      </Route>

      <Route path="/automation">
        <ProtectedRoute>
          <Automation />
        </ProtectedRoute>
      </Route>

      <Route path="/changes">
        <ProtectedRoute>
          <Changes />
        </ProtectedRoute>
      </Route>

      <Route path="/replies">
        <ProtectedRoute>
          <ReplyAnalytics />
        </ProtectedRoute>
      </Route>

      <Route path="/replies/analytics">
        <ProtectedRoute>
          <ReplyAnalytics />
        </ProtectedRoute>
      </Route>

      <Route path="/journey-progress">
        <ProtectedRoute>
          <JourneyProgress />
        </ProtectedRoute>
      </Route>

      <Route path="/contact-journeys">
        <ProtectedRoute>
          <ContactJourneys />
        </ProtectedRoute>
      </Route>

      <Route path="/contact/:id">
        <ProtectedRoute>
          <ContactPanel />
        </ProtectedRoute>
      </Route>

      <Route path="/">
        {authService.isAuthenticated() ? <Redirect to="/dashboard" /> : <Redirect to="/login" />}
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

async function fetchAutoSession(): Promise<{ email: string; orgId: string; sessionId: string } | null> {
  const MAX_ATTEMPTS = 5;
  const RETRY_DELAY_MS = 1200;

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    try {
      const res = await fetch("/api/auto-session");
      if (res.status === 200) {
        const data = await res.json() as { email: string; orgId: string; sessionId: string };
        if (data?.email) return data;
      }
      if (res.status === 204 && attempt < MAX_ATTEMPTS) {
        await new Promise<void>((resolve) => setTimeout(resolve, RETRY_DELAY_MS));
        continue;
      }
    } catch {
      if (attempt < MAX_ATTEMPTS) {
        await new Promise<void>((resolve) => setTimeout(resolve, RETRY_DELAY_MS));
        continue;
      }
    }
    break;
  }
  return null;
}

function applyAutoSessionUser(data: { email: string; orgId: string; sessionId: string }) {
  const user = {
    id: 0,
    email: data.email,
    name: data.email,
    role: "user",
    organizationID: data.orgId,
  };
  localStorage.setItem(AUTO_SESSION_USER_KEY, JSON.stringify(user));
  localStorage.setItem(AUTO_SESSION_STORAGE_KEY, data.sessionId);
}

function AutoSessionGate({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(authService.isAuthenticated());
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Always sync the configured org id from the server on mount, regardless
  // of whether we're already authenticated. This ensures every tab/session
  // picks up an org change made elsewhere without needing a restart.
  // Also re-sync on window focus so background tabs catch up the next time
  // the user returns to them, and when this tab becomes visible again.
  useEffect(() => {
    let cancelled = false;
    let lastOrg: string | null = null;
    const sync = async () => {
      if (cancelled) return;
      const result = await syncOrgIdFromServer();
      if (result === null) {
        console.debug("[org-sync] /api/local/settings sync returned no value");
        return;
      }
      // Only invalidate when the org id actually changed, so background
      // focus/visibility ticks don't trigger needless refetch churn.
      if (lastOrg !== null && lastOrg !== result) {
        try { queryClient.invalidateQueries(); } catch (e) {
          console.debug("[org-sync] query invalidation failed:", e);
        }
      }
      lastOrg = result;
    };
    sync();
    window.addEventListener("focus", sync);
    document.addEventListener("visibilitychange", sync);
    return () => {
      cancelled = true;
      window.removeEventListener("focus", sync);
      document.removeEventListener("visibilitychange", sync);
    };
  }, []);

  // Surface safeUpdate array-clear warnings as a non-blocking toast so the
  // user can see the genuine concern even though the save itself proceeds.
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent<{ message: string }>).detail;
      if (!detail?.message) return;
      toast({ title: "Saved with a warning", description: detail.message });
    };
    window.addEventListener("safe-update-warning", handler);
    return () => window.removeEventListener("safe-update-warning", handler);
  }, [toast]);

  // Initial auto-session check on mount.
  useEffect(() => {
    if (ready) return;

    let cancelled = false;

    fetchAutoSession().then(async (data) => {
      if (cancelled) return;
      if (data) {
        applyAutoSessionUser(data);
        console.log("[auto-session] Signed in automatically as", data.email);
        // Now that the session is bound on the server, immediately resync
        // the configured org id so the very first authenticated request
        // uses the right value (the on-mount sync above may have run before
        // the session cookie was attached).
        const before = resolveLocalOrgId();
        const resolved = await syncOrgIdFromServer();
        if (resolved && resolved !== before) {
          try { queryClient.invalidateQueries(); } catch (e) {
            console.debug("[org-sync] post-auth invalidation failed:", e);
          }
        }
        setReady(true);
        navigate("/dashboard");
      } else {
        setReady(true);
      }
    });

    return () => { cancelled = true; };
  }, []);

  // Listen for 401s from proxy calls — silently re-check the auto-session
  // rather than redirecting to the login page.
  useEffect(() => {
    let recheckInProgress = false;

    async function handleSessionExpired() {
      if (recheckInProgress) return;
      recheckInProgress = true;

      console.log("[auto-session] 401 detected — requesting immediate session refresh…");
      try {
        // Ask the server to immediately verify and re-establish the session.
        // This avoids waiting up to 30 minutes for the keep-alive interval.
        let data: { email: string; orgId: string; sessionId: string } | null = null;
        try {
          const refreshRes = await fetch("/api/auto-session/refresh", { method: "POST" });
          if (refreshRes.status === 200) {
            data = await refreshRes.json() as { email: string; orgId: string; sessionId: string };
          }
        } catch {
          // If the refresh endpoint itself fails, fall back to polling.
        }

        // Fallback: poll /api/auto-session in case the refresh is still in flight.
        if (!data) {
          data = await fetchAutoSession();
        }

        if (data) {
          applyAutoSessionUser(data);
          console.log("[auto-session] Session refreshed — invalidating queries");
          queryClient.invalidateQueries();
        } else {
          console.warn("[auto-session] Re-check failed — session could not be restored");
        }
      } finally {
        recheckInProgress = false;
      }
    }

    window.addEventListener("mindfultext:session-expired", handleSessionExpired);
    return () => window.removeEventListener("mindfultext:session-expired", handleSessionExpired);
  }, []);

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="flex flex-col items-center gap-3 text-gray-500">
          <div className="w-8 h-8 border-4 border-gray-300 border-t-indigo-500 rounded-full animate-spin" />
          <span className="text-sm">Connecting…</span>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}

const localStoragePersister = createSyncStoragePersister({
  storage: typeof window !== "undefined" ? window.localStorage : undefined,
  key: "mindfultext_query_cache",
});

// Only these dashboard query keys are worth persisting across hard refreshes —
// they're the slow, upstream-backed reads. Everything else stays in-memory.
const PERSISTED_QUERY_KEYS = new Set([
  "dashboard-stats",
  "insights",
  "attrition",
  "revenue",
  "attribution",
]);

function App() {
  return (
    <PersistQueryClientProvider
      client={queryClient}
      persistOptions={{
        persister: localStoragePersister,
        maxAge: 24 * 60 * 60 * 1000, // 24h
        // Bust the persisted cache when the active org changes so one org's
        // numbers never paint under another org.
        buster: resolveLocalOrgId(),
        dehydrateOptions: {
          shouldDehydrateQuery: (query) =>
            query.state.status === "success" &&
            Array.isArray(query.queryKey) &&
            PERSISTED_QUERY_KEYS.has(query.queryKey[0] as string),
        },
      }}
      onSuccess={() => {
        // Cache restored from localStorage paints instantly; immediately
        // revalidate in the background so numbers refresh.
        queryClient.invalidateQueries();
      }}
    >
      <TooltipProvider>
        <Toaster />
        <Switch>
          {/* Public, login-free subscriber pages — must bypass AutoSessionGate. */}
          <Route path="/p/:token">
            {(params) => <SubscriberPage token={params.token} />}
          </Route>
          <Route>
            <AutoSessionGate>
              <Router />
            </AutoSessionGate>
          </Route>
        </Switch>
      </TooltipProvider>
    </PersistQueryClientProvider>
  );
}

export default App;
