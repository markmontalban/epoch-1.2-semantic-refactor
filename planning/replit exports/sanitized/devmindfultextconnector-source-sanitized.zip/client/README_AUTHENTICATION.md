# MindfulText Authentication

This founder console is a React frontend plus an Express backend. The backend
proxies the external MindfulText API at `dev.mindfultext.com`. Authentication is
handled **server-side with session cookies** — there is no JWT and no token in
the browser.

## How it actually works

1. The browser identifies itself to our Express server with an `X-Session-ID`
   header (a UUID stored in `localStorage` as `mindfultext_session_id`). This is
   a key into the server's session store; it is **not** a MindfulText token.
2. The Express server keeps the real MindfulText session cookies per session id
   in `.session-cookies.json` (see `server/session.ts`).
3. When a session has no cookies, the server can **auto-login** to MindfulText
   using credentials from Settings (`.org-settings.json`) or the
   `MINDFULTEXT_EMAIL` / `MINDFULTEXT_PASSWORD` env vars, then stores the
   returned `Set-Cookie` values (see `performAutoLogin` in
   `server/orgSettings.ts`). A background job keeps the auto-session warm.
4. Browser calls to `/api/proxy/mindfultext/*` are forwarded upstream with the
   stored cookies attached, org-bearing paths rewritten to the configured org
   (see `server/proxy.ts`).

```
Browser (X-Session-ID)
    ↓
Express server  ──(session cookies)──▶  dev.mindfultext.com
    ▲                                        │
    └──────── stored in .session-cookies.json
```

## Configuring credentials

Set the founder's MindfulText login either in the in-app Settings page or via
environment variables:

- `MINDFULTEXT_EMAIL`
- `MINDFULTEXT_PASSWORD`

Credentials saved through Settings are encrypted at rest (`server/secrets.ts`).

## Agent-safe mode

Programmatic sends and upstream module/journey edits are gated by
`AGENT_SAFE_MODE` (default on). Automation and non-UI callers cannot mutate
upstream data without an explicit operator confirm token; the human dashboard
flows pass through unchanged. See `server/agentSafety.ts`.

## Troubleshooting

- **Upstream 401 / "session expired"**: the stored cookies lapsed. Re-save
  credentials in Settings or confirm the env vars are set; the auto-session
  will re-login.
- **Wrong organization**: the configured org id drives path/body rewriting.
  Check the org dropdown in Settings.
- **"Failed to fetch"**: verify `dev.mindfultext.com` is reachable from the
  server (not just the browser) — all upstream calls are server-side.
