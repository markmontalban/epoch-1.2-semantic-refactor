# Backend Alignment TODO

This tracks the practical fixes needed so the app consistently uses MindfulText's backend API instead of mixing legacy local routes.

## Immediate fixes

- [x] Audit active client flows and identify components still calling legacy local endpoints.
- [x] Replace hardcoded org assumptions with org ID derived from authenticated user context.
- [x] Fix `ContactModal` to use MindfulText org ID flow (remove dependency on local organizations endpoint).
- [x] Fix `Profile` page to use session-auth user data instead of JWT-only local profile routes.
- [x] Add compatibility methods in API service for stale pages still referenced by TypeScript.
- [x] Run type-check and lints; fix any issues introduced by refactor.

## Next cleanup wave

- [x] Remove dead local Postgres/JWT CRUD routes that are no longer used by the UI.
- [x] Remove stale pages/components not linked from routes/navigation.
- [x] Consolidate markdown docs into one current architecture/readme document.
