#!/usr/bin/env bash
# Smoke test for the local staging layer + MindfulText proxy.
# Usage: EMAIL=m@mindfultext.com PASSWORD=yourpassword bash scripts/smoke-test.sh
#
# Steps:
#   1. GET  /api/local/health       — staging layer is alive
#   2. GET  /api/local/ai/models    — routing config returned
#   3. POST /api/local/ai/plan      — creates a content draft + token-usage row
#   4. POST /api/local/inbound      — creates inbound + draft-reply rows
#   5. GET  /api/local/tokens/:org  — token-usage rows are present
#   (then optional MindfulText proxy endpoints if PASSWORD is set)

set -euo pipefail

BASE="http://localhost:5000"
ORG="${ORG:-00000022}"
EMAIL="${EMAIL:-m@mindfultext.com}"
PASSWORD="${PASSWORD:-}"
SESSION_ID="smoke-test-$(date +%s)"

pass() { echo "✅ $1"; }
fail() { echo "❌ $1"; FAILURES=$((FAILURES + 1)); }
FAILURES=0

# ---------------------------------------------------------------------------
# 1. Health
# ---------------------------------------------------------------------------
echo "--- 1. Health ---"
HEALTH=$(curl -sf "$BASE/api/local/health" || echo "ERROR")
if echo "$HEALTH" | python3 -c "import json,sys; d=json.load(sys.stdin); assert d.get('status')=='ok'" 2>/dev/null; then
  pass "GET /api/local/health → ok"
else
  fail "GET /api/local/health"
  echo "  Response: $HEALTH"
fi

# ---------------------------------------------------------------------------
# 2. Models
# ---------------------------------------------------------------------------
echo "--- 2. Models ---"
MODELS=$(curl -sf "$BASE/api/local/ai/models" || echo "ERROR")
if echo "$MODELS" | python3 -c "import json,sys; d=json.load(sys.stdin); assert 'routingModel' in d and 'docsUrl' in d; assert 'frontier' not in d and 'cheap' not in d" 2>/dev/null; then
  pass "GET /api/local/ai/models → {routingModel, docsUrl}"
else
  fail "GET /api/local/ai/models"
  echo "  Response: $MODELS"
fi

# ---------------------------------------------------------------------------
# 3. AI plan (creates draft + token-usage row)
# ---------------------------------------------------------------------------
echo "--- 3. AI plan ---"
PLAN=$(curl -sf -X POST "$BASE/api/local/ai/plan" \
  -H "Content-Type: application/json" \
  -d "{\"organizationId\":\"$ORG\",\"topic\":\"Smoke test — mindfulness breathing\",\"textCount\":2}" \
  || echo "ERROR")
if echo "$PLAN" | python3 -c "import json,sys; d=json.load(sys.stdin); assert 'draft' in d and 'tokenUsage' in d; assert d['tokenUsage'].get('model','') not in ('openrouter/auto','')" 2>/dev/null; then
  DRAFT_ID=$(echo "$PLAN" | python3 -c "import json,sys; print(json.load(sys.stdin)['draft']['id'])")
  MODEL_USED=$(echo "$PLAN" | python3 -c "import json,sys; print(json.load(sys.stdin)['tokenUsage']['model'])")
  pass "POST /api/local/ai/plan → draft #$DRAFT_ID, model=$MODEL_USED"
else
  fail "POST /api/local/ai/plan (check OPENROUTER_API_KEY)"
  echo "  Response: $(echo "$PLAN" | head -c 400)"
  DRAFT_ID=""
fi

# ---------------------------------------------------------------------------
# 4. Inbound message + draft reply
# ---------------------------------------------------------------------------
echo "--- 4. Inbound + draft reply ---"
INBOUND=$(curl -sf -X POST "$BASE/api/local/inbound" \
  -H "Content-Type: application/json" \
  -d "{\"organizationId\":\"$ORG\",\"contactPhone\":\"+15005550001\",\"content\":\"Hi, I need help with my breathing exercises\"}" \
  || echo "ERROR")
if echo "$INBOUND" | python3 -c "import json,sys; d=json.load(sys.stdin); assert 'inbound' in d and 'draftReply' in d" 2>/dev/null; then
  INBOUND_ID=$(echo "$INBOUND" | python3 -c "import json,sys; print(json.load(sys.stdin)['inbound']['id'])")
  pass "POST /api/local/inbound → inbound #$INBOUND_ID + draft reply created"
else
  fail "POST /api/local/inbound (check OPENROUTER_API_KEY)"
  echo "  Response: $(echo "$INBOUND" | head -c 400)"
fi

# ---------------------------------------------------------------------------
# 5. Token usage
# ---------------------------------------------------------------------------
echo "--- 5. Token usage ---"
TOKENS=$(curl -sf "$BASE/api/local/tokens/$ORG" || echo "ERROR")
if echo "$TOKENS" | python3 -c "import json,sys; d=json.load(sys.stdin); assert d.get('totalTokens',0) > 0" 2>/dev/null; then
  TOTAL=$(echo "$TOKENS" | python3 -c "import json,sys; print(json.load(sys.stdin)['totalTokens'])")
  pass "GET /api/local/tokens/$ORG → $TOTAL total tokens logged"
else
  fail "GET /api/local/tokens/$ORG (no rows or zero tokens)"
  echo "  Response: $(echo "$TOKENS" | head -c 400)"
fi

# ---------------------------------------------------------------------------
# 5b. Settings: credentials + org dropdown
# ---------------------------------------------------------------------------
if [[ -n "$PASSWORD" ]]; then
  echo "--- 5b. Settings credentials + org dropdown ---"

  LOGIN_RES=$(curl -s -X POST "$BASE/api/local/settings/login" \
    -H "Content-Type: application/json" \
    -H "X-Session-ID: $SESSION_ID" \
    -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\"}")
  LOGIN_OK=$(echo "$LOGIN_RES" | python3 -c "import json,sys; d=json.load(sys.stdin); print('1' if d.get('ok') and isinstance(d.get('orgs'),list) else '0')" 2>/dev/null || echo "0")
  if [[ "$LOGIN_OK" == "1" ]]; then
    ORG_COUNT=$(echo "$LOGIN_RES" | python3 -c "import json,sys; print(len(json.load(sys.stdin)['orgs']))")
    pass "POST /api/local/settings/login → ok, $ORG_COUNT org(s) returned"
  else
    fail "POST /api/local/settings/login"
    echo "  Response: $(echo "$LOGIN_RES" | head -c 400)"
  fi

  # /api/local/settings/orgs has three legitimate shapes:
  #   - { orgs: [...] }                   → normal account, validate dropdown
  #   - { orgs: [], code: "byuser_forbidden" } → MindfulText 403'd byUser;
  #                                              login is still good, user
  #                                              enters orgId manually
  #   - 401 with code=credentials_expired → re-login required
  ORGS_RES=$(curl -s "$BASE/api/local/settings/orgs" -H "X-Session-ID: $SESSION_ID")
  ORGS_CODE=$(echo "$ORGS_RES" | python3 -c "import json,sys; print(json.load(sys.stdin).get('code',''))" 2>/dev/null || echo "")
  FIRST_ORG=$(echo "$ORGS_RES" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['orgs'][0]['id'] if d.get('orgs') else '')" 2>/dev/null || echo "")
  if [[ -n "$FIRST_ORG" ]]; then
    pass "GET /api/local/settings/orgs → first org $FIRST_ORG"
  elif [[ "$ORGS_CODE" == "byuser_forbidden" ]]; then
    pass "GET /api/local/settings/orgs → byuser_forbidden (manual-entry fallback)"
  else
    fail "GET /api/local/settings/orgs"
    echo "  Response: $(echo "$ORGS_RES" | head -c 400)"
  fi

  # When byUser is forbidden, fall back to the env-var / configured org id
  # for the remaining checks — the user would type this into the manual
  # entry field.
  TARGET_ORG="$FIRST_ORG"
  if [[ -z "$TARGET_ORG" && "$ORGS_CODE" == "byuser_forbidden" ]]; then
    TARGET_ORG=$(curl -s "$BASE/api/local/settings" -H "X-Session-ID: $SESSION_ID" \
      | python3 -c "import json,sys; print(json.load(sys.stdin).get('orgId',''))" 2>/dev/null || echo "")
  fi

  if [[ -n "$TARGET_ORG" ]]; then
    PUT_RES=$(curl -s -X PUT "$BASE/api/local/settings" \
      -H "Content-Type: application/json" \
      -H "X-Session-ID: $SESSION_ID" \
      -d "{\"orgId\":\"$TARGET_ORG\"}")
    PUT_OK=$(echo "$PUT_RES" | python3 -c "import json,sys,os; d=json.load(sys.stdin); print('1' if d.get('orgId')==os.environ['O'] else '0')" O="$TARGET_ORG" 2>/dev/null || echo "0")
    [[ "$PUT_OK" == "1" ]] && pass "PUT /api/local/settings → $TARGET_ORG" \
      || { fail "PUT /api/local/settings"; echo "  Response: $(echo "$PUT_RES" | head -c 400)"; }

    # Bogus org should only be rejected when byUser actually returned a
    # list to validate against. When the account is byuser_forbidden the
    # server can't tell good from bad, so it accepts any 8-digit id.
    if [[ -n "$FIRST_ORG" ]]; then
      REJ_HTTP=$(curl -s -o /dev/null -w "%{http_code}" -X PUT "$BASE/api/local/settings" \
        -H "Content-Type: application/json" -H "X-Session-ID: $SESSION_ID" \
        -d "{\"orgId\":\"99999999\"}")
      [[ "$REJ_HTTP" == "400" ]] && pass "PUT /api/local/settings rejects bogus org → 400" \
        || fail "PUT bogus org should be 400, got $REJ_HTTP"
    fi

    PROXY_HTTP=$(curl -s -o /dev/null -w "%{http_code}" -H "X-Session-ID: $SESSION_ID" \
      "$BASE/api/proxy/mindfultext/api/contacts/byOrganization/$TARGET_ORG?page=1&pageSize=1")
    [[ "$PROXY_HTTP" =~ ^2 ]] && pass "Proxy contacts against selected org → $PROXY_HTTP" \
      || fail "Proxy against selected org → $PROXY_HTTP"
  fi

  # Bad credentials must hit the login endpoint (not the gate) — include
  # X-Session-ID so a 401 unambiguously means MindfulText rejected the
  # credentials, with code=invalid_credentials.
  BAD_BODY=$(curl -s -X POST "$BASE/api/local/settings/login" \
    -H "Content-Type: application/json" -H "X-Session-ID: $SESSION_ID" \
    -d "{\"email\":\"$EMAIL\",\"password\":\"definitely-not-the-password\"}")
  BAD_CODE=$(echo "$BAD_BODY" | python3 -c "import json,sys; print(json.load(sys.stdin).get('code',''))" 2>/dev/null || echo "")
  [[ "$BAD_CODE" == "invalid_credentials" ]] && pass "Bad credentials rejected with code=invalid_credentials" \
    || { fail "Bad credentials code expected invalid_credentials, got '$BAD_CODE'"; echo "  Body: $(echo "$BAD_BODY" | head -c 200)"; }

  # Login endpoint must be reachable without any pre-existing session
  # (first-boot path) — verify by using a fresh sid that has no cookies.
  FRESH_SID="smoke-fresh-$(date +%s%N)"
  FRESH_HTTP=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE/api/local/settings/login" \
    -H "Content-Type: application/json" -H "X-Session-ID: $FRESH_SID" \
    -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\"}")
  [[ "$FRESH_HTTP" =~ ^2 ]] && pass "Login works on a fresh session (no prebound cookies) → $FRESH_HTTP" \
    || fail "Login on fresh session should succeed, got $FRESH_HTTP"
fi

# ---------------------------------------------------------------------------
# Optional: MindfulText proxy (only if PASSWORD is set)
# ---------------------------------------------------------------------------
if [[ -n "$PASSWORD" ]]; then
  echo ""
  echo "--- MindfulText proxy ---"
  LOGIN=$(curl -s -X POST "$BASE/api/proxy/mindfultext/api/login" \
    -H "Content-Type: application/json" \
    -H "X-Session-ID: $SESSION_ID" \
    -d "{\"email\":\"$EMAIL\",\"password\":\"$PASSWORD\"}")

  STATUS=$(echo "$LOGIN" | python3 -c "import json,sys; d=json.load(sys.stdin); print('ok' if d.get('data',{}).get('email') else 'fail')" 2>/dev/null || echo "fail")
  if [[ "$STATUS" == "ok" ]]; then
    pass "Login"
    proxy_fetch() {
      local label="$1" path="$2" method="${3:-GET}" body="${4:-}"
      HTTP=$(curl -s -o /dev/null -w "%{http_code}" -X "$method" \
        "$BASE/api/proxy/mindfultext$path" \
        -H "Accept: application/json" -H "X-Session-ID: $SESSION_ID" \
        ${body:+-H "Content-Type: application/json" -d "$body"})
      if [[ "$HTTP" -ge 200 && "$HTTP" -lt 300 ]]; then pass "$label → $HTTP"
      else fail "$label → $HTTP"; fi
    }
    proxy_fetch "Modules"      "/api/modules/byOrganization/$ORG"
    proxy_fetch "Contacts"     "/api/contacts/$ORG" "POST" "{}"
    proxy_fetch "Journeys"     "/api/journeys/byOrganization/$ORG"
    proxy_fetch "Messages"     "/api/messages/byOrganization/$ORG"
    proxy_fetch "Actions"      "/api/actions/byOrganization/$ORG"
    proxy_fetch "Integrations" "/api/integrations/byOrganization/$ORG"
    proxy_fetch "Team"         "/api/team/byOrganization/$ORG"
  else
    fail "Login failed — skipping proxy checks"
  fi
fi

# 6. Reshape rules + pending changes + memory + manual reorder
# 7. Webhook intake (only if CONTENT_WEBHOOK_SECRET is set)
# ---------------------------------------------------------------------------
echo ""
echo "--- 6. Personal-journey automation ---"

CONTACT_ID="smoke-contact-$(date +%s)"

# Seed a default journey template so bootstrap has modules to work with.
curl -sf -X POST "$BASE/api/local/journey-templates" \
  -H "Content-Type: application/json" \
  -d "{\"organizationId\":\"$ORG\",\"moduleIds\":[\"mod-a\",\"mod-b\",\"mod-c\"]}" > /dev/null \
  && pass "Seed default journey template" \
  || fail "Seed default journey template"

# Create an auto-skip rule (keyword "later" → skip next, applies immediately).
RULE_AUTO=$(curl -sf -X POST "$BASE/api/local/reshape-rules" \
  -H "Content-Type: application/json" \
  -d "{\"organizationId\":\"$ORG\",\"name\":\"Smoke auto-skip\",\"triggerType\":\"keyword\",\"triggerValue\":\"later\",\"actionType\":\"skip\",\"approvalMode\":\"auto\",\"priority\":50,\"continueAfter\":true}")
RULE_AUTO_ID=$(echo "$RULE_AUTO" | python3 -c "import json,sys; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
[[ -n "$RULE_AUTO_ID" ]] && pass "Create auto-skip rule (#$RULE_AUTO_ID)" || fail "Create auto-skip rule"

# Create a review-required insert rule (keyword "info" → insert mod-x, review).
RULE_REVIEW=$(curl -sf -X POST "$BASE/api/local/reshape-rules" \
  -H "Content-Type: application/json" \
  -d "{\"organizationId\":\"$ORG\",\"name\":\"Smoke review-insert\",\"triggerType\":\"keyword\",\"triggerValue\":\"info\",\"actionType\":\"insert\",\"actionParams\":{\"moduleId\":\"mod-x\"},\"approvalMode\":\"review\",\"priority\":60}")
RULE_REVIEW_ID=$(echo "$RULE_REVIEW" | python3 -c "import json,sys; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
[[ -n "$RULE_REVIEW_ID" ]] && pass "Create review-insert rule (#$RULE_REVIEW_ID)" || fail "Create review-insert rule"

# Inbound message that triggers BOTH rules (auto-skip applied, insert queued).
INBOUND2=$(curl -sf -X POST "$BASE/api/local/inbound" \
  -H "Content-Type: application/json" \
  -d "{\"organizationId\":\"$ORG\",\"contactId\":\"$CONTACT_ID\",\"contactPhone\":\"+15005550999\",\"content\":\"Tell me later, I want more info\"}")
RESHAPE_OK=$(echo "$INBOUND2" | python3 -c "import json,sys; d=json.load(sys.stdin); r=d.get('reshape',{}); print('1' if (len(r.get('applied',[]))>=1 or len(r.get('pending',[]))>=1) else '0')" 2>/dev/null)
[[ "$RESHAPE_OK" == "1" ]] && pass "Inbound triggered reshape evaluation" || fail "Inbound did not trigger reshape"

# Verify pending changes count.
PENDING_COUNT=$(curl -sf "$BASE/api/local/pending-changes/$ORG/count" | python3 -c "import json,sys; print(json.load(sys.stdin)['count'])" 2>/dev/null || echo "0")
[[ "$PENDING_COUNT" -ge 1 ]] && pass "Pending changes queue has $PENDING_COUNT entry" || fail "Pending queue empty after review-insert rule"

# Approve the first pending change.
PENDING_ID=$(curl -sf "$BASE/api/local/pending-changes/$ORG?status=pending" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d[0]['id'] if d else '')" 2>/dev/null)
if [[ -n "$PENDING_ID" ]]; then
  curl -sf -X POST "$BASE/api/local/pending-changes/$PENDING_ID/approve" \
    -H "Content-Type: application/json" -d "{}" > /dev/null \
    && pass "Approve pending change #$PENDING_ID" \
    || fail "Approve pending change"
fi

# Check personal-journey state shows events from auto + review.
JOURNEY=$(curl -sf "$BASE/api/local/personal-journey/$ORG/$CONTACT_ID")
EVENT_COUNT=$(echo "$JOURNEY" | python3 -c "import json,sys; print(len(json.load(sys.stdin).get('events',[])))" 2>/dev/null || echo "0")
[[ "$EVENT_COUNT" -ge 2 ]] && pass "Personal journey has $EVENT_COUNT events" || fail "Personal journey events missing (got $EVENT_COUNT)"

# Manual reorder via the op endpoint.
curl -sf -X POST "$BASE/api/local/personal-journey/$ORG/$CONTACT_ID/op" \
  -H "Content-Type: application/json" \
  -d "{\"op\":\"reorder\",\"newQueue\":[\"mod-c\",\"mod-a\",\"mod-b\"]}" > /dev/null \
  && pass "Manual reorder via op endpoint" \
  || fail "Manual reorder"

# Per-contact memory: verify recordContactActivity wrote a row.
PROFILE=$(curl -sf "$BASE/api/local/contact-profile/$ORG/$CONTACT_ID")
MEM_ROWS=$(echo "$PROFILE" | python3 -c "import json,sys; print(len(json.load(sys.stdin).get('memory',[])))" 2>/dev/null || echo "0")
[[ "$MEM_ROWS" -ge 1 ]] && pass "Contact memory recorded ($MEM_ROWS row)" || fail "Contact memory not recorded"

# Toggle memory off → memory rows purged.
curl -sf -X POST "$BASE/api/local/contact-profile/$ORG/$CONTACT_ID/memory-toggle" \
  -H "Content-Type: application/json" -d "{\"enabled\":false}" > /dev/null
PROFILE2=$(curl -sf "$BASE/api/local/contact-profile/$ORG/$CONTACT_ID")
MEM_AFTER=$(echo "$PROFILE2" | python3 -c "import json,sys; print(len(json.load(sys.stdin).get('memory',[])))" 2>/dev/null || echo "?")
ENABLED=$(echo "$PROFILE2" | python3 -c "import json,sys; print(json.load(sys.stdin)['profile']['memoryEnabled'])" 2>/dev/null)
if [[ "$MEM_AFTER" == "0" && "$ENABLED" == "False" ]]; then
  pass "Memory opt-out purged rows"
else
  fail "Memory opt-out failed (rows=$MEM_AFTER, enabled=$ENABLED)"
fi

# AI-decide rule: keyword "stuck" → AI decides (review). Verifies the
# ai_decide path produces a proposal with a reason.
RULE_AI=$(curl -sf -X POST "$BASE/api/local/reshape-rules" \
  -H "Content-Type: application/json" \
  -d "{\"organizationId\":\"$ORG\",\"name\":\"Smoke ai-decide\",\"triggerType\":\"keyword\",\"triggerValue\":\"stuck\",\"actionType\":\"ai_decide\",\"approvalMode\":\"review\",\"priority\":40}")
RULE_AI_ID=$(echo "$RULE_AI" | python3 -c "import json,sys; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
[[ -n "$RULE_AI_ID" ]] && pass "Create ai-decide rule (#$RULE_AI_ID)" || fail "Create ai-decide rule"

# Test endpoint: should report ai-decide rule matches "I'm stuck on this".
TEST_RES=$(curl -sf -X POST "$BASE/api/local/reshape-rules/$ORG/test" \
  -H "Content-Type: application/json" \
  -d "{\"content\":\"I'm stuck on this\",\"contactId\":\"smoke-test-fresh-$(date +%s%N)\"}")
TEST_MATCH=$(echo "$TEST_RES" | python3 -c "import json,sys; d=json.load(sys.stdin); print(any(m['actionType']=='ai_decide' for m in d.get('matchedRules',[])))" 2>/dev/null)
[[ "$TEST_MATCH" == "True" ]] && pass "Rule-test endpoint matched ai-decide" || fail "Rule-test endpoint did not match ai-decide"

# Trigger ai-decide via inbound on a fresh contact to get a pending change.
CONTACT_AI="smoke-ai-$(date +%s)"
curl -sf -X POST "$BASE/api/local/inbound" \
  -H "Content-Type: application/json" \
  -d "{\"organizationId\":\"$ORG\",\"contactId\":\"$CONTACT_AI\",\"contactPhone\":\"+15005551234\",\"content\":\"I'm stuck on this\"}" > /dev/null
AI_PENDING=$(curl -sf "$BASE/api/local/pending-changes/$ORG?status=pending" | python3 -c "import json,sys; d=json.load(sys.stdin); print(any((c.get('aiReason') or '').startswith('AI') for c in d))" 2>/dev/null)
[[ "$AI_PENDING" == "True" ]] && pass "AI-decide produced pending change with reason" || fail "AI-decide pending change missing"

# Memory after auto-reshape: the original auto-skip on $CONTACT_ID should
# have triggered a recordContactActivity call from dispatchProposal as well
# as the inbound writer. Verify memory still reflects the auto-reshape note.
PROFILE_AI=$(curl -sf "$BASE/api/local/contact-profile/$ORG/$CONTACT_AI")
MEM_AI=$(echo "$PROFILE_AI" | python3 -c "import json,sys; m=json.load(sys.stdin).get('memory',[]); print(m[0].get('value','') if m else '')" 2>/dev/null)
echo "$MEM_AI" | grep -q "replied" && pass "Memory contains inbound note for ai-decide contact" || fail "Memory missing inbound note for ai-decide contact"

# Mirror round-trip: the in-memory cachedFieldIdByOrg map will be empty unless
# the MindfulText API has the customFields endpoint. We can't assert success
# (best-effort), but we CAN assert that toggling memory does not error and
# returns memoryEnabled=false. (Field-mirror clear is fire-and-forget.)
MIRROR_TOGGLE=$(curl -sf -X POST "$BASE/api/local/contact-profile/$ORG/$CONTACT_AI/memory-toggle" \
  -H "Content-Type: application/json" -d "{\"enabled\":false}" | python3 -c "import json,sys; print(json.load(sys.stdin).get('memoryEnabled'))" 2>/dev/null)
[[ "$MIRROR_TOGGLE" == "False" ]] && pass "Mirror-clear path runs without error" || fail "Mirror-clear path failed"

# Cleanup rules so reruns don't accumulate.
[[ -n "$RULE_AUTO_ID" ]] && curl -sf -X DELETE "$BASE/api/local/reshape-rules/$RULE_AUTO_ID" > /dev/null
[[ -n "$RULE_REVIEW_ID" ]] && curl -sf -X DELETE "$BASE/api/local/reshape-rules/$RULE_REVIEW_ID" > /dev/null
[[ -n "$RULE_AI_ID" ]] && curl -sf -X DELETE "$BASE/api/local/reshape-rules/$RULE_AI_ID" > /dev/null

# ---------------------------------------------------------------------------
# 6b. Workbench page (route + redirect from /bulk-edit)
# ---------------------------------------------------------------------------
echo ""
echo "--- 6b. Workbench page ---"

WB_HTTP=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/workbench")
[[ "$WB_HTTP" == "200" ]] && pass "GET /workbench → 200" || fail "GET /workbench → $WB_HTTP"

# /bulk-edit is a client-side redirect. The dev server still returns 200 (Vite
# serves the SPA shell), so we just verify the route still resolves and that
# the server-side bundle references Workbench, not the deleted BulkEdit page.
BE_HTTP=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/bulk-edit")
[[ "$BE_HTTP" == "200" ]] && pass "GET /bulk-edit → 200 (SPA serves redirect)" || fail "GET /bulk-edit → $BE_HTTP"

# Multi-type editable batch via the same endpoints the Workbench Apply uses.
# Pick the first journey + module + contact + action returned for $ORG and
# PATCH/PUT a no-op-ish field. Only run if the proxy login above succeeded.
if [[ -n "$PASSWORD" ]]; then
  echo "--- 6c. Workbench multi-type apply (smoke) ---"
  FIRST_JOURNEY=$(curl -sf -H "X-Session-ID: $SESSION_ID" \
    "$BASE/api/proxy/mindfultext/api/journeys/byOrganization/$ORG" \
    | python3 -c "import json,sys; d=json.load(sys.stdin).get('data',[]); print(d[0]['id'] if d else '')" 2>/dev/null)
  if [[ -n "$FIRST_JOURNEY" ]]; then
    # Re-PUT the journey with its existing name (no real change) → exercises
    # the same code path the Workbench Journeys editor uses.
    JBODY=$(curl -sf -H "X-Session-ID: $SESSION_ID" \
      "$BASE/api/proxy/mindfultext/api/journeys/$FIRST_JOURNEY" \
      | python3 -c "import json,sys; d=json.load(sys.stdin).get('data',{}); import json as j; print(j.dumps({'name':d.get('name','')}))")
    JR=$(curl -s -o /dev/null -w "%{http_code}" -X PUT \
      -H "Content-Type: application/json" -H "X-Session-ID: $SESSION_ID" \
      -d "$JBODY" \
      "$BASE/api/proxy/mindfultext/api/journeys/$FIRST_JOURNEY")
    [[ "$JR" =~ ^2 ]] && pass "Journey PUT no-op via proxy ($JR)" || fail "Journey PUT → $JR"
  else
    echo "  (no journeys found — skipping journey PUT)"
  fi

  # Module no-op PUT via proxy — the same code path the Workbench Modules editor
  # exercises when bulk-applying name/description/tag changes.
  FIRST_MODULE=$(curl -sf -H "X-Session-ID: $SESSION_ID" \
    "$BASE/api/proxy/mindfultext/api/modules/byOrganization/$ORG" \
    | python3 -c "import json,sys; d=json.load(sys.stdin).get('data',[]); print(d[0]['id'] if d else '')" 2>/dev/null)
  if [[ -n "$FIRST_MODULE" ]]; then
    MBODY=$(curl -sf -H "X-Session-ID: $SESSION_ID" \
      "$BASE/api/proxy/mindfultext/api/modules/$FIRST_MODULE" \
      | python3 -c "import json,sys; d=json.load(sys.stdin).get('data',{}); import json as j; print(j.dumps({'name':d.get('name','')}))")
    MR=$(curl -s -o /dev/null -w "%{http_code}" -X PUT \
      -H "Content-Type: application/json" -H "X-Session-ID: $SESSION_ID" \
      -d "$MBODY" \
      "$BASE/api/proxy/mindfultext/api/modules/$FIRST_MODULE")
    [[ "$MR" =~ ^2 ]] && pass "Module PUT no-op via proxy ($MR)" || fail "Module PUT → $MR"
  else
    echo "  (no modules found — skipping module PUT)"
  fi

  # Contact no-op PUT via proxy — Workbench Contacts editor batch path.
  FIRST_CONTACT=$(curl -sf -X POST -H "Content-Type: application/json" \
    -H "X-Session-ID: $SESSION_ID" -d "{}" \
    "$BASE/api/proxy/mindfultext/api/contacts/$ORG" \
    | python3 -c "import json,sys; d=json.load(sys.stdin).get('data',[]); print(d[0]['id'] if d else '')" 2>/dev/null)
  if [[ -n "$FIRST_CONTACT" ]]; then
    CBODY=$(curl -sf -H "X-Session-ID: $SESSION_ID" \
      "$BASE/api/proxy/mindfultext/api/contacts/$FIRST_CONTACT" \
      | python3 -c "import json,sys; d=json.load(sys.stdin).get('data',{}); import json as j; print(j.dumps({'firstName':d.get('firstName','') or ''}))")
    CR=$(curl -s -o /dev/null -w "%{http_code}" -X PUT \
      -H "Content-Type: application/json" -H "X-Session-ID: $SESSION_ID" \
      -d "$CBODY" \
      "$BASE/api/proxy/mindfultext/api/contacts/$FIRST_CONTACT")
    [[ "$CR" =~ ^2 ]] && pass "Contact PUT no-op via proxy ($CR)" || fail "Contact PUT → $CR"
  else
    echo "  (no contacts found — skipping contact PUT)"
  fi

  # Bulk-PATCH a reshape rule's enabled flag (Workbench Rules editor).
  RULE_BULK=$(curl -sf -X POST "$BASE/api/local/reshape-rules" \
    -H "Content-Type: application/json" \
    -d "{\"organizationId\":\"$ORG\",\"name\":\"Smoke wb-bulk\",\"triggerType\":\"keyword\",\"triggerValue\":\"wb\",\"actionType\":\"skip\",\"approvalMode\":\"review\",\"priority\":10,\"enabled\":true}")
  RULE_BULK_ID=$(echo "$RULE_BULK" | python3 -c "import json,sys; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
  if [[ -n "$RULE_BULK_ID" ]]; then
    PATCH_HTTP=$(curl -s -o /dev/null -w "%{http_code}" -X PATCH \
      -H "Content-Type: application/json" \
      -d "{\"enabled\":false,\"priority\":99}" \
      "$BASE/api/local/reshape-rules/$RULE_BULK_ID")
    [[ "$PATCH_HTTP" =~ ^2 ]] && pass "Workbench rule bulk-PATCH ($PATCH_HTTP)" || fail "Rule PATCH → $PATCH_HTTP"
    curl -sf -X DELETE "$BASE/api/local/reshape-rules/$RULE_BULK_ID" > /dev/null
  fi

  # Bulk pending approval/reject from Workbench: create a review-rule,
  # trigger inbound to enqueue, then approve via the same endpoint Workbench uses.
  WB_RULE=$(curl -sf -X POST "$BASE/api/local/reshape-rules" \
    -H "Content-Type: application/json" \
    -d "{\"organizationId\":\"$ORG\",\"name\":\"Smoke wb-pending\",\"triggerType\":\"keyword\",\"triggerValue\":\"wbpend\",\"actionType\":\"skip\",\"approvalMode\":\"review\",\"priority\":20}")
  WB_RULE_ID=$(echo "$WB_RULE" | python3 -c "import json,sys; print(json.load(sys.stdin).get('id',''))" 2>/dev/null)
  WB_CONTACT="smoke-wb-$(date +%s)"
  curl -sf -X POST "$BASE/api/local/inbound" \
    -H "Content-Type: application/json" \
    -d "{\"organizationId\":\"$ORG\",\"contactId\":\"$WB_CONTACT\",\"contactPhone\":\"+15005552468\",\"content\":\"please wbpend now\"}" > /dev/null
  WB_PENDING_ID=$(curl -sf "$BASE/api/local/pending-changes/$ORG?status=pending" \
    | python3 -c "import json,sys; d=json.load(sys.stdin); print(next((c['id'] for c in d if c['contactId']=='$WB_CONTACT'), ''))" 2>/dev/null)
  if [[ -n "$WB_PENDING_ID" ]]; then
    APP_HTTP=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
      -H "Content-Type: application/json" -d "{}" \
      "$BASE/api/local/pending-changes/$WB_PENDING_ID/approve")
    [[ "$APP_HTTP" =~ ^2 ]] && pass "Workbench pending bulk-approve ($APP_HTTP)" || fail "Pending approve → $APP_HTTP"
  else
    fail "Workbench pending-change was not enqueued"
  fi
  [[ -n "$WB_RULE_ID" ]] && curl -sf -X DELETE "$BASE/api/local/reshape-rules/$WB_RULE_ID" > /dev/null
fi

# ---------------------------------------------------------------------------
# 7. Webhook intake (only if CONTENT_WEBHOOK_SECRET is set)
# ---------------------------------------------------------------------------
if [[ -n "${CONTENT_WEBHOOK_SECRET:-}" ]]; then
  echo ""
  echo "--- 7. Webhook intake ---"
  WH_TITLE="Smoke webhook $(date +%s)"
  WH=$(curl -s -X POST "$BASE/api/webhooks/drafts" \
    -H "Content-Type: application/json" \
    -H "X-Webhook-Secret: $CONTENT_WEBHOOK_SECRET" \
    -d "{\"organizationId\":\"$ORG\",\"audienceTag\":\"smoke\",\"title\":\"$WH_TITLE\",\"texts\":[\"hello from smoke test\",\"second nudge\"]}")
  WH_ID=$(echo "$WH" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('draftId',''))" 2>/dev/null || echo "")
  if [[ -n "$WH_ID" ]]; then
    pass "POST /api/webhooks/drafts → draft #$WH_ID"
    DRAFTS=$(curl -sf "$BASE/api/local/drafts/$ORG" || echo "[]")
    if echo "$DRAFTS" | python3 -c "import json,sys,os; d=json.load(sys.stdin); t=os.environ['T']; assert any(x.get('id')==int(os.environ['I']) and x.get('title')==t for x in d)" T="$WH_TITLE" I="$WH_ID" 2>/dev/null; then
      pass "Webhook draft visible in /api/local/drafts/$ORG"
    else
      fail "Webhook draft not found in drafts list"
    fi
    REJECT=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$BASE/api/webhooks/drafts" \
      -H "Content-Type: application/json" -H "X-Webhook-Secret: wrong-secret" \
      -d "{\"audienceTag\":\"x\",\"texts\":[\"y\"]}")
    if [[ "$REJECT" == "401" ]]; then pass "Bad secret rejected (401)"
    else fail "Bad secret should return 401, got $REJECT"; fi
  else
    fail "POST /api/webhooks/drafts"
    echo "  Response: $(echo "$WH" | head -c 400)"
  fi
else
  echo ""
  echo "--- 7. Webhook intake — skipped (CONTENT_WEBHOOK_SECRET not set) ---"
fi
# ---------------------------------------------------------------------------
# 8. Dashboard stats — shape + non-negative counts for two periods
# ---------------------------------------------------------------------------
echo ""
echo "--- 8. Dashboard stats ---"
for P in month all; do
  STATS=$(curl -sf "$BASE/api/local/dashboard-stats?orgId=$ORG&period=$P" || echo "ERROR")
  if echo "$STATS" | python3 -c "
import json,sys
d=json.load(sys.stdin)
m=d['metrics']
keys=['contacts','journeys','modules','actions','texts','replies','sends','stops','unsubscribeRate']
for k in keys:
    assert k in m, f'missing {k}'
    assert m[k]['value']>=0, f'{k} value negative'
    assert isinstance(m[k]['supportsTrend'], bool)
" 2>/dev/null; then
    pass "GET /api/local/dashboard-stats?period=$P → 10 metrics, non-negative"
  else
    fail "GET /api/local/dashboard-stats?period=$P"
    echo "  Response: $(echo "$STATS" | head -c 400)"
  fi
done

# ---------------------------------------------------------------------------
# 8b. Dashboard stats caching (two-layer SWR — server side)
#   - A repeat call within the TTL must return the SAME cachedAt (cache hit).
#   - ?refresh=1 must force a recompute → a NEWER cachedAt.
# ---------------------------------------------------------------------------
echo ""
echo "--- 8b. Dashboard stats caching ---"

cached_at() {
  curl -sf "$1" | python3 -c "import json,sys; print(json.load(sys.stdin).get('cachedAt',''))" 2>/dev/null || echo ""
}

# Prime the cache with a forced recompute so the first read below is a known
# fresh entry (avoids flaking on a stale entry left by section 8).
PRIME_URL="$BASE/api/local/dashboard-stats?orgId=$ORG&period=month&refresh=1"
HIT_URL="$BASE/api/local/dashboard-stats?orgId=$ORG&period=month"

CA0=$(cached_at "$PRIME_URL")
CA1=$(cached_at "$HIT_URL")
CA2=$(cached_at "$HIT_URL")
if [[ -n "$CA1" && "$CA1" == "$CA2" ]]; then
  pass "Repeat dashboard-stats call returns stable cachedAt ($CA1)"
else
  fail "Repeat dashboard-stats cachedAt not stable (CA1='$CA1', CA2='$CA2')"
fi

# ?refresh=1 must bypass the cache and produce a strictly newer cachedAt.
sleep 1
CA3=$(cached_at "$PRIME_URL")
NEWER=$(O1="$CA1" O3="$CA3" python3 -c "import os; print('1' if os.environ['O3']>os.environ['O1'] else '0')" 2>/dev/null || echo "0")
if [[ -n "$CA3" && "$NEWER" == "1" ]]; then
  pass "?refresh=1 forces a recompute → newer cachedAt ($CA3)"
else
  fail "?refresh=1 did not produce a newer cachedAt (before='$CA1', after='$CA3')"
fi

# ---------------------------------------------------------------------------
# 9. Reply attribution + analytics (Task #96)
# ---------------------------------------------------------------------------
echo ""
echo "--- 9. Reply attribution + analytics ---"

ATTR_CONTACT="smoke-attr-$(date +%s)"

# Seed a default template so the contact has modules to advance through.
curl -sf -X POST "$BASE/api/local/journey-templates" \
  -H "Content-Type: application/json" \
  -d "{\"organizationId\":\"$ORG\",\"moduleIds\":[\"mod-attr-1\",\"mod-attr-2\"]}" > /dev/null

# Trigger an `advanced` event by manually advancing the personal journey.
curl -sf -X POST "$BASE/api/local/personal-journey/$ORG/$ATTR_CONTACT/op" \
  -H "Content-Type: application/json" \
  -d "{\"op\":\"advance\"}" > /dev/null \
  && pass "Advance personal-journey for $ATTR_CONTACT" \
  || fail "Advance personal-journey"

# Now record an inbound from that contact — should auto-attribute to the
# advanced module.
INBOUND_ATTR=$(curl -sf -X POST "$BASE/api/local/inbound" \
  -H "Content-Type: application/json" \
  -d "{\"organizationId\":\"$ORG\",\"contactId\":\"$ATTR_CONTACT\",\"contactPhone\":\"+15005558888\",\"content\":\"Got it, thanks\"}")
ATTR_MODULE=$(echo "$INBOUND_ATTR" | python3 -c "import json,sys; print(json.load(sys.stdin).get('inbound',{}).get('moduleId') or '')" 2>/dev/null)
[[ "$ATTR_MODULE" == "mod-attr-1" ]] && pass "Inbound attributed moduleId=$ATTR_MODULE" || fail "Inbound moduleId not stamped (got '$ATTR_MODULE')"

# Backfill is idempotent — should not change attributed rows.
BF=$(curl -sf -X POST "$BASE/api/local/inbound/backfill-attribution" \
  -H "Content-Type: application/json" -d "{\"organizationId\":\"$ORG\"}")
echo "$BF" | python3 -c "import json,sys; d=json.load(sys.stdin); assert 'scanned' in d and 'attributed' in d" 2>/dev/null \
  && pass "Backfill returned summary $(echo "$BF" | head -c 100)" \
  || fail "Backfill summary missing"

# Reply analytics endpoint should include the module with replies>=1.
ANALYTICS=$(curl -sf "$BASE/api/local/reply-analytics/$ORG")
HAS_ROW=$(echo "$ANALYTICS" | python3 -c "import json,sys; d=json.load(sys.stdin); print(any(r['moduleId']=='mod-attr-1' and r['replies']>=1 for r in d.get('rows',[])))" 2>/dev/null)
[[ "$HAS_ROW" == "True" ]] && pass "Reply analytics shows mod-attr-1 with replies>=1" || fail "Reply analytics missing mod-attr-1"

# Drawer endpoint returns the actual inbound message.
DRAWER=$(curl -sf "$BASE/api/local/reply-analytics/$ORG/module/mod-attr-1")
DRAWER_HAS=$(echo "$DRAWER" | python3 -c "import json,sys; d=json.load(sys.stdin); print(any(m['contactId']=='$ATTR_CONTACT' for m in d.get('messages',[])))" 2>/dev/null)
[[ "$DRAWER_HAS" == "True" ]] && pass "Drawer endpoint returns contact's reply" || fail "Drawer endpoint missing contact reply"

# ---------------------------------------------------------------------------
echo ""
if [[ "$FAILURES" -eq 0 ]]; then
  echo "✅ All checks passed."
else
  echo "❌ $FAILURES check(s) failed."
  exit 1
fi
