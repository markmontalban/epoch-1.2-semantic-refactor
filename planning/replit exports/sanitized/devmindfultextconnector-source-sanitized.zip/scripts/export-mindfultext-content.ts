/**
 * Export the configured MindfulText organization's module-text corpus as
 * canonical local JSONL. This is intentionally a GET-only data reader.
 *
 * Usage:
 *   npm run export:mindfultext-content
 *
 * It reuses the server's authenticated auto-session in .session-cookies.json.
 * Start the application once (or sign in through Settings) before running this
 * command. The generated files are intentionally gitignored local artifacts.
 */
import fs from "node:fs";
import path from "node:path";
import { getConfiguredOrgId } from "../server/orgSettings";
import { mtFetch } from "../server/mtClient";
import { AUTO_SESSION_ID, sessionStore } from "../server/session";
import {
  buildSnapshotManifest,
  fetchModuleCorpus,
  type SnapshotRequest,
} from "../server/contentSnapshot";

const OUTPUT_DIRECTORY = path.join(
  process.cwd(),
  "exports",
  "mindfultext-content-snapshot-aug-6-2026",
);
const JSONL_FILE = path.join(OUTPUT_DIRECTORY, "module-texts.jsonl");
const MANIFEST_FILE = path.join(OUTPUT_DIRECTORY, "manifest.json");

function fail(message: string): never {
  console.error(`[content-export] ${message}`);
  process.exit(1);
}

if (process.argv.length > 2) {
  fail("This command has a fixed local destination and does not accept arguments.");
}

const orgId = getConfiguredOrgId();
const cookies = sessionStore[AUTO_SESSION_ID];
if (!cookies) {
  fail("No authenticated MindfulText auto-session is available. Start the app once or sign in through Settings, then retry.");
}

const request: SnapshotRequest = async (requestPath, options) => {
  // Keep this guard next to the network boundary: data retrieval may only be GET.
  if (options.method !== "GET") {
    throw new Error(`Refusing non-GET MindfulText export request: ${options.method}`);
  }
  let response: Response;
  try {
    response = await mtFetch(requestPath, { method: "GET", cookies });
  } catch (error) {
    throw new Error(`MindfulText GET ${requestPath} failed: ${error instanceof Error ? error.message : String(error)}`);
  }
  if (!response.ok) {
    throw new Error(`MindfulText GET ${requestPath} failed with HTTP ${response.status}. No snapshot was written.`);
  }
  try {
    return await response.json();
  } catch {
    throw new Error(`MindfulText GET ${requestPath} returned invalid JSON. No snapshot was written.`);
  }
};

try {
  const { modules, rows } = await fetchModuleCorpus(orgId, request);
  const manifest = buildSnapshotManifest(orgId, modules, rows, new Date().toISOString());
  const jsonl = rows.map((row) => JSON.stringify(row)).join("\n") + (rows.length ? "\n" : "");

  fs.mkdirSync(OUTPUT_DIRECTORY, { recursive: true, mode: 0o700 });
  const jsonlTemp = `${JSONL_FILE}.tmp`;
  const manifestTemp = `${MANIFEST_FILE}.tmp`;
  try {
    fs.writeFileSync(jsonlTemp, jsonl, { encoding: "utf8", mode: 0o600 });
    fs.writeFileSync(manifestTemp, `${JSON.stringify(manifest, null, 2)}\n`, { encoding: "utf8", mode: 0o600 });
    fs.renameSync(jsonlTemp, JSONL_FILE);
    fs.renameSync(manifestTemp, MANIFEST_FILE);
  } catch (error) {
    fs.rmSync(jsonlTemp, { force: true });
    fs.rmSync(manifestTemp, { force: true });
    throw error;
  }

  console.log(`[content-export] Wrote ${JSONL_FILE}`);
  console.log(`[content-export] Wrote ${MANIFEST_FILE}`);
  console.log(
    `[content-export] modules=${manifest.module_count}, texts=${manifest.text_count}, ` +
    `media_texts=${manifest.media_text_count}, action_attached_texts=${manifest.action_attached_text_count}`,
  );
  if (manifest.expected_comparison.matches_expected_inventory) {
    console.log("[content-export] Counts match the expected inventory (~283 modules, ~1,112 texts).");
  } else {
    console.warn(
      `[content-export] Counts differ from expected inventory: modules ${manifest.module_count} ` +
      `(difference ${manifest.expected_comparison.module_count_difference}), texts ${manifest.text_count} ` +
      `(difference ${manifest.expected_comparison.text_count_difference}). The snapshot was not reconciled or filtered.`,
    );
  }
} catch (error) {
  fail(error instanceof Error ? error.message : String(error));
}