CREATE TABLE IF NOT EXISTS "segments" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"name" text NOT NULL,
	"include_tags" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"exclude_tags" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"match_mode" text DEFAULT 'OR' NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_segments_org" ON "segments" USING btree ("organization_id");
