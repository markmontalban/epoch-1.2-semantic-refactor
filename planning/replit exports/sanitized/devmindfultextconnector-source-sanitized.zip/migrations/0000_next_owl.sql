CREATE TABLE "agent_memory" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"contact_id" text,
	"memory_type" text DEFAULT 'fact' NOT NULL,
	"key" text NOT NULL,
	"value" text NOT NULL,
	"summary" text,
	"priority" integer DEFAULT 0,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "agent_rules" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"name" text NOT NULL,
	"content" text NOT NULL,
	"scope" text DEFAULT 'global' NOT NULL,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "analytics_snapshots" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"snapshot_date" text NOT NULL,
	"new_contacts" integer DEFAULT 0 NOT NULL,
	"new_launches" integer DEFAULT 0 NOT NULL,
	"messages_sent" integer DEFAULT 0 NOT NULL,
	"messages_received" integer DEFAULT 0 NOT NULL,
	"total_contacts" integer,
	"total_launches" integer,
	"total_sent" integer,
	"total_received" integer,
	"captured_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "attribution_events" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text,
	"visitor_id" text,
	"contact_id" text,
	"utm_source" text,
	"utm_medium" text,
	"utm_campaign" text,
	"utm_term" text,
	"utm_content" text,
	"referrer" text,
	"landing_path" text,
	"user_agent" text,
	"metadata" jsonb,
	"occurred_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "audience_briefs" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"tag" text NOT NULL,
	"brief" text DEFAULT '' NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "contact_profiles" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"contact_id" text NOT NULL,
	"memory_enabled" boolean DEFAULT true NOT NULL,
	"memory_field_id" text,
	"page_note" text,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "content_drafts" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"title" text NOT NULL,
	"module_type" text DEFAULT 'sms',
	"content_plan" jsonb,
	"generated_texts" jsonb,
	"status" text DEFAULT 'draft' NOT NULL,
	"mindfultext_module_id" text,
	"audience_tag" text,
	"created_by" text,
	"metadata" jsonb,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "content_programs" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"subscriber_needs" jsonb,
	"program_content" jsonb,
	"status" text DEFAULT 'draft' NOT NULL,
	"access_type" text DEFAULT 'free',
	"coupon_code" text,
	"created_by" text,
	"metadata" jsonb,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "draft_messages" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"contact_id" text,
	"contact_phone" text,
	"inbound_message_id" integer,
	"draft_content" text NOT NULL,
	"status" text DEFAULT 'generated' NOT NULL,
	"ai_model" text,
	"metadata" jsonb,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "entity_snapshots" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"entity_type" text NOT NULL,
	"entity_id" text NOT NULL,
	"entity_name" text,
	"snapshot" jsonb NOT NULL,
	"reason" text DEFAULT 'before_edit' NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "inbound_messages" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"contact_id" text,
	"contact_phone" text,
	"content" text,
	"received_at" timestamp DEFAULT now(),
	"draft_generated" boolean DEFAULT false,
	"module_id" text,
	"attribution_source" text,
	"metadata" jsonb
);
--> statement-breakpoint
CREATE TABLE "message_events" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"direction" text NOT NULL,
	"contact_id" text,
	"contact_phone" text,
	"module_id" text,
	"journey_id" text,
	"text_index" integer,
	"in_reply_to_text_index" integer,
	"content" text,
	"source" text DEFAULT 'webhook' NOT NULL,
	"occurred_at" timestamp DEFAULT now(),
	"metadata" jsonb
);
--> statement-breakpoint
CREATE TABLE "page_events" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text,
	"contact_id" text,
	"token" text,
	"event_type" text DEFAULT 'view' NOT NULL,
	"path" text,
	"user_agent" text,
	"occurred_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "page_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"brand_name" text DEFAULT 'MindfulText' NOT NULL,
	"tagline" text DEFAULT 'Your space to revisit and explore.' NOT NULL,
	"accent_color" text DEFAULT '#6366f1' NOT NULL,
	"footer_text" text DEFAULT 'MindfulText' NOT NULL,
	"show_topics" boolean DEFAULT true NOT NULL,
	"topics_label" text DEFAULT 'Your topics' NOT NULL,
	"show_received" boolean DEFAULT true NOT NULL,
	"received_label" text DEFAULT 'Messages you’ve received' NOT NULL,
	"show_library" boolean DEFAULT true NOT NULL,
	"library_label" text DEFAULT 'More for you' NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now(),
	CONSTRAINT "page_settings_organization_id_unique" UNIQUE("organization_id")
);
--> statement-breakpoint
CREATE TABLE "pending_changes" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"contact_id" text NOT NULL,
	"inbound_message_id" integer,
	"rule_id" integer,
	"current_sequence" jsonb NOT NULL,
	"proposed_sequence" jsonb NOT NULL,
	"proposed_ops" jsonb,
	"ai_reason" text,
	"send_required" boolean DEFAULT false NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"decided_by" text,
	"decided_at" timestamp,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "personal_journey_events" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"contact_id" text NOT NULL,
	"event_type" text NOT NULL,
	"module_id" text,
	"rule_id" integer,
	"source" text DEFAULT 'manual' NOT NULL,
	"inbound_message_id" integer,
	"reason" text,
	"metadata" jsonb,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "personal_journey_templates" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"tag" text,
	"module_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "personal_journeys" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"contact_id" text NOT NULL,
	"module_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"current_index" integer DEFAULT 0 NOT NULL,
	"paused" boolean DEFAULT false NOT NULL,
	"subscription_id" text,
	"last_advanced_at" timestamp,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "published_content" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"title" text NOT NULL,
	"body" text NOT NULL,
	"topic" text,
	"source_type" text DEFAULT 'draft' NOT NULL,
	"source_id" text,
	"published" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "reshape_rules" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"name" text NOT NULL,
	"trigger_type" text NOT NULL,
	"trigger_value" text DEFAULT '',
	"action_type" text NOT NULL,
	"action_params" jsonb,
	"approval_mode" text DEFAULT 'review' NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"priority" integer DEFAULT 100 NOT NULL,
	"continue_after" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "subscriber_page_tokens" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"contact_id" text NOT NULL,
	"token" text NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"last_visit_at" timestamp,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "subscriber_page_tokens_token_unique" UNIQUE("token")
);
--> statement-breakpoint
CREATE TABLE "token_usage" (
	"id" serial PRIMARY KEY NOT NULL,
	"organization_id" text NOT NULL,
	"task_type" text NOT NULL,
	"model" text NOT NULL,
	"prompt_tokens" integer DEFAULT 0 NOT NULL,
	"completion_tokens" integer DEFAULT 0 NOT NULL,
	"total_tokens" integer DEFAULT 0 NOT NULL,
	"estimated_cost_usd" real DEFAULT 0,
	"reference_id" integer,
	"reference_type" text,
	"metadata" jsonb,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE INDEX "idx_agent_memory_org" ON "agent_memory" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_agent_memory_contact" ON "agent_memory" USING btree ("contact_id");--> statement-breakpoint
CREATE INDEX "idx_agent_rules_org" ON "agent_rules" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_analytics_snapshots_org_date" ON "analytics_snapshots" USING btree ("organization_id","snapshot_date");--> statement-breakpoint
CREATE INDEX "idx_attribution_events_org" ON "attribution_events" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_attribution_events_visitor" ON "attribution_events" USING btree ("visitor_id");--> statement-breakpoint
CREATE INDEX "idx_attribution_events_contact" ON "attribution_events" USING btree ("contact_id");--> statement-breakpoint
CREATE INDEX "idx_audience_briefs_org_tag" ON "audience_briefs" USING btree ("organization_id","tag");--> statement-breakpoint
CREATE INDEX "idx_contact_profiles_org" ON "contact_profiles" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_contact_profiles_contact" ON "contact_profiles" USING btree ("contact_id");--> statement-breakpoint
CREATE INDEX "idx_content_drafts_org" ON "content_drafts" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_content_programs_org" ON "content_programs" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_draft_messages_org" ON "draft_messages" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_snapshots_org" ON "entity_snapshots" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_snapshots_entity" ON "entity_snapshots" USING btree ("entity_type","entity_id");--> statement-breakpoint
CREATE INDEX "idx_inbound_messages_org" ON "inbound_messages" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_message_events_org" ON "message_events" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_message_events_contact" ON "message_events" USING btree ("contact_id");--> statement-breakpoint
CREATE INDEX "idx_message_events_module" ON "message_events" USING btree ("module_id");--> statement-breakpoint
CREATE INDEX "idx_page_events_org" ON "page_events" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_page_events_contact" ON "page_events" USING btree ("contact_id");--> statement-breakpoint
CREATE INDEX "idx_page_events_token" ON "page_events" USING btree ("token");--> statement-breakpoint
CREATE INDEX "idx_page_settings_org" ON "page_settings" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_pending_changes_org" ON "pending_changes" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_pending_changes_status" ON "pending_changes" USING btree ("status");--> statement-breakpoint
CREATE INDEX "idx_pj_events_org" ON "personal_journey_events" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_pj_events_contact" ON "personal_journey_events" USING btree ("contact_id");--> statement-breakpoint
CREATE INDEX "idx_pj_templates_org" ON "personal_journey_templates" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_personal_journeys_org" ON "personal_journeys" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_personal_journeys_contact" ON "personal_journeys" USING btree ("contact_id");--> statement-breakpoint
CREATE INDEX "idx_published_content_org" ON "published_content" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_published_content_topic" ON "published_content" USING btree ("topic");--> statement-breakpoint
CREATE INDEX "idx_reshape_rules_org" ON "reshape_rules" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_subscriber_page_tokens_org" ON "subscriber_page_tokens" USING btree ("organization_id");--> statement-breakpoint
CREATE INDEX "idx_subscriber_page_tokens_contact" ON "subscriber_page_tokens" USING btree ("contact_id");--> statement-breakpoint
CREATE INDEX "idx_token_usage_org" ON "token_usage" USING btree ("organization_id");