# MindfulText Dashboard

## Overview

This is a comprehensive full-stack web application for MindfulText, a customer journey management platform. The application provides a complete dashboard for managing all aspects of customer journey automation including organizations, contacts, journeys, modules, messages, subscriptions, integrations, actions, team management, and analytics. It uses a server-side MindfulText session-cookie proxy for authentication, a modern responsive UI built with React and shadcn/ui components, and a local Postgres layer for AI content staging, automation, and analytics.

## Recent Changes

✓ Jul 14, 2026 - Searchable meditation library on subscriber pages (demo MVP)
  - New `harvested_links` table + link fields on `published_content`
    (contentType/url/theme/complexity/sourceDay). "Scan modules for links"
    (POST /api/local/library/harvest) pulls every org module via the proxy,
    extracts URLs from text bodies, classifies them (likelyMeditation +
    theme from filename/module context), and stages them idempotently
    (unique org+url, onConflictDoNothing; re-scans only add new links).
  - New admin "Library" page (/library): To review / Published / Discarded
    tabs, inline title/theme/level edits, Publish/Discard per link;
    publishing creates a `published_content` meditation row. Deleting a
    published item returns its harvested link to the review queue.
  - Public subscriber page (/p/:token) now shows a searchable meditation
    library (search box + theme/level filter chips, tappable "Listen now"
    cards logging content_open) and dedupes received-module variants
    (e.g. "X" / "X for Sleep" grouped with an "N versions" pill).
    Fixed a crash from PersistQueryClientProvider cache restore (data
    undefined while isLoading is false — guard on !data, not isLoading).
  - Public /view event endpoint hardened: eventType allowlist
    (view/content_open) + 500-char path cap.
  - ContactPanel: "Open page" button next to subscriber-link controls.

✓ Jun 14, 2026 - Connect live replies to reshape rules and draft review
  - Poll MindfulText /api/messages every 3 minutes (plus manual "Check for replies")
    and run each new inbound through processInboundReply (dedupe via mtMessageId).
  - Replies feed reshape rules → pending_changes → Changes tab; message_events
    updated live for analytics.
  - New Replies sidebar page: draft-reply review (edit/approve/copy/mark sent — no auto-send).

✓ Jun 14, 2026 - Group management: tag detail, segments, and bulk actions
  - Audiences tags open a detail page (/audiences/:tag) with member list and
    rollups (sends, replies, page views, journey status) from local event tables.
  - Bulk actions per tag or segment: enroll all members in a journey template,
    generate subscriber /p/:token links, and deep-link to Drafts with audienceTag preset.
  - Saved segments (multi-tag AND/OR cohorts) with CRUD, /segments/:id detail view,
    and segment picker in Drafts (SMS push still requires a single tag).

✓ Jun 9, 2026 - Opt-in Phase 2 proxy/local auth hardening (off by default)
  - Added two env flags, both default off so daily ops are unchanged:
    PROXY_STRICT_AUTH requires an interactive operator session or confirm token
    for every MindfulText proxy request (not just mutations), and
    STRICT_LOCAL_AUTH drops the shared auto-session fallback in the /api/local
    auth gate so each request must resolve to its own bound session.
  - These add login/session friction, so they ship disabled: enable them in a
    test session, exercise the dashboard + proxy flows, then turn them on for
    real once session edge cases are confirmed. Documented in README.md.

✓ Jun 9, 2026 - Subscriber profile pages and marketing attribution intake
  - New tokenized public pages: GET /api/public/profile/:token returns a
    contact's topics (MindfulText tags), the content they've received, and a
    topic-matched library feed; the SPA route /p/:token renders a mobile-first
    page with no login and no data beyond first name. Access is gated solely by
    an unguessable token; a best-effort page-view is logged per visit.
  - Founder tooling: generate/copy/revoke a contact's link in the Contact
    panel, a "Publish" action on Content Drafts that copies generated texts into
    a local library (no upstream write, no texts sent), and a Subscriber pages
    card (views + unique subscribers) in the Dashboard engagement tab.
  - POST /api/track now supports cross-origin posts from the marketing site via
    a CORS allowlist (TRACK_CORS_ORIGINS, default mindfultext.com + www) with
    OPTIONS preflight handling. The request contract is documented in README.md.

✓ Jun 9, 2026 - Phase 2 foundation: split routes, shared HTTP client, cleanup
  - Extracted infrastructure out of the 4.6k-line `server/routes.ts` into
    focused modules (`session.ts`, `orgSettings.ts`, `proxy.ts`, `schedulers.ts`,
    `mtReporting.ts`); routes.ts now wires them via imports with no behavior
    change. Shared auto-login state is exposed through getters/setters.
  - New `server/mtClient.ts`: every server-side `dev.mindfultext.com` call now
    goes through `mtFetch`, which owns the base URL, standard headers, and a
    request timeout (`MT_TIMEOUT_MS`, default 15s) that aborts hung sockets.
  - Fixed the Express error handler that responded then re-threw (it now logs
    and guards against double-send). Removed unused auth deps (`passport`,
    `passport-local`, `express-session`, `connect-pg-simple`, `memorystore`),
    the dead `test-mindfultext-api.js`, the unused `users`/`organizations`
    schema exports, and the unused `launchJourney` client method. Added an
    `npm test` script for `swrCache.test.ts` and corrected the auth docs
    (cookie proxy, not JWT) in this file and `client/README_AUTHENTICATION.md`.

✓ Jun 9, 2026 - Agent-safe guardrails for sends and module/journey edits
  - New `server/agentSafety.ts`: `AGENT_SAFE_MODE` (default on; set
    `AGENT_SAFE_MODE=false` to restore legacy behavior) plus one-time confirm
    tokens and an `OPERATOR_EMAIL` constant (default `m@mindfultext.com`).
  - Auto-reshape no longer sends on its own. When a rule's `approvalMode` is
    `auto`, the queue ops still apply immediately, but instead of launching the
    next message the system files a send-only `pending_changes` row
    (`send_required = true`, migration 0005) for the founder to approve in the
    Changes screen. Skip/pause/resume queue behavior is unchanged.
  - The MindfulText proxy now blocks mutating upstream calls (subscription
    launches, module/journey POST/PUT) unless they come from an interactive
    operator browser session or carry a one-time `X-Operator-Confirm` token
    (issued by `POST /api/local/operator/confirm-token`). Normal dashboard use
    is unaffected; agents, scripts, and webhooks cannot send or edit without
    approval.
  - Changes screen labels send-only approvals ("Send pending" badge,
    "Approve & send" button).

✓ Jun 4, 2026 - Remove Dashboard Funnel tab
  - Dropped the Funnel tab and `FunnelSection` (stage bars + conversion cards);
    Overview KPI tiles and period comparison chart remain the primary summary.

✓ Jun 4, 2026 - Dashboard message tiles use calendar periods
  - Daily/weekly/monthly/yearly/custom message counts align to local-time
    midnight boundaries (Monday 00:00 for weeks), not rolling 24h/7d windows.
  - Resolution order: MindfulText reporting with explicit bounds, daily snapshot
    cumulative diffs, then local message_events / inbound_messages.

✓ Jun 2, 2026 - Add Attrition tab (opt-out deep-dive)
  - New `GET /api/local/attrition`: combines per-contact `isUnsubscribed` state
    with a STOP-event scan of the message feed. The feed reliably contains
    every current opt-out's STOP with a timestamp (verified 11/11), so it's the
    source of truth for WHEN someone opted out; `byContact` (only the unsubbed
    set — cheap) bounds "texts received before opt-out" and resolves the
    module/journey they were on. STOP events persisted to `message_events`
    (source `optout-scan`, idempotent via `replaceOptOutScanEvents`).
  - New Dashboard "Attrition" tab: summary cards (currently unsubscribed,
    rate, all-time STOP events, avg texts before opt-out), a monthly STOP
    timeline, and a per-contact table (name, tags, unsub date, texts before,
    module, journey). Note: STOP events (56) >> currently unsubscribed (11)
    because of resubscribes/conversational "stop"/removals.

✓ Jun 2, 2026 - Fix opt-out / unsubscribe tiles (real source)
  - Opt-outs and unsubscribe rate were derived from a STOP-keyword scan of the
    local `inbound_messages` table, which is empty (webhook-only, and STOP is
    carrier/platform-handled so it rarely reaches a webhook) → always 0.
  - Now sourced from MindfulText's authoritative per-contact `isUnsubscribed`
    flag (every opt-out, however it arrived), computed from the contacts list
    the dashboard already fetches. Rate = unsubscribed ÷ contacts that received
    a message. It's a point-in-time total (no period trend); Phase 2 snapshots
    can add a trend later. Removed `countOptOutInboundMessages`.

✓ Jun 2, 2026 - Founder dashboard Phase 4: AI insights + prompt control
  - `generateInsights` (server/ai) + `GET /api/local/insights` feed real
    reporting deltas (weekly/monthly), reply rate, AI cost, and snapshot count
    into OpenRouter and return 3-5 JSON highlights. New Insights tab renders
    them with sentiment accents + suggested questions that deep-link to Ask
    (`/ask?q=…`, which now prefills its input from the query param).
  - Agent prompt transparency: `GET/PUT /api/local/base-prompt` read/write
    `mindfultext.md` (cache-aware); new `AgentPromptsCard` in Settings edits the
    base prompt and manages org `agent_rules` (add/delete, scoped).

✓ Jun 2, 2026 - Founder dashboard Phase 3: revenue + attribution
  - `server/stripeClient.ts` resolves a read-only Stripe client from the Replit
    connector or `STRIPE_SECRET_KEY`; `getRevenueSummary` computes MRR / new
    revenue / churn. `GET /api/local/revenue` returns `{connected:false}` when
    Stripe isn't configured (Revenue tab shows a connect prompt).
  - New `attribution_events` table (migration 0004) + `POST /api/track` (public)
    capturing UTM params + a first-party visitor id; client
    `lib/attribution.ts` fires on load. `GET /api/local/attribution` summarizes
    top sources/campaigns, shown on the Revenue tab.

✓ Jun 2, 2026 - Founder dashboard Phase 2: time-series logging layer
  - New tables `analytics_snapshots` (daily capture of reporting deltas +
    cumulative totals → real calendar trends) and `message_events` (granular
    per-text send/reply log keyed by contact/module/journey/textIndex).
  - Migration `0003_needy_betty_ross.sql` (applied via `drizzle-kit push`).
  - Storage helpers: `upsertAnalyticsSnapshot`, `getAnalyticsSnapshots`,
    `recordMessageEvent`, `countMessageEvents`, `backfillMessageEvents`.
  - Daily scheduler in `registerRoutes` captures a snapshot (rangeInDays 1 +
    -1) and seeds `message_events` from existing personalJourneyEvents +
    inboundMessages once on startup. New endpoints:
    `GET /api/local/analytics/timeseries`, `POST /api/local/analytics/snapshot`,
    `POST /api/local/message-events/backfill`.

✓ Jun 2, 2026 - Founder dashboard Phase 1: connected tabbed view
  - Rebuilt `Dashboard.tsx` into a tabbed founder view (Overview / Engagement /
    Cost, later Attrition / Revenue / Insights) using Recharts + shadcn (kept on
    the existing design system rather than bolting on Tremor's separate theme).
  - Overview keeps the KPI tiles (now labeled with real meanings) plus a
    current-vs-prior comparison bar chart. (An intermediate Funnel tab with
    stage bars and conversion ratios was removed Jun 4, 2026.)
  - Engagement tab embeds Reply Analytics; Cost tab embeds Token Usage. Removed
    their standalone sidebar entries (routes still registered for deep links).

✓ Jun 2, 2026 - Founder dashboard Phase 0: real analytics foundation
  - Discovered MindfulText's real Analytics API: `POST /api/reporting/{orgId}`
    with `{ rangeInDays }` (-1 = all time), returning `newContacts`,
    `newLaunches`, `messagesSent`, `messagesReceived`. These are the true
    totals (58k+ sends) the old 16-row `/api/messages` feed could never show.
  - New proxy `GET /api/local/analytics` (named `range` or integer
    `rangeInDays`) with auto-session refresh + retry.
  - Dashboard `texts`/`sends`/`replies` tiles now come from `reporting`
    (prior window derived as reporting(2N) − reporting(N)); `stops`/unsubscribe
    rate now count locally captured opt-out inbound via
    `countOptOutInboundMessages`. Removed the 16-row message feed and the
    `messagesNote` bandaid. Reporting windows are rolling (not calendar);
    Phase 2 snapshots will add calendar-accurate trends.

✓ May 21, 2026 - Dashboard replies vs STOP / unsubscribe rate
  - Replies tile uses attributed local `inbound_messages` (excludes STOP and
    unattributed carrier texts).
  - Added Stops and Unsubscribe rate tiles; rate = stops in period ÷ active contacts.

✓ May 21, 2026 - Fix dashboard period bucketing (Unix seconds)
  - MindfulText `createdAt` values are Unix seconds; parsing as ms put every
    record in 1970 so period tiles matched lifetime totals or broke entirely.
  - Dashboard stats now multiply numeric timestamps below 1e12 by 1000; message
    tiles prefer `sentAt` when present.

✓ May 21, 2026 - Dashboard period-accurate tiles + Weekly range
  - Card headlines now show counts in the selected period (day / week Mon–Sun /
    month / year / custom) in the browser timezone, not lifetime inventory.
  - Added Weekly period; All time still shows lifetime totals with no delta.
  - Message tiles filter the 16-row recent feed by period (see dashboard note).

✓ May 21, 2026 - Added Replit checkpoint workflow rule
  - Added an always-on Cursor project rule so future agent work remembers to
    typecheck, review the diff, stage specific files, and commit each completed
    unit of work.
  - Captured the Replit dev server and protected-file guardrails in the rule so
    SSH edits stay compatible with Replit checkpoints.

✓ May 20, 2026 - Show org name in header + Settings (Task #114 follow-up)
  - `GET /api/local/settings` now also returns `orgName`, resolved via
    `GET /api/organizations/{orgId}` (per-org endpoint works even when
    `byUser` is forbidden). Cached server-side per orgId so polls don't
    re-fetch.
  - Header displays a "🏢 Wheelchair Ball 00000030" pill to the left of
    the email + Sign Out, sourced from the same query the Settings page
    uses (TanStack Query, 30s staleTime). Switching orgs from Settings
    invalidates the query so the header updates immediately.
  - Settings page (byuser_forbidden state) now shows "Currently active:
    <name> <id>" above the manual ID input.

✓ May 20, 2026 - Settings login fix: handle byUser 403 (Task #114 follow-up)
  - MindfulText's `/api/organizations/byUser` returns 403 for some accounts
    even when the cookies are valid for every other endpoint. The first cut
    of Task #114 treated that 403 as "invalid credentials" and erased the
    session, so the Settings sign-in always failed even with a correct
    email + password.
  - Replaced `fetchOrgsByUser` with `probeOrgsByUser` returning a tagged
    union (`ok` / `unauthorized` / `forbidden` / `error`). Login + keep-alive
    now keep the session on `forbidden` and only re-auth on `unauthorized`.
  - `GET /api/local/settings/orgs` now returns `{ orgs: [], code:
    "byuser_forbidden" }` (HTTP 200) for those accounts. PUT validation
    skips when the list is unavailable rather than blocking the save.
  - Settings page added a manual "Organization ID" text input that appears
    only in the byuser_forbidden state, with a clear "Signed in, but
    MindfulText didn't share an org list" notice.
  - Keep-alive job now reads the same Settings-saved → env-var credential
    precedence as initial login (was env-only).
  - Smoke test (`scripts/smoke-test.sh` §5b) updated to accept either the
    dropdown path or the byuser_forbidden path so it stays green across
    both account types.

✓ May 20, 2026 - Settings: email/password + org dropdown (Task #114)
  - `.org-settings.json` now also holds `{ email, password }` (gitignored,
    chmod 600). GET `/api/local/settings` returns only the safe fields
    (`orgId`, `email`, `hasPassword`, `signedIn`) — password is never echoed
    back. `performAutoLogin` prefers settings-stored credentials over env
    vars, so the user's Settings sign-in survives restarts.
  - New `POST /api/local/settings/login` (exempt from the auth gate) — logs
    into MindfulText, captures cookies into the `AUTO_SESSION_ID` slot,
    persists creds, binds the resulting session to the caller's
    `X-Session-ID`, and returns `{ ok, orgs, orgId }`. Distinct error codes
    for `invalid_credentials` / `network_error` / `missing_fields`.
  - New `GET /api/local/settings/orgs` — returns the cached `byUser` list,
    refetching from MindfulText with stored cookies; returns 401 +
    `code: "credentials_expired"` so the UI can prompt re-login.
  - `PUT /api/local/settings` now validates the chosen orgId against that
    list and rejects with 400 + `org_not_accessible` if it isn't one the
    user can reach.
  - `/settings` page rewritten with two cards: a sign-in card (email +
    password + Sign in / Update credentials button, with clear "not signed
    in" / "signed in as X" / "session expired" states) and an Organization
    card with a `<Select>` dropdown of name + id. Saving the org
    invalidates all queries so every tab switches over without a restart.
  - Smoke test (`scripts/smoke-test.sh`) section 5b covers the new flow:
    POST creds → orgs returned → PUT validated org → proxied contacts
    fetch against that org → bogus org rejected (400) → bad creds
    rejected (401).
  - **Out of scope, intentionally:** MindfulText role-based access
    (Manager/Reporter/Editor/Communicator). Future work would surface the
    current user's role from MindfulText and gate sidebar items / routes
    accordingly (e.g. a Reporter-only partner only sees Analytics).

✓ May 14, 2026 - Single-user mode + Settings org ID (Task #111)
  - Loosened the client `safeUpdate` "would clear array field" guard to a
    `console.warn` that still lets the save through (snapshot-based undo
    remains).
  - Server `/api/local/*` auth gate: org-mismatch on URL param, path segment,
    and request body now logs a warning and continues (no more 403s).
    `ownsEntity` and the `orgId` route param do the same.
  - Added a persisted `.org-settings.json` (gitignored) with module-level
    helpers `loadOrgSettings`/`saveOrgSettings`/`getConfiguredOrgId`. The
    hardcoded `KNOWN_ORG_ID`/webhook fallback now reads from this file
    (defaults to `00000022`).
  - New endpoints: `GET /api/local/settings`, `PUT /api/local/settings`
    (clears the per-session org cache so the new value applies immediately).
  - New `/settings` page (sidebar entry with Settings icon) with a single
    "Organization ID" field, TanStack Query backed, toast feedback. On save
    it mirrors to `localStorage` and invalidates all queries so every tab +
    request switches over without a restart.
  - `client/src/lib/localApi.ts` is now the single source of truth for the
    client org id (reads `localStorage`, defaults to `00000022`); `App.tsx`
    syncs from `/api/local/settings` on boot. `client/src/lib/api.ts`
    `resolveOrgId` defers to it.

✓ May 10, 2026 - Reshape-on-reply + per-contact memory (Task #62)
  - Added `personal_journeys`, `personal_journey_events`, `reshape_rules`,
    `pending_changes`, `contact_profiles`, `personal_journey_templates`;
    extended `agent_memory` with `contactId` + `summary`.
  - `server/personalJourney.ts` is the single writer for queue mutations;
    every change appends an event row tagged `auto`/`review`/`manual`.
  - `server/reshape.ts` evaluates org rules in priority order; auto-mode
    applies immediately, review-mode queues to `pending_changes`.
  - Inbound handler now runs rule evaluation + writes per-contact memory
    (mirrors to MindfulText custom field `agentMemory`, best-effort).
  - New routes: `/api/local/reshape-rules`, `/api/local/pending-changes`
    (`/count`, `/:id/approve`, `/:id/reject`),
    `/api/local/personal-journey/:org/:contact` (+ `/op`),
    `/api/local/contact-profile/:org/:contact` (+ memory toggle/clear),
    `/api/local/journey-templates`.
  - New pages: `/automation`, `/changes` (with sidebar pending badge),
    `/contact/:id`. Sidebar shows live pending count.
  - `scripts/smoke-test.sh` extended with the full happy path: rule create,
    inbound triggers both auto + review, approve pending, manual reorder,
    memory write + opt-out purge.

✓ April 24, 2026 - Hardened proxy session handling and removed legacy artifacts
  - **Session keying**: replaced `req.ip` with browser-generated UUID (`X-Session-ID` header).
    The browser stores the UUID in `localStorage`; the server uses it as the cookie-store key.
    Survives server restarts and Replit's internal proxy rewrites that change the apparent IP.
  - **Session persistence**: server-side MindfulText cookies now saved to `.session-cookies.json`
    (gitignored) and re-loaded on startup so users stay logged in across restarts.
  - **Org resolution**: `resolveOrgId` now handles `organizationID` as a string; auth layer
    attempts `GET /api/organizations/byUser` after login and stores result; falls back to
    hardcoded `DEFAULT_ORG_ID = '00000022'` with a clear comment when that endpoint is absent.
  - **Removed `server/storage.ts`**: entirely unused; no code imported it after routes.ts slim-down.
  - **Kept `shared/schema.ts`**: referenced by `drizzle.config.ts` — annotated as legacy, not to
    be imported from application code.
  - **`scripts/smoke-test.sh`**: minimal bash script that logs in and verifies each proxy endpoint.
  - **TypeScript**: `npm run check` passes clean.

✓ March 20, 2026 - Aligned with confirmed MindfulText API endpoints
  - Updated API service with confirmed endpoints from Chrome DevTools:
    - List: GET `/api/{resource}/byOrganization/{orgId}`
    - Detail: GET `/api/{resource}/{entityId}`
    - Search: POST `/api/{resource}/{orgId}/search`
    - Create: POST `/api/{resource}/{orgId}`
    - Update: PUT `/api/{resource}/{entityId}`
    - Launch: POST `/api/subscriptions/launch/{orgId}`
    - Contacts list: POST `/api/contacts/{orgId}` (uses POST with body)
  - Removed "Demo Mode" indicator badge
  - Updated sidebar navigation to match MindfulText's structure (Content/Communications/Insights sections)
  - Added Launch page with contact/journey selection and launch trigger
  - Removed Organizations and Subscriptions pages (not in MindfulText's navigation)
  - Fixed all pages to call API directly without org-dependency chain
  - Org ID `00000022` hardcoded as zero-padded 8-digit string
  - Updated Analytics page to use MindfulText data model

✓ March 19, 2026 - Fixed API data fetching through server proxy
  - All dashboard pages now route API calls through the Express proxy to avoid CORS errors
  - Fixed all pages using MindfulTextAPI class as static calls; now use apiService singleton instance
  - Added missing API methods: getTeamMembers, getIntegrations, getSubscriptions
  - makeAuthenticatedRequest now unwraps MindfulText API `{ data: ..., errors: [] }` response format
  - Added safeRequest wrapper and ensureArray helper for graceful error handling
  - Login confirmed working with form-urlencoded format via proxy

✓ July 21, 2025 - Enhanced MindfulText API connection and debugging
  - Updated API authentication to use Bearer token format (API key as access token)
  - Configured secure DNS connection to org.mindfultext.com with valid SSL
  - Built comprehensive API connection testing and debugging system
  - Verified DNS resolution, SSL certificates, and endpoint accessibility
  - Identified authentication method requirement: Bearer token instead of API key headers
  - Created detailed error handling with troubleshooting guidance
  - Ready for API key verification with MindfulText support

✓ December 19, 2024 - Completed comprehensive MindfulText frontend application
  - Built all major feature pages with full CRUD functionality
  - Implemented JWT authentication system with protected routes
  - Added sample data across all entities for realistic demonstration
  - Created responsive sidebar navigation and modern UI components
  - Integrated backend API endpoints for all MindfulText features
  - Added loading states, error handling, and user feedback throughout
  - Deployed application running successfully on port 5000

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **State Management**: TanStack Query (React Query) for server state
- **Build Tool**: Vite for development and building
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for REST API
- **Authentication**: Server-side MindfulText session-cookie proxy (no JWT). The
  browser sends an `X-Session-ID` UUID; the server keeps the real MindfulText
  cookies per session in `.session-cookies.json` and can auto-login from Settings
  or `MINDFULTEXT_EMAIL`/`MINDFULTEXT_PASSWORD`. See `server/session.ts`,
  `server/orgSettings.ts`, and `server/proxy.ts`.
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless database
- **Schema**: Shared TypeScript schemas between client and server

### Database Design
- **ORM**: Drizzle with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` for type sharing
- **Tables**: Local staging/automation/analytics tables (content drafts, draft messages, inbound messages, agent rules/memory, reshape rules, pending changes, personal journeys, analytics snapshots, attribution events). Contacts/journeys/modules/subscriptions live upstream in MindfulText and are not mirrored as local tables.
- **Migrations**: Generated in `./migrations` directory

## Key Components

### Authentication System
- Session-cookie proxy: the browser holds only an `X-Session-ID` UUID in
  `localStorage`; the Express server stores the upstream MindfulText cookies and
  attaches them when forwarding `/api/proxy/mindfultext/*` requests.
- Auto-login keeps a server-side `auto-session` warm from saved credentials so
  the console survives restarts without a manual sign-in.
- Agent-safe mode (`AGENT_SAFE_MODE`, default on) blocks programmatic sends and
  upstream module/journey edits unless attributed to the operator with a
  one-time confirm token; human dashboard flows are exempt.

### Core Features
1. **Organizations Management**: Create and manage multiple organizations
2. **Contact Management**: Full CRUD operations for contacts with organization association
3. **Journey Builder**: Create customer journeys with modules and analytics
4. **Module System**: Content modules for journey building
5. **Message Center**: Send and track messages
6. **Subscription Management**: Handle customer subscriptions
7. **Integrations**: Connect with third-party services
8. **Actions**: Automated triggers and actions
9. **Team Management**: User roles and permissions
10. **Analytics Dashboard**: Performance metrics and insights

### UI Components
- Consistent design system using shadcn/ui
- Responsive layout with sidebar navigation
- Loading states and error handling
- Toast notifications for user feedback
- Modal dialogs for forms
- Professional gradient color scheme

## Data Flow

1. **Authentication Flow**: Browser `X-Session-ID` → server-side MindfulText cookie store → upstream proxy with cookies attached (auto-login refills the store when empty)
2. **Data Fetching**: React Query manages server state with automatic caching and invalidation
3. **Form Submission**: React Hook Form → API request → Query invalidation → UI update
4. **Navigation**: Wouter handles routing with protected route wrappers

## External Dependencies

### Frontend Dependencies
- React ecosystem (React, React DOM)
- TanStack Query for server state
- Wouter for routing
- Radix UI components for accessibility
- Tailwind CSS for styling
- Lucide React for icons
- Date-fns for date manipulation

### Backend Dependencies
- Express.js for API server
- Drizzle ORM for database operations
- Neon serverless database client
- MindfulText session cookies persisted to `.session-cookies.json` (no DB-backed session store)

### Development Tools
- TypeScript for type safety
- Vite for development and building
- ESBuild for server bundling
- Drizzle Kit for database migrations
- PostCSS for CSS processing

## Deployment Strategy

### Development
- Vite dev server for frontend with HMR
- tsx for running TypeScript server in development
- Concurrent development of client and server

### Production Build
- Vite builds frontend to `dist/public`
- ESBuild bundles server to `dist/index.js`
- Single deployment artifact with static files served by Express

### Environment Configuration
- Database URL required via `DATABASE_URL` environment variable
- Optional MindfulText auto-login via `MINDFULTEXT_EMAIL` / `MINDFULTEXT_PASSWORD`
- `AGENT_SAFE_MODE` (default on) and `MT_TIMEOUT_MS` (upstream request timeout) tunables
- Node environment detection for development features

### Database
- Drizzle migrations for schema changes
- PostgreSQL database (Neon serverless recommended)
- Connection pooling and error handling built-in