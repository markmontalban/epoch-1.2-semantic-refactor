import {
  pgTable,
  text,
  serial,
  integer,
  boolean,
  timestamp,
  jsonb,
  real,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ---------------------------------------------------------------------------
// Content drafts — staged module content before pushing to MindfulText
// ---------------------------------------------------------------------------

export const contentDrafts = pgTable(
  "content_drafts",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    title: text("title").notNull(),
    moduleType: text("module_type").default("sms"),
    /** The full content plan from the planning AI step */
    contentPlan: jsonb("content_plan"),
    /** Array of generated text items (draft SMS bodies, etc.) */
    generatedTexts: jsonb("generated_texts"),
    /** "planning" | "generating" | "draft" | "review" | "approved" | "pushed" */
    status: text("status").notNull().default("draft"),
    /** ID of the module in MindfulText once pushed (null while still local) */
    mindfulTextModuleId: text("mindfultext_module_id"),
    /** Optional MindfulText contact tag this draft is targeted at. When set,
     * the matching audience brief is injected into AI prompts, and the tag is
     * sent on the pushed module so only those contacts receive it. */
    audienceTag: text("audience_tag"),
    createdBy: text("created_by"),
    metadata: jsonb("metadata"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [index("idx_content_drafts_org").on(t.organizationId)],
);

// ---------------------------------------------------------------------------
// Draft messages — auto-generated reply drafts when inbound messages arrive
// ---------------------------------------------------------------------------

export const draftMessages = pgTable(
  "draft_messages",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    contactId: text("contact_id"),
    contactPhone: text("contact_phone"),
    /** The inbound message this draft is responding to */
    inboundMessageId: integer("inbound_message_id"),
    draftContent: text("draft_content").notNull(),
    /** "generated" | "edited" | "approved" | "sent" | "discarded" */
    status: text("status").notNull().default("generated"),
    aiModel: text("ai_model"),
    metadata: jsonb("metadata"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [index("idx_draft_messages_org").on(t.organizationId)],
);

// ---------------------------------------------------------------------------
// Inbound message tracker — log every received text
// ---------------------------------------------------------------------------

export const inboundMessages = pgTable(
  "inbound_messages",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    contactId: text("contact_id"),
    contactPhone: text("contact_phone"),
    content: text("content"),
    receivedAt: timestamp("received_at").defaultNow(),
    /** Whether a draft reply was auto-generated */
    draftGenerated: boolean("draft_generated").default(false),
    /** Module that prompted this reply, attributed at write-time. */
    moduleId: text("module_id"),
    /** "prior_send" | "none" | "manual" — how we picked the moduleId. */
    attributionSource: text("attribution_source"),
    metadata: jsonb("metadata"),
  },
  (t) => [index("idx_inbound_messages_org").on(t.organizationId)],
);

// ---------------------------------------------------------------------------
// Agent memory — persistent context for the AI agent (like mindfultext.md)
// ---------------------------------------------------------------------------

export const agentMemory = pgTable(
  "agent_memory",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    /** Optional contact id — when set, this memory row belongs to one contact. */
    contactId: text("contact_id"),
    /** "rule" | "fact" | "preference" | "conversation_summary" */
    memoryType: text("memory_type").notNull().default("fact"),
    key: text("key").notNull(),
    value: text("value").notNull(),
    /** Short rolling AI-generated summary of recent activity for this contact. */
    summary: text("summary"),
    /** Higher priority memories are injected first into the system prompt */
    priority: integer("priority").default(0),
    isActive: boolean("is_active").default(true),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [
    index("idx_agent_memory_org").on(t.organizationId),
    index("idx_agent_memory_contact").on(t.contactId),
  ],
);

// ---------------------------------------------------------------------------
// Contact profiles — local mirror of select MindfulText contact attrs we need
// to manage independently (memory opt-in toggle).
// ---------------------------------------------------------------------------

export const contactProfiles = pgTable(
  "contact_profiles",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    contactId: text("contact_id").notNull(),
    /** Default true. When false, no memory rows are written for this contact. */
    memoryEnabled: boolean("memory_enabled").notNull().default(true),
    /** MindfulText custom-field id for the memory mirror (cached per contact). */
    memoryFieldId: text("memory_field_id"),
    /** Founder-written note shown only on THIS contact's subscriber page. */
    pageNote: text("page_note"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [
    index("idx_contact_profiles_org").on(t.organizationId),
    index("idx_contact_profiles_contact").on(t.contactId),
  ],
);

// ---------------------------------------------------------------------------
// Personal journeys — every contact has one ordered queue of module ids.
// ---------------------------------------------------------------------------

export const personalJourneys = pgTable(
  "personal_journeys",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    contactId: text("contact_id").notNull(),
    /** Ordered list of MindfulText module ids. */
    moduleIds: jsonb("module_ids").$type<string[]>().notNull().default([]),
    /** Index into moduleIds of the next module to send. */
    currentIndex: integer("current_index").notNull().default(0),
    paused: boolean("paused").notNull().default(false),
    /** MindfulText subscription id this personal journey is enrolled in. */
    subscriptionId: text("subscription_id"),
    lastAdvancedAt: timestamp("last_advanced_at"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [
    index("idx_personal_journeys_org").on(t.organizationId),
    index("idx_personal_journeys_contact").on(t.contactId),
  ],
);

export const personalJourneyEvents = pgTable(
  "personal_journey_events",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    contactId: text("contact_id").notNull(),
    /** "sent" | "inserted" | "skipped" | "reordered" | "paused" | "resumed" | "advanced" */
    eventType: text("event_type").notNull(),
    moduleId: text("module_id"),
    ruleId: integer("rule_id"),
    /** "auto" | "review" | "manual" */
    source: text("source").notNull().default("manual"),
    inboundMessageId: integer("inbound_message_id"),
    reason: text("reason"),
    metadata: jsonb("metadata"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (t) => [
    index("idx_pj_events_org").on(t.organizationId),
    index("idx_pj_events_contact").on(t.contactId),
  ],
);

// ---------------------------------------------------------------------------
// Reshape rules — org-level rules that mutate a contact's personal journey
// when an inbound message arrives.
// ---------------------------------------------------------------------------

export const reshapeRules = pgTable(
  "reshape_rules",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    name: text("name").notNull(),
    /** "keyword" | "intent" | "any_reply" */
    triggerType: text("trigger_type").notNull(),
    /** keyword string, intent label, or "" for any_reply */
    triggerValue: text("trigger_value").default(""),
    /** "insert" | "skip" | "reorder" | "pause" | "resume" | "ai_decide" */
    actionType: text("action_type").notNull(),
    /** Action-specific params: { moduleId } for insert, { topic } for reorder, etc. */
    actionParams: jsonb("action_params").$type<Record<string, unknown>>(),
    /** "auto" | "review" — auto applies immediately; review goes to pending queue. */
    approvalMode: text("approval_mode").notNull().default("review"),
    enabled: boolean("enabled").notNull().default(true),
    /** Lower number = evaluated first. */
    priority: integer("priority").notNull().default(100),
    /** When true, evaluation continues to the next matching rule. */
    continueAfter: boolean("continue_after").notNull().default(false),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [index("idx_reshape_rules_org").on(t.organizationId)],
);

// ---------------------------------------------------------------------------
// Pending changes — review queue entries waiting for human approval.
// ---------------------------------------------------------------------------

export const pendingChanges = pgTable(
  "pending_changes",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    contactId: text("contact_id").notNull(),
    inboundMessageId: integer("inbound_message_id"),
    ruleId: integer("rule_id"),
    /** Snapshot of the queue before any change. */
    currentSequence: jsonb("current_sequence").$type<string[]>().notNull(),
    /** Proposed queue (or proposed ops) the reviewer can approve / edit. */
    proposedSequence: jsonb("proposed_sequence").$type<string[]>().notNull(),
    /** Action ops list: [{ op: "insert", moduleId, at }, …] */
    proposedOps: jsonb("proposed_ops"),
    aiReason: text("ai_reason"),
    /**
     * When true, the queue ops were already applied automatically and this row
     * only gates the outbound send: approving it launches the next message.
     * Used by agent-safe mode so auto-reshape never sends without approval.
     */
    sendRequired: boolean("send_required").notNull().default(false),
    /** "pending" | "approved" | "edited" | "rejected" */
    status: text("status").notNull().default("pending"),
    decidedBy: text("decided_by"),
    decidedAt: timestamp("decided_at"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (t) => [
    index("idx_pending_changes_org").on(t.organizationId),
    index("idx_pending_changes_status").on(t.status),
  ],
);

// ---------------------------------------------------------------------------
// Personal journey templates — starting queue for new contacts (default + per-tag).
// ---------------------------------------------------------------------------

export const personalJourneyTemplates = pgTable(
  "personal_journey_templates",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    /** Tag name; null/empty means the org-wide default template. */
    tag: text("tag"),
    moduleIds: jsonb("module_ids").$type<string[]>().notNull().default([]),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [index("idx_pj_templates_org").on(t.organizationId)],
);

// ---------------------------------------------------------------------------
// Agent rules — organization-specific rules that extend mindfultext.md
// ---------------------------------------------------------------------------

export const agentRules = pgTable(
  "agent_rules",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    /** Rule name for quick reference */
    name: text("name").notNull(),
    /** The actual rule content (markdown) */
    content: text("content").notNull(),
    /** "global" | "content_generation" | "reply_drafting" | "program_creation" */
    scope: text("scope").notNull().default("global"),
    isActive: boolean("is_active").default(true),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [index("idx_agent_rules_org").on(t.organizationId)],
);

// ---------------------------------------------------------------------------
// Token usage — track AI API costs per request
// ---------------------------------------------------------------------------

export const tokenUsage = pgTable(
  "token_usage",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    /** "content_planning" | "content_generation" | "reply_drafting" | "program_creation" */
    taskType: text("task_type").notNull(),
    model: text("model").notNull(),
    promptTokens: integer("prompt_tokens").notNull().default(0),
    completionTokens: integer("completion_tokens").notNull().default(0),
    totalTokens: integer("total_tokens").notNull().default(0),
    /** Estimated cost in USD */
    estimatedCostUsd: real("estimated_cost_usd").default(0),
    /** Reference to the draft or message that triggered this usage */
    referenceId: integer("reference_id"),
    referenceType: text("reference_type"),
    metadata: jsonb("metadata"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (t) => [index("idx_token_usage_org").on(t.organizationId)],
);

// ---------------------------------------------------------------------------
// Content programs — pre-generated text programs for subscribers
// ---------------------------------------------------------------------------

export const contentPrograms = pgTable(
  "content_programs",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    name: text("name").notNull(),
    description: text("description"),
    /** The subscriber's needs/goals that this program addresses */
    subscriberNeeds: jsonb("subscriber_needs"),
    /** Generated program structure (modules, schedule, texts) */
    programContent: jsonb("program_content"),
    /** "generating" | "draft" | "review" | "active" | "archived" */
    status: text("status").notNull().default("draft"),
    /** "free" | "paid" | "coupon" */
    accessType: text("access_type").default("free"),
    couponCode: text("coupon_code"),
    createdBy: text("created_by"),
    metadata: jsonb("metadata"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [index("idx_content_programs_org").on(t.organizationId)],
);

// ---------------------------------------------------------------------------
// Entity snapshots — point-in-time backups of MindfulText records before edits
// Lets us undo a bad save by re-PUTting the previous state.
// ---------------------------------------------------------------------------

export const entitySnapshots = pgTable(
  "entity_snapshots",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    /** "module" | "contact" | "action" | "journey" */
    entityType: text("entity_type").notNull(),
    /** MindfulText record ID, e.g. "00000550" */
    entityId: text("entity_id").notNull(),
    /** Cached display name for the snapshot list UI */
    entityName: text("entity_name"),
    /** Full record body as returned by MindfulText, just before the edit */
    snapshot: jsonb("snapshot").notNull(),
    /** Why we took it: "before_bulk_edit" | "before_single_edit" | "manual" | "restore_point" */
    reason: text("reason").notNull().default("before_edit"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (t) => [
    index("idx_snapshots_org").on(t.organizationId),
    index("idx_snapshots_entity").on(t.entityType, t.entityId),
  ],
);

// ---------------------------------------------------------------------------
// Audience briefs — markdown guidance attached to a contact tag
// ---------------------------------------------------------------------------

export const audienceBriefs = pgTable(
  "audience_briefs",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    /** The MindfulText contact tag this brief targets. Stored as-is (case-sensitive). */
    tag: text("tag").notNull(),
    /** Markdown body the AI receives when generating for this audience. */
    brief: text("brief").notNull().default(""),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [index("idx_audience_briefs_org_tag").on(t.organizationId, t.tag)],
);

// ---------------------------------------------------------------------------
// Segments — saved multi-tag cohorts (include/exclude rules over contact tags)
// ---------------------------------------------------------------------------

export const segments = pgTable(
  "segments",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    name: text("name").notNull(),
    includeTags: jsonb("include_tags").$type<string[]>().notNull().default([]),
    excludeTags: jsonb("exclude_tags").$type<string[]>().notNull().default([]),
    /** "AND" = contact must have all includeTags; "OR" = at least one. */
    matchMode: text("match_mode").notNull().default("OR"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [index("idx_segments_org").on(t.organizationId)],
);

// ---------------------------------------------------------------------------
// Analytics snapshots — daily capture of MindfulText's real reporting totals.
// MindfulText only exposes rolling "last N days" / all-time numbers, so we
// snapshot them once a day to build a true calendar time-series for trends.
// ---------------------------------------------------------------------------

export const analyticsSnapshots = pgTable(
  "analytics_snapshots",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    /** Calendar date this row represents, as YYYY-MM-DD (server/UTC day). */
    snapshotDate: text("snapshot_date").notNull(),
    /** Per-day deltas (reporting rangeInDays=1 at capture time). */
    newContacts: integer("new_contacts").notNull().default(0),
    newLaunches: integer("new_launches").notNull().default(0),
    messagesSent: integer("messages_sent").notNull().default(0),
    messagesReceived: integer("messages_received").notNull().default(0),
    /** Cumulative all-time totals captured alongside the daily delta. */
    totalContacts: integer("total_contacts"),
    totalLaunches: integer("total_launches"),
    totalSent: integer("total_sent"),
    totalReceived: integer("total_received"),
    capturedAt: timestamp("captured_at").defaultNow(),
  },
  (t) => [
    index("idx_analytics_snapshots_org_date").on(t.organizationId, t.snapshotDate),
  ],
);

// ---------------------------------------------------------------------------
// Message events — granular per-text send/reply log so we can answer
// "who replied to which text, in which module/journey" over time. Widens the
// coverage of the older personalJourneyEvents/inboundMessages tables.
// ---------------------------------------------------------------------------

export const messageEvents = pgTable(
  "message_events",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    /** "send" | "reply" */
    direction: text("direction").notNull(),
    contactId: text("contact_id"),
    contactPhone: text("contact_phone"),
    moduleId: text("module_id"),
    journeyId: text("journey_id"),
    /** Index of the specific text within the module that was sent. */
    textIndex: integer("text_index"),
    /** For replies: the text index this reply is responding to, when known. */
    inReplyToTextIndex: integer("in_reply_to_text_index"),
    content: text("content"),
    /** "webhook" | "backfill" | "manual" — provenance of this row. */
    source: text("source").notNull().default("webhook"),
    occurredAt: timestamp("occurred_at").defaultNow(),
    metadata: jsonb("metadata"),
  },
  (t) => [
    index("idx_message_events_org").on(t.organizationId),
    index("idx_message_events_contact").on(t.contactId),
    index("idx_message_events_module").on(t.moduleId),
  ],
);

// ---------------------------------------------------------------------------
// Attribution events — UTM + first-party cookie capture for revenue/source
// attribution. Foundation for tying visits -> contacts -> revenue.
// ---------------------------------------------------------------------------

export const attributionEvents = pgTable(
  "attribution_events",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id"),
    /** Stable visitor id from a first-party cookie / localStorage. */
    visitorId: text("visitor_id"),
    /** MindfulText contact id, when a visit can be tied to a contact. */
    contactId: text("contact_id"),
    utmSource: text("utm_source"),
    utmMedium: text("utm_medium"),
    utmCampaign: text("utm_campaign"),
    utmTerm: text("utm_term"),
    utmContent: text("utm_content"),
    referrer: text("referrer"),
    landingPath: text("landing_path"),
    userAgent: text("user_agent"),
    metadata: jsonb("metadata"),
    occurredAt: timestamp("occurred_at").defaultNow(),
  },
  (t) => [
    index("idx_attribution_events_org").on(t.organizationId),
    index("idx_attribution_events_visitor").on(t.visitorId),
    index("idx_attribution_events_contact").on(t.contactId),
  ],
);

// ---------------------------------------------------------------------------
// Subscriber profile pages — tokenized public links per contact, a published
// content library, and a page-view event log. Powers the read-only /p/:token
// subscriber experience without any login or outbound texts.
// ---------------------------------------------------------------------------

export const subscriberPageTokens = pgTable(
  "subscriber_page_tokens",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    contactId: text("contact_id").notNull(),
    /** Unguessable URL token (the only credential for the public page). */
    token: text("token").notNull().unique(),
    /** Revoked links stay in the table but stop resolving. */
    active: boolean("active").notNull().default(true),
    lastVisitAt: timestamp("last_visit_at"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (t) => [
    index("idx_subscriber_page_tokens_org").on(t.organizationId),
    index("idx_subscriber_page_tokens_contact").on(t.contactId),
  ],
);

export const publishedContent = pgTable(
  "published_content",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    title: text("title").notNull(),
    /** The web-visible copy shown in the binge feed. */
    body: text("body").notNull(),
    /** Topic/tag used to group library items and match a contact's interests. */
    topic: text("topic"),
    /** "draft" | "module" | "manual" — where this library item came from. */
    sourceType: text("source_type").notNull().default("draft"),
    /** Originating content_drafts id or MindfulText module id, when applicable. */
    sourceId: text("source_id"),
    /** "text" | "meditation" — meditation items are external links. */
    contentType: text("content_type").notNull().default("text"),
    /** Destination URL for link items (e.g. a WordPress meditation page). */
    url: text("url"),
    /** Meditation theme, e.g. "sleep", "stress", "focus". */
    theme: text("theme"),
    /** Complexity/level, e.g. "beginner", "intermediate", "advanced". */
    complexity: text("complexity"),
    /** 1-based text/day index within the source module the link came from. */
    sourceDay: integer("source_day"),
    published: boolean("published").notNull().default(true),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [
    index("idx_published_content_org").on(t.organizationId),
    index("idx_published_content_topic").on(t.topic),
  ],
);

export const pageEvents = pgTable(
  "page_events",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id"),
    contactId: text("contact_id"),
    /** The page token the visit came through. */
    token: text("token"),
    /** "view" | "content_open" | ... */
    eventType: text("event_type").notNull().default("view"),
    path: text("path"),
    userAgent: text("user_agent"),
    occurredAt: timestamp("occurred_at").defaultNow(),
  },
  (t) => [
    index("idx_page_events_org").on(t.organizationId),
    index("idx_page_events_contact").on(t.contactId),
    index("idx_page_events_token").on(t.token),
  ],
);

// ---------------------------------------------------------------------------
// Subscriber page settings — one row per org controlling the look and copy of
// the public /p/:token pages (brand, accent, section toggles + labels).
// ---------------------------------------------------------------------------

export const pageSettings = pgTable(
  "page_settings",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull().unique(),
    /** Sender/brand name shown at the top and in the footer. */
    brandName: text("brand_name").notNull().default("MindfulText"),
    /** Sub-line under the greeting. */
    tagline: text("tagline").notNull().default("Your space to revisit and explore."),
    /** Accent color as a hex string (e.g. "#6366f1"). */
    accentColor: text("accent_color").notNull().default("#6366f1"),
    /** Footer credit line. */
    footerText: text("footer_text").notNull().default("MindfulText"),
    showTopics: boolean("show_topics").notNull().default(true),
    topicsLabel: text("topics_label").notNull().default("Your topics"),
    showReceived: boolean("show_received").notNull().default(true),
    receivedLabel: text("received_label").notNull().default("Messages you’ve received"),
    showLibrary: boolean("show_library").notNull().default(true),
    libraryLabel: text("library_label").notNull().default("More for you"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [index("idx_page_settings_org").on(t.organizationId)],
);

// ---------------------------------------------------------------------------
// Harvested links — URLs pulled out of MindfulText module texts, staged for
// founder review before being published into the subscriber library.
// ---------------------------------------------------------------------------

export const harvestedLinks = pgTable(
  "harvested_links",
  {
    id: serial("id").primaryKey(),
    organizationId: text("organization_id").notNull(),
    /** Normalized URL — unique per org so re-running the import skips it. */
    url: text("url").notNull(),
    moduleId: text("module_id"),
    moduleName: text("module_name"),
    /** 1-based index of the text within the module ("Day N"). */
    dayIndex: integer("day_index"),
    /** Surrounding text snippet for review context. */
    context: text("context"),
    /** Heuristic guess: does this look like a meditation link? */
    likelyMeditation: boolean("likely_meditation").notNull().default(false),
    /** Pre-filled title guess for the review form. */
    suggestedTitle: text("suggested_title"),
    /** Pre-filled theme guess (e.g. "sleep") for the review form. */
    suggestedTheme: text("suggested_theme"),
    /** "staged" | "published" | "discarded" */
    status: text("status").notNull().default("staged"),
    /** The library row this link became when published. */
    publishedContentId: integer("published_content_id"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (t) => [
    uniqueIndex("uq_harvested_links_org_url").on(t.organizationId, t.url),
    index("idx_harvested_links_status").on(t.organizationId, t.status),
  ],
);

// ---------------------------------------------------------------------------
// Insert schemas
// ---------------------------------------------------------------------------

export const insertContentDraftSchema = createInsertSchema(contentDrafts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDraftMessageSchema = createInsertSchema(draftMessages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInboundMessageSchema = createInsertSchema(
  inboundMessages,
).omit({
  id: true,
  receivedAt: true,
});

export const insertAgentMemorySchema = createInsertSchema(agentMemory).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAgentRuleSchema = createInsertSchema(agentRules).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTokenUsageSchema = createInsertSchema(tokenUsage).omit({
  id: true,
  createdAt: true,
});

export const insertContentProgramSchema = createInsertSchema(
  contentPrograms,
).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEntitySnapshotSchema = createInsertSchema(
  entitySnapshots,
).omit({
  id: true,
  createdAt: true,
});

export const insertContactProfileSchema = createInsertSchema(contactProfiles).omit({
  id: true, createdAt: true, updatedAt: true,
});
export const insertPersonalJourneySchema = createInsertSchema(personalJourneys).omit({
  id: true, createdAt: true, updatedAt: true,
});
export const insertPersonalJourneyEventSchema = createInsertSchema(personalJourneyEvents).omit({
  id: true, createdAt: true,
});
export const insertReshapeRuleSchema = createInsertSchema(reshapeRules).omit({
  id: true, createdAt: true, updatedAt: true,
});
export const insertPendingChangeSchema = createInsertSchema(pendingChanges).omit({
  id: true, createdAt: true, decidedAt: true,
});
export const insertPersonalJourneyTemplateSchema = createInsertSchema(personalJourneyTemplates).omit({
  id: true, createdAt: true, updatedAt: true,
});
export const insertAudienceBriefSchema = createInsertSchema(audienceBriefs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSegmentSchema = createInsertSchema(segments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAnalyticsSnapshotSchema = createInsertSchema(analyticsSnapshots).omit({
  id: true,
  capturedAt: true,
});

// occurredAt is intentionally NOT omitted (it has a default, so it's optional)
// so backfill can preserve original timestamps from legacy tables.
export const insertMessageEventSchema = createInsertSchema(messageEvents).omit({
  id: true,
});

export const insertAttributionEventSchema = createInsertSchema(attributionEvents).omit({
  id: true,
  occurredAt: true,
});

export const insertSubscriberPageTokenSchema = createInsertSchema(subscriberPageTokens).omit({
  id: true,
  createdAt: true,
});

export const insertPublishedContentSchema = createInsertSchema(publishedContent).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPageEventSchema = createInsertSchema(pageEvents).omit({
  id: true,
  occurredAt: true,
});

export const insertPageSettingsSchema = createInsertSchema(pageSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertHarvestedLinkSchema = createInsertSchema(harvestedLinks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type ContentDraft = typeof contentDrafts.$inferSelect;
export type InsertContentDraft = z.infer<typeof insertContentDraftSchema>;
export type DraftMessage = typeof draftMessages.$inferSelect;
export type InsertDraftMessage = z.infer<typeof insertDraftMessageSchema>;
export type InboundMessage = typeof inboundMessages.$inferSelect;
export type InsertInboundMessage = z.infer<typeof insertInboundMessageSchema>;
export type AgentMemory = typeof agentMemory.$inferSelect;
export type InsertAgentMemory = z.infer<typeof insertAgentMemorySchema>;
export type AgentRule = typeof agentRules.$inferSelect;
export type InsertAgentRule = z.infer<typeof insertAgentRuleSchema>;
export type TokenUsage = typeof tokenUsage.$inferSelect;
export type InsertTokenUsage = z.infer<typeof insertTokenUsageSchema>;
export type ContentProgram = typeof contentPrograms.$inferSelect;
export type InsertContentProgram = z.infer<typeof insertContentProgramSchema>;
export type EntitySnapshot = typeof entitySnapshots.$inferSelect;
export type InsertEntitySnapshot = z.infer<typeof insertEntitySnapshotSchema>;
export type ContactProfile = typeof contactProfiles.$inferSelect;
export type InsertContactProfile = z.infer<typeof insertContactProfileSchema>;
export type PersonalJourney = typeof personalJourneys.$inferSelect;
export type InsertPersonalJourney = z.infer<typeof insertPersonalJourneySchema>;
export type PersonalJourneyEvent = typeof personalJourneyEvents.$inferSelect;
export type InsertPersonalJourneyEvent = z.infer<typeof insertPersonalJourneyEventSchema>;
export type ReshapeRule = typeof reshapeRules.$inferSelect;
export type InsertReshapeRule = z.infer<typeof insertReshapeRuleSchema>;
export type PendingChange = typeof pendingChanges.$inferSelect;
export type InsertPendingChange = z.infer<typeof insertPendingChangeSchema>;
export type PersonalJourneyTemplate = typeof personalJourneyTemplates.$inferSelect;
export type InsertPersonalJourneyTemplate = z.infer<typeof insertPersonalJourneyTemplateSchema>;

export type AudienceBrief = typeof audienceBriefs.$inferSelect;
export type InsertAudienceBrief = z.infer<typeof insertAudienceBriefSchema>;
export type Segment = typeof segments.$inferSelect;
export type InsertSegment = z.infer<typeof insertSegmentSchema>;

export type AnalyticsSnapshot = typeof analyticsSnapshots.$inferSelect;
export type InsertAnalyticsSnapshot = z.infer<typeof insertAnalyticsSnapshotSchema>;
export type MessageEvent = typeof messageEvents.$inferSelect;
export type InsertMessageEvent = z.infer<typeof insertMessageEventSchema>;
export type AttributionEvent = typeof attributionEvents.$inferSelect;
export type InsertAttributionEvent = z.infer<typeof insertAttributionEventSchema>;
export type SubscriberPageToken = typeof subscriberPageTokens.$inferSelect;
export type InsertSubscriberPageToken = z.infer<typeof insertSubscriberPageTokenSchema>;
export type PublishedContent = typeof publishedContent.$inferSelect;
export type InsertPublishedContent = z.infer<typeof insertPublishedContentSchema>;
export type PageEvent = typeof pageEvents.$inferSelect;
export type InsertPageEvent = z.infer<typeof insertPageEventSchema>;
export type PageSettings = typeof pageSettings.$inferSelect;
export type InsertPageSettings = z.infer<typeof insertPageSettingsSchema>;
export type HarvestedLink = typeof harvestedLinks.$inferSelect;
export type InsertHarvestedLink = z.infer<typeof insertHarvestedLinkSchema>;
