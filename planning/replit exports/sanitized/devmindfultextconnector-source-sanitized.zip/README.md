# MindfulText Admin Frontend (Custom)

This repository is a custom admin frontend for MindfulText.

The app's source of truth is the MindfulText backend at `https://dev.mindfultext.com`.
The local Node server exists to proxy browser requests to MindfulText, preserve session cookies, and run a **local staging database** with AI-powered content generation.

> See **[LEGACY_API.md](LEGACY_API.md)** for a reference on the upstream MindfulText API — ID formats, module/journey structure, why there is no upstream approval state, SMS vs MMS (`mediaURLs`), and the limits on tags and metadata.

## Architecture

### Data flow

```
Browser → Express server → proxy → dev.mindfultext.com  (live data)
                         → local PostgreSQL              (drafts, memory, tracking)
                         → OpenRouter → AI models        (content generation)
```

### Components

- `client/`: React + TypeScript + Vite + TanStack Query + wouter
- `server/`: Express server that provides:
  - Security headers + static serving in production
  - Proxy route: `/api/proxy/mindfultext/*` → `https://dev.mindfultext.com/*`
  - Local API: `/api/local/*` — drafts, AI, memory, rules, token tracking
- `server/ai/`: AI service layer using OpenRouter (`openrouter/auto` by default)
- `server/ai/rules.ts`: Rules engine that merges `mindfultext.md` + org-specific DB rules
- `shared/schema.ts`: Drizzle ORM schema for the local PostgreSQL database
- `mindfultext.md`: Base AI agent rules (like Cursor's rules system)

### Local database tables

| Table | Purpose |
|-------|---------|
| `content_drafts` | Module content staged before pushing to MindfulText |
| `draft_messages` | Auto-generated reply drafts for inbound messages |
| `inbound_messages` | Tracker for every received text message |
| `agent_memory` | Persistent context/facts about each organization |
| `agent_rules` | Organization-specific rules extending mindfultext.md |
| `token_usage` | Token in/out tracking with cost estimates |
| `content_programs` | Pre-generated text programs for subscribers |

## AI content pipeline

Two-step workflow; each step calls OpenRouter's **Auto Router** (`openrouter/auto`), which picks a model per request. You are billed at the **routed** model's rate; the API response and `token_usage` rows record the actual model slug.

1. **Planning**: Creates a content plan with research, module structure, and text outlines.
2. **Generation**: Writes the actual SMS texts following the plan.

### Rules system (mindfultext.md)

Inspired by Cursor's rules system. Three layers are merged into the AI system prompt:

1. **`mindfultext.md`** — base personality, constraints, and behavior (file on disk)
2. **Organization rules** — stored in the database, scoped by task type
3. **Agent memory** — facts and preferences accumulated over time

No external framework needed — just a markdown file + database entries injected into the system prompt. Edit `mindfultext.md` to change base behavior; use the rules API to add per-org overrides.

## API reference

### Content drafts
- `POST /api/local/drafts` — create a draft
- `GET /api/local/drafts/:orgId` — list drafts for an org
- `GET /api/local/drafts/detail/:id` — get single draft
- `PATCH /api/local/drafts/:id` — update a draft

### AI generation
- `POST /api/local/ai/plan` — plan content (Auto Router)
- `POST /api/local/ai/generate/:draftId` — generate texts from plan (Auto Router)
- `GET /api/local/ai/models` — routing config and reference pricing hints

### Inbound messages
- `POST /api/local/inbound` — log an inbound message + auto-generate draft reply
- `GET /api/local/inbound/:orgId` — list inbound messages

### Draft replies
- `GET /api/local/draft-messages/:orgId` — list draft replies
- `PATCH /api/local/draft-messages/:id` — update/approve a draft reply

### Agent memory
- `POST /api/local/memory` — upsert a memory entry
- `GET /api/local/memory/:orgId` — list active memories
- `DELETE /api/local/memory/:id` — remove a memory

### Agent rules
- `POST /api/local/rules` — create a rule
- `GET /api/local/rules/:orgId?scope=...` — list active rules
- `PATCH /api/local/rules/:id` — update a rule
- `DELETE /api/local/rules/:id` — remove a rule
- `POST /api/local/rules/reload-base` — reload mindfultext.md from disk

### Token usage
- `GET /api/local/tokens/:orgId` — usage summary with per-model breakdown

### Audience briefs
- `GET /api/local/audiences/:orgId` — list every contact tag joined with any saved brief
- `PUT /api/local/audiences/:orgId/:tag` — upsert the markdown brief for a tag (body: `{ "brief": "..." }`)
- `DELETE /api/local/audiences/:orgId/:tag` — clear the brief for a tag

When a draft has an `audienceTag` set, the matching brief is appended to the AI system prompt as an "Audience guidance" block, and the tag is included on the pushed module so MindfulText only delivers to contacts with that tag.

### Webhook intake (drafts)
- `POST /api/webhooks/drafts` — outside agents (e.g. Cursor) can drop drafts straight into the Drafts page.

Headers:
- `X-Webhook-Secret: $CONTENT_WEBHOOK_SECRET` (required — request rejected with 401 if absent or wrong)

Body fields (JSON):
- `audienceTag` (required) — MindfulText contact tag this draft targets
- `organizationId` (optional, default `00000022`)
- `title` (optional)
- Either `texts: ["body 1", "body 2", ...]` (skips AI; draft lands in `draft` status), **OR**
- `topic`, plus optional `goals`, `textCount`, `additionalContext` — runs the existing Plan + Generate pipeline

Response: `{ "draftId": 123, "status": "draft", "viewUrl": "/drafts" }`

Sample `curl`:
```bash
curl -X POST http://localhost:5000/api/webhooks/drafts \
  -H "Content-Type: application/json" \
  -H "X-Webhook-Secret: $CONTENT_WEBHOOK_SECRET" \
  -d '{
    "audienceTag": "vip",
    "title": "VIP morning ritual",
    "texts": [
      "Good morning! 30 seconds of breath work — in for 4, hold for 4, out for 6.",
      "Your second nudge: pick one tiny win for today and write it down."
    ]
  }'
```

### Content programs
- `POST /api/local/programs` — create a program
- `GET /api/local/programs/:orgId` — list programs
- `GET /api/local/programs/detail/:id` — get single program
- `PATCH /api/local/programs/:id` — update a program
- `DELETE /api/local/programs/:id` — delete a program

### Subscriber pages
A public, login-free profile page per subscriber, reached via an unguessable token.

Founder tooling (authed `/api/local`):
- `POST /api/local/subscriber-link/:contactId` — get-or-create a contact's link; returns `{ id, token, url, active }`
- `DELETE /api/local/subscriber-link/:id` — revoke a link
- `GET /api/local/library` — list published library items
- `POST /api/local/library` — publish an item (`{ title, body, topic?, sourceType?, sourceId? }`)
- `PATCH /api/local/library/:id` — toggle visibility (`{ published: boolean }`)
- `DELETE /api/local/library/:id` — remove a library item
- `GET /api/local/page-stats?days=30` — `{ totalViews, uniqueContacts }`

Public (no auth — token-scoped, read-only):
- `GET /api/public/profile/:token` — `{ firstName, topics, received, library }`
- `POST /api/public/profile/:token/view` — append-only page-view log
- SPA route `/p/:token` renders the mobile-first subscriber page.

### Attribution tracking
- `POST /api/track` — record a marketing/attribution event. Cross-origin enabled for the marketing site via a CORS allowlist (`TRACK_CORS_ORIGINS`, default `https://mindfultext.com,https://www.mindfultext.com`). Preflight `OPTIONS /api/track` is handled.

Body fields (all optional, strings truncated to 500 chars):
- `visitorId`, `contactId`
- `utmSource` / `utm_source`, `utmMedium` / `utm_medium`, `utmCampaign` / `utm_campaign`, `utmTerm` / `utm_term`, `utmContent` / `utm_content`
- `referrer`, `landingPath` / `path`
- `metadata` (object)

The organization is taken from the server's configured org; `userAgent` is read from the request header. Response: `{ "ok": true }`.

Sample cross-origin `fetch` from the marketing site:
```js
fetch("https://<console-host>/api/track", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    visitorId: "abc123",
    utmSource: "instagram",
    utmCampaign: "spring-launch",
    landingPath: "/trial",
  }),
});
```

### Health
- `GET /api/local/health` — system status

## Environment variables

### Required

| Variable | Purpose |
|----------|---------|
| `DATABASE_URL` | PostgreSQL connection string |
| `OPENROUTER_API_KEY` | API key for OpenRouter (AI model access) |

### Optional

| Variable | Default | Purpose |
|----------|---------|---------|
| `OPENROUTER_MODEL` | `openrouter/auto` | Set to a specific model slug to bypass Auto Router (e.g. debugging) |
| `OPENROUTER_BASE_URL` | `https://openrouter.ai/api/v1` | AI API base URL |
| `CONTENT_WEBHOOK_SECRET` | (none) | Shared secret for `POST /api/webhooks/drafts`. If unset, the webhook returns 503. |
| `AGENT_SAFE_MODE` | `on` | When on, blocks programmatic sends and upstream module/journey edits unless attributed to the operator with a one-time confirm token. Human dashboard flows are exempt. Set `false` to restore legacy behavior. |
| `PROXY_STRICT_AUTH` | `false` | When `true`, every MindfulText proxy request (not just mutations) requires an interactive operator session or a one-time confirm token. Adds friction — enable and test session edge cases before relying on it. |
| `STRICT_LOCAL_AUTH` | `false` | When `true`, the `/api/local` auth gate drops the shared auto-session fallback so each request must resolve to its own bound session. Adds friction — enable and test before relying on it. |
| `MT_TIMEOUT_MS` | `15000` | Timeout for server-side MindfulText API calls (aborts hung sockets). |
| `MINDFULTEXT_EMAIL` / `MINDFULTEXT_PASSWORD` | | Server-side auto-login credentials for the MindfulText session. |
| `TRACK_CORS_ORIGINS` | `https://mindfultext.com,https://www.mindfultext.com` | Comma-separated origin allowlist for cross-origin `POST /api/track`. |
| `VITE_API_BASE_URL` | `https://dev.mindfultext.com` | MindfulText API base |
| `VITE_MINDFULTEXT_EMAIL` | | Auto-fill login email |
| `VITE_MINDFULTEXT_PASSWORD` | | Auto-fill login password |
| `PORT` | `5000` | Server port |

## Setup

```bash
# Install dependencies
npm install

# Set up environment
export DATABASE_URL="postgresql://..."
export OPENROUTER_API_KEY="sk-or-..."

# Push database schema
npm run db:push

# Run the app
npm run dev
```

## Development

```bash
npm run dev            # Full app (server + frontend)
npm run dev:frontend   # Frontend only
npm run check          # Type-check
npm run build          # Production build
npm run db:push        # Push schema changes to database
```

## Cost notes

With Auto Router, cost depends on **which model was selected** for each call. There is no extra routing fee. See [OpenRouter Auto Router](https://openrouter.ai/docs/guides/routing/routers/auto-router) and check `GET /api/local/tokens/:orgId` for billed models and estimates stored per request.

## Known cleanup status

Tracked in `BACKEND_ALIGNMENT_TODO.md`.
