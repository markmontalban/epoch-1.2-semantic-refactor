# MindfulText content snapshot export

Run the read-only local snapshot command with:

```bash
npm run export:mindfultext-content
```

The command reads only `GET /api/modules/byOrganization/{orgId}` and
`GET /api/modules/{moduleId}` through the shared MindfulText client. It uses the
configured organization and the authenticated auto-session already stored by the
application. Start the application once (or sign in through Settings) before
running it so that session exists.

It writes these local-only, gitignored files:

```text
exports/mindfultext-content-snapshot-aug-6-2026/module-texts.jsonl
exports/mindfultext-content-snapshot-aug-6-2026/manifest.json
```

The JSONL file contains message content and may include personalization tokens,
media URLs, and action metadata. Treat both files as sensitive local artifacts:
do not commit, upload, or share them. The command reports aggregate counts and
any difference from the reference inventory without printing corpus content.