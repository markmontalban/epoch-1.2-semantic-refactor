import Stripe from "stripe";

// ---------------------------------------------------------------------------
// Stripe client resolver
// ---------------------------------------------------------------------------
// Revenue is read-only here, so we just need an authenticated Stripe client.
// We resolve credentials in priority order:
//   1. STRIPE_SECRET_KEY env var (simple/self-hosted setups)
//   2. The Replit "stripe" connector (fetched from the connection API)
// If neither is available the founder dashboard shows a "connect Stripe"
// empty state instead of failing.

let cached: { client: Stripe; expiresAt: number } | null = null;

function replitToken(): string | null {
  if (process.env.REPL_IDENTITY) return `repl ${process.env.REPL_IDENTITY}`;
  if (process.env.WEB_REPL_RENEWAL) return `depl ${process.env.WEB_REPL_RENEWAL}`;
  return null;
}

async function resolveSecretFromConnector(): Promise<string | null> {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const token = replitToken();
  if (!hostname || !token) return null;
  try {
    const r = await fetch(
      `https://${hostname}/api/v2/connection?include_secrets=true&connector_names=stripe`,
      { headers: { Accept: "application/json", X_REPLIT_TOKEN: token } },
    );
    if (!r.ok) return null;
    const j = (await r.json()) as {
      items?: Array<{ settings?: Record<string, unknown> }>;
    };
    const settings = j.items?.[0]?.settings ?? {};
    const key =
      (settings.secret_key as string | undefined) ??
      (settings.api_key as string | undefined) ??
      (settings.access_token as string | undefined);
    return typeof key === "string" && key ? key : null;
  } catch {
    return null;
  }
}

/**
 * Returns an authenticated Stripe client, or null when no credentials are
 * configured. Cached for a few minutes so we don't hit the connector API on
 * every request.
 */
export async function getStripeClient(): Promise<Stripe | null> {
  if (cached && cached.expiresAt > Date.now()) return cached.client;

  const secret =
    process.env.STRIPE_SECRET_KEY || (await resolveSecretFromConnector());
  if (!secret) return null;

  const client = new Stripe(secret);
  cached = { client, expiresAt: Date.now() + 5 * 60 * 1000 };
  return client;
}

export interface RevenueSummary {
  connected: true;
  currency: string;
  /** Monthly recurring revenue from active subscriptions, in major units. */
  mrr: number;
  activeSubscriptions: number;
  /** Paid invoice revenue within the window, in major units. */
  newRevenue: number;
  /** Subscriptions canceled within the window. */
  churnedSubscriptions: number;
}

export interface RevenueUnavailable {
  connected: false;
  reason: string;
}

/** Normalize a recurring price to a monthly amount in major units. */
function monthlyAmount(item: Stripe.SubscriptionItem): number {
  const price = item.price;
  const unit = (price.unit_amount ?? 0) / 100;
  const qty = item.quantity ?? 1;
  const interval = price.recurring?.interval;
  const count = price.recurring?.interval_count ?? 1;
  const perMonth =
    interval === "year"
      ? unit / (12 * count)
      : interval === "week"
        ? (unit * 52) / 12 / count
        : interval === "day"
          ? (unit * 365) / 12 / count
          : unit / count; // month (or one-off treated as monthly)
  return perMonth * qty;
}

/**
 * Compute a revenue summary over the trailing `rangeInDays` (use a large
 * number / 36500 for "all time"). Returns `{ connected: false }` when Stripe
 * is not configured.
 */
export async function getRevenueSummary(
  rangeInDays: number,
): Promise<RevenueSummary | RevenueUnavailable> {
  const stripe = await getStripeClient();
  if (!stripe) return { connected: false, reason: "stripe_not_connected" };

  const sinceSec =
    rangeInDays > 0
      ? Math.floor(Date.now() / 1000) - rangeInDays * 86_400
      : 0;

  let mrr = 0;
  let activeSubscriptions = 0;
  let currency = "usd";
  for await (const sub of stripe.subscriptions.list({ status: "active", limit: 100 })) {
    activeSubscriptions++;
    for (const item of sub.items.data) {
      mrr += monthlyAmount(item);
      if (item.price.currency) currency = item.price.currency;
    }
  }

  let newRevenue = 0;
  const invoiceParams: Stripe.InvoiceListParams = { status: "paid", limit: 100 };
  if (sinceSec > 0) invoiceParams.created = { gte: sinceSec };
  for await (const inv of stripe.invoices.list(invoiceParams)) {
    newRevenue += (inv.amount_paid ?? 0) / 100;
    if (inv.currency) currency = inv.currency;
  }

  let churnedSubscriptions = 0;
  const canceledParams: Stripe.SubscriptionListParams = {
    status: "canceled",
    limit: 100,
  };
  for await (const sub of stripe.subscriptions.list(canceledParams)) {
    const canceledAt = sub.canceled_at ?? sub.ended_at ?? 0;
    if (sinceSec === 0 || canceledAt >= sinceSec) churnedSubscriptions++;
  }

  return {
    connected: true,
    currency,
    mrr: Math.round(mrr * 100) / 100,
    activeSubscriptions,
    newRevenue: Math.round(newRevenue * 100) / 100,
    churnedSubscriptions,
  };
}
