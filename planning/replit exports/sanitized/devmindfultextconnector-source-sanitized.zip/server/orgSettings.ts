/**
 * Single-user org configuration + MindfulText auto-login.
 *
 * Persists the configured org id and (optional, encrypted) credentials to a
 * gitignored JSON file, and owns the server's auto-login against MindfulText.
 * `autoSessionUser` and `cachedOrgs` are process-wide state exposed via
 * getters/setters so other modules can read/update them across files.
 */
import fs from "fs";
import path from "path";
import { encryptSecret, decryptSecret, isEncrypted } from "./secrets";
import { AUTO_SESSION_ID } from "./session";
import { mtFetch } from "./mtClient";

const ORG_SETTINGS_FILE = path.join(process.cwd(), ".org-settings.json");

export type OrgSettings = {
  orgId: string;
  email?: string;
  password?: string;
  // Last dashboard view the client actually requested. Persisted so the
  // startup cache warm-up can seed the *exact* cache key real traffic uses
  // (the key includes tz + period); without these it would warm tz=UTC/month
  // and miss the usual non-UTC first request after a restart.
  lastTz?: string;
  lastPeriod?: string;
};

// Single-user configurable org id + (optional) MindfulText credentials.
// Persisted to a small JSON file so values survive restarts and are shared
// across tabs/sessions immediately. The file is gitignored; chmod 600 below
// keeps the password out of casual sight on shared dev machines, and the
// password itself is encrypted at rest via `server/secrets.ts` so reading the
// JSON alone no longer yields the cleartext.
export function loadOrgSettings(): OrgSettings {
  try {
    if (fs.existsSync(ORG_SETTINGS_FILE)) {
      const j = JSON.parse(fs.readFileSync(ORG_SETTINGS_FILE, "utf-8")) as {
        orgId?: unknown; email?: unknown; password?: unknown;
      };
      const orgId = (typeof j.orgId === "string" && j.orgId.trim()) ? j.orgId.trim() : "00000022";
      const email = typeof j.email === "string" && j.email.trim() ? j.email.trim() : undefined;
      let password: string | undefined;
      if (typeof j.password === "string" && j.password) {
        const decrypted = decryptSecret(j.password);
        // `null` => looks encrypted but the key changed/corrupted. Drop the
        // password so auto-login falls back to env vars and the UI surfaces a
        // "session expired" state, prompting the user to re-enter creds.
        password = decrypted ?? undefined;
      }
      const jj = j as { lastTz?: unknown; lastPeriod?: unknown };
      const lastTz = typeof jj.lastTz === "string" && jj.lastTz.trim() ? jj.lastTz.trim() : undefined;
      const lastPeriod =
        typeof jj.lastPeriod === "string" && jj.lastPeriod.trim() ? jj.lastPeriod.trim() : undefined;
      return { orgId, email, password, lastTz, lastPeriod };
    }
  } catch {
    /* fall through to default */
  }
  return { orgId: "00000022" };
}

export function saveOrgSettings(s: OrgSettings) {
  // Throws on failure so callers can fail-closed (return 5xx) and the user
  // doesn't get a misleading success toast when persistence is broken.
  const onDisk: {
    orgId: string; email?: string; password?: string; lastTz?: string; lastPeriod?: string;
  } = { orgId: s.orgId };
  if (s.email) onDisk.email = s.email;
  if (s.password) onDisk.password = encryptSecret(s.password);
  if (s.lastTz) onDisk.lastTz = s.lastTz;
  if (s.lastPeriod) onDisk.lastPeriod = s.lastPeriod;
  fs.writeFileSync(ORG_SETTINGS_FILE, JSON.stringify(onDisk, null, 2));
  try { fs.chmodSync(ORG_SETTINGS_FILE, 0o600); } catch { /* best-effort */ }
}

// One-shot migration: if the file on disk still contains a plaintext password
// (from before this change), re-encrypt it in place on startup so we don't
// leave cleartext sitting around longer than necessary.
function migrateOrgSettingsPasswordIfNeeded(): void {
  try {
    if (!fs.existsSync(ORG_SETTINGS_FILE)) return;
    const raw = JSON.parse(fs.readFileSync(ORG_SETTINGS_FILE, "utf-8")) as {
      password?: unknown;
    };
    if (typeof raw.password === "string" && raw.password && !isEncrypted(raw.password)) {
      const current = loadOrgSettings();
      if (current.password) {
        saveOrgSettings(current);
        console.log("[org-settings] migrated plaintext password to encrypted form");
      }
    }
  } catch (e) {
    console.warn("[org-settings] migration check failed:", e instanceof Error ? e.message : String(e));
  }
}
migrateOrgSettingsPasswordIfNeeded();

export function getConfiguredOrgId(): string {
  return loadOrgSettings().orgId;
}

let autoSessionUser: { email: string; orgId: string; sessionId: string } | null = null;
// Cached `byUser` org list from the most recent successful login or refresh.
// Powers the Settings page dropdown without an extra round-trip to MindfulText
// on every page render.
let cachedOrgs: { id: string; name: string }[] = [];

export function getAutoSessionUser(): { email: string; orgId: string; sessionId: string } | null {
  return autoSessionUser;
}
export function setAutoSessionUser(v: { email: string; orgId: string; sessionId: string } | null): void {
  autoSessionUser = v;
}
export function getCachedOrgs(): { id: string; name: string }[] {
  return cachedOrgs;
}
export function setCachedOrgs(v: { id: string; name: string }[]): void {
  cachedOrgs = v;
}

// Cached single-org lookups (id → name) so /api/local/settings can return the
// active org's friendly name without hammering MindfulText on every poll.
const orgNameCache: Record<string, string> = {};

export async function fetchOrgName(orgId: string, cookies: string): Promise<string | null> {
  if (orgNameCache[orgId]) return orgNameCache[orgId];
  try {
    const r = await mtFetch(`/api/organizations/${orgId}`, { cookies });
    if (!r.ok) return null;
    const j = (await r.json()) as { data?: { name?: string } };
    const name = j?.data?.name;
    if (typeof name === "string" && name) {
      orgNameCache[orgId] = name;
      return name;
    }
    return null;
  } catch {
    return null;
  }
}

// Result of probing /api/organizations/byUser:
//   { status: "ok", orgs }           — endpoint returned a list
//   { status: "unauthorized" }       — 401, cookies expired/invalid → re-login
//   { status: "forbidden" }          — 403, cookies are good but this account
//                                       isn't permitted to list orgs (locked-
//                                       down accounts). Caller should treat
//                                       the session as valid and let the user
//                                       enter the org id manually.
//   { status: "error" }              — anything else (network/5xx); transient.
export type OrgsProbe =
  | { status: "ok"; orgs: { id: string; name: string }[] }
  | { status: "unauthorized" }
  | { status: "forbidden" }
  | { status: "error" };

export async function probeOrgsByUser(cookies: string): Promise<OrgsProbe> {
  try {
    const r = await mtFetch("/api/organizations/byUser", { cookies });
    if (r.status === 401) return { status: "unauthorized" };
    if (r.status === 403) return { status: "forbidden" };
    if (!r.ok) return { status: "error" };
    const j = (await r.json()) as Record<string, unknown>;
    const raw = Array.isArray(j)
      ? (j as Record<string, unknown>[])
      : Array.isArray((j as { data?: unknown[] }).data)
        ? ((j as { data: Record<string, unknown>[] }).data)
        : [];
    const orgs = raw
      .filter((o) => o && (o.id != null))
      .map((o) => ({
        id: String(o.id).padStart(8, "0"),
        name: typeof o.name === "string" && o.name ? o.name : String(o.id),
      }));
    return { status: "ok", orgs };
  } catch {
    return { status: "error" };
  }
}

export async function performAutoLogin(
  sessionStore: Record<string, string>,
  saveSessionStore: (store: Record<string, string>) => void,
  override?: { email: string; password: string },
): Promise<{ ok: boolean; reason?: string; orgs?: { id: string; name: string }[]; orgsProbe?: string }> {
  const settings = loadOrgSettings();
  // Settings-stored credentials always win over env vars when present, so the
  // user's Settings-page sign-in survives across restarts.
  const email = override?.email || settings.email || process.env.MINDFULTEXT_EMAIL;
  const password = override?.password || settings.password || process.env.MINDFULTEXT_PASSWORD;

  if (!email || !password) {
    console.log("[auto-login] No credentials configured (Settings or MINDFULTEXT_EMAIL/PASSWORD) — skipping auto-login");
    return { ok: false, reason: "no_credentials" };
  }

  console.log(`[auto-login] Attempting auto-login for ${email}…`);

  try {
    const body = new URLSearchParams({ email, password }).toString();
    const response = await mtFetch("/api/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body,
      redirect: "manual",
    });

    if (!response.ok) {
      const text = await response.text().catch(() => "");
      console.error(`[auto-login] Login failed — HTTP ${response.status}: ${text.substring(0, 200)}`);
      // MindfulText returns 400 with "Login failed." for bad credentials,
      // not 401. Treat any 4xx from /api/login as invalid credentials so
      // the UI can show a clear "wrong email or password" message.
      const isAuthFailure = response.status >= 400 && response.status < 500;
      return { ok: false, reason: isAuthFailure ? "invalid_credentials" : "login_failed" };
    }

    // Capture cookies from the login response — success requires real session cookies.
    const setCookieHeaders = response.headers.getSetCookie?.() || [];
    if (setCookieHeaders.length === 0) {
      console.error("[auto-login] Login endpoint returned 200 but no Set-Cookie headers — cannot establish a session. Treating as failure.");
      return { ok: false, reason: "no_cookies" };
    }

    const cookieMap = new Map<string, string>();
    for (const raw of setCookieHeaders) {
      const nameValue = raw.split(";")[0].trim();
      const [name] = nameValue.split("=");
      if (name && nameValue) cookieMap.set(name, nameValue);
    }
    sessionStore[AUTO_SESSION_ID] = Array.from(cookieMap.values()).join("; ");
    saveSessionStore(sessionStore);
    console.log(`[auto-login] Stored ${setCookieHeaders.length} cookie(s) under session "${AUTO_SESSION_ID}"`);

    // Probe /api/organizations/byUser to (a) verify the session and
    // (b) populate the org dropdown. Note: some MindfulText accounts are
    // permitted to log in but NOT to call byUser (it returns 403). Those
    // sessions are still valid for per-org endpoints — we just can't
    // populate the dropdown for them.
    const storedCookies = sessionStore[AUTO_SESSION_ID];
    const configured = loadOrgSettings();
    let orgId = configured.orgId;
    const probe = await probeOrgsByUser(storedCookies);
    if (probe.status === "unauthorized") {
      delete sessionStore[AUTO_SESSION_ID];
      saveSessionStore(sessionStore);
      console.error("[auto-login] Session cookies were rejected by MindfulText (401). Treating as failure.");
      return { ok: false, reason: "invalid_credentials" };
    }
    let orgs: { id: string; name: string }[] = [];
    if (probe.status === "ok") {
      orgs = probe.orgs;
      cachedOrgs = orgs;
      const stillAccessible = orgs.some((o) => o.id === orgId);
      if (!stillAccessible && orgs.length > 0) orgId = orgs[0].id;
    } else if (probe.status === "forbidden") {
      console.warn("[auto-login] byUser returned 403 — account can't list orgs; keeping session, user must enter org id manually.");
      cachedOrgs = [];
    } else {
      console.warn("[auto-login] byUser probe failed (transient/network). Keeping session.");
    }

    autoSessionUser = { email, orgId, sessionId: AUTO_SESSION_ID };
    console.log(`[auto-login] Auto-login succeeded — email=${email} orgId=${orgId} orgs=${orgs.length} probe=${probe.status}`);
    return { ok: true, orgs, orgsProbe: probe.status };
  } catch (error) {
    console.error("[auto-login] Auto-login threw an unexpected error:", error instanceof Error ? error.message : String(error));
    return { ok: false, reason: "network_error" };
  }
}
