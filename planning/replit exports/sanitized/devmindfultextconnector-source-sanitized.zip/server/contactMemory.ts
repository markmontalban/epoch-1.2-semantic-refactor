/**
 * Per-contact memory writer + MindfulText custom-field mirror.
 *
 * - When the contact has memoryEnabled=false: every write is a no-op.
 * - Otherwise: upsert a single rolling agent_memory row keyed (orgId, contactId, "summary")
 *   and mirror the summary string to a designated custom field on the
 *   MindfulText contact via the proxy.
 */
import { and, eq } from "drizzle-orm";
import { db } from "./db";
import {
  agentMemory,
  contactProfiles,
  type ContactProfile,
} from "../shared/schema";
import { mtFetch } from "./mtClient";

const MEMORY_KEY = "personal_summary";
const MEMORY_FIELD_NAME = "agentMemory";
const MAX_SUMMARY_CHARS = 4000;

let cachedFieldIdByOrg: Map<string, string> = new Map();

export async function getContactProfile(
  organizationId: string,
  contactId: string,
): Promise<ContactProfile> {
  const [row] = await db
    .select()
    .from(contactProfiles)
    .where(
      and(
        eq(contactProfiles.organizationId, organizationId),
        eq(contactProfiles.contactId, contactId),
      ),
    );
  if (row) return row;
  const [created] = await db
    .insert(contactProfiles)
    .values({ organizationId, contactId, memoryEnabled: true })
    .returning();
  return created;
}

/**
 * Read-only profile lookup — returns null when no row exists instead of
 * creating one. Use this from read-only paths (e.g. the public subscriber
 * page) so a page view never mutates DB state.
 */
export async function getExistingContactProfile(
  organizationId: string,
  contactId: string,
): Promise<ContactProfile | null> {
  const [row] = await db
    .select()
    .from(contactProfiles)
    .where(
      and(
        eq(contactProfiles.organizationId, organizationId),
        eq(contactProfiles.contactId, contactId),
      ),
    );
  return row ?? null;
}

export async function setMemoryEnabled(
  organizationId: string,
  contactId: string,
  enabled: boolean,
  storedCookies?: string,
): Promise<ContactProfile> {
  const profile = await getContactProfile(organizationId, contactId);
  const [updated] = await db
    .update(contactProfiles)
    .set({ memoryEnabled: enabled, updatedAt: new Date() })
    .where(eq(contactProfiles.id, profile.id))
    .returning();

  if (!enabled) {
    // Purge: drop all memory rows for this contact.
    await db
      .delete(agentMemory)
      .where(
        and(
          eq(agentMemory.organizationId, organizationId),
          eq(agentMemory.contactId, contactId),
        ),
      );
    // Also clear the mirrored MindfulText custom field.
    if (storedCookies) {
      await mirrorToMindfulText(organizationId, contactId, "", storedCookies).catch(() => {});
    }
  }
  return updated;
}

/** Save the founder-written subscriber-page note for a single contact. */
export async function setContactPageNote(
  organizationId: string,
  contactId: string,
  note: string,
): Promise<ContactProfile> {
  const profile = await getContactProfile(organizationId, contactId);
  const trimmed = note.trim();
  const [updated] = await db
    .update(contactProfiles)
    .set({ pageNote: trimmed.length ? trimmed : null, updatedAt: new Date() })
    .where(eq(contactProfiles.id, profile.id))
    .returning();
  return updated;
}

export async function getContactMemory(
  organizationId: string,
  contactId: string,
) {
  return db
    .select()
    .from(agentMemory)
    .where(
      and(
        eq(agentMemory.organizationId, organizationId),
        eq(agentMemory.contactId, contactId),
      ),
    );
}

export async function clearContactMemory(
  organizationId: string,
  contactId: string,
  storedCookies?: string,
) {
  await db
    .delete(agentMemory)
    .where(
      and(
        eq(agentMemory.organizationId, organizationId),
        eq(agentMemory.contactId, contactId),
      ),
    );
  if (storedCookies) {
    await mirrorToMindfulText(organizationId, contactId, "", storedCookies).catch(() => {});
  }
}

/**
 * Append a piece of activity to the contact's rolling summary. Returns the
 * summary string actually stored (trimmed to MAX_SUMMARY_CHARS), or null when
 * memory is disabled.
 */
export async function recordContactActivity(opts: {
  organizationId: string;
  contactId: string;
  note: string;
  storedCookies?: string;
}): Promise<string | null> {
  const profile = await getContactProfile(opts.organizationId, opts.contactId);
  if (!profile.memoryEnabled) return null;

  const existing = await db
    .select()
    .from(agentMemory)
    .where(
      and(
        eq(agentMemory.organizationId, opts.organizationId),
        eq(agentMemory.contactId, opts.contactId),
        eq(agentMemory.key, MEMORY_KEY),
      ),
    );

  const stamp = new Date().toISOString().substring(0, 16).replace("T", " ");
  const line = `[${stamp}] ${opts.note}`;
  let merged: string;
  if (existing.length === 0) {
    merged = line;
    await db.insert(agentMemory).values({
      organizationId: opts.organizationId,
      contactId: opts.contactId,
      key: MEMORY_KEY,
      value: merged,
      summary: merged,
      memoryType: "conversation_summary",
    });
  } else {
    const previous = existing[0].value ?? "";
    merged = `${line}\n${previous}`;
    if (merged.length > MAX_SUMMARY_CHARS) {
      merged = merged.substring(0, MAX_SUMMARY_CHARS);
    }
    await db
      .update(agentMemory)
      .set({ value: merged, summary: merged, updatedAt: new Date() })
      .where(eq(agentMemory.id, existing[0].id));
  }

  if (opts.storedCookies) {
    mirrorToMindfulText(opts.organizationId, opts.contactId, merged, opts.storedCookies).catch(
      (err) => console.warn("[contact-memory] mirror failed:", err instanceof Error ? err.message : err),
    );
  }

  return merged;
}

/**
 * Resolve the MindfulText custom-field id for the memory mirror, creating it
 * once on first use. Cached per-org in process memory + per-contact-profile.
 */
async function resolveMemoryFieldId(
  organizationId: string,
  storedCookies: string,
): Promise<string | null> {
  const cached = cachedFieldIdByOrg.get(organizationId);
  if (cached) return cached;

  // Try to list existing custom fields. The MindfulText API path is best-effort
  // here — if the endpoint isn't present we silently skip mirroring.
  try {
    const listRes = await mtFetch(
      `/api/customFields/byOrganization/${organizationId}`,
      { cookies: storedCookies },
    );
    if (listRes.ok) {
      const json = (await listRes.json()) as { data?: Array<{ id?: string; name?: string }> } | Array<{ id?: string; name?: string }>;
      const list = Array.isArray(json)
        ? json
        : Array.isArray((json as { data?: unknown[] }).data)
          ? (json as { data: Array<{ id?: string; name?: string }> }).data
          : [];
      const found = list.find((f) => f && f.name === MEMORY_FIELD_NAME);
      if (found?.id) {
        cachedFieldIdByOrg.set(organizationId, String(found.id));
        return String(found.id);
      }
    }
  } catch {
    /* ignore */
  }

  // Create the field. Best-effort.
  try {
    const createRes = await mtFetch(
      `/api/customFields/${organizationId}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        cookies: storedCookies,
        body: JSON.stringify({ name: MEMORY_FIELD_NAME, type: "text" }),
      },
    );
    if (createRes.ok) {
      const json = (await createRes.json()) as { data?: { id?: string } } | { id?: string };
      const id = (json as { data?: { id?: string } }).data?.id ?? (json as { id?: string }).id;
      if (id) {
        cachedFieldIdByOrg.set(organizationId, String(id));
        return String(id);
      }
    }
  } catch {
    /* ignore */
  }
  return null;
}

async function mirrorToMindfulText(
  organizationId: string,
  contactId: string,
  summary: string,
  storedCookies: string,
): Promise<void> {
  const fieldId = await resolveMemoryFieldId(organizationId, storedCookies);
  if (!fieldId) return; // mirroring not possible on this deployment

  // Best-effort write — most MindfulText deployments expose either a
  // /api/contacts/{contactId}/customFields/{fieldId} PUT or a generic
  // /api/contacts/{contactId} PATCH. We try the first; if it fails we don't
  // surface the error.
  try {
    await mtFetch(
      `/api/contacts/${contactId}/customFields/${fieldId}`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        cookies: storedCookies,
        body: JSON.stringify({ value: summary }),
      },
    );
  } catch {
    /* non-fatal */
  }
}

export const __test_internals = { MEMORY_KEY, MEMORY_FIELD_NAME };
