/**
 * Read-only canonical export helpers for MindfulText module text.
 *
 * This module intentionally contains no write operations. Its requester is
 * passed in by the CLI so tests can exercise pagination and mapping entirely
 * from fixtures, without contacting MindfulText.
 */

export const SNAPSHOT_FORMAT = "mindfultext-content-snapshot/v1";
export const EXPECTED_MODULE_COUNT = 283;
export const EXPECTED_TEXT_COUNT = 1112;
export const MODULE_PAGE_LIMIT = 100;

type UnknownRecord = Record<string, unknown>;

export type ModuleTextRow = {
  module_id: string;
  module_name: string | null;
  module_description: string | null;
  module_tags: string[];
  module_is_public: boolean | null;
  module_is_archived: boolean | null;
  module_created_at: string | null;
  module_updated_at: string | null;
  text_index: number;
  text_count: number;
  subject: string | null;
  content: string | null;
  action_id: string | null;
  action_matches: string[];
  media_urls: string[];
  has_media: boolean;
};

export type SnapshotManifest = {
  format: typeof SNAPSHOT_FORMAT;
  generated_at: string;
  organization_id: string;
  module_count: number;
  text_count: number;
  media_text_count: number;
  action_attached_text_count: number;
  distinct_module_tags: Record<string, number>;
  texts_per_module_distribution: Record<string, number>;
  expected_comparison: {
    expected_module_count: number;
    actual_module_count: number;
    module_count_difference: number;
    expected_text_count: number;
    actual_text_count: number;
    text_count_difference: number;
    matches_expected_inventory: boolean;
  };
};

export type SnapshotRequest = (path: string, options: { method: "GET" }) => Promise<unknown>;

export type ModuleCorpus = {
  modules: UnknownRecord[];
  rows: ModuleTextRow[];
};

function isRecord(value: unknown): value is UnknownRecord {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function requiredString(value: unknown, label: string): string {
  if (typeof value !== "string") {
    throw new Error(`Malformed MindfulText response: ${label} must be a string.`);
  }
  return value;
}

function optionalString(value: unknown, label: string): string | null {
  if (value === undefined || value === null) return null;
  if (typeof value !== "string") {
    throw new Error(`Malformed MindfulText response: ${label} must be a string when supplied.`);
  }
  return value;
}

function stringArray(value: unknown, label: string): string[] {
  if (value === undefined || value === null) return [];
  if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) {
    throw new Error(`Malformed MindfulText response: ${label} must be an array of strings.`);
  }
  return [...value];
}

function optionalBoolean(value: unknown, label: string): boolean | null {
  if (value === undefined || value === null) return null;
  if (typeof value !== "boolean") {
    throw new Error(`Malformed MindfulText response: ${label} must be a boolean when supplied.`);
  }
  return value;
}

export function isoFromEpochSeconds(value: unknown, label: string): string | null {
  if (value === undefined || value === null || value === "") return null;
  if (typeof value !== "number" || !Number.isFinite(value)) {
    throw new Error(`Malformed MindfulText response: ${label} must be epoch seconds when supplied.`);
  }
  const date = new Date(value * 1000);
  if (Number.isNaN(date.getTime())) {
    throw new Error(`Malformed MindfulText response: ${label} is not a valid epoch-second timestamp.`);
  }
  return date.toISOString();
}

function moduleIdOf(module: UnknownRecord, label: string): string {
  return requiredString(module.id, `${label}.id`);
}

function textRowsForModule(module: UnknownRecord, label: string): ModuleTextRow[] {
  const moduleId = moduleIdOf(module, label);
  if (!Array.isArray(module.texts)) {
    throw new Error(`Malformed MindfulText response: ${label}.texts must be an array after detail fallback.`);
  }

  const moduleName = optionalString(module.name, `${label}.name`);
  const moduleDescription = optionalString(module.description, `${label}.description`);
  const moduleTags = stringArray(module.tags, `${label}.tags`);
  const moduleIsPublic = optionalBoolean(module.isPublic, `${label}.isPublic`);
  const moduleIsArchived = optionalBoolean(module.isArchived, `${label}.isArchived`);
  const moduleCreatedAt = isoFromEpochSeconds(module.createdAt, `${label}.createdAt`);
  const moduleUpdatedAt = isoFromEpochSeconds(module.updatedAt, `${label}.updatedAt`);
  const textCount = module.texts.length;

  return module.texts.map((value, textIndex) => {
    if (!isRecord(value)) {
      throw new Error(`Malformed MindfulText response: ${label}.texts[${textIndex}] must be an object.`);
    }
    const mediaUrls = stringArray(value.mediaURLs, `${label}.texts[${textIndex}].mediaURLs`);
    return {
      module_id: moduleId,
      module_name: moduleName,
      module_description: moduleDescription,
      module_tags: [...moduleTags],
      module_is_public: moduleIsPublic,
      module_is_archived: moduleIsArchived,
      module_created_at: moduleCreatedAt,
      module_updated_at: moduleUpdatedAt,
      text_index: textIndex,
      text_count: textCount,
      subject: optionalString(value.subject, `${label}.texts[${textIndex}].subject`),
      content: optionalString(value.content, `${label}.texts[${textIndex}].content`),
      action_id: optionalString(value.actionID, `${label}.texts[${textIndex}].actionID`),
      action_matches: stringArray(value.actionMatches, `${label}.texts[${textIndex}].actionMatches`),
      media_urls: mediaUrls,
      has_media: mediaUrls.length > 0,
    };
  });
}

type ParsedPage = {
  modules: UnknownRecord[];
  metadata: UnknownRecord;
};

function extractModules(value: unknown): UnknownRecord[] | null {
  if (Array.isArray(value)) return value.every(isRecord) ? value : null;
  if (!isRecord(value)) return null;
  for (const key of ["items", "modules", "results"]) {
    if (Array.isArray(value[key])) {
      return (value[key] as unknown[]).every(isRecord) ? value[key] as UnknownRecord[] : null;
    }
  }
  return null;
}

function parseListPage(raw: unknown): ParsedPage {
  if (Array.isArray(raw)) {
    const modules = extractModules(raw);
    if (!modules) throw new Error("Malformed MindfulText response: module list contains a non-object item.");
    return { modules, metadata: {} };
  }
  if (!isRecord(raw)) {
    throw new Error("Malformed MindfulText response: module list must be an array or object envelope.");
  }

  const modules = extractModules(raw.data) ?? extractModules(raw);
  if (!modules) {
    throw new Error("Malformed MindfulText response: module list envelope has no supported array.");
  }

  const nestedData = isRecord(raw.data) ? raw.data : {};
  const nestedPagination = isRecord(raw.pagination) ? raw.pagination : {};
  const dataPagination = isRecord(nestedData.pagination) ? nestedData.pagination : {};
  return { modules, metadata: { ...raw, ...nestedData, ...nestedPagination, ...dataPagination } };
}

function positiveInteger(value: unknown, label: string): number | null {
  if (value === undefined || value === null) return null;
  if (typeof value !== "number" || !Number.isInteger(value) || value < 0) {
    throw new Error(`Malformed MindfulText pagination: ${label} must be a non-negative integer.`);
  }
  return value;
}

function nextPageFromMetadata(
  metadata: UnknownRecord,
  page: number,
  itemsLength: number,
  collectedLength: number,
): number | null {
  const hasMore = metadata.hasMore;
  if (hasMore !== undefined && typeof hasMore !== "boolean") {
    throw new Error("Malformed MindfulText pagination: hasMore must be a boolean.");
  }

  const nextPageValue = metadata.nextPage;
  let nextPage: number | null = null;
  if (nextPageValue !== undefined && nextPageValue !== null && nextPageValue !== false) {
    const parsedNextPage = positiveInteger(nextPageValue, "nextPage");
    if (parsedNextPage === null || parsedNextPage === 0 || parsedNextPage <= page) {
      throw new Error("Malformed MindfulText pagination: nextPage must advance.");
    }
    nextPage = parsedNextPage;
  }

  const total = positiveInteger(metadata.total ?? metadata.totalCount, "total/totalCount");
  const totalPages = positiveInteger(metadata.totalPages ?? metadata.pageCount, "totalPages/pageCount");

  if (total !== null) {
    if (collectedLength > total) {
      throw new Error(`Malformed MindfulText pagination: collected ${collectedLength} modules, exceeding total ${total}.`);
    }
    if (collectedLength === total) {
      if (hasMore === true || nextPage !== null) {
        throw new Error("Malformed MindfulText pagination: metadata indicates another page after the reported total.");
      }
      return null;
    }
    if (hasMore === false || nextPageValue === null || nextPageValue === false) {
      throw new Error(`Incomplete MindfulText module list: received ${collectedLength} of reported ${total} modules.`);
    }
    return nextPage ?? page + 1;
  }

  if (totalPages !== null) {
    if (page > totalPages) {
      throw new Error("Malformed MindfulText pagination: current page exceeds totalPages.");
    }
    if (page === totalPages) {
      if (hasMore === true || nextPage !== null) {
        throw new Error("Malformed MindfulText pagination: metadata indicates another page after totalPages.");
      }
      return null;
    }
    if (hasMore === false || nextPageValue === null || nextPageValue === false) {
      throw new Error("Incomplete MindfulText module list: metadata ended before totalPages.");
    }
    return nextPage ?? page + 1;
  }

  if (hasMore === false || nextPageValue === null || nextPageValue === false) return null;
  if (hasMore === true || nextPage !== null) return nextPage ?? page + 1;
  // The live modules endpoint may ignore page/limit and return the complete
  // authoritative list in one array, without pagination metadata. A list
  // larger than the requested limit is therefore a verified unpaged boundary,
  // not a partial page that should be guessed at.
  if (itemsLength > MODULE_PAGE_LIMIT) {
    return null;
  }
  return itemsLength === MODULE_PAGE_LIMIT ? page + 1 : null;
}

function detailFromResponse(raw: unknown, moduleId: string): UnknownRecord {
  if (isRecord(raw) && isRecord(raw.data)) return raw.data;
  if (isRecord(raw)) return raw;
  throw new Error(`Malformed MindfulText response: module detail ${moduleId} must be an object.`);
}

function sortRows(rows: ModuleTextRow[]): ModuleTextRow[] {
  return rows.sort((a, b) => {
    if (a.module_id < b.module_id) return -1;
    if (a.module_id > b.module_id) return 1;
    return a.text_index - b.text_index;
  });
}

/**
 * Fetch every module, requesting detail only for list records that omit the
 * `texts` property. All caller requests are constrained to GET at the type and
 * call-site level; this function has no mutation path.
 */
export async function fetchModuleCorpus(orgId: string, request: SnapshotRequest): Promise<ModuleCorpus> {
  const modules: UnknownRecord[] = [];
  const ids = new Set<string>();
  let page = 1;

  for (let requestCount = 0; requestCount < 10_000; requestCount++) {
    const raw = await request(
      `/api/modules/byOrganization/${encodeURIComponent(orgId)}?page=${page}&limit=${MODULE_PAGE_LIMIT}`,
      { method: "GET" },
    );
    const parsed = parseListPage(raw);

    for (const module of parsed.modules) {
      const moduleId = moduleIdOf(module, `modules page ${page}`);
      if (ids.has(moduleId)) {
        throw new Error(`Malformed MindfulText pagination: module ${moduleId} appeared more than once.`);
      }
      ids.add(moduleId);
      modules.push(module);
    }

    const nextPage = nextPageFromMetadata(parsed.metadata, page, parsed.modules.length, modules.length);
    if (nextPage === null) break;
    page = nextPage;

    if (requestCount === 9_999) {
      throw new Error("Malformed MindfulText pagination: exceeded 10,000 module-list pages.");
    }
  }

  const resolvedModules: UnknownRecord[] = [];
  for (const module of modules) {
    const moduleId = moduleIdOf(module, "module");
    if (Object.prototype.hasOwnProperty.call(module, "texts")) {
      if (!Array.isArray(module.texts)) {
        throw new Error(`Malformed MindfulText response: module ${moduleId}.texts must be an array when supplied.`);
      }
      resolvedModules.push(module);
      continue;
    }

    const detail = detailFromResponse(
      await request(`/api/modules/${encodeURIComponent(moduleId)}`, { method: "GET" }),
      moduleId,
    );
    if (moduleIdOf(detail, `module detail ${moduleId}`) !== moduleId) {
      throw new Error(`Malformed MindfulText response: detail ID did not match requested module ${moduleId}.`);
    }
    resolvedModules.push(detail);
  }

  const rows = sortRows(resolvedModules.flatMap((module, index) => textRowsForModule(module, `modules[${index}]`)));
  return { modules: resolvedModules, rows };
}

/** Build deterministic aggregate metadata from the finalized module rows. */
export function buildSnapshotManifest(
  organizationId: string,
  modules: UnknownRecord[],
  rows: ModuleTextRow[],
  generatedAt: string,
): SnapshotManifest {
  const tagCounts = new Map<string, number>();
  const textsPerModule = new Map<number, number>();

  for (const module of modules) {
    const tags = stringArray(module.tags, `module ${moduleIdOf(module, "module")}.tags`);
    for (const tag of Array.from(new Set(tags))) tagCounts.set(tag, (tagCounts.get(tag) ?? 0) + 1);
    const textCount = Array.isArray(module.texts) ? module.texts.length : 0;
    textsPerModule.set(textCount, (textsPerModule.get(textCount) ?? 0) + 1);
  }

  const distinctModuleTags = Object.fromEntries(
    Array.from(tagCounts.entries()).sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0),
  );
  const distribution = Object.fromEntries(
    Array.from(textsPerModule.entries()).sort(([left], [right]) => left - right).map(([count, modulesAtCount]) => [String(count), modulesAtCount]),
  );
  const moduleCount = modules.length;
  const textCount = rows.length;

  return {
    format: SNAPSHOT_FORMAT,
    generated_at: generatedAt,
    organization_id: organizationId,
    module_count: moduleCount,
    text_count: textCount,
    media_text_count: rows.filter((row) => row.has_media).length,
    action_attached_text_count: rows.filter((row) => row.action_id !== null && row.action_id !== "").length,
    distinct_module_tags: distinctModuleTags,
    texts_per_module_distribution: distribution,
    expected_comparison: {
      expected_module_count: EXPECTED_MODULE_COUNT,
      actual_module_count: moduleCount,
      module_count_difference: moduleCount - EXPECTED_MODULE_COUNT,
      expected_text_count: EXPECTED_TEXT_COUNT,
      actual_text_count: textCount,
      text_count_difference: textCount - EXPECTED_TEXT_COUNT,
      matches_expected_inventory: moduleCount === EXPECTED_MODULE_COUNT && textCount === EXPECTED_TEXT_COUNT,
    },
  };
}