import { eq, and, desc, sql, gte, lt } from "drizzle-orm";
import { randomBytes } from "crypto";
import { db } from "./db";
import {
  contentDrafts,
  draftMessages,
  inboundMessages,
  personalJourneyEvents,
  agentMemory,
  agentRules,
  tokenUsage,
  contentPrograms,
  entitySnapshots,
  reshapeRules,
  pendingChanges,
  personalJourneyTemplates,
  audienceBriefs,
  segments,
  analyticsSnapshots,
  messageEvents,
  attributionEvents,
  subscriberPageTokens,
  publishedContent,
  pageEvents,
  pageSettings,
  harvestedLinks,
  type InsertContentDraft,
  type InsertDraftMessage,
  type InsertInboundMessage,
  type InsertAgentMemory,
  type InsertAgentRule,
  type InsertTokenUsage,
  type InsertContentProgram,
  type InsertEntitySnapshot,
  type InsertReshapeRule,
  type InsertPersonalJourneyTemplate,
  type InsertAudienceBrief,
  type Segment,
  type InsertAnalyticsSnapshot,
  type InsertMessageEvent,
  type InsertAttributionEvent,
  type InsertSubscriberPageToken,
  type InsertPublishedContent,
  type InsertPageEvent,
  type InsertPageSettings,
  type PageSettings,
  type InsertHarvestedLink,
  type HarvestedLink,
} from "../shared/schema";

// ---------------------------------------------------------------------------
// Content drafts
// ---------------------------------------------------------------------------

export async function createContentDraft(data: InsertContentDraft) {
  const [row] = await db.insert(contentDrafts).values(data).returning();
  return row;
}

export async function getContentDrafts(organizationId: string) {
  return db
    .select()
    .from(contentDrafts)
    .where(eq(contentDrafts.organizationId, organizationId))
    .orderBy(desc(contentDrafts.createdAt));
}

export async function getContentDraft(id: number) {
  const [row] = await db
    .select()
    .from(contentDrafts)
    .where(eq(contentDrafts.id, id));
  return row ?? null;
}

export async function updateContentDraft(
  id: number,
  data: Partial<InsertContentDraft>,
) {
  const [row] = await db
    .update(contentDrafts)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(contentDrafts.id, id))
    .returning();
  return row;
}

// ---------------------------------------------------------------------------
// Draft messages
// ---------------------------------------------------------------------------

export async function createDraftMessage(data: InsertDraftMessage) {
  const [row] = await db.insert(draftMessages).values(data).returning();
  return row;
}

export async function getDraftMessages(organizationId: string) {
  return db
    .select()
    .from(draftMessages)
    .where(eq(draftMessages.organizationId, organizationId))
    .orderBy(desc(draftMessages.createdAt));
}

export async function updateDraftMessage(
  id: number,
  data: Partial<InsertDraftMessage>,
) {
  const [row] = await db
    .update(draftMessages)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(draftMessages.id, id))
    .returning();
  return row;
}

// ---------------------------------------------------------------------------
// Inbound messages
// ---------------------------------------------------------------------------

export async function createInboundMessage(
  data: InsertInboundMessage & { receivedAt?: Date },
) {
  const [row] = await db.insert(inboundMessages).values(data).returning();
  return row;
}

export async function getInboundMessages(organizationId: string) {
  return db
    .select()
    .from(inboundMessages)
    .where(eq(inboundMessages.organizationId, organizationId))
    .orderBy(desc(inboundMessages.receivedAt));
}

/** True when this MindfulText message id was already ingested for the org. */
export async function isMtMessageIdKnown(
  organizationId: string,
  mtMessageId: string,
): Promise<boolean> {
  const [row] = await db
    .select({ id: inboundMessages.id })
    .from(inboundMessages)
    .where(
      and(
        eq(inboundMessages.organizationId, organizationId),
        sql`${inboundMessages.metadata}->>'mtMessageId' = ${mtMessageId}`,
      ),
    )
    .limit(1);
  return !!row;
}

/** Draft replies awaiting operator review (generated or edited, not yet sent/discarded). */
export async function countActionableDraftMessages(
  organizationId: string,
): Promise<number> {
  const rows = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(draftMessages)
    .where(
      and(
        eq(draftMessages.organizationId, organizationId),
        sql`${draftMessages.status} IN ('generated', 'edited', 'approved')`,
      ),
    );
  return rows[0]?.c ?? 0;
}

/** Draft message linked to an inbound row, if any. */
export async function getDraftMessageByInboundId(
  organizationId: string,
  inboundMessageId: number,
) {
  const [row] = await db
    .select()
    .from(draftMessages)
    .where(
      and(
        eq(draftMessages.organizationId, organizationId),
        eq(draftMessages.inboundMessageId, inboundMessageId),
      ),
    )
    .orderBy(desc(draftMessages.createdAt))
    .limit(1);
  return row ?? null;
}

/**
 * Find the most recent `advanced` event for (organizationId, contactId)
 * whose createdAt is strictly before `before`. Used to attribute an inbound
 * reply to the module that prompted it.
 */
export async function findPriorAdvancedEvent(
  organizationId: string,
  contactId: string,
  before: Date,
) {
  const [row] = await db
    .select()
    .from(personalJourneyEvents)
    .where(
      and(
        eq(personalJourneyEvents.organizationId, organizationId),
        eq(personalJourneyEvents.contactId, contactId),
        eq(personalJourneyEvents.eventType, "advanced"),
        lt(personalJourneyEvents.createdAt, before),
      ),
    )
    .orderBy(desc(personalJourneyEvents.createdAt))
    .limit(1);
  return row ?? null;
}

export async function setInboundAttribution(
  id: number,
  data: { moduleId: string | null; attributionSource: string; metadata?: Record<string, unknown> | null },
) {
  const [row] = await db
    .update(inboundMessages)
    .set({
      moduleId: data.moduleId,
      attributionSource: data.attributionSource,
      ...(data.metadata !== undefined ? { metadata: data.metadata } : {}),
    })
    .where(eq(inboundMessages.id, id))
    .returning();
  return row;
}

/** All inbounds for an org with a non-null moduleId, in receivedAt range. */
export async function listAttributedInbounds(
  organizationId: string,
  start: Date | null,
  end: Date | null,
) {
  const conditions = [eq(inboundMessages.organizationId, organizationId)];
  if (start) conditions.push(gte(inboundMessages.receivedAt, start));
  if (end) conditions.push(lt(inboundMessages.receivedAt, end));
  return db
    .select()
    .from(inboundMessages)
    .where(and(...conditions))
    .orderBy(desc(inboundMessages.receivedAt));
}

/**
 * Per-module aggregates for reply analytics. Returns one row per module that
 * had either at least one `advanced` send OR at least one attributed inbound
 * in the given range.
 */
export async function aggregateReplyAnalytics(
  organizationId: string,
  start: Date | null,
  end: Date | null,
) {
  // Sends per module from personalJourneyEvents (eventType='advanced').
  const sendConds = [
    eq(personalJourneyEvents.organizationId, organizationId),
    eq(personalJourneyEvents.eventType, "advanced"),
  ];
  if (start) sendConds.push(gte(personalJourneyEvents.createdAt, start));
  if (end) sendConds.push(lt(personalJourneyEvents.createdAt, end));
  const sendRows = await db
    .select({
      moduleId: personalJourneyEvents.moduleId,
      sends: sql<number>`count(*)::int`,
    })
    .from(personalJourneyEvents)
    .where(and(...sendConds))
    .groupBy(personalJourneyEvents.moduleId);

  // Replies per module from inboundMessages, only attributed rows.
  const replyConds = [eq(inboundMessages.organizationId, organizationId)];
  if (start) replyConds.push(gte(inboundMessages.receivedAt, start));
  if (end) replyConds.push(lt(inboundMessages.receivedAt, end));
  const replyRows = await db
    .select({
      moduleId: inboundMessages.moduleId,
      replies: sql<number>`count(*)::int`,
      lastReplyAt: sql<Date | null>`max(${inboundMessages.receivedAt})`,
    })
    .from(inboundMessages)
    .where(and(...replyConds))
    .groupBy(inboundMessages.moduleId);

  return { sendRows, replyRows };
}

// ---------------------------------------------------------------------------
// Agent memory
// ---------------------------------------------------------------------------

export async function upsertMemory(data: InsertAgentMemory) {
  const existing = await db
    .select()
    .from(agentMemory)
    .where(
      and(
        eq(agentMemory.organizationId, data.organizationId),
        eq(agentMemory.key, data.key),
      ),
    );

  if (existing.length > 0) {
    const [row] = await db
      .update(agentMemory)
      .set({ value: data.value, updatedAt: new Date() })
      .where(eq(agentMemory.id, existing[0].id))
      .returning();
    return row;
  }

  const [row] = await db.insert(agentMemory).values(data).returning();
  return row;
}

export async function getActiveMemories(organizationId: string) {
  return db
    .select()
    .from(agentMemory)
    .where(
      and(
        eq(agentMemory.organizationId, organizationId),
        eq(agentMemory.isActive, true),
      ),
    )
    .orderBy(desc(agentMemory.priority));
}

export async function deleteMemory(id: number) {
  await db.delete(agentMemory).where(eq(agentMemory.id, id));
}

// ---------------------------------------------------------------------------
// Agent rules
// ---------------------------------------------------------------------------

export async function createAgentRule(data: InsertAgentRule) {
  const [row] = await db.insert(agentRules).values(data).returning();
  return row;
}

export async function getActiveRules(organizationId: string, scope?: string) {
  const conditions = [
    eq(agentRules.organizationId, organizationId),
    eq(agentRules.isActive, true),
  ];
  if (scope) {
    conditions.push(eq(agentRules.scope, scope));
  }
  return db.select().from(agentRules).where(and(...conditions));
}

export async function updateAgentRule(
  id: number,
  data: Partial<InsertAgentRule>,
) {
  const [row] = await db
    .update(agentRules)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(agentRules.id, id))
    .returning();
  return row;
}

export async function deleteAgentRule(id: number) {
  await db.delete(agentRules).where(eq(agentRules.id, id));
}

// ---------------------------------------------------------------------------
// Token usage
// ---------------------------------------------------------------------------

export async function logTokenUsage(data: InsertTokenUsage) {
  const [row] = await db.insert(tokenUsage).values(data).returning();
  return row;
}

export async function getTokenUsageSummary(organizationId: string) {
  const rows = await db
    .select()
    .from(tokenUsage)
    .where(eq(tokenUsage.organizationId, organizationId))
    .orderBy(desc(tokenUsage.createdAt));

  const totalPromptTokens = rows.reduce(
    (sum, r) => sum + (r.promptTokens ?? 0),
    0,
  );
  const totalCompletionTokens = rows.reduce(
    (sum, r) => sum + (r.completionTokens ?? 0),
    0,
  );
  const totalCostUsd = rows.reduce(
    (sum, r) => sum + (r.estimatedCostUsd ?? 0),
    0,
  );

  const byModel: Record<
    string,
    { promptTokens: number; completionTokens: number; costUsd: number }
  > = {};
  for (const r of rows) {
    const entry = byModel[r.model] ?? {
      promptTokens: 0,
      completionTokens: 0,
      costUsd: 0,
    };
    entry.promptTokens += r.promptTokens ?? 0;
    entry.completionTokens += r.completionTokens ?? 0;
    entry.costUsd += r.estimatedCostUsd ?? 0;
    byModel[r.model] = entry;
  }

  return {
    totalPromptTokens,
    totalCompletionTokens,
    totalTokens: totalPromptTokens + totalCompletionTokens,
    totalCostUsd: Math.round(totalCostUsd * 10000) / 10000,
    byModel,
    recentUsage: rows.slice(0, 50),
  };
}

// ---------------------------------------------------------------------------
// Content programs
// ---------------------------------------------------------------------------

export async function createContentProgram(data: InsertContentProgram) {
  const [row] = await db.insert(contentPrograms).values(data).returning();
  return row;
}

export async function getContentPrograms(organizationId: string) {
  return db
    .select()
    .from(contentPrograms)
    .where(eq(contentPrograms.organizationId, organizationId))
    .orderBy(desc(contentPrograms.createdAt));
}

export async function getContentProgram(id: number) {
  const [row] = await db
    .select()
    .from(contentPrograms)
    .where(eq(contentPrograms.id, id));
  return row ?? null;
}

export async function updateContentProgram(
  id: number,
  data: Partial<InsertContentProgram>,
) {
  const [row] = await db
    .update(contentPrograms)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(contentPrograms.id, id))
    .returning();
  return row;
}

export async function deleteContentProgram(id: number) {
  await db.delete(contentPrograms).where(eq(contentPrograms.id, id));
}

// ---------------------------------------------------------------------------
// Entity snapshots — pre-edit backups for one-click undo
// ---------------------------------------------------------------------------

/** Delete snapshots older than N days. Keeps the table from growing forever. */
export async function pruneOldSnapshots(retentionDays = 30): Promise<number> {
  const cutoff = new Date(Date.now() - retentionDays * 24 * 60 * 60 * 1000);
  const result = await db
    .delete(entitySnapshots)
    .where(sql`${entitySnapshots.createdAt} < ${cutoff}`)
    .returning({ id: entitySnapshots.id });
  return result.length;
}

export async function createEntitySnapshot(data: InsertEntitySnapshot) {
  const [row] = await db.insert(entitySnapshots).values(data).returning();
  // Opportunistic prune: cheap, runs only on writes, cap at 30 days retention.
  pruneOldSnapshots(30).catch((e) =>
    console.warn("[snapshots] prune failed:", e instanceof Error ? e.message : e),
  );
  return row;
}

export async function listEntitySnapshots(
  organizationId: string,
  opts?: { entityType?: string; entityId?: string; limit?: number },
) {
  const conditions = [eq(entitySnapshots.organizationId, organizationId)];
  if (opts?.entityType) {
    conditions.push(eq(entitySnapshots.entityType, opts.entityType));
  }
  if (opts?.entityId) {
    conditions.push(eq(entitySnapshots.entityId, opts.entityId));
  }
  return db
    .select()
    .from(entitySnapshots)
    .where(and(...conditions))
    .orderBy(desc(entitySnapshots.createdAt))
    .limit(opts?.limit ?? 100);
}

export async function getEntitySnapshot(id: number) {
  const [row] = await db
    .select()
    .from(entitySnapshots)
    .where(eq(entitySnapshots.id, id));
  return row ?? null;
}

// ---------------------------------------------------------------------------
// Dashboard time-series counts
// ---------------------------------------------------------------------------
//
// Source mapping for the 8 dashboard tiles:
//   - Contacts/Journeys/Modules/Actions → MindfulText `byOrganization` lists
//     (no creation timestamp exposed locally → no period filtering, just the
//     current count). Fetched in routes.ts via the proxy session cookies.
//   - Texts / Sends / Replies → calendar [start,end) via dashboardMetrics
//     (snapshot cumulative diffs + local message_events / inboundMessages).

export async function countDraftMessages(
  organizationId: string,
  start: Date | null,
  end: Date | null,
): Promise<number> {
  const conditions = [eq(draftMessages.organizationId, organizationId)];
  if (start) conditions.push(gte(draftMessages.createdAt, start));
  if (end) conditions.push(lt(draftMessages.createdAt, end));
  const rows = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(draftMessages)
    .where(and(...conditions));
  return rows[0]?.c ?? 0;
}

export async function countInboundMessages(
  organizationId: string,
  start: Date | null,
  end: Date | null,
): Promise<number> {
  const conditions = [
    eq(inboundMessages.organizationId, organizationId),
    // Exclude carrier STOP/HELP and other unattributed inbound messages
    // from the dashboard "Replies" tile — they're not real conversation
    // replies. NULL attribution_source (legacy rows) is also excluded.
    sql`${inboundMessages.attributionSource} IS NOT NULL AND ${inboundMessages.attributionSource} <> 'none'`,
  ];
  if (start) conditions.push(gte(inboundMessages.receivedAt, start));
  if (end) conditions.push(lt(inboundMessages.receivedAt, end));
  const rows = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(inboundMessages)
    .where(and(...conditions));
  return rows[0]?.c ?? 0;
}

export async function countSentEvents(
  organizationId: string,
  start: Date | null,
  end: Date | null,
): Promise<number> {
  const conditions = [
    eq(personalJourneyEvents.organizationId, organizationId),
    eq(personalJourneyEvents.eventType, "sent"),
  ];
  if (start) conditions.push(gte(personalJourneyEvents.createdAt, start));
  if (end) conditions.push(lt(personalJourneyEvents.createdAt, end));
  const rows = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(personalJourneyEvents)
    .where(and(...conditions));
  return rows[0]?.c ?? 0;
}

// ---------------------------------------------------------------------------
// Analytics snapshots — daily time-series of MindfulText's real reporting
// ---------------------------------------------------------------------------

/** Insert (or replace) the snapshot for one (org, date). One row per day. */
export async function upsertAnalyticsSnapshot(data: InsertAnalyticsSnapshot) {
  await db
    .delete(analyticsSnapshots)
    .where(
      and(
        eq(analyticsSnapshots.organizationId, data.organizationId),
        eq(analyticsSnapshots.snapshotDate, data.snapshotDate),
      ),
    );
  const [row] = await db.insert(analyticsSnapshots).values(data).returning();
  return row;
}

export async function hasAnalyticsSnapshot(
  organizationId: string,
  snapshotDate: string,
): Promise<boolean> {
  const [row] = await db
    .select({ id: analyticsSnapshots.id })
    .from(analyticsSnapshots)
    .where(
      and(
        eq(analyticsSnapshots.organizationId, organizationId),
        eq(analyticsSnapshots.snapshotDate, snapshotDate),
      ),
    )
    .limit(1);
  return !!row;
}

/** Ordered daily snapshots for an org, optional [fromDate, toDate) on the
 *  YYYY-MM-DD string (lexical compare works for ISO dates). */
export async function getAnalyticsSnapshots(
  organizationId: string,
  fromDate?: string | null,
  toDate?: string | null,
) {
  const conds = [eq(analyticsSnapshots.organizationId, organizationId)];
  if (fromDate) conds.push(gte(analyticsSnapshots.snapshotDate, fromDate));
  if (toDate) conds.push(lt(analyticsSnapshots.snapshotDate, toDate));
  return db
    .select()
    .from(analyticsSnapshots)
    .where(and(...conds))
    .orderBy(analyticsSnapshots.snapshotDate);
}

// ---------------------------------------------------------------------------
// Message events — granular per-text send/reply log
// ---------------------------------------------------------------------------

export async function recordMessageEvent(data: InsertMessageEvent) {
  const [row] = await db.insert(messageEvents).values(data).returning();
  return row;
}

/**
 * Replace the persisted opt-out (STOP) scan results for an org. We re-derive
 * these from MindfulText's message feed on demand, so this is idempotent:
 * delete the prior `optout-scan` rows, then insert the fresh set. Keeps a
 * durable STOP-event timeline even if the live feed window later shifts.
 */
export async function replaceOptOutScanEvents(
  organizationId: string,
  rows: InsertMessageEvent[],
): Promise<number> {
  await db
    .delete(messageEvents)
    .where(
      and(
        eq(messageEvents.organizationId, organizationId),
        eq(messageEvents.source, "optout-scan"),
      ),
    );
  if (rows.length) await db.insert(messageEvents).values(rows);
  return rows.length;
}

export async function countMessageEvents(
  organizationId: string,
  direction?: "send" | "reply",
): Promise<number> {
  const conds = [eq(messageEvents.organizationId, organizationId)];
  if (direction) conds.push(eq(messageEvents.direction, direction));
  const rows = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(messageEvents)
    .where(and(...conds));
  return rows[0]?.c ?? 0;
}

/** Calendar-window send count from the granular message_events log. */
export async function countMessageEventsInRange(
  organizationId: string,
  start: Date | null,
  end: Date | null,
  direction: "send" | "reply",
): Promise<number> {
  const conds = [
    eq(messageEvents.organizationId, organizationId),
    eq(messageEvents.direction, direction),
    sql`${messageEvents.source} <> 'optout-scan'`,
  ];
  if (start) conds.push(gte(messageEvents.occurredAt, start));
  if (end) conds.push(lt(messageEvents.occurredAt, end));
  const rows = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(messageEvents)
    .where(and(...conds));
  return rows[0]?.c ?? 0;
}

/**
 * Seed message_events from the existing tables (one-time per org): sends from
 * personalJourneyEvents (sent/advanced), replies from inboundMessages. No-op
 * if the org already has message_events rows, so it's safe to call repeatedly.
 */
export async function backfillMessageEvents(
  organizationId: string,
): Promise<{ sends: number; replies: number; skipped: boolean }> {
  const existing = await countMessageEvents(organizationId);
  if (existing > 0) return { sends: 0, replies: 0, skipped: true };

  const sendEvents = await db
    .select()
    .from(personalJourneyEvents)
    .where(
      and(
        eq(personalJourneyEvents.organizationId, organizationId),
        sql`${personalJourneyEvents.eventType} IN ('sent','advanced')`,
      ),
    );
  const sendRows: InsertMessageEvent[] = sendEvents.map((e) => ({
    organizationId,
    direction: "send",
    contactId: e.contactId,
    moduleId: e.moduleId,
    source: "backfill",
    occurredAt: e.createdAt ?? undefined,
  }));

  const inbound = await db
    .select()
    .from(inboundMessages)
    .where(eq(inboundMessages.organizationId, organizationId));
  const replyRows: InsertMessageEvent[] = inbound.map((m) => ({
    organizationId,
    direction: "reply",
    contactId: m.contactId,
    contactPhone: m.contactPhone,
    moduleId: m.moduleId,
    content: m.content,
    source: "backfill",
    occurredAt: m.receivedAt ?? undefined,
  }));

  if (sendRows.length) await db.insert(messageEvents).values(sendRows);
  if (replyRows.length) await db.insert(messageEvents).values(replyRows);
  return { sends: sendRows.length, replies: replyRows.length, skipped: false };
}

// ---------------------------------------------------------------------------
// Attribution events — UTM + cookie capture
// ---------------------------------------------------------------------------

export async function recordAttributionEvent(data: InsertAttributionEvent) {
  const [row] = await db.insert(attributionEvents).values(data).returning();
  return row;
}

/** Top UTM sources/campaigns for an org over a trailing window (days). */
export async function getAttributionSummary(
  organizationId: string,
  sinceDays?: number,
): Promise<{
  total: number;
  bySource: { key: string; count: number }[];
  byCampaign: { key: string; count: number }[];
}> {
  const conds = [eq(attributionEvents.organizationId, organizationId)];
  if (sinceDays && sinceDays > 0) {
    const since = new Date(Date.now() - sinceDays * 86_400_000);
    conds.push(gte(attributionEvents.occurredAt, since));
  }
  const where = and(...conds);

  const totalRows = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(attributionEvents)
    .where(where);

  const bySource = await db
    .select({
      key: sql<string>`coalesce(${attributionEvents.utmSource}, 'direct')`,
      count: sql<number>`count(*)::int`,
    })
    .from(attributionEvents)
    .where(where)
    .groupBy(sql`coalesce(${attributionEvents.utmSource}, 'direct')`)
    .orderBy(sql`count(*) desc`)
    .limit(10);

  const byCampaign = await db
    .select({
      key: sql<string>`coalesce(${attributionEvents.utmCampaign}, 'none')`,
      count: sql<number>`count(*)::int`,
    })
    .from(attributionEvents)
    .where(where)
    .groupBy(sql`coalesce(${attributionEvents.utmCampaign}, 'none')`)
    .orderBy(sql`count(*) desc`)
    .limit(10);

  return { total: totalRows[0]?.c ?? 0, bySource, byCampaign };
}

// ---------------------------------------------------------------------------
// Reshape rules
// ---------------------------------------------------------------------------

export async function createReshapeRule(data: InsertReshapeRule) {
  // Apply per-action default approval mode when caller didn't pass one.
  // skip / pause / resume default to "auto"; insert / ai_decide / reorder
  // default to "review" so a human signs off on more disruptive changes.
  const callerProvidedMode =
    data.approvalMode === "auto" || data.approvalMode === "review";
  const approvalMode = callerProvidedMode
    ? data.approvalMode
    : data.actionType === "skip" || data.actionType === "pause" || data.actionType === "resume"
      ? "auto"
      : "review";
  const [row] = await db.insert(reshapeRules).values({ ...data, approvalMode }).returning();
  return row;
}
export async function listReshapeRules(organizationId: string) {
  return db
    .select()
    .from(reshapeRules)
    .where(eq(reshapeRules.organizationId, organizationId))
    .orderBy(reshapeRules.priority);
}
export async function updateReshapeRule(id: number, data: Partial<InsertReshapeRule>) {
  const [row] = await db
    .update(reshapeRules)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(reshapeRules.id, id))
    .returning();
  return row;
}
export async function deleteReshapeRule(id: number) {
  await db.delete(reshapeRules).where(eq(reshapeRules.id, id));
}

// ---------------------------------------------------------------------------
// Pending changes
// ---------------------------------------------------------------------------

export async function listPendingChanges(organizationId: string, status?: string) {
  const conditions = [eq(pendingChanges.organizationId, organizationId)];
  if (status) conditions.push(eq(pendingChanges.status, status));
  return db
    .select()
    .from(pendingChanges)
    .where(and(...conditions))
    .orderBy(pendingChanges.createdAt);
}
export async function getPendingChange(id: number) {
  const [row] = await db.select().from(pendingChanges).where(eq(pendingChanges.id, id));
  return row ?? null;
}
export async function decidePendingChange(
  id: number,
  status: "approved" | "edited" | "rejected",
  decidedBy?: string,
  proposedSequence?: string[],
) {
  const patch: Record<string, unknown> = {
    status,
    decidedBy: decidedBy ?? null,
    decidedAt: new Date(),
  };
  if (proposedSequence) patch.proposedSequence = proposedSequence;
  const [row] = await db
    .update(pendingChanges)
    .set(patch)
    .where(eq(pendingChanges.id, id))
    .returning();
  return row;
}
export async function countPendingChanges(organizationId: string) {
  const rows = await db
    .select()
    .from(pendingChanges)
    .where(
      and(
        eq(pendingChanges.organizationId, organizationId),
        eq(pendingChanges.status, "pending"),
      ),
    );
  return rows.length;
}

// ---------------------------------------------------------------------------
// Personal journey templates
// ---------------------------------------------------------------------------

export async function listPersonalJourneyTemplates(organizationId: string) {
  return db
    .select()
    .from(personalJourneyTemplates)
    .where(eq(personalJourneyTemplates.organizationId, organizationId));
}
export async function upsertPersonalJourneyTemplate(data: InsertPersonalJourneyTemplate) {
  const existing = await db
    .select()
    .from(personalJourneyTemplates)
    .where(
      and(
        eq(personalJourneyTemplates.organizationId, data.organizationId),
        // tag may be null for the default template
        data.tag
          ? eq(personalJourneyTemplates.tag, data.tag)
          : sql`${personalJourneyTemplates.tag} IS NULL`,
      ),
    );
  const moduleIds = (data.moduleIds as string[] | undefined) ?? [];
  if (existing.length > 0) {
    const [row] = await db
      .update(personalJourneyTemplates)
      .set({ moduleIds, updatedAt: new Date() })
      .where(eq(personalJourneyTemplates.id, existing[0].id))
      .returning();
    return row;
  }
  const [row] = await db
    .insert(personalJourneyTemplates)
    .values({ ...data, moduleIds })
    .returning();
  return row;
}
export async function deletePersonalJourneyTemplate(id: number) {
  await db.delete(personalJourneyTemplates).where(eq(personalJourneyTemplates.id, id));
}

// ---------------------------------------------------------------------------
// Audience briefs — markdown guidance per (org, tag)
// ---------------------------------------------------------------------------

export async function listAudienceBriefs(organizationId: string) {
  return db
    .select()
    .from(audienceBriefs)
    .where(eq(audienceBriefs.organizationId, organizationId));
}

export async function getAudienceBrief(organizationId: string, tag: string) {
  const [row] = await db
    .select()
    .from(audienceBriefs)
    .where(
      and(
        eq(audienceBriefs.organizationId, organizationId),
        eq(audienceBriefs.tag, tag),
      ),
    );
  return row ?? null;
}

export async function upsertAudienceBrief(data: InsertAudienceBrief) {
  const existing = await getAudienceBrief(data.organizationId, data.tag);
  if (existing) {
    const [row] = await db
      .update(audienceBriefs)
      .set({ brief: data.brief ?? "", updatedAt: new Date() })
      .where(eq(audienceBriefs.id, existing.id))
      .returning();
    return row;
  }
  const [row] = await db.insert(audienceBriefs).values(data).returning();
  return row;
}

// ---------------------------------------------------------------------------
// Cross-entity ownership lookup
// ---------------------------------------------------------------------------
//
// Used by routes that accept an entity `:id` without an `:orgId` segment to
// verify the entity actually belongs to the caller's session org before
// reading or mutating it. Returns the row's organizationId (string), or
// `null` when the row doesn't exist. Routes turn `null` into 404 and a
// mismatch into 403.

export type OwnedEntityKind =
  | "contentDraft"
  | "draftMessage"
  | "agentMemory"
  | "agentRule"
  | "contentProgram"
  | "entitySnapshot"
  | "reshapeRule"
  | "pendingChange"
  | "personalJourneyTemplate";

export async function getEntityOrgId(
  kind: OwnedEntityKind,
  id: number,
): Promise<string | null> {
  if (!Number.isFinite(id)) return null;
  switch (kind) {
    case "contentDraft": {
      const [row] = await db
        .select({ organizationId: contentDrafts.organizationId })
        .from(contentDrafts)
        .where(eq(contentDrafts.id, id));
      return row?.organizationId ?? null;
    }
    case "draftMessage": {
      const [row] = await db
        .select({ organizationId: draftMessages.organizationId })
        .from(draftMessages)
        .where(eq(draftMessages.id, id));
      return row?.organizationId ?? null;
    }
    case "agentMemory": {
      const [row] = await db
        .select({ organizationId: agentMemory.organizationId })
        .from(agentMemory)
        .where(eq(agentMemory.id, id));
      return row?.organizationId ?? null;
    }
    case "agentRule": {
      const [row] = await db
        .select({ organizationId: agentRules.organizationId })
        .from(agentRules)
        .where(eq(agentRules.id, id));
      return row?.organizationId ?? null;
    }
    case "contentProgram": {
      const [row] = await db
        .select({ organizationId: contentPrograms.organizationId })
        .from(contentPrograms)
        .where(eq(contentPrograms.id, id));
      return row?.organizationId ?? null;
    }
    case "entitySnapshot": {
      const [row] = await db
        .select({ organizationId: entitySnapshots.organizationId })
        .from(entitySnapshots)
        .where(eq(entitySnapshots.id, id));
      return row?.organizationId ?? null;
    }
    case "reshapeRule": {
      const [row] = await db
        .select({ organizationId: reshapeRules.organizationId })
        .from(reshapeRules)
        .where(eq(reshapeRules.id, id));
      return row?.organizationId ?? null;
    }
    case "pendingChange": {
      const [row] = await db
        .select({ organizationId: pendingChanges.organizationId })
        .from(pendingChanges)
        .where(eq(pendingChanges.id, id));
      return row?.organizationId ?? null;
    }
    case "personalJourneyTemplate": {
      const [row] = await db
        .select({ organizationId: personalJourneyTemplates.organizationId })
        .from(personalJourneyTemplates)
        .where(eq(personalJourneyTemplates.id, id));
      return row?.organizationId ?? null;
    }
  }
}

export async function deleteAudienceBrief(organizationId: string, tag: string) {
  await db
    .delete(audienceBriefs)
    .where(
      and(
        eq(audienceBriefs.organizationId, organizationId),
        eq(audienceBriefs.tag, tag),
      ),
    );
}

// ---------------------------------------------------------------------------
// Segments — saved multi-tag cohorts
// ---------------------------------------------------------------------------

export async function listSegments(organizationId: string): Promise<Segment[]> {
  return db
    .select()
    .from(segments)
    .where(eq(segments.organizationId, organizationId))
    .orderBy(segments.name);
}

export async function getSegment(
  organizationId: string,
  id: number,
): Promise<Segment | null> {
  const [row] = await db
    .select()
    .from(segments)
    .where(
      and(eq(segments.organizationId, organizationId), eq(segments.id, id)),
    )
    .limit(1);
  return row ?? null;
}

export async function createSegment(data: {
  organizationId: string;
  name: string;
  includeTags: string[];
  excludeTags?: string[];
  matchMode?: string;
}): Promise<Segment> {
  const [row] = await db
    .insert(segments)
    .values({
      organizationId: data.organizationId,
      name: data.name,
      includeTags: data.includeTags,
      excludeTags: data.excludeTags ?? [],
      matchMode: data.matchMode ?? "OR",
    })
    .returning();
  return row;
}

export async function updateSegment(
  organizationId: string,
  id: number,
  patch: {
    name?: string;
    includeTags?: string[];
    excludeTags?: string[];
    matchMode?: string;
  },
): Promise<Segment | null> {
  const [row] = await db
    .update(segments)
    .set({ ...patch, updatedAt: new Date() })
    .where(
      and(eq(segments.organizationId, organizationId), eq(segments.id, id)),
    )
    .returning();
  return row ?? null;
}

export async function deleteSegment(organizationId: string, id: number) {
  await db
    .delete(segments)
    .where(
      and(eq(segments.organizationId, organizationId), eq(segments.id, id)),
    );
}

export async function getPersonalJourneyTemplateById(
  organizationId: string,
  id: number,
) {
  const [row] = await db
    .select()
    .from(personalJourneyTemplates)
    .where(
      and(
        eq(personalJourneyTemplates.organizationId, organizationId),
        eq(personalJourneyTemplates.id, id),
      ),
    )
    .limit(1);
  return row ?? null;
}

// ---------------------------------------------------------------------------
// Subscriber page tokens — tokenized public links per contact
// ---------------------------------------------------------------------------

/** Reuse the contact's active link if one exists, otherwise mint a new one. */
export async function getOrCreatePageToken(
  organizationId: string,
  contactId: string,
) {
  const [existing] = await db
    .select()
    .from(subscriberPageTokens)
    .where(
      and(
        eq(subscriberPageTokens.organizationId, organizationId),
        eq(subscriberPageTokens.contactId, contactId),
        eq(subscriberPageTokens.active, true),
      ),
    )
    .limit(1);
  if (existing) return existing;

  const token = randomBytes(24).toString("base64url");
  const [row] = await db
    .insert(subscriberPageTokens)
    .values({ organizationId, contactId, token, active: true })
    .returning();
  return row;
}

/** Resolve an active token to its row (the only auth for the public page). */
export async function getActivePageToken(token: string) {
  const [row] = await db
    .select()
    .from(subscriberPageTokens)
    .where(
      and(
        eq(subscriberPageTokens.token, token),
        eq(subscriberPageTokens.active, true),
      ),
    )
    .limit(1);
  return row ?? null;
}

export async function revokePageToken(organizationId: string, id: number) {
  await db
    .update(subscriberPageTokens)
    .set({ active: false })
    .where(
      and(
        eq(subscriberPageTokens.id, id),
        eq(subscriberPageTokens.organizationId, organizationId),
      ),
    );
}

export async function touchPageTokenVisit(token: string) {
  await db
    .update(subscriberPageTokens)
    .set({ lastVisitAt: new Date() })
    .where(eq(subscriberPageTokens.token, token));
}

// ---------------------------------------------------------------------------
// Published content library — web-visible copies grouped by topic
// ---------------------------------------------------------------------------

export async function createPublishedContent(data: InsertPublishedContent) {
  const [row] = await db.insert(publishedContent).values(data).returning();
  return row;
}

export async function listPublishedContent(
  organizationId: string,
  opts?: { topic?: string; onlyPublished?: boolean },
) {
  const conds = [eq(publishedContent.organizationId, organizationId)];
  if (opts?.topic) conds.push(eq(publishedContent.topic, opts.topic));
  if (opts?.onlyPublished) conds.push(eq(publishedContent.published, true));
  return db
    .select()
    .from(publishedContent)
    .where(and(...conds))
    .orderBy(desc(publishedContent.createdAt));
}

/** Published items whose topic matches any of the contact's interests. */
export async function getPublishedContentByTopics(
  organizationId: string,
  topics: string[],
  limit = 12,
) {
  if (topics.length === 0) return [];
  return db
    .select()
    .from(publishedContent)
    .where(
      and(
        eq(publishedContent.organizationId, organizationId),
        eq(publishedContent.published, true),
        sql`${publishedContent.topic} = any(${topics})`,
      ),
    )
    .orderBy(desc(publishedContent.createdAt))
    .limit(limit);
}

export async function setPublishedContentVisibility(
  organizationId: string,
  id: number,
  published: boolean,
) {
  const [row] = await db
    .update(publishedContent)
    .set({ published, updatedAt: new Date() })
    .where(
      and(
        eq(publishedContent.id, id),
        eq(publishedContent.organizationId, organizationId),
      ),
    )
    .returning();
  return row ?? null;
}

export async function deletePublishedContent(organizationId: string, id: number) {
  await db
    .delete(publishedContent)
    .where(
      and(
        eq(publishedContent.id, id),
        eq(publishedContent.organizationId, organizationId),
      ),
    );
}

export async function updatePublishedContent(
  organizationId: string,
  id: number,
  patch: Partial<
    Pick<
      InsertPublishedContent,
      "title" | "body" | "topic" | "theme" | "complexity" | "published"
    >
  >,
) {
  const [row] = await db
    .update(publishedContent)
    .set({ ...patch, updatedAt: new Date() })
    .where(
      and(
        eq(publishedContent.id, id),
        eq(publishedContent.organizationId, organizationId),
      ),
    )
    .returning();
  return row ?? null;
}

// ---------------------------------------------------------------------------
// Harvested links — staged URLs pulled from MindfulText module texts
// ---------------------------------------------------------------------------

/** Insert staged links, silently skipping URLs already harvested for the org. */
export async function insertHarvestedLinks(rows: InsertHarvestedLink[]) {
  if (rows.length === 0) return [] as HarvestedLink[];
  return db
    .insert(harvestedLinks)
    .values(rows)
    .onConflictDoNothing({
      target: [harvestedLinks.organizationId, harvestedLinks.url],
    })
    .returning();
}

export async function listHarvestedLinks(
  organizationId: string,
  status?: string,
) {
  const conds = [eq(harvestedLinks.organizationId, organizationId)];
  if (status) conds.push(eq(harvestedLinks.status, status));
  return db
    .select()
    .from(harvestedLinks)
    .where(and(...conds))
    .orderBy(desc(harvestedLinks.likelyMeditation), desc(harvestedLinks.id));
}

export async function getHarvestedLink(organizationId: string, id: number) {
  const [row] = await db
    .select()
    .from(harvestedLinks)
    .where(
      and(
        eq(harvestedLinks.id, id),
        eq(harvestedLinks.organizationId, organizationId),
      ),
    )
    .limit(1);
  return row ?? null;
}

export async function updateHarvestedLink(
  organizationId: string,
  id: number,
  patch: Partial<
    Pick<
      InsertHarvestedLink,
      "status" | "suggestedTitle" | "suggestedTheme" | "publishedContentId"
    >
  >,
) {
  const [row] = await db
    .update(harvestedLinks)
    .set({ ...patch, updatedAt: new Date() })
    .where(
      and(
        eq(harvestedLinks.id, id),
        eq(harvestedLinks.organizationId, organizationId),
      ),
    )
    .returning();
  return row ?? null;
}

/**
 * When a published library item is deleted, put the harvested link it came
 * from back in the review queue so the URL can be re-published later
 * (the org+url unique index blocks re-harvesting it).
 */
export async function resetHarvestedLinkForPublishedContent(
  organizationId: string,
  publishedContentId: number,
) {
  await db
    .update(harvestedLinks)
    .set({ status: "staged", publishedContentId: null, updatedAt: new Date() })
    .where(
      and(
        eq(harvestedLinks.organizationId, organizationId),
        eq(harvestedLinks.publishedContentId, publishedContentId),
      ),
    );
}

// ---------------------------------------------------------------------------
// Page events — public profile page view log
// ---------------------------------------------------------------------------

export async function recordPageEvent(data: InsertPageEvent) {
  const [row] = await db.insert(pageEvents).values(data).returning();
  return row;
}

/** Total page views and unique contacts reached over a trailing window. */
export async function getPageViewStats(
  organizationId: string,
  sinceDays?: number,
): Promise<{ totalViews: number; uniqueContacts: number }> {
  const conds = [eq(pageEvents.organizationId, organizationId)];
  if (sinceDays && sinceDays > 0) {
    const since = new Date(Date.now() - sinceDays * 86_400_000);
    conds.push(gte(pageEvents.occurredAt, since));
  }
  const where = and(...conds);
  const [row] = await db
    .select({
      totalViews: sql<number>`count(*)::int`,
      uniqueContacts: sql<number>`count(distinct ${pageEvents.contactId})::int`,
    })
    .from(pageEvents)
    .where(where);
  return {
    totalViews: row?.totalViews ?? 0,
    uniqueContacts: row?.uniqueContacts ?? 0,
  };
}

// ---------------------------------------------------------------------------
// Subscriber page settings — one row per org, upserted
// ---------------------------------------------------------------------------

/** The built-in defaults shown before an org has saved any page settings. */
export function defaultPageSettings(): Omit<PageSettings, "id" | "createdAt" | "updatedAt"> {
  return {
    organizationId: "",
    brandName: "MindfulText",
    tagline: "Your space to revisit and explore.",
    accentColor: "#6366f1",
    footerText: "MindfulText",
    showTopics: true,
    topicsLabel: "Your topics",
    showReceived: true,
    receivedLabel: "Messages you’ve received",
    showLibrary: true,
    libraryLabel: "More for you",
  };
}

/** Return the org's saved page settings, or null when none exist yet. */
export async function getPageSettings(
  organizationId: string,
): Promise<PageSettings | null> {
  const [row] = await db
    .select()
    .from(pageSettings)
    .where(eq(pageSettings.organizationId, organizationId))
    .limit(1);
  return row ?? null;
}

/** Insert or update the org's page settings (one row per org). */
export async function upsertPageSettings(
  organizationId: string,
  data: Partial<Omit<InsertPageSettings, "organizationId">>,
): Promise<PageSettings> {
  const existing = await getPageSettings(organizationId);
  if (existing) {
    const [updated] = await db
      .update(pageSettings)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(pageSettings.organizationId, organizationId))
      .returning();
    return updated;
  }
  const [created] = await db
    .insert(pageSettings)
    .values({ ...data, organizationId })
    .returning();
  return created;
}
