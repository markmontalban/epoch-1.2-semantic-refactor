/**
 * Reshape-rule evaluator + dispatcher.
 *
 * Loads org rules in priority order and produces a list of proposed reshape
 * actions for an inbound message. Each action is then dispatched: applied
 * immediately if approval mode is "auto", or saved to the pending_changes
 * queue if "review".
 */
import { and, asc, eq } from "drizzle-orm";
import { db } from "./db";
import {
  reshapeRules,
  pendingChanges,
  type ReshapeRule,
  type PersonalJourney,
} from "../shared/schema";
import {
  bootstrapJourneyForContact,
  getPersonalJourney,
  getNextModule,
  insertNext,
  skipNext,
  reorder,
  pause,
  resume,
  advance,
  launchNextForContact,
  type EventSource,
} from "./personalJourney";
import { recordContactActivity } from "./contactMemory";
import { AGENT_SAFE_MODE } from "./agentSafety";
import { complete } from "./ai";
import { logTokenUsage } from "./storage";

/**
 * Ask the AI to propose a queue mutation given the inbound message + current
 * queue + available modules. Returns parsed ops + a one-line reason. Falls
 * back to a deterministic skip when the AI key isn't configured or the
 * response can't be parsed.
 */
async function proposeAiReshape(opts: {
  organizationId: string;
  inboundContent: string;
  currentQueue: string[];
  currentIndex: number;
  modulesAvailable: string[];
}): Promise<{ ops: ReshapeOp[]; reason: string }> {
  const fallbackSkipped = opts.currentQueue[opts.currentIndex] ?? null;
  const fallback = (): { ops: ReshapeOp[]; reason: string } => ({
    ops: fallbackSkipped
      ? [{ op: "skip", moduleId: fallbackSkipped, at: opts.currentIndex }]
      : [],
    reason: "AI unavailable — defaulting to skip next module",
  });

  if (!process.env.OPENROUTER_API_KEY) return fallback();

  const userPrompt = `A contact replied to our SMS journey.

Their message: "${opts.inboundContent}"

Their queued upcoming modules (in order, first is next to send):
${opts.currentQueue.slice(opts.currentIndex).map((m, i) => `${i + 1}. ${m}`).join("\n") || "(empty)"}

Available modules in this org:
${opts.modulesAvailable.length ? opts.modulesAvailable.join(", ") : "(none provided)"}

Decide ONE of these reshape actions to best serve the contact:
- {"op":"skip","moduleId":"<id>","at":${opts.currentIndex}}
- {"op":"insert","moduleId":"<id>","at":${opts.currentIndex}}
- {"op":"reorder","newQueue":["<id>","<id>",...]}
- {"op":"pause"}
- {"op":"resume"}

Return ONLY a JSON object: {"ops":[...one op...],"reason":"<one short sentence>"}`;

  try {
    const result = await complete({
      model: process.env.OPENROUTER_MODEL?.trim() || "openai/gpt-oss-20b:free",
      systemPrompt: "You decide how to reshape an SMS journey queue based on a contact's reply. Be concise and return strict JSON.",
      userPrompt,
      temperature: 0.4,
      maxTokens: 400,
    });

    await logTokenUsage({
      organizationId: opts.organizationId,
      taskType: "reshape_propose",
      model: result.model,
      promptTokens: result.promptTokens,
      completionTokens: result.completionTokens,
      totalTokens: result.totalTokens,
      estimatedCostUsd: result.estimatedCostUsd,
      referenceType: "reshape",
    }).catch(() => {});

    // Strip code fences if any.
    const raw = result.content.trim().replace(/^```(?:json)?\s*|\s*```$/g, "");
    const parsed = JSON.parse(raw) as { ops?: ReshapeOp[]; reason?: string };
    if (Array.isArray(parsed.ops) && parsed.ops.length > 0) {
      return {
        ops: parsed.ops.filter((o) => o && typeof o.op === "string"),
        reason: parsed.reason ?? "AI proposed reshape",
      };
    }
  } catch (err) {
    console.warn("[reshape] AI proposer failed — falling back:", err instanceof Error ? err.message : err);
  }
  return fallback();
}

export type ReshapeOp =
  | { op: "insert"; moduleId: string; at: number }
  | { op: "skip"; moduleId: string | null; at: number }
  | { op: "reorder"; newQueue: string[] }
  | { op: "pause" }
  | { op: "resume" }
  | { op: "advance" };

export interface ReshapeProposal {
  rule: ReshapeRule;
  ops: ReshapeOp[];
  reason: string;
  proposedSequence: string[];
  currentSequence: string[];
}

function applyOpsToQueue(
  current: PersonalJourney,
  ops: ReshapeOp[],
): { queue: string[]; pausedFlag: boolean | null } {
  let queue = [...current.moduleIds];
  let pausedFlag: boolean | null = null;
  let cursor = current.currentIndex;

  for (const op of ops) {
    if (op.op === "insert") {
      queue.splice(op.at ?? cursor, 0, op.moduleId);
    } else if (op.op === "skip") {
      // simulate skip by advancing cursor; queue array unchanged but the
      // proposed-sequence below trims out the skipped one for clarity.
      queue.splice(op.at ?? cursor, 1);
    } else if (op.op === "reorder") {
      queue = [...op.newQueue];
    } else if (op.op === "pause") {
      pausedFlag = true;
    } else if (op.op === "resume") {
      pausedFlag = false;
    }
  }
  return { queue, pausedFlag };
}

function matchKeyword(content: string, value: string): boolean {
  if (!value) return false;
  return content.toLowerCase().includes(value.toLowerCase());
}

/**
 * Lightweight intent classifier. Real impl could call AI; here we use simple
 * keyword buckets so the runtime works without an OpenRouter key.
 */
function matchIntent(content: string, intent: string): boolean {
  const text = content.toLowerCase();
  const buckets: Record<string, string[]> = {
    stop: ["stop", "unsubscribe", "quit", "remove me"],
    help: ["help", "support", "?"],
    pause: ["pause", "break", "later"],
    resume: ["resume", "back", "continue"],
    interested: ["yes", "interested", "tell me more", "more info"],
    feedback: ["love", "great", "thank", "amazing", "hate", "bad"],
  };
  const keywords = buckets[intent.toLowerCase()] ?? [intent.toLowerCase()];
  return keywords.some((k) => text.includes(k));
}

/**
 * Evaluate every active rule against the inbound message. Stops at the first
 * matching rule unless that rule has continueAfter=true.
 */
export async function evaluateRules(opts: {
  organizationId: string;
  contactId: string;
  inboundContent: string;
  currentJourney: PersonalJourney;
  modulesAvailable?: string[];
}): Promise<ReshapeProposal[]> {
  const rawRules = await db
    .select()
    .from(reshapeRules)
    .where(
      and(
        eq(reshapeRules.organizationId, opts.organizationId),
        eq(reshapeRules.enabled, true),
      ),
    )
    .orderBy(asc(reshapeRules.priority));

  // Trigger-type precedence: keyword first (most specific), then intent,
  // then any_reply (catch-all). Within each tier we honor numeric priority.
  const tierOf = (t: string) => (t === "keyword" ? 0 : t === "intent" ? 1 : 2);
  const rules = [...rawRules].sort((a, b) => {
    const tier = tierOf(a.triggerType) - tierOf(b.triggerType);
    return tier !== 0 ? tier : a.priority - b.priority;
  });

  const proposals: ReshapeProposal[] = [];

  for (const rule of rules) {
    let matched = false;
    if (rule.triggerType === "any_reply") matched = true;
    else if (rule.triggerType === "keyword") matched = matchKeyword(opts.inboundContent, rule.triggerValue ?? "");
    else if (rule.triggerType === "intent") matched = matchIntent(opts.inboundContent, rule.triggerValue ?? "");
    if (!matched) continue;

    const params = (rule.actionParams as Record<string, unknown> | null) ?? {};
    const ops: ReshapeOp[] = [];
    let reason = `rule "${rule.name}" matched`;

    if (rule.actionType === "insert") {
      const moduleId = String(params.moduleId ?? "");
      if (moduleId) ops.push({ op: "insert", moduleId, at: opts.currentJourney.currentIndex });
    } else if (rule.actionType === "skip") {
      const skipped = opts.currentJourney.moduleIds[opts.currentJourney.currentIndex] ?? null;
      ops.push({ op: "skip", moduleId: skipped, at: opts.currentJourney.currentIndex });
    } else if (rule.actionType === "reorder") {
      const newQueue = Array.isArray(params.newQueue) ? params.newQueue.map(String) : opts.currentJourney.moduleIds;
      ops.push({ op: "reorder", newQueue });
    } else if (rule.actionType === "pause") {
      ops.push({ op: "pause" });
    } else if (rule.actionType === "resume") {
      ops.push({ op: "resume" });
    } else if (rule.actionType === "ai_decide") {
      const proposed = await proposeAiReshape({
        organizationId: opts.organizationId,
        inboundContent: opts.inboundContent,
        currentQueue: opts.currentJourney.moduleIds,
        currentIndex: opts.currentJourney.currentIndex,
        modulesAvailable: opts.modulesAvailable ?? [],
      });
      ops.push(...proposed.ops);
      reason = `AI: ${proposed.reason}`;
    }

    if (ops.length > 0) {
      const sim = applyOpsToQueue(opts.currentJourney, ops);
      proposals.push({
        rule,
        ops,
        reason,
        currentSequence: opts.currentJourney.moduleIds.slice(opts.currentJourney.currentIndex),
        proposedSequence: sim.queue.slice(opts.currentJourney.currentIndex),
      });
    }

    if (!rule.continueAfter) break;
  }

  return proposals;
}

/** Default approval mode for an action when the rule itself doesn't override. */
export function defaultApprovalMode(actionType: string): "auto" | "review" {
  if (actionType === "insert" || actionType === "ai_decide") return "review";
  return "auto"; // skip, pause, resume
}

/**
 * Dispatch a proposal: apply auto, or queue a pending_changes row for review.
 * Returns either the applied PersonalJourney or the created PendingChange row.
 */
export async function dispatchProposal(opts: {
  organizationId: string;
  contactId: string;
  inboundMessageId?: number;
  proposal: ReshapeProposal;
  storedCookies?: string;
}): Promise<{ kind: "applied"; ruleId: number } | { kind: "pending"; pendingId: number }> {
  const { proposal } = opts;
  const mode = proposal.rule.approvalMode || defaultApprovalMode(proposal.rule.actionType);

  if (mode === "review") {
    const [row] = await db
      .insert(pendingChanges)
      .values({
        organizationId: opts.organizationId,
        contactId: opts.contactId,
        inboundMessageId: opts.inboundMessageId ?? null,
        ruleId: proposal.rule.id,
        currentSequence: proposal.currentSequence,
        proposedSequence: proposal.proposedSequence,
        proposedOps: proposal.ops as unknown as Record<string, unknown>,
        aiReason: proposal.reason,
        status: "pending",
      })
      .returning();
    return { kind: "pending", pendingId: row.id };
  }

  // auto — apply immediately via the runtime
  await applyOps({
    organizationId: opts.organizationId,
    contactId: opts.contactId,
    ops: proposal.ops,
    source: "auto",
    ruleId: proposal.rule.id,
    reason: proposal.reason,
    inboundMessageId: opts.inboundMessageId,
  });

  // Memory: record that a rule fired (best-effort, non-blocking).
  recordContactActivity({
    organizationId: opts.organizationId,
    contactId: opts.contactId,
    note: `auto-reshape "${proposal.rule.name}" → ${proposal.ops.map((o) => o.op).join(", ")}`,
    storedCookies: opts.storedCookies,
  }).catch(() => {});

  // Agent-safe mode: the queue ops above were applied automatically, but the
  // actual outbound send is never fired without operator approval. Queue a
  // send-only pending change (when there's a next message to send) so the
  // founder can approve it in the Changes review screen.
  if (AGENT_SAFE_MODE) {
    const journey = await getPersonalJourney(opts.organizationId, opts.contactId);
    const nextModule = journey ? getNextModule(journey) : null;
    if (!nextModule || !journey) {
      return { kind: "applied", ruleId: proposal.rule.id };
    }
    const upcoming = journey.moduleIds.slice(journey.currentIndex);
    const [row] = await db
      .insert(pendingChanges)
      .values({
        organizationId: opts.organizationId,
        contactId: opts.contactId,
        inboundMessageId: opts.inboundMessageId ?? null,
        ruleId: proposal.rule.id,
        currentSequence: upcoming,
        proposedSequence: upcoming,
        proposedOps: [],
        aiReason: `${proposal.reason} — queue updated automatically; approve to send the next message`,
        sendRequired: true,
        status: "pending",
      })
      .returning();
    return { kind: "pending", pendingId: row.id };
  }

  // Legacy behavior (AGENT_SAFE_MODE off): push the next module via launch
  // (best-effort) so the personal queue advances on the wire immediately.
  if (opts.storedCookies) {
    launchNextForContact({
      organizationId: opts.organizationId,
      contactId: opts.contactId,
      storedCookies: opts.storedCookies,
      source: "auto",
    }).catch(() => {});
  }
  return { kind: "applied", ruleId: proposal.rule.id };
}

/** Apply a list of reshape ops to a contact's queue (single writer). */
export async function applyOps(opts: {
  organizationId: string;
  contactId: string;
  ops: ReshapeOp[];
  source: EventSource;
  ruleId?: number;
  reason?: string;
  inboundMessageId?: number;
}): Promise<void> {
  await bootstrapJourneyForContact(opts.organizationId, opts.contactId);
  for (const op of opts.ops) {
    if (op.op === "insert") {
      await insertNext(opts.organizationId, opts.contactId, op.moduleId, opts.source, opts.ruleId, opts.reason, opts.inboundMessageId);
    } else if (op.op === "skip") {
      await skipNext(opts.organizationId, opts.contactId, opts.source, opts.ruleId, opts.reason, opts.inboundMessageId);
    } else if (op.op === "reorder") {
      await reorder(opts.organizationId, opts.contactId, op.newQueue, opts.source, opts.ruleId, opts.reason, opts.inboundMessageId);
    } else if (op.op === "pause") {
      await pause(opts.organizationId, opts.contactId, opts.source, opts.ruleId, opts.reason, opts.inboundMessageId);
    } else if (op.op === "resume") {
      await resume(opts.organizationId, opts.contactId, opts.source, opts.ruleId, opts.reason, opts.inboundMessageId);
    } else if (op.op === "advance") {
      await advance(opts.organizationId, opts.contactId, opts.source, opts.reason);
    }
  }
}
