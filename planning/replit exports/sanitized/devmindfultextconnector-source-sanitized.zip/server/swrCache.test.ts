// Unit tests for the in-process stale-while-revalidate cache.
//
// Run with: npx tsx --test server/swrCache.test.ts
//
// Covers the four behaviours the dashboard relies on:
//   1. Fresh hit  — a repeat call within the TTL returns the cached value
//      without re-invoking the fetcher (and reports stale:false).
//   2. Stale hit  — past the TTL the old value is served immediately with
//      stale:true while a single (deduped) background refresh repopulates it.
//   3. Force      — { force:true } bypasses any cached value and awaits a
//      fresh fetch, replacing the entry.
//   4. invalidate — invalidateSwr(prefix) drops only matching keys; the
//      no-arg form clears the whole store.

import test from "node:test";
import assert from "node:assert/strict";

import { swr, invalidateSwr } from "./swrCache";

// A fetcher factory that counts how many times it ran and returns a fresh
// sequential value each time, so we can prove when a recompute happened.
function counter(start = 1) {
  let n = start;
  let calls = 0;
  const fetcher = async () => {
    calls += 1;
    return n++;
  };
  return {
    fetcher,
    get calls() {
      return calls;
    },
  };
}

const tick = (ms = 0) => new Promise((r) => setTimeout(r, ms));

test("fresh hit: repeat call within TTL returns cached value, no recompute", async () => {
  invalidateSwr();
  const c = counter();
  const key = "test-fresh|org1";

  const first = await swr(key, 10_000, c.fetcher);
  assert.equal(first.value, 1);
  assert.equal(first.stale, false);

  const second = await swr(key, 10_000, c.fetcher);
  assert.equal(second.value, 1, "second call returns the same cached value");
  assert.equal(second.stale, false);
  assert.equal(second.cachedAt, first.cachedAt, "cachedAt is stable on a hit");
  assert.equal(c.calls, 1, "fetcher only ran once");
});

test("miss: first call computes and stores with stale:false", async () => {
  invalidateSwr();
  const c = counter(42);
  const r = await swr("test-miss|org1", 10_000, c.fetcher);
  assert.equal(r.value, 42);
  assert.equal(r.stale, false);
  assert.equal(c.calls, 1);
});

test("stale hit: serves old value with stale:true then background-refreshes (deduped)", async () => {
  invalidateSwr();
  const c = counter();
  const key = "test-stale|org1";

  const first = await swr(key, 20, c.fetcher);
  assert.equal(first.value, 1);

  // Let the entry go stale.
  await tick(40);

  // Fire two concurrent stale reads — both should serve the stale value and
  // only ONE background refresh should be triggered (refreshing dedupe).
  const [a, b] = await Promise.all([
    swr(key, 20, c.fetcher),
    swr(key, 20, c.fetcher),
  ]);
  assert.equal(a.value, 1, "stale value served immediately");
  assert.equal(a.stale, true);
  assert.equal(b.value, 1);
  assert.equal(b.stale, true);

  // Wait for the background refresh to settle.
  await tick(30);
  assert.equal(c.calls, 2, "exactly one background refresh ran (deduped)");

  // Read with a long TTL so the freshly-refreshed entry is unambiguously a
  // fresh hit (the 20ms TTL above would expire it again before we can read).
  const third = await swr(key, 10_000, c.fetcher);
  assert.equal(third.value, 2, "refreshed value now served");
  assert.equal(third.stale, false);
  assert.ok(third.cachedAt > first.cachedAt, "cachedAt advanced after refresh");
});

test("stale refresh failure keeps the stale value and allows a later retry", async () => {
  invalidateSwr();
  const key = "test-stale-fail|org1";
  let calls = 0;
  const flaky = async () => {
    calls += 1;
    if (calls === 1) return 100; // initial populate
    if (calls === 2) throw new Error("upstream down"); // first refresh fails
    return 200; // later retry succeeds
  };

  const first = await swr(key, 20, flaky);
  assert.equal(first.value, 100);

  await tick(40);
  const stale = await swr(key, 20, flaky); // triggers failing refresh
  assert.equal(stale.value, 100);
  assert.equal(stale.stale, true);

  await tick(30); // let the failing refresh reject
  assert.equal(calls, 2);

  // Still stale (refresh failed), so another read retries the refresh.
  const retry = await swr(key, 20, flaky);
  assert.equal(retry.value, 100, "stale value retained after failed refresh");
  assert.equal(retry.stale, true);

  await tick(30);
  assert.equal(calls, 3, "a later read retried the refresh");

  // Long TTL so the freshly-repopulated entry reads as a fresh hit.
  const ok = await swr(key, 10_000, flaky);
  assert.equal(ok.value, 200, "retry eventually repopulates the entry");
  assert.equal(ok.stale, false);
});

test("force: bypasses a fresh cached value and recomputes", async () => {
  invalidateSwr();
  const c = counter();
  const key = "test-force|org1";

  const first = await swr(key, 10_000, c.fetcher);
  assert.equal(first.value, 1);

  await tick(2); // guarantee the new cachedAt lands in a later millisecond
  const forced = await swr(key, 10_000, c.fetcher, { force: true });
  assert.equal(forced.value, 2, "force recomputed even though the entry was fresh");
  assert.equal(forced.stale, false);
  assert.equal(c.calls, 2);
  assert.ok(forced.cachedAt > first.cachedAt, "force produced a new cachedAt");

  // The forced value is now the cached one.
  const after = await swr(key, 10_000, c.fetcher);
  assert.equal(after.value, 2);
  assert.equal(after.cachedAt, forced.cachedAt);
  assert.equal(c.calls, 2, "subsequent hit did not recompute");
});

test("invalidateSwr(prefix): drops only matching keys", async () => {
  invalidateSwr();
  const a = counter(1);
  const b = counter(100);

  await swr("dashboard-stats|orgA", 10_000, a.fetcher); // value 1
  await swr("attrition|orgA", 10_000, b.fetcher); // value 100
  assert.equal(a.calls, 1);
  assert.equal(b.calls, 1);

  invalidateSwr("dashboard-stats|");

  // The dashboard-stats key was dropped → recompute.
  const reA = await swr("dashboard-stats|orgA", 10_000, a.fetcher);
  assert.equal(reA.value, 2, "dropped key recomputed");
  assert.equal(a.calls, 2);

  // The attrition key was untouched → still cached.
  const reB = await swr("attrition|orgA", 10_000, b.fetcher);
  assert.equal(reB.value, 100, "non-matching key stayed cached");
  assert.equal(b.calls, 1);
});

test("invalidateSwr(): no argument clears the whole store (org change)", async () => {
  invalidateSwr();
  const a = counter(1);
  const b = counter(100);

  await swr("dashboard-stats|orgA", 10_000, a.fetcher);
  await swr("attrition|orgB", 10_000, b.fetcher);
  assert.equal(a.calls, 1);
  assert.equal(b.calls, 1);

  invalidateSwr(); // e.g. active org changed

  const reA = await swr("dashboard-stats|orgA", 10_000, a.fetcher);
  const reB = await swr("attrition|orgB", 10_000, b.fetcher);
  assert.equal(reA.value, 2, "every key recomputed after a full clear");
  assert.equal(reB.value, 101);
  assert.equal(a.calls, 2);
  assert.equal(b.calls, 2);
});
