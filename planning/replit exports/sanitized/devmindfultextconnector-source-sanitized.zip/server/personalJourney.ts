/**
 * Personal-journey runtime — single writer for each contact's queue.
 * Every mutation appends a personal_journey_events row.
 */
import { and, desc, eq } from "drizzle-orm";
import { db } from "./db";
import {
  personalJourneys,
  personalJourneyEvents,
  personalJourneyTemplates,
  type PersonalJourney,
} from "../shared/schema";
import { mtFetch } from "./mtClient";

export type EventSource = "auto" | "review" | "manual";

interface AppendEventOpts {
  organizationId: string;
  contactId: string;
  eventType: string;
  moduleId?: string | null;
  ruleId?: number | null;
  source: EventSource;
  inboundMessageId?: number | null;
  reason?: string | null;
  metadata?: Record<string, unknown> | null;
}

async function appendEvent(opts: AppendEventOpts) {
  await db.insert(personalJourneyEvents).values({
    organizationId: opts.organizationId,
    contactId: opts.contactId,
    eventType: opts.eventType,
    moduleId: opts.moduleId ?? null,
    ruleId: opts.ruleId ?? null,
    source: opts.source,
    inboundMessageId: opts.inboundMessageId ?? null,
    reason: opts.reason ?? null,
    metadata: opts.metadata ?? null,
  });
}

export async function getPersonalJourney(
  organizationId: string,
  contactId: string,
): Promise<PersonalJourney | null> {
  const [row] = await db
    .select()
    .from(personalJourneys)
    .where(
      and(
        eq(personalJourneys.organizationId, organizationId),
        eq(personalJourneys.contactId, contactId),
      ),
    );
  return row ?? null;
}

export async function bootstrapJourneyForContact(
  organizationId: string,
  contactId: string,
  contactTags: string[] = [],
): Promise<PersonalJourney> {
  const existing = await getPersonalJourney(organizationId, contactId);
  if (existing) return existing;

  // Pick a template: first matching tag template wins, else org default.
  const templates = await db
    .select()
    .from(personalJourneyTemplates)
    .where(eq(personalJourneyTemplates.organizationId, organizationId));

  let chosen = templates.find(
    (t) => t.tag && contactTags.includes(t.tag),
  );
  if (!chosen) chosen = templates.find((t) => !t.tag);

  const moduleIds = chosen?.moduleIds ?? [];

  const [row] = await db
    .insert(personalJourneys)
    .values({
      organizationId,
      contactId,
      moduleIds,
      currentIndex: 0,
      paused: false,
    })
    .returning();
  return row;
}

/** Replace (or create) a contact's journey queue from a template module list. */
export async function applyTemplateToContact(
  organizationId: string,
  contactId: string,
  moduleIds: string[],
  source: EventSource = "manual",
  reason?: string,
): Promise<PersonalJourney> {
  const existing = await getPersonalJourney(organizationId, contactId);
  if (existing) {
    const [updated] = await db
      .update(personalJourneys)
      .set({
        moduleIds,
        currentIndex: 0,
        paused: false,
        updatedAt: new Date(),
      })
      .where(eq(personalJourneys.id, existing.id))
      .returning();

    await appendEvent({
      organizationId,
      contactId,
      eventType: "reordered",
      source,
      reason: reason ?? "template_apply",
      metadata: { before: existing.moduleIds, after: moduleIds, templateApply: true },
    });
    return updated;
  }

  const [row] = await db
    .insert(personalJourneys)
    .values({
      organizationId,
      contactId,
      moduleIds,
      currentIndex: 0,
      paused: false,
    })
    .returning();

  await appendEvent({
    organizationId,
    contactId,
    eventType: "reordered",
    source,
    reason: reason ?? "template_apply",
    metadata: { after: moduleIds, templateApply: true },
  });
  return row;
}

export function getNextModule(j: PersonalJourney): string | null {
  if (j.paused) return null;
  if (j.currentIndex >= j.moduleIds.length) return null;
  return j.moduleIds[j.currentIndex] ?? null;
}

export async function advance(
  organizationId: string,
  contactId: string,
  source: EventSource = "auto",
  reason?: string,
): Promise<PersonalJourney | null> {
  const current = await bootstrapJourneyForContact(organizationId, contactId);
  if (current.paused) return current;
  const moduleId = getNextModule(current);
  if (!moduleId) return current;

  const [updated] = await db
    .update(personalJourneys)
    .set({
      currentIndex: current.currentIndex + 1,
      lastAdvancedAt: new Date(),
      updatedAt: new Date(),
    })
    .where(eq(personalJourneys.id, current.id))
    .returning();

  await appendEvent({
    organizationId, contactId,
    eventType: "advanced",
    moduleId,
    source,
    reason: reason ?? null,
  });
  return updated;
}

export async function insertNext(
  organizationId: string,
  contactId: string,
  moduleId: string,
  source: EventSource,
  ruleId?: number,
  reason?: string,
  inboundMessageId?: number,
): Promise<PersonalJourney> {
  const current = await bootstrapJourneyForContact(organizationId, contactId);
  const next = [...current.moduleIds];
  next.splice(current.currentIndex, 0, moduleId);
  const [updated] = await db
    .update(personalJourneys)
    .set({ moduleIds: next, updatedAt: new Date() })
    .where(eq(personalJourneys.id, current.id))
    .returning();

  await appendEvent({
    organizationId, contactId,
    eventType: "inserted",
    moduleId, ruleId, source,
    inboundMessageId, reason,
  });
  return updated;
}

export async function skipNext(
  organizationId: string,
  contactId: string,
  source: EventSource,
  ruleId?: number,
  reason?: string,
  inboundMessageId?: number,
): Promise<PersonalJourney> {
  const current = await bootstrapJourneyForContact(organizationId, contactId);
  const skipped = current.moduleIds[current.currentIndex] ?? null;
  if (current.currentIndex >= current.moduleIds.length) return current;
  const [updated] = await db
    .update(personalJourneys)
    .set({ currentIndex: current.currentIndex + 1, updatedAt: new Date() })
    .where(eq(personalJourneys.id, current.id))
    .returning();

  await appendEvent({
    organizationId, contactId,
    eventType: "skipped",
    moduleId: skipped, ruleId, source,
    inboundMessageId, reason,
  });
  return updated;
}

export async function reorder(
  organizationId: string,
  contactId: string,
  newQueue: string[],
  source: EventSource,
  ruleId?: number,
  reason?: string,
  inboundMessageId?: number,
): Promise<PersonalJourney> {
  const current = await bootstrapJourneyForContact(organizationId, contactId);
  const [updated] = await db
    .update(personalJourneys)
    .set({ moduleIds: newQueue, updatedAt: new Date() })
    .where(eq(personalJourneys.id, current.id))
    .returning();

  await appendEvent({
    organizationId, contactId,
    eventType: "reordered",
    ruleId, source, inboundMessageId, reason,
    metadata: { before: current.moduleIds, after: newQueue },
  });
  return updated;
}

export async function pause(
  organizationId: string,
  contactId: string,
  source: EventSource,
  ruleId?: number,
  reason?: string,
  inboundMessageId?: number,
): Promise<PersonalJourney> {
  const current = await bootstrapJourneyForContact(organizationId, contactId);
  const [updated] = await db
    .update(personalJourneys)
    .set({ paused: true, updatedAt: new Date() })
    .where(eq(personalJourneys.id, current.id))
    .returning();
  await appendEvent({
    organizationId, contactId,
    eventType: "paused",
    ruleId, source, inboundMessageId, reason,
  });
  return updated;
}

export async function resume(
  organizationId: string,
  contactId: string,
  source: EventSource,
  ruleId?: number,
  reason?: string,
  inboundMessageId?: number,
): Promise<PersonalJourney> {
  const current = await bootstrapJourneyForContact(organizationId, contactId);
  const [updated] = await db
    .update(personalJourneys)
    .set({ paused: false, updatedAt: new Date() })
    .where(eq(personalJourneys.id, current.id))
    .returning();
  await appendEvent({
    organizationId, contactId,
    eventType: "resumed",
    ruleId, source, inboundMessageId, reason,
  });
  return updated;
}

export async function listEvents(
  organizationId: string,
  contactId: string,
  limit = 20,
) {
  return db
    .select()
    .from(personalJourneyEvents)
    .where(
      and(
        eq(personalJourneyEvents.organizationId, organizationId),
        eq(personalJourneyEvents.contactId, contactId),
      ),
    )
    .orderBy(desc(personalJourneyEvents.createdAt))
    .limit(limit);
}

/**
 * Push the next module via MindfulText's launch endpoint. Returns the launched
 * moduleId or null if there's nothing to launch (queue empty / paused).
 *
 * This is the single writer for the contact's "personal" subscription.
 */
export async function launchNextForContact(opts: {
  organizationId: string;
  contactId: string;
  storedCookies: string;
  source?: EventSource;
}): Promise<{ moduleId: string | null; httpStatus: number | null }> {
  const j = await bootstrapJourneyForContact(opts.organizationId, opts.contactId);
  const moduleId = getNextModule(j);
  if (!moduleId) return { moduleId: null, httpStatus: null };

  let httpStatus: number | null = null;
  let networkError: string | null = null;
  try {
    const res = await mtFetch(`/api/subscriptions/launch/${opts.organizationId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      cookies: opts.storedCookies,
      body: JSON.stringify({
        contactIds: [opts.contactId],
        moduleIds: [moduleId],
      }),
    });
    httpStatus = res.status;
  } catch (e) {
    networkError = e instanceof Error ? e.message : String(e);
  }

  const succeeded = httpStatus !== null && httpStatus >= 200 && httpStatus < 300;
  if (succeeded) {
    // Only advance the queue when the launch actually succeeded so the
    // local journey stays in sync with what was sent on the wire.
    await advance(opts.organizationId, opts.contactId, opts.source ?? "auto", "launchNext");
    await appendEvent({
      organizationId: opts.organizationId,
      contactId: opts.contactId,
      eventType: "sent",
      moduleId,
      source: opts.source ?? "auto",
      reason: `launch ${httpStatus}`,
    });
  } else {
    // Record the failure but DO NOT advance — the next call will retry.
    await appendEvent({
      organizationId: opts.organizationId,
      contactId: opts.contactId,
      eventType: "send_failed",
      moduleId,
      source: opts.source ?? "auto",
      reason: networkError ? `network: ${networkError}` : `launch failed ${httpStatus}`,
    });
  }
  return { moduleId, httpStatus };
}
