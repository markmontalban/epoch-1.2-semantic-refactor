/**
 * Agent-safety guardrails.
 *
 * These protect the two operations the founder must always approve in person:
 *   1. Sending texts / launching subscriptions to contacts.
 *   2. Editing modules or journeys on MindfulText.
 *
 * When AGENT_SAFE_MODE is on (the default), automated server paths never send
 * on their own — they defer to the review queue — and programmatic callers
 * hitting the MindfulText proxy with a mutating request are blocked unless
 * they present a one-time confirm token issued from the operator UI. Normal
 * interactive UI requests (an operator logged in through the browser) are
 * exempt and behave exactly as before.
 */
import { randomUUID } from "crypto";

/** Operator account allowed to approve sends and module/journey edits. */
export const OPERATOR_EMAIL = (
  process.env.OPERATOR_EMAIL || "m@mindfultext.com"
).toLowerCase();

/** Default on. Set AGENT_SAFE_MODE=false to restore legacy auto-send behavior. */
export const AGENT_SAFE_MODE = process.env.AGENT_SAFE_MODE !== "false";

/**
 * Phase 2 hardening — both OFF by default because they add friction and need
 * session-edge-case testing before they replace the founder's daily workflow.
 *
 * PROXY_STRICT_AUTH: when on, *every* MindfulText proxy request (not just
 *   mutations) must come from an interactive operator session or carry a
 *   one-time confirm token. Non-UI callers are blocked outright.
 *
 * STRICT_LOCAL_AUTH: when on, the /api/local auth gate no longer falls back to
 *   the shared auto-session — a request must resolve to its own bound session.
 */
export const PROXY_STRICT_AUTH = process.env.PROXY_STRICT_AUTH === "true";
export const STRICT_LOCAL_AUTH = process.env.STRICT_LOCAL_AUTH === "true";

const TOKEN_TTL_MS = 5 * 60 * 1000;
const confirmTokens = new Map<string, number>();

/** Issue a short-lived, single-use confirm token for a programmatic mutation. */
export function issueConfirmToken(): { token: string; expiresAt: number } {
  const token = randomUUID();
  const expiresAt = Date.now() + TOKEN_TTL_MS;
  confirmTokens.set(token, expiresAt);
  return { token, expiresAt };
}

/** Verify and consume a confirm token. Returns true only for a live token. */
export function consumeConfirmToken(token: string | undefined): boolean {
  if (!token) return false;
  const expiresAt = confirmTokens.get(token);
  if (expiresAt === undefined) return false;
  confirmTokens.delete(token);
  return expiresAt > Date.now();
}

/**
 * True for MindfulText proxy paths that send messages or edit modules/journeys.
 * Only POST/PUT are considered mutating; reads pass through untouched.
 */
export function isGuardedUpstreamMutation(method: string, targetPath: string): boolean {
  const m = method.toUpperCase();
  if (m !== "POST" && m !== "PUT") return false;
  const p = targetPath.toLowerCase();
  if (p.includes("/subscriptions/launch/")) return true;
  if (/\/api\/modules(\/|$|\?)/.test(p)) return true;
  if (/\/api\/journeys(\/|$|\?)/.test(p)) return true;
  return false;
}
