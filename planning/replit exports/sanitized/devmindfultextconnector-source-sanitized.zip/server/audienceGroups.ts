/**
 * Shared helpers for tag-based groups and saved segments — membership
 * resolution, per-contact stats rollups, and detail payloads.
 */
import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "./db";
import {
  messageEvents,
  pageEvents,
  personalJourneys,
  type PersonalJourney,
  type Segment,
} from "../shared/schema";

export type MTContact = {
  id?: string;
  tags?: string[];
  isArchived?: boolean;
  firstName?: string;
  lastName?: string;
  name?: string;
  [k: string]: unknown;
};

export function contactIdOf(c: MTContact): string {
  return String(c.id ?? "");
}

export function contactDisplayName(c: MTContact): string {
  const fn = typeof c.firstName === "string" ? c.firstName : "";
  const ln = typeof c.lastName === "string" ? c.lastName : "";
  const combined = `${fn} ${ln}`.trim();
  if (combined) return combined;
  if (typeof c.name === "string" && c.name.trim()) return c.name.trim();
  const id = contactIdOf(c);
  return id || "Unknown";
}

export function normalizeTags(tags: unknown): string[] {
  if (!Array.isArray(tags)) return [];
  return tags
    .filter((t): t is string => typeof t === "string" && t.trim().length > 0)
    .map((t) => t.trim());
}

export function filterContactsByTag(contacts: MTContact[], tag: string): MTContact[] {
  const needle = tag.trim();
  return contacts.filter(
    (c) => !c.isArchived && normalizeTags(c.tags).includes(needle),
  );
}

export function filterContactsBySegment(
  contacts: MTContact[],
  includeTags: string[],
  excludeTags: string[],
  matchMode: string,
): MTContact[] {
  const inc = includeTags.map((t) => t.trim()).filter(Boolean);
  const exc = excludeTags.map((t) => t.trim()).filter(Boolean);
  const mode = matchMode === "AND" ? "AND" : "OR";
  return contacts.filter((c) => {
    if (c.isArchived) return false;
    const tags = normalizeTags(c.tags);
    if (exc.some((t) => tags.includes(t))) return false;
    if (inc.length === 0) return false;
    if (mode === "AND") return inc.every((t) => tags.includes(t));
    return inc.some((t) => tags.includes(t));
  });
}

export function filterContactsBySegmentRow(
  contacts: MTContact[],
  segment: Pick<Segment, "includeTags" | "excludeTags" | "matchMode">,
): MTContact[] {
  return filterContactsBySegment(
    contacts,
    segment.includeTags ?? [],
    segment.excludeTags ?? [],
    segment.matchMode,
  );
}

export type JourneyStatus = "none" | "active" | "paused" | "completed";

export function journeyStatusFor(j: PersonalJourney | undefined): JourneyStatus {
  if (!j) return "none";
  if (j.paused) return "paused";
  if (j.currentIndex >= j.moduleIds.length) return "completed";
  return "active";
}

export interface GroupMemberStats {
  id: string;
  name: string;
  tags: string[];
  sends: number;
  replies: number;
  pageViews: number;
  journeyStatus: JourneyStatus;
}

export interface GroupDetailStats {
  contactCount: number;
  sends: number;
  replies: number;
  replyRate: number;
  pageViews: number;
  activeJourneys: number;
  pausedJourneys: number;
  completedJourneys: number;
}

export interface GroupDetailPayload {
  kind: "tag" | "segment";
  tag?: string;
  segment?: {
    id: number;
    name: string;
    includeTags: string[];
    excludeTags: string[];
    matchMode: string;
  };
  brief?: string;
  briefUpdatedAt: string | null;
  stats: GroupDetailStats;
  members: GroupMemberStats[];
}

async function fetchPerContactMessageCounts(
  orgId: string,
  contactIds: string[],
): Promise<Map<string, { sends: number; replies: number }>> {
  const map = new Map<string, { sends: number; replies: number }>();
  for (const id of contactIds) map.set(id, { sends: 0, replies: 0 });
  if (contactIds.length === 0) return map;

  const rows = await db
    .select({
      contactId: messageEvents.contactId,
      direction: messageEvents.direction,
      c: sql<number>`count(*)::int`,
    })
    .from(messageEvents)
    .where(
      and(
        eq(messageEvents.organizationId, orgId),
        inArray(messageEvents.contactId, contactIds),
        sql`${messageEvents.source} <> 'optout-scan'`,
      ),
    )
    .groupBy(messageEvents.contactId, messageEvents.direction);

  for (const row of rows) {
    if (!row.contactId) continue;
    const cur = map.get(row.contactId) ?? { sends: 0, replies: 0 };
    if (row.direction === "send") cur.sends = row.c;
    else if (row.direction === "reply") cur.replies = row.c;
    map.set(row.contactId, cur);
  }
  return map;
}

async function fetchPerContactPageViews(
  orgId: string,
  contactIds: string[],
): Promise<Map<string, number>> {
  const map = new Map<string, number>();
  for (const id of contactIds) map.set(id, 0);
  if (contactIds.length === 0) return map;

  const rows = await db
    .select({
      contactId: pageEvents.contactId,
      c: sql<number>`count(*)::int`,
    })
    .from(pageEvents)
    .where(
      and(
        eq(pageEvents.organizationId, orgId),
        inArray(pageEvents.contactId, contactIds),
      ),
    )
    .groupBy(pageEvents.contactId);

  for (const row of rows) {
    if (!row.contactId) continue;
    map.set(row.contactId, row.c);
  }
  return map;
}

async function fetchJourneysByContact(
  orgId: string,
  contactIds: string[],
): Promise<Map<string, PersonalJourney>> {
  const map = new Map<string, PersonalJourney>();
  if (contactIds.length === 0) return map;

  const rows = await db
    .select()
    .from(personalJourneys)
    .where(
      and(
        eq(personalJourneys.organizationId, orgId),
        inArray(personalJourneys.contactId, contactIds),
      ),
    );

  for (const row of rows) map.set(row.contactId, row);
  return map;
}

export async function buildGroupDetail(
  orgId: string,
  memberContacts: MTContact[],
  meta:
    | { kind: "tag"; tag: string; brief?: string; briefUpdatedAt?: Date | null }
    | {
        kind: "segment";
        segment: Pick<
          Segment,
          "id" | "name" | "includeTags" | "excludeTags" | "matchMode"
        >;
      },
): Promise<GroupDetailPayload> {
  const contactIds = memberContacts.map(contactIdOf).filter(Boolean);
  const [msgMap, viewMap, journeyMap] = await Promise.all([
    fetchPerContactMessageCounts(orgId, contactIds),
    fetchPerContactPageViews(orgId, contactIds),
    fetchJourneysByContact(orgId, contactIds),
  ]);

  let totalSends = 0;
  let totalReplies = 0;
  let totalViews = 0;
  let activeJourneys = 0;
  let pausedJourneys = 0;
  let completedJourneys = 0;

  const members: GroupMemberStats[] = memberContacts.map((c) => {
    const id = contactIdOf(c);
    const msg = msgMap.get(id) ?? { sends: 0, replies: 0 };
    const pageViews = viewMap.get(id) ?? 0;
    const journey = journeyMap.get(id);
    const journeyStatus = journeyStatusFor(journey);

    totalSends += msg.sends;
    totalReplies += msg.replies;
    totalViews += pageViews;
    if (journeyStatus === "active") activeJourneys += 1;
    else if (journeyStatus === "paused") pausedJourneys += 1;
    else if (journeyStatus === "completed") completedJourneys += 1;

    return {
      id,
      name: contactDisplayName(c),
      tags: normalizeTags(c.tags),
      sends: msg.sends,
      replies: msg.replies,
      pageViews,
      journeyStatus,
    };
  });

  members.sort((a, b) => a.name.localeCompare(b.name) || a.id.localeCompare(b.id));

  const stats: GroupDetailStats = {
    contactCount: members.length,
    sends: totalSends,
    replies: totalReplies,
    replyRate: totalSends > 0 ? Math.round((totalReplies / totalSends) * 1000) / 10 : 0,
    pageViews: totalViews,
    activeJourneys,
    pausedJourneys,
    completedJourneys,
  };

  if (meta.kind === "tag") {
    return {
      kind: "tag",
      tag: meta.tag,
      brief: meta.brief ?? "",
      briefUpdatedAt: meta.briefUpdatedAt?.toISOString() ?? null,
      stats,
      members,
    };
  }

  return {
    kind: "segment",
    segment: {
      id: meta.segment.id,
      name: meta.segment.name,
      includeTags: meta.segment.includeTags ?? [],
      excludeTags: meta.segment.excludeTags ?? [],
      matchMode: meta.segment.matchMode,
    },
    briefUpdatedAt: null,
    stats,
    members,
  };
}
