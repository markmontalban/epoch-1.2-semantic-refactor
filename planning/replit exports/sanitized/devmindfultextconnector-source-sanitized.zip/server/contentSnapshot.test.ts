import assert from "node:assert/strict";
import test from "node:test";
import {
  buildSnapshotManifest,
  fetchModuleCorpus,
  isoFromEpochSeconds,
  type SnapshotRequest,
} from "./contentSnapshot";

function fixtureRequester(responses: Record<string, unknown>, calls: { path: string; method: string }[]): SnapshotRequest {
  return async (path, options) => {
    calls.push({ path, method: options.method });
    if (!(path in responses)) throw new Error(`Missing fixture for ${path}`);
    return responses[path];
  };
}

test("paginates, falls back to detail only when texts are omitted, and preserves canonical rows", async () => {
  const calls: { path: string; method: string }[] = [];
  const responses = {
    "/api/modules/byOrganization/00000022?page=1&limit=100": {
      data: [{
        id: "00000010",
        name: "Second module",
        description: "Description as stored",
        tags: ["b", "a"],
        isPublic: true,
        isArchived: false,
        createdAt: 1,
        updatedAt: 2,
      }],
      total: 2,
    },
    "/api/modules/byOrganization/00000022?page=2&limit=100": {
      data: [{
        id: "00000002",
        name: "First module",
        description: "",
        tags: ["a"],
        isPublic: false,
        isArchived: true,
        createdAt: 3,
        updatedAt: 4,
        texts: [{
          subject: "",
          content: "Hi {{ Contact.FirstName }} — keep “this” exactly.",
          actionID: "",
          actionMatches: [],
          mediaURLs: [],
        }],
      }],
      total: 2,
    },
    "/api/modules/00000010": {
      data: {
        id: "00000010",
        name: "Second module",
        description: "Description as stored",
        tags: ["b", "a"],
        isPublic: true,
        isArchived: false,
        createdAt: 1,
        updatedAt: 2,
        texts: [
          {
            subject: "Verbatim subject",
            content: "First text",
            actionID: "00000052",
            actionMatches: ["evidence"],
            mediaURLs: ["https://example.test/image.jpg"],
          },
          {
            subject: "",
            content: "Second text",
            actionID: "",
            actionMatches: [],
            mediaURLs: [],
          },
        ],
      },
    },
  };

  const corpus = await fetchModuleCorpus("00000022", fixtureRequester(responses, calls));

  assert.deepEqual(calls, [
    { path: "/api/modules/byOrganization/00000022?page=1&limit=100", method: "GET" },
    { path: "/api/modules/byOrganization/00000022?page=2&limit=100", method: "GET" },
    { path: "/api/modules/00000010", method: "GET" },
  ]);
  assert.deepEqual(corpus.rows.map((row) => [row.module_id, row.text_index]), [
    ["00000002", 0],
    ["00000010", 0],
    ["00000010", 1],
  ]);
  assert.equal(corpus.rows[1].content, "First text");
  assert.equal(corpus.rows[1].action_id, "00000052");
  assert.deepEqual(corpus.rows[1].media_urls, ["https://example.test/image.jpg"]);
  assert.equal(corpus.rows[1].has_media, true);
  assert.equal(corpus.rows[0].content, "Hi {{ Contact.FirstName }} — keep “this” exactly.");
  assert.equal(corpus.rows[1].module_created_at, "1970-01-01T00:00:01.000Z");
  assert.equal(corpus.rows[1].module_updated_at, "1970-01-01T00:00:02.000Z");
});

test("uses the short final page boundary when no pagination metadata is supplied", async () => {
  const calls: { path: string; method: string }[] = [];
  const corpus = await fetchModuleCorpus("org", fixtureRequester({
    "/api/modules/byOrganization/org?page=1&limit=100": [{
      id: "00000001",
      texts: [],
    }],
  }, calls));

  assert.equal(corpus.modules.length, 1);
  assert.equal(corpus.rows.length, 0);
  assert.equal(calls.length, 1);
});

test("accepts an authoritative unpaged module list when the endpoint ignores limit", async () => {
  const calls: { path: string; method: string }[] = [];
  const modules = Array.from({ length: 101 }, (_, index) => ({
    id: String(index + 1).padStart(8, "0"),
    texts: [],
  }));
  const corpus = await fetchModuleCorpus("org", fixtureRequester({
    "/api/modules/byOrganization/org?page=1&limit=100": { data: modules },
  }, calls));

  assert.equal(corpus.modules.length, 101);
  assert.equal(corpus.rows.length, 0);
  assert.deepEqual(calls, [
    { path: "/api/modules/byOrganization/org?page=1&limit=100", method: "GET" },
  ]);
});

test("fails rather than exporting a malformed detail response or duplicate paginated module", async () => {
  await assert.rejects(
    fetchModuleCorpus("org", fixtureRequester({
      "/api/modules/byOrganization/org?page=1&limit=100": { data: [{ id: "00000001" }], total: 2 },
      "/api/modules/byOrganization/org?page=2&limit=100": { data: [{ id: "00000001", texts: [] }], total: 2 },
      "/api/modules/00000001": { data: { id: "00000001", texts: [] } },
    }, [])),
    /appeared more than once/,
  );

  await assert.rejects(
    fetchModuleCorpus("org", fixtureRequester({
      "/api/modules/byOrganization/org?page=1&limit=100": [{ id: "00000001" }],
      "/api/modules/00000001": { data: { id: "wrong-id", texts: [] } },
    }, [])),
    /did not match requested module/,
  );
});

test("converts epoch seconds and aggregates manifest fields from finalized rows", async () => {
  assert.equal(isoFromEpochSeconds(1_700_000_000, "timestamp"), "2023-11-14T22:13:20.000Z");
  assert.throws(() => isoFromEpochSeconds("1700000000", "timestamp"), /epoch seconds/);

  const corpus = await fetchModuleCorpus("org", fixtureRequester({
    "/api/modules/byOrganization/org?page=1&limit=100": [{
      id: "00000009",
      tags: ["sleep", "sleep", "calm"],
      texts: [{
        subject: "",
        content: "A",
        actionID: "00000002",
        actionMatches: ["yes"],
        mediaURLs: ["https://example.test/a.jpg"],
      }],
    }, {
      id: "00000010",
      tags: ["calm"],
      texts: [],
    }],
  }, []));
  const manifest = buildSnapshotManifest("org", corpus.modules, corpus.rows, "2026-08-06T00:00:00.000Z");

  assert.equal(manifest.module_count, 2);
  assert.equal(manifest.text_count, 1);
  assert.equal(manifest.media_text_count, 1);
  assert.equal(manifest.action_attached_text_count, 1);
  assert.deepEqual(manifest.distinct_module_tags, { calm: 2, sleep: 1 });
  assert.deepEqual(manifest.texts_per_module_distribution, { "0": 1, "1": 1 });
  assert.equal(manifest.expected_comparison.module_count_difference, -281);
  assert.equal(manifest.expected_comparison.text_count_difference, -1111);
});