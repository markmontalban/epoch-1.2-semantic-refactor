import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import {
  createContentDraft,
  getContentDrafts,
  getContentDraft,
  updateContentDraft,
  createDraftMessage,
  getDraftMessages,
  updateDraftMessage,
  createInboundMessage,
  getInboundMessages,
  findPriorAdvancedEvent,
  setInboundAttribution,
  listAttributedInbounds,
  aggregateReplyAnalytics,
  upsertMemory,
  getActiveMemories,
  deleteMemory,
  createAgentRule,
  getActiveRules,
  updateAgentRule,
  deleteAgentRule,
  logTokenUsage,
  getTokenUsageSummary,
  createContentProgram,
  getContentPrograms,
  getContentProgram,
  updateContentProgram,
  deleteContentProgram,
  createEntitySnapshot,
  listEntitySnapshots,
  getEntitySnapshot,
  createReshapeRule,
  listReshapeRules,
  updateReshapeRule,
  deleteReshapeRule,
  listPendingChanges,
  getPendingChange,
  decidePendingChange,
  countPendingChanges,
  listPersonalJourneyTemplates,
  upsertPersonalJourneyTemplate,
  deletePersonalJourneyTemplate,
  listAudienceBriefs,
  getAudienceBrief,
  upsertAudienceBrief,
  deleteAudienceBrief,
  listSegments,
  getSegment,
  createSegment,
  updateSegment,
  deleteSegment,
  getPersonalJourneyTemplateById,
  countActionableDraftMessages,
  getDraftMessageByInboundId,
  countDraftMessages,
  countInboundMessages,
  countMessageEventsInRange,
  getEntityOrgId,
  upsertAnalyticsSnapshot,
  getAnalyticsSnapshots,
  backfillMessageEvents,
  replaceOptOutScanEvents,
  recordAttributionEvent,
  getAttributionSummary,
  getOrCreatePageToken,
  revokePageToken,
  createPublishedContent,
  listPublishedContent,
  setPublishedContentVisibility,
  deletePublishedContent,
  resetHarvestedLinkForPublishedContent,
  updatePublishedContent,
  listHarvestedLinks,
  getHarvestedLink,
  updateHarvestedLink,
  getPageSettings,
  upsertPageSettings,
  defaultPageSettings,
  getPageViewStats,
  type OwnedEntityKind,
} from "./storage";
import { mtFetch } from "./mtClient";
import { harvestModuleLinks } from "./linkHarvester";
import {
  REPORTING_RANGE_DAYS,
  fetchMtReporting,
  getCalendarMessageCounts,
  type MtReporting,
} from "./mtReporting";
import {
  AUTO_SESSION_ID,
  sessionStore,
  sessionOrgs,
  saveSessionStore,
  extractSessionId,
  resolveOrgIdFromCookies,
} from "./session";
import {
  loadOrgSettings,
  saveOrgSettings,
  getConfiguredOrgId,
  fetchOrgName,
  probeOrgsByUser,
  performAutoLogin,
  getAutoSessionUser,
  setAutoSessionUser,
  getCachedOrgs,
  setCachedOrgs,
  type OrgSettings,
} from "./orgSettings";
import { getRevenueSummary } from "./stripeClient";
import { swr, invalidateSwr } from "./swrCache";
import {
  bootstrapJourneyForContact,
  applyTemplateToContact,
  getPersonalJourney,
  insertNext,
  skipNext,
  reorder,
  pause,
  resume,
  listEvents,
  launchNextForContact,
} from "./personalJourney";
import {
  evaluateRules,
  dispatchProposal,
  applyOps,
  type ReshapeOp,
} from "./reshape";
import {
  getContactProfile,
  setMemoryEnabled,
  getContactMemory,
  clearContactMemory,
  recordContactActivity,
  setContactPageNote,
} from "./contactMemory";
import { processInboundReply, pollInboundReplies } from "./inbound";
import {
  buildGroupDetail,
  contactIdOf,
  filterContactsBySegmentRow,
  filterContactsByTag,
} from "./audienceGroups";
import {
  createContentPlan,
  generateTextsFromPlan,
  generateDraftReply,
  getAvailableModels,
  askQuestion,
  askQuestionStream,
  generateInsights,
} from "./ai/index";
import { invalidateBaseRulesCache, getBaseRules, setBaseRules } from "./ai/rules";
import { AGENT_SAFE_MODE, STRICT_LOCAL_AUTH, issueConfirmToken } from "./agentSafety";
import { registerProxyRoutes } from "./proxy";
import { registerPublicRoutes } from "./publicRoutes";
import {
  startBackgroundJobs,
  checkAndRefreshAutoSession,
  captureDailySnapshot,
} from "./schedulers";
import { z } from "zod";
import {
  startOfDay, startOfWeek, startOfMonth, startOfYear,
  addDays, addWeeks, addMonths, addYears, parseISO,
} from "date-fns";
import { toZonedTime, fromZonedTime } from "date-fns-tz";

function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

type Json = string | number | boolean | null | Json[] | { [key: string]: Json };

function parseJsonContent(raw: string): Json {
  const match = raw.match(/\{[\s\S]*\}/);
  if (match) {
    try { return JSON.parse(match[0]) as Json; } catch { /* fall through */ }
  }
  return raw;
}

// Stale-while-revalidate TTLs for the founder dashboard endpoints. Short
// enough that a returning user sees up-to-date numbers, long enough that
// rapid re-opens / period toggles don't re-hammer the upstream APIs. AI
// insights are pricier (an LLM call) so they live longer.
const DASHBOARD_CACHE_TTL_MS = 60 * 1000;
const INSIGHTS_CACHE_TTL_MS = 5 * 60 * 1000;

export async function registerRoutes(app: Express): Promise<Server> {
  // -----------------------------------------------------------------------
  // Session cookie proxy for MindfulText (unchanged)
  // -----------------------------------------------------------------------

  // -----------------------------------------------------------------------
  // Helper: fetch ALL contacts across pages from MindfulText API.
  // Tries common pagination conventions and logs the shape on first fetch.
  // -----------------------------------------------------------------------

  type MTContact = { tags?: string[]; isArchived?: boolean; [k: string]: unknown };

  async function fetchAllMTContacts(
    orgId: string,
    headers: Record<string, string>,
  ): Promise<MTContact[]> {
    const PAGE_SIZE = 100;
    const all: MTContact[] = [];
    let page = 1;
    let keepGoing = true;

    while (keepGoing) {
      const path =
        `/api/contacts/byOrganization/${orgId}` +
        `?page=${page}&pageSize=${PAGE_SIZE}`;
      const res = await mtFetch(path, { method: "GET", headers });
      if (!res.ok) break;

      const raw = (await res.json()) as Record<string, unknown>;

      // Log pagination shape once so we can see what fields exist
      if (page === 1) {
        const shapeKeys = Object.keys(raw).filter((k) => k !== "data");
        console.log(
          `[contacts-paginator] page 1 shape — non-data keys: ${JSON.stringify(shapeKeys)} ` +
          `data.length=${Array.isArray(raw.data) ? (raw.data as unknown[]).length : "n/a"}`,
        );
      }

      const pageItems: MTContact[] = Array.isArray(raw.data)
        ? (raw.data as MTContact[])
        : Array.isArray(raw)
          ? (raw as MTContact[])
          : [];

      all.push(...pageItems);

      // Determine whether there are more pages using whichever field exists.
      const total = typeof raw.total === "number" ? raw.total : null;
      const totalCount = typeof raw.totalCount === "number" ? raw.totalCount : null;
      const pageCount = typeof raw.pageCount === "number" ? raw.pageCount : null;
      const totalPages = typeof raw.totalPages === "number" ? raw.totalPages : null;
      const hasMore = typeof raw.hasMore === "boolean" ? raw.hasMore : null;
      const nextPage = raw.nextPage != null ? raw.nextPage : null;

      if (hasMore === false) {
        keepGoing = false;
      } else if (nextPage === null || nextPage === false || nextPage === undefined) {
        // If the API doesn't advertise pagination at all, assume one page.
        if (total === null && totalCount === null && pageCount === null && totalPages === null && hasMore === null && nextPage === null) {
          keepGoing = false;
        } else {
          keepGoing = false;
        }
      } else if (total !== null) {
        keepGoing = all.length < total;
      } else if (totalCount !== null) {
        keepGoing = all.length < totalCount;
      } else if (pageCount !== null) {
        keepGoing = page < pageCount;
      } else if (totalPages !== null) {
        keepGoing = page < totalPages;
      } else {
        // If page returned fewer items than PAGE_SIZE, we're on the last page.
        keepGoing = pageItems.length === PAGE_SIZE;
      }

      page++;
      if (page > 50) break; // safety cap
    }

    return all;
  }

  // Auth gate for all /api/local/* routes. Requires a non-empty session
  // entry for the request's X-Session-ID. By default this falls back to the
  // shared auto-session so the single-operator console keeps working even when
  // a request arrives without its own bound session; set STRICT_LOCAL_AUTH=true
  // to drop that fallback. Browsers in dev mode get the auto-login cookies
  // bound to their own X-Session-ID via /api/auto-session below. Also rejects
  // (403) when the request
  // includes an orgId (in the query string or path) that doesn't match
  // the session's resolved org, so a logged-in user can't change a URL
  // to read another org's local data.
  app.use("/api/local", async (req, res, next) => {
    // The Settings sign-in endpoint must be reachable BEFORE any session
    // exists — it's how the user establishes one in the first place when no
    // env-var auto-login is configured. Exempt it from the auth gate.
    // Inside an `app.use("/api/local", ...)` middleware, `req.path` is the
    // path relative to the mount (e.g. `/settings/login`), so check both
    // mounted and absolute forms to be safe.
    if (req.path === "/settings/login" || req.path === "/api/local/settings/login") {
      return next();
    }

    const sid = extractSessionId(req);
    // STRICT_LOCAL_AUTH (opt-in, Phase 2): drop the shared auto-session
    // fallback so a request must resolve to its own bound session. Off by
    // default so the founder's current workflow keeps working.
    const ownCookies = STRICT_LOCAL_AUTH
      ? sessionStore[sid]
      : sessionStore[sid] || sessionStore[AUTO_SESSION_ID];
    if (!ownCookies) {
      return res.status(401).json({ error: "unauthenticated" });
    }

    // Single-user mode: configured org id is the source of truth. We still
    // best-effort cache the cookie-resolved org so logs stay informative,
    // but the configured value always wins for auth decisions.
    const orgId = getConfiguredOrgId();
    if (!sessionOrgs[sid]) {
      resolveOrgIdFromCookies(ownCookies)
        .then((resolved) => { if (resolved) sessionOrgs[sid] = resolved; })
        .catch(() => {});
    }
    sessionOrgs[sid] = orgId;

    // Single-user mode: org-mismatch on URL/body no longer rejects. We log
    // a warning and proceed with the configured org so the user can navigate
    // freely (e.g. opening a stale URL after changing the org id).
    // Single-user mode: any inbound query/body org reference is rewritten
    // to the configured org so stale client state can never drive writes
    // against a different organization. Logged for visibility.
    const queryOrg = typeof req.query.orgId === "string" ? req.query.orgId : null;
    if (queryOrg && queryOrg !== orgId) {
      console.warn(`[local-api] org mismatch on query (${queryOrg} vs configured ${orgId}) — rewriting to configured value`);
      (req.query as Record<string, unknown>).orgId = orgId;
    }
    if (req.body && typeof req.body === "object" && !Array.isArray(req.body)) {
      const bodyObj = req.body as Record<string, unknown>;
      // MindfulText payloads use both casings (`organizationId` and
      // `organizationID`) — normalize whichever is present.
      for (const key of ["organizationId", "organizationID"] as const) {
        const bodyOrg = bodyObj[key];
        if (bodyOrg === undefined || bodyOrg === null || bodyOrg === "") continue;
        const normalized = (typeof bodyOrg === "string" || typeof bodyOrg === "number")
          ? String(bodyOrg).padStart(8, "0")
          : null;
        if (normalized !== orgId && String(bodyOrg) !== orgId) {
          console.warn(`[local-api] org mismatch on body.${key} (${String(bodyOrg)} vs configured ${orgId}) — rewriting to configured value`);
          bodyObj[key] = orgId;
        }
      }
    }

    (req as Request & { sessionOrgId?: string; sessionId?: string }).sessionOrgId = orgId;
    (req as Request & { sessionOrgId?: string; sessionId?: string }).sessionId = sid;
    next();
  });

  // Per-route orgId check — single-user mode: rewrite any mismatched
  // `:orgId` path segment to the server-configured org id so stale client
  // state can't drive a handler against the wrong organization. Logs a
  // warning so the substitution is visible.
  app.param("orgId", (req, _res, next, value) => {
    const sessionOrgId = (req as Request & { sessionOrgId?: string }).sessionOrgId;
    if (sessionOrgId && String(value) !== sessionOrgId) {
      console.warn(`[local-api] org mismatch on path (${String(value)} vs configured ${sessionOrgId}) — rewriting to configured value`);
      req.params.orgId = sessionOrgId;
    }
    next();
  });

  // Helper for `:id` routes that don't carry an `:orgId` segment. Looks up
  // the entity's organizationId and compares to the session's org. Sends
  // the appropriate response and returns false on mismatch/missing so the
  // caller can early-return; returns true when the row is owned by the
  // caller and the handler should proceed.
  async function ownsEntity(
    req: Request,
    res: import("express").Response,
    kind: OwnedEntityKind,
    rawId: string,
  ): Promise<boolean> {
    const id = Number(rawId);
    if (!Number.isFinite(id)) {
      res.status(400).json({ error: "invalid id" });
      return false;
    }
    const sessionOrgId = (req as Request & { sessionOrgId?: string }).sessionOrgId;
    if (!sessionOrgId) {
      res.status(401).json({ error: "no organization for session" });
      return false;
    }
    const owner = await getEntityOrgId(kind, id);
    if (owner === null) {
      res.status(404).json({ error: "Not found" });
      return false;
    }
    if (owner !== sessionOrgId) {
      console.warn(`[local-api] ownsEntity mismatch for ${kind}#${id} (owner ${owner} vs session ${sessionOrgId}) — single-user mode, proceeding`);
    }
    return true;
  }

  // -----------------------------------------------------------------------
  // Local API — Settings (single-user configurable org id + credentials)
  // -----------------------------------------------------------------------
  // Returns only the safe-to-expose fields: never includes the stored
  // password. `signedIn` reflects whether the server holds valid-looking
  // session cookies for the configured account (best-effort — actual
  // validity is verified by the keep-alive ping).
  app.get("/api/local/settings", async (_req, res) => {
    const s = loadOrgSettings();
    const cookies = sessionStore[AUTO_SESSION_ID];
    const signedIn = !!cookies;
    // Best-effort: resolve the configured org's friendly name so the UI can
    // show "Wheelchair Ball (00000030)" instead of just "00000030". Cached
    // per orgId so repeated polls don't re-fetch.
    let orgName: string | null = null;
    if (cookies && s.orgId) {
      orgName = await fetchOrgName(s.orgId, cookies);
    }
    res.json({
      orgId: s.orgId,
      orgName,
      email: s.email ?? (getAutoSessionUser()?.email ?? null),
      hasPassword: !!s.password,
      signedIn,
    });
  });

  app.put("/api/local/settings", async (req, res) => {
    const body = req.body as { orgId?: unknown };
    if (!body || typeof body.orgId !== "string" || !body.orgId.trim()) {
      return res.status(400).json({ error: "orgId is required" });
    }
    const raw = body.orgId.trim();
    // Canonicalize numeric org ids to the 8-digit zero-padded form so
    // callers entering "22" and "00000022" produce the same configured id.
    const orgId = /^\d+$/.test(raw) ? raw.padStart(8, "0") : raw;

    // Validate against the byUser list when we have session cookies — the
    // user shouldn't be able to switch to an org their MindfulText account
    // can't actually see. When cookies are absent we accept the value
    // (first-boot path) and rely on a subsequent login to fix any mismatch.
    const storedCookies = sessionStore[AUTO_SESSION_ID];
    if (storedCookies) {
      let orgs = getCachedOrgs();
      if (orgs.length === 0) {
        const probe = await probeOrgsByUser(storedCookies);
        if (probe.status === "ok") {
          orgs = probe.orgs;
          setCachedOrgs(probe.orgs);
        }
        // For "forbidden" / "error" we skip validation: the account either
        // can't list orgs at all, or the probe failed transiently. Either
        // way blocking the save would be worse than accepting it.
      }
      if (orgs.length > 0 && !orgs.some((o) => o.id === orgId)) {
        return res.status(400).json({
          error: `Organization ${orgId} isn't in your MindfulText accounts. Pick one from the dropdown.`,
          code: "org_not_accessible",
        });
      }
    }

    const current = loadOrgSettings();
    try {
      saveOrgSettings({ ...current, orgId });
    } catch (e) {
      console.error("[org-settings] failed to persist:", e instanceof Error ? e.message : String(e));
      return res.status(500).json({ error: "failed to persist org settings" });
    }
    // Force every cached session to pick up the new value on the next request.
    for (const k of Object.keys(sessionOrgs)) sessionOrgs[k] = orgId;
    const su = getAutoSessionUser();
    if (su) setAutoSessionUser({ ...su, orgId });
    // Drop the dashboard SWR cache so the new org's numbers aren't served the
    // previous org's cached values.
    invalidateSwr();
    res.json({ orgId });
  });

  // POST /api/local/settings/login — exempted from the auth gate above.
  // Logs into MindfulText with the supplied credentials, captures cookies,
  // persists creds, and binds the resulting session to the caller's sid so
  // the very next request authenticates.
  app.post("/api/local/settings/login", async (req, res) => {
    const body = (req.body || {}) as { email?: unknown; password?: unknown };
    const email = typeof body.email === "string" ? body.email.trim() : "";
    const password = typeof body.password === "string" ? body.password : "";
    if (!email || !password) {
      return res.status(400).json({ error: "email and password are required", code: "missing_fields" });
    }

    const result = await performAutoLogin(sessionStore, saveSessionStore, { email, password });
    if (!result.ok) {
      const status = result.reason === "invalid_credentials" ? 401
        : result.reason === "network_error" ? 502
        : 400;
      return res.status(status).json({
        error: result.reason === "invalid_credentials"
          ? "Email or password rejected by MindfulText."
          : result.reason === "network_error"
            ? "Couldn't reach MindfulText — check your connection and try again."
            : "Login failed.",
        code: result.reason || "login_failed",
      });
    }

    // Persist credentials so future restarts auto-login as this user.
    try {
      const current = loadOrgSettings();
      saveOrgSettings({ ...current, email, password });
    } catch (e) {
      console.error("[settings/login] failed to persist credentials:", e instanceof Error ? e.message : String(e));
    }

    // Bind cookies to the caller's own sid so the next request from this
    // browser authenticates without waiting for /api/auto-session.
    const sid = extractSessionId(req);
    if (sid && sid !== AUTO_SESSION_ID) {
      sessionStore[sid] = sessionStore[AUTO_SESSION_ID];
      saveSessionStore(sessionStore);
      const su = getAutoSessionUser();
      if (su) sessionOrgs[sid] = su.orgId;
    }

    res.json({
      ok: true,
      email,
      orgs: result.orgs || [],
      orgId: getAutoSessionUser()?.orgId || loadOrgSettings().orgId,
      sessionId: AUTO_SESSION_ID,
    });
  });

  // GET /api/local/settings/orgs — returns the user's accessible orgs.
  // Returns 401 + code so the UI can prompt re-login when cookies have
  // expired.
  app.get("/api/local/settings/orgs", async (_req, res) => {
    const storedCookies = sessionStore[AUTO_SESSION_ID];
    if (!storedCookies) {
      return res.status(401).json({ error: "Not signed in to MindfulText.", code: "not_signed_in" });
    }
    const probe = await probeOrgsByUser(storedCookies);
    if (probe.status === "unauthorized") {
      // Cookies are stale — clear them so /api/local/settings reports
      // signedIn=false and the UI prompts a fresh sign-in immediately.
      delete sessionStore[AUTO_SESSION_ID];
      saveSessionStore(sessionStore);
      setAutoSessionUser(null);
      setCachedOrgs([]);
      return res.status(401).json({ error: "MindfulText session expired — sign in again.", code: "credentials_expired" });
    }
    if (probe.status === "forbidden") {
      // Signed in, but this account isn't allowed to list orgs. Return an
      // empty list with a code so the UI can show the manual-entry fallback
      // instead of an error toast.
      setCachedOrgs([]);
      return res.json({ orgs: [], orgId: loadOrgSettings().orgId, code: "byuser_forbidden" });
    }
    if (probe.status === "error") {
      return res.status(502).json({ error: "Couldn't reach MindfulText to fetch your orgs. Try again.", code: "fetch_error" });
    }
    setCachedOrgs(probe.orgs);
    res.json({ orgs: probe.orgs, orgId: loadOrgSettings().orgId });
  });

  registerProxyRoutes(app);
  registerPublicRoutes(app);

  // -----------------------------------------------------------------------
  // Local API — Subscriber pages (founder tooling)
  // -----------------------------------------------------------------------

  /** Build the absolute /p/:token URL from the request's own origin. */
  function publicPageUrl(req: Request, token: string): string {
    const proto = (req.headers["x-forwarded-proto"] as string) || req.protocol || "https";
    const host = req.headers.host || "";
    return `${proto}://${host}/p/${token}`;
  }

  // Get-or-create a contact's tokenized link.
  app.post("/api/local/subscriber-link/:contactId", async (req, res) => {
    try {
      const orgId = getConfiguredOrgId();
      const row = await getOrCreatePageToken(orgId, req.params.contactId);
      res.json({ id: row.id, token: row.token, url: publicPageUrl(req, row.token), active: row.active });
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // Revoke a link by its token-row id.
  app.delete("/api/local/subscriber-link/:id", async (req, res) => {
    try {
      const orgId = getConfiguredOrgId();
      await revokePageToken(orgId, Number(req.params.id));
      res.json({ ok: true });
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Subscriber page settings (appearance + section toggles)
  // -----------------------------------------------------------------------

  app.get("/api/local/page-settings", async (_req, res) => {
    try {
      const orgId = getConfiguredOrgId();
      const settings = await getPageSettings(orgId);
      res.json(settings ?? defaultPageSettings());
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.put("/api/local/page-settings", async (req, res) => {
    try {
      const orgId = getConfiguredOrgId();
      const b = (req.body ?? {}) as Record<string, unknown>;
      const str = (v: unknown) => (typeof v === "string" ? v.trim() : undefined);
      const bool = (v: unknown) => (typeof v === "boolean" ? v : undefined);
      const patch = {
        brandName: str(b.brandName),
        tagline: str(b.tagline),
        accentColor: str(b.accentColor),
        footerText: str(b.footerText),
        showTopics: bool(b.showTopics),
        topicsLabel: str(b.topicsLabel),
        showReceived: bool(b.showReceived),
        receivedLabel: str(b.receivedLabel),
        showLibrary: bool(b.showLibrary),
        libraryLabel: str(b.libraryLabel),
      };
      // Drop undefined keys so we never overwrite a column with null.
      const clean = Object.fromEntries(
        Object.entries(patch).filter(([, v]) => v !== undefined),
      );
      const saved = await upsertPageSettings(orgId, clean);
      res.json(saved);
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Published content library
  // -----------------------------------------------------------------------

  app.get("/api/local/library", async (_req, res) => {
    try {
      const orgId = getConfiguredOrgId();
      res.json(await listPublishedContent(orgId));
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.post("/api/local/library", async (req, res) => {
    try {
      const orgId = getConfiguredOrgId();
      const { title, body, topic, sourceType, sourceId } = req.body ?? {};
      if (typeof title !== "string" || !title.trim() || typeof body !== "string" || !body.trim()) {
        return res.status(400).json({ error: "title and body are required" });
      }
      const row = await createPublishedContent({
        organizationId: orgId,
        title: title.trim(),
        body: body.trim(),
        topic: typeof topic === "string" && topic.trim() ? topic.trim() : null,
        sourceType: typeof sourceType === "string" ? sourceType : "draft",
        sourceId: sourceId != null ? String(sourceId) : null,
      });
      res.status(201).json(row);
    } catch (e: unknown) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  app.patch("/api/local/library/:id", async (req, res) => {
    try {
      const orgId = getConfiguredOrgId();
      const b = (req.body ?? {}) as Record<string, unknown>;
      const str = (v: unknown) => (typeof v === "string" ? v.trim() : undefined);
      const patch = {
        published: typeof b.published === "boolean" ? b.published : undefined,
        title: str(b.title) || undefined,
        body: typeof b.body === "string" ? b.body : undefined,
        topic: str(b.topic),
        theme: str(b.theme),
        complexity: str(b.complexity),
      };
      const clean = Object.fromEntries(
        Object.entries(patch).filter(([, v]) => v !== undefined),
      );
      if (Object.keys(clean).length === 0) {
        return res.status(400).json({ error: "No fields to update" });
      }
      const row = await updatePublishedContent(orgId, Number(req.params.id), clean);
      if (!row) return res.status(404).json({ error: "Not found" });
      res.json(row);
    } catch (e: unknown) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  app.delete("/api/local/library/:id", async (req, res) => {
    try {
      const orgId = getConfiguredOrgId();
      const id = Number(req.params.id);
      await deletePublishedContent(orgId, id);
      // Return the source harvested link (if any) to the review queue so the
      // URL can be re-published — re-harvesting is blocked by the org+url index.
      await resetHarvestedLinkForPublishedContent(orgId, id);
      res.json({ ok: true });
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Link harvester (staged meditation links from module texts)
  // -----------------------------------------------------------------------

  // Scan all MindfulText modules for URLs and stage new ones for review.
  app.post("/api/local/library/harvest", async (req, res) => {
    try {
      const orgId = getConfiguredOrgId();
      const sessionId = extractSessionId(req);
      const cookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
      if (!cookies) {
        return res.status(401).json({ error: "Not signed in to MindfulText — sign in from Settings first." });
      }
      const summary = await harvestModuleLinks(orgId, cookies);
      res.json(summary);
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // List harvested links, optionally by status ("staged" | "published" | "discarded").
  app.get("/api/local/library/staged", async (req, res) => {
    try {
      const orgId = getConfiguredOrgId();
      const status = typeof req.query.status === "string" ? req.query.status : undefined;
      res.json(await listHarvestedLinks(orgId, status));
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // Edit a staged link (discard / restore / tweak suggestions).
  app.patch("/api/local/library/staged/:id", async (req, res) => {
    try {
      const orgId = getConfiguredOrgId();
      const b = (req.body ?? {}) as Record<string, unknown>;
      const patch: Record<string, unknown> = {};
      if (typeof b.status === "string" && ["staged", "discarded"].includes(b.status)) {
        patch.status = b.status;
      }
      if (typeof b.suggestedTitle === "string") patch.suggestedTitle = b.suggestedTitle.trim();
      if (typeof b.suggestedTheme === "string") patch.suggestedTheme = b.suggestedTheme.trim();
      if (Object.keys(patch).length === 0) {
        return res.status(400).json({ error: "No fields to update" });
      }
      const row = await updateHarvestedLink(orgId, Number(req.params.id), patch);
      if (!row) return res.status(404).json({ error: "Not found" });
      res.json(row);
    } catch (e: unknown) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  // Confirm a staged link as a meditation and publish it into the library.
  app.post("/api/local/library/staged/:id/publish", async (req, res) => {
    try {
      const orgId = getConfiguredOrgId();
      const id = Number(req.params.id);
      const link = await getHarvestedLink(orgId, id);
      if (!link) return res.status(404).json({ error: "Not found" });
      if (link.status === "published") {
        return res.status(409).json({ error: "Already published", publishedContentId: link.publishedContentId });
      }
      const b = (req.body ?? {}) as Record<string, unknown>;
      const title =
        (typeof b.title === "string" && b.title.trim()) ||
        link.suggestedTitle ||
        link.url;
      const theme =
        (typeof b.theme === "string" && b.theme.trim()) || link.suggestedTheme || null;
      const complexity =
        (typeof b.complexity === "string" && b.complexity.trim()) || null;
      const description = typeof b.description === "string" ? b.description.trim() : "";

      const row = await createPublishedContent({
        organizationId: orgId,
        title,
        body: description,
        topic: typeof b.topic === "string" && b.topic.trim() ? b.topic.trim() : theme,
        sourceType: "module",
        sourceId: link.moduleId,
        contentType: "meditation",
        url: link.url,
        theme,
        complexity,
        sourceDay: link.dayIndex,
      });
      await updateHarvestedLink(orgId, id, {
        status: "published",
        publishedContentId: row.id,
      });
      res.status(201).json(row);
    } catch (e: unknown) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  // Subscriber page-view stats for the Dashboard engagement tab.
  app.get("/api/local/page-stats", async (req, res) => {
    try {
      const orgId = getConfiguredOrgId();
      const days = req.query.days ? Number(req.query.days) : undefined;
      res.json(await getPageViewStats(orgId, Number.isFinite(days) ? days : undefined));
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Content drafts
  // -----------------------------------------------------------------------

  app.post("/api/local/drafts", async (req, res) => {
    try {
      const draft = await createContentDraft(req.body);
      res.status(201).json(draft);
    } catch (e: unknown) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  app.get("/api/local/drafts/:orgId", async (req, res) => {
    try {
      const drafts = await getContentDrafts(req.params.orgId);
      res.json(drafts);
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.get("/api/local/drafts/detail/:id", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "contentDraft", req.params.id))) return;
      const draft = await getContentDraft(Number(req.params.id));
      if (!draft) return res.status(404).json({ error: "Not found" });
      res.json(draft);
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.patch("/api/local/drafts/:id", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "contentDraft", req.params.id))) return;
      const draft = await updateContentDraft(Number(req.params.id), req.body);
      res.json(draft);
    } catch (e: unknown) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  app.post("/api/local/drafts/:id/push", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "contentDraft", req.params.id))) return;
      const id = Number(req.params.id);
      const draft = await getContentDraft(id);
      if (!draft) return res.status(404).json({ error: "Draft not found" });

      if (draft.status === "pushed") {
        return res.status(409).json({
          error: "Draft already pushed",
          mindfulTextModuleId: draft.mindfulTextModuleId,
        });
      }

      if (!draft.generatedTexts) {
        return res
          .status(400)
          .json({ error: "Draft has no generated texts — run the generate step first." });
      }

      const modulePayload: Record<string, unknown> = {
        name: draft.title,
        moduleType: draft.moduleType ?? "sms",
      };

      // If this draft is targeted at an audience tag, include it on the
      // module so MindfulText only delivers to contacts with that tag. Verify
      // the tag still exists on at least one contact before pushing — surface
      // a clear error otherwise.
      if (draft.audienceTag) {
        const sessionIdForTagCheck = extractSessionId(req);
        const cookiesForTagCheck =
          sessionStore[sessionIdForTagCheck] || sessionStore[AUTO_SESSION_ID] || "";
        if (cookiesForTagCheck) {
          try {
            const contacts = await fetchAllMTContacts(draft.organizationId, {
              Accept: "application/json",
              "User-Agent": "MindfulText-CustomFrontend/1.0",
              Cookie: cookiesForTagCheck,
            });
            const tagExists = contacts.some(
              (c) => Array.isArray(c.tags) && c.tags.includes(draft.audienceTag as string),
            );
            if (!tagExists) {
              return res.status(400).json({
                error: `Audience tag "${draft.audienceTag}" no longer exists on any contact — push aborted. Update or clear the tag and try again.`,
              });
            }
          } catch {
            // Network/auth issues fetching contacts are non-fatal for tag verification —
            // proceed and let MindfulText decide.
          }
        }
        modulePayload.tags = [draft.audienceTag];
      }

      const gt = draft.generatedTexts as unknown;
      if (Array.isArray(gt)) {
        modulePayload.texts = gt;
      } else if (gt && typeof gt === "object") {
        const asRecord = gt as Record<string, unknown>;
        if (Array.isArray(asRecord.texts)) {
          modulePayload.texts = asRecord.texts;
        } else if (Array.isArray(asRecord.messages)) {
          modulePayload.texts = asRecord.messages;
        } else {
          modulePayload.texts = [gt];
        }
      } else if (gt !== null && gt !== undefined) {
        modulePayload.texts = [gt];
      }

      const sessionId = extractSessionId(req);
      const storedCookies = sessionStore[sessionId] || "";
      const orgId = draft.organizationId;
      const targetUrl = `https://dev.mindfultext.com/api/modules/${orgId}`;

      const proxyHeaders: Record<string, string> = {
        "Content-Type": "application/json",
      };
      if (storedCookies) proxyHeaders.Cookie = storedCookies;

      console.log(
        `[PUSH] POST → ${targetUrl} (session: ${sessionId.substring(0, 8)}…)`,
      );

      const mtResponse = await mtFetch(`/api/modules/${orgId}`, {
        method: "POST",
        headers: proxyHeaders,
        body: JSON.stringify(modulePayload),
      });

      const responseText = await mtResponse.text();
      let responseData: unknown;
      try {
        responseData = JSON.parse(responseText);
      } catch {
        responseData = responseText;
      }

      console.log(`[PUSH] → ${mtResponse.status}: ${responseText.substring(0, 200)}`);

      if (!mtResponse.ok) {
        return res.status(mtResponse.status).json({
          error: "MindfulText API rejected the module",
          details: responseData,
        });
      }

      let moduleId: string | null = null;
      if (responseData && typeof responseData === "object") {
        const r = responseData as Record<string, unknown>;
        const inner = r.data ?? r;
        if (inner && typeof inner === "object") {
          const d = inner as Record<string, unknown>;
          const raw = d.id ?? d.moduleId ?? null;
          if (raw !== null) moduleId = String(raw);
        }
      }

      const updated = await updateContentDraft(id, {
        status: "pushed",
        mindfulTextModuleId: moduleId ?? undefined,
      });

      res.json({ draft: updated, moduleId, mindfulTextResponse: responseData });
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — AI content generation pipeline
  // -----------------------------------------------------------------------

  /** Step 1: Plan content (OpenRouter Auto Router unless OPENROUTER_MODEL is set) */
  app.post("/api/local/ai/plan", async (req, res) => {
    try {
      const { organizationId, topic, audience, goals, textCount, additionalContext, audienceTag } = req.body;
      if (!organizationId || !topic) {
        return res.status(400).json({ error: "organizationId and topic are required" });
      }

      const result = await createContentPlan({
        organizationId,
        topic,
        audience,
        goals,
        textCount,
        additionalContext,
        audienceTag: audienceTag || null,
      });

      const contentPlan = parseJsonContent(result.content);

      const draft = await createContentDraft({
        organizationId,
        title: topic,
        contentPlan,
        audienceTag: audienceTag || null,
        status: "planning",
        metadata: {
          planModel: result.model,
          planTokens: result.totalTokens,
          planCostUsd: result.estimatedCostUsd,
        },
      });

      res.status(201).json({ draft, tokenUsage: {
        model: result.model,
        promptTokens: result.promptTokens,
        completionTokens: result.completionTokens,
        estimatedCostUsd: result.estimatedCostUsd,
      }});
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  /** Step 2: Generate texts from plan (OpenRouter Auto Router unless OPENROUTER_MODEL is set) */
  app.post("/api/local/ai/generate/:draftId", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "contentDraft", req.params.draftId))) return;
      const draftId = Number(req.params.draftId);
      const draft = await getContentDraft(draftId);
      if (!draft) return res.status(404).json({ error: "Draft not found" });

      const result = await generateTextsFromPlan({
        organizationId: draft.organizationId,
        contentPlan: draft.contentPlan,
        audienceTag: draft.audienceTag,
      });

      const generatedTexts = parseJsonContent(result.content);

      const existingMeta =
        draft.metadata !== null && typeof draft.metadata === "object"
          ? (draft.metadata as Record<string, unknown>)
          : {};

      const updated = await updateContentDraft(draftId, {
        generatedTexts,
        status: "draft",
        metadata: {
          ...existingMeta,
          generateModel: result.model,
          generateTokens: result.totalTokens,
          generateCostUsd: result.estimatedCostUsd,
        },
      });

      res.json({ draft: updated, tokenUsage: {
        model: result.model,
        promptTokens: result.promptTokens,
        completionTokens: result.completionTokens,
        estimatedCostUsd: result.estimatedCostUsd,
      }});
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  /** Get available models and costs */
  app.get("/api/local/ai/models", (_req, res) => {
    res.json(getAvailableModels());
  });

  // -----------------------------------------------------------------------
  // Local API — Inbound messages + draft reply generation
  // -----------------------------------------------------------------------

  /** Record an inbound message and auto-generate a draft reply */
  app.post("/api/local/inbound", async (req, res) => {
    try {
      const { organizationId, contactId, contactPhone, content, metadata, contactTags } =
        req.body;
      if (!organizationId || !content) {
        return res
          .status(400)
          .json({ error: "organizationId and content are required" });
      }

      const sessionId = extractSessionId(req);
      const storedCookies =
        sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || undefined;

      const result = await processInboundReply({
        organizationId,
        contactId,
        contactPhone,
        content,
        metadata,
        contactTags: Array.isArray(contactTags)
          ? contactTags.map(String)
          : [],
        storedCookies,
        eventSource: "webhook",
      });

      if (result.skipped) {
        return res.status(200).json(result);
      }

      res.status(201).json({
        inbound: result.inbound,
        draftReply: result.draftReply,
        reshape: result.reshape,
        tokenUsage: result.tokenUsage,
      });
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  /** Poll MindfulText for new inbound replies and run the intake pipeline. */
  app.post("/api/local/inbound/poll-now", async (req, res) => {
    try {
      const orgId =
        (req.body?.organizationId as string | undefined) ||
        getConfiguredOrgId();
      const result = await pollInboundReplies(orgId);
      res.json(result);
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.get("/api/local/inbound/:orgId", async (req, res) => {
    try {
      res.json(await getInboundMessages(req.params.orgId));
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  /**
   * One-shot backfill: stamp `moduleId` onto historical inbound rows that
   * don't have it yet, using the same nearest-prior-`advanced`-event logic as
   * the write-time path. Idempotent — only touches rows where moduleId IS NULL.
   * Re-run from `scripts/smoke-test.sh` or via the Reply Analytics page button.
   */
  app.post("/api/local/inbound/backfill-attribution", async (req, res) => {
    try {
      const orgId = (req.body?.organizationId as string | undefined) || (req.query.orgId as string | undefined);
      if (!orgId) {
        return res.status(400).json({ error: "organizationId required" });
      }
      const all = await getInboundMessages(orgId);
      // Idempotent: skip rows already processed (either attributed or
      // explicitly marked "none" by a prior backfill / write-time pass).
      const candidates = all.filter((r) => !r.moduleId && !r.attributionSource && r.contactId);
      let attributed = 0;
      let skipped = 0;
      for (const row of candidates) {
        const receivedAt = row.receivedAt ?? new Date();
        const prior = await findPriorAdvancedEvent(orgId, row.contactId!, receivedAt);
        if (prior?.moduleId) {
          const ageMs = receivedAt.getTime() - (prior.createdAt?.getTime() ?? receivedAt.getTime());
          await setInboundAttribution(row.id, {
            moduleId: prior.moduleId,
            attributionSource: "prior_send",
            metadata: {
              ...(typeof row.metadata === "object" && row.metadata ? row.metadata as Record<string, unknown> : {}),
              priorSendEventId: prior.id,
              priorSendAgeMs: ageMs,
              backfilled: true,
            },
          });
          attributed++;
        } else {
          await setInboundAttribution(row.id, { moduleId: null, attributionSource: "none" });
          skipped++;
        }
      }
      res.json({ scanned: all.length, candidates: candidates.length, attributed, skipped });
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  /**
   * Reply analytics — module-level send/reply aggregates with optional date
   * range. Module names are resolved via the proxied MT modules endpoint.
   * Cutoff for "low confidence" replies is 3 days; the UI flags those rows.
   */
  app.get("/api/local/reply-analytics/:orgId", async (req, res) => {
    try {
      const { orgId } = req.params;
      const fromRaw = req.query.from as string | undefined;
      const toRaw = req.query.to as string | undefined;
      const start = fromRaw ? new Date(fromRaw) : null;
      const end = toRaw ? new Date(toRaw) : null;

      const { sendRows, replyRows } = await aggregateReplyAnalytics(orgId, start, end);

      // Resolve module names from MT (best-effort — falls back to moduleId).
      const sessionId = extractSessionId(req);
      const cookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
      const nameById = new Map<string, string>();
      if (cookies) {
        try {
          const r = await mtFetch(`/api/modules/byOrganization/${orgId}`, { cookies });
          if (r.ok) {
            const json = await r.json() as { data?: { id: string; name?: string }[] };
            for (const m of json.data ?? []) {
              if (m.id) nameById.set(String(m.id), m.name ?? String(m.id));
            }
          }
        } catch {
          // best-effort — fall through with empty cache
        }
      }

      const byModule = new Map<string, { moduleId: string; sends: number; replies: number; lastReplyAt: Date | null }>();
      const ensure = (mid: string) => {
        if (!byModule.has(mid)) byModule.set(mid, { moduleId: mid, sends: 0, replies: 0, lastReplyAt: null });
        return byModule.get(mid)!;
      };
      for (const r of sendRows) {
        if (!r.moduleId) continue;
        ensure(r.moduleId).sends = r.sends;
      }
      for (const r of replyRows) {
        if (!r.moduleId) continue;
        const row = ensure(r.moduleId);
        row.replies = r.replies;
        row.lastReplyAt = r.lastReplyAt ? new Date(r.lastReplyAt) : null;
      }

      const rows = Array.from(byModule.values()).map((r) => ({
        moduleId: r.moduleId,
        moduleName: nameById.get(r.moduleId) ?? r.moduleId,
        sends: r.sends,
        replies: r.replies,
        replyRate: r.sends > 0 ? r.replies / r.sends : 0,
        lastReplyAt: r.lastReplyAt ? r.lastReplyAt.toISOString() : null,
      }));

      res.json({
        rows,
        range: { from: start?.toISOString() ?? null, to: end?.toISOString() ?? null },
      });
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  /** Inbound messages attributed to a specific module — for the drawer. */
  app.get("/api/local/reply-analytics/:orgId/module/:moduleId", async (req, res) => {
    try {
      const { orgId, moduleId } = req.params;
      const fromRaw = req.query.from as string | undefined;
      const toRaw = req.query.to as string | undefined;
      const start = fromRaw ? new Date(fromRaw) : null;
      const end = toRaw ? new Date(toRaw) : null;

      const all = await listAttributedInbounds(orgId, start, end);
      const filtered = all.filter((r) => r.moduleId === moduleId);
      // Cutoff for low-confidence: 3 days (≈259_200_000 ms). Tunable here.
      const LOW_CONFIDENCE_MS = 3 * 24 * 60 * 60 * 1000;
      const messages = filtered.map((r) => {
        const meta = (r.metadata as Record<string, unknown> | null) ?? {};
        const ageMs = typeof meta.priorSendAgeMs === "number" ? meta.priorSendAgeMs : null;
        return {
          id: r.id,
          contactId: r.contactId,
          contactPhone: r.contactPhone,
          content: r.content,
          receivedAt: r.receivedAt ? r.receivedAt.toISOString() : null,
          attributionSource: r.attributionSource,
          priorSendAgeMs: ageMs,
          lowConfidence: ageMs !== null && ageMs > LOW_CONFIDENCE_MS,
        };
      });
      res.json({ moduleId, messages });
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Draft messages
  // -----------------------------------------------------------------------

  app.get("/api/local/draft-messages/:orgId", async (req, res) => {
    try {
      const orgId = req.params.orgId;
      const drafts = await getDraftMessages(orgId);
      const inbound = await getInboundMessages(orgId);
      const inboundById = new Map(inbound.map((m) => [m.id, m]));
      const enriched = drafts.map((d) => ({
        ...d,
        inboundContent: d.inboundMessageId
          ? inboundById.get(d.inboundMessageId)?.content ?? null
          : null,
        inboundReceivedAt: d.inboundMessageId
          ? inboundById.get(d.inboundMessageId)?.receivedAt ?? null
          : null,
      }));
      res.json(enriched);
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.get("/api/local/draft-messages/:orgId/count", async (req, res) => {
    try {
      res.json({
        count: await countActionableDraftMessages(req.params.orgId),
      });
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.patch("/api/local/draft-messages/:id", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "draftMessage", req.params.id))) return;
      const updated = await updateDraftMessage(
        Number(req.params.id),
        req.body,
      );
      res.json(updated);
    } catch (e: unknown) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Agent memory
  // -----------------------------------------------------------------------

  app.post("/api/local/memory", async (req, res) => {
    try {
      const mem = await upsertMemory(req.body);
      res.status(201).json(mem);
    } catch (e: unknown) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  app.get("/api/local/memory/:orgId", async (req, res) => {
    try {
      res.json(await getActiveMemories(req.params.orgId));
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.delete("/api/local/memory/:id", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "agentMemory", req.params.id))) return;
      await deleteMemory(Number(req.params.id));
      res.json({ ok: true });
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Agent rules
  // -----------------------------------------------------------------------

  app.post("/api/local/rules", async (req, res) => {
    try {
      const rule = await createAgentRule(req.body);
      res.status(201).json(rule);
    } catch (e: unknown) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  app.get("/api/local/rules/:orgId", async (req, res) => {
    try {
      const scope = req.query.scope as string | undefined;
      res.json(await getActiveRules(req.params.orgId, scope));
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.patch("/api/local/rules/:id", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "agentRule", req.params.id))) return;
      const updated = await updateAgentRule(Number(req.params.id), req.body);
      res.json(updated);
    } catch (e: unknown) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  app.delete("/api/local/rules/:id", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "agentRule", req.params.id))) return;
      await deleteAgentRule(Number(req.params.id));
      res.json({ ok: true });
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  /** Reload mindfultext.md from disk */
  app.post("/api/local/rules/reload-base", async (_req, res) => {
    invalidateBaseRulesCache();
    res.json({ ok: true, message: "mindfultext.md cache cleared" });
  });

  /** Read the base agent prompt (mindfultext.md). */
  app.get("/api/local/base-prompt", async (_req, res) => {
    try {
      res.json({ content: getBaseRules() });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  /** Overwrite the base agent prompt (mindfultext.md) and refresh the cache. */
  app.put("/api/local/base-prompt", async (req, res) => {
    try {
      const content = (req.body as { content?: unknown })?.content;
      if (typeof content !== "string") {
        return res.status(400).json({ error: "content (string) is required" });
      }
      setBaseRules(content);
      res.json({ ok: true, content });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Token usage
  // -----------------------------------------------------------------------

  app.get("/api/local/tokens/:orgId", async (req, res) => {
    try {
      res.json(await getTokenUsageSummary(req.params.orgId));
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Content programs (future — basic CRUD for now)
  // -----------------------------------------------------------------------

  app.post("/api/local/programs", async (req, res) => {
    try {
      const program = await createContentProgram(req.body);
      res.status(201).json(program);
    } catch (e: unknown) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  app.get("/api/local/programs/:orgId", async (req, res) => {
    try {
      res.json(await getContentPrograms(req.params.orgId));
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.get("/api/local/programs/detail/:id", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "contentProgram", req.params.id))) return;
      const program = await getContentProgram(Number(req.params.id));
      if (!program) return res.status(404).json({ error: "Not found" });
      res.json(program);
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.patch("/api/local/programs/:id", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "contentProgram", req.params.id))) return;
      const updated = await updateContentProgram(
        Number(req.params.id),
        req.body,
      );
      res.json(updated);
    } catch (e: unknown) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  app.delete("/api/local/programs/:id", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "contentProgram", req.params.id))) return;
      await deleteContentProgram(Number(req.params.id));
      res.json({ ok: true });
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Ask (chat with MindfulText data)
  // -----------------------------------------------------------------------

  app.post("/api/ask", async (req, res) => {
    try {
      const { question, model } = req.body as {
        question?: string;
        model?: string;
      };

      if (!question || typeof question !== "string" || !question.trim()) {
        return res.status(400).json({ error: "question is required" });
      }

      // Org ID is derived server-side from the authenticated session — never
      // trusted from client input. Fail-closed: if no session cookies are present
      // (user not authenticated via proxy), reject the request immediately.
      const KNOWN_ORG_ID = getConfiguredOrgId();
      const sessionId = extractSessionId(req);
      const storedCookies = sessionStore[sessionId] || "";

      if (!storedCookies) {
        return res.status(401).json({ error: "Not authenticated — please log in first." });
      }

      const proxyHeaders: Record<string, string> = {
        Accept: "application/json",
        "User-Agent": "MindfulText-CustomFrontend/1.0",
        Cookie: storedCookies,
      };

      // Attempt to resolve org from MindfulText API; fall back to known single-org ID
      // only when the endpoint is unavailable (not when the session is invalid).
      let orgId = KNOWN_ORG_ID;
      try {
        const orgRes = await mtFetch(
          "/api/organizations/byUser",
          { headers: proxyHeaders }
        );
        if (orgRes.ok) {
          const orgJson = (await orgRes.json()) as { data?: { id: string | number }[] } | { id: string | number }[];
          const orgs = Array.isArray(orgJson)
            ? orgJson
            : Array.isArray((orgJson as { data?: { id: string | number }[] }).data)
              ? (orgJson as { data: { id: string | number }[] }).data
              : [];
          if (orgs.length > 0 && orgs[0].id) {
            orgId = String(orgs[0].id).padStart(8, "0");
          }
        } else if (orgRes.status >= 500) {
          return res.status(502).json({ error: "Could not resolve organization — upstream error." });
        }
        // 401/403/404: endpoint absent or requires different permissions on this
        // deployment — fall through to KNOWN_ORG_ID (single-org deployment).
      } catch {
        /* network error — fail closed */
        return res.status(502).json({ error: "Could not reach MindfulText to verify organization." });
      }

      // Build a lightweight data snapshot for context
      const contextParts: string[] = [];

      // Local drafts (keyed to resolved org)
      try {
        const drafts = await getContentDrafts(orgId);
        const recentDrafts = drafts
          .slice(0, 5)
          .map((d) => `"${d.title}" (${d.status})`)
          .join(", ");
        contextParts.push(`Total local drafts: ${drafts.length}`);
        if (drafts.length > 0) contextParts.push(`Recent drafts: ${recentDrafts}`);
      } catch {
        /* non-fatal */
      }

      // MindfulText contacts snapshot via session-keyed proxy
      // Contacts use POST /api/contacts/{orgId} (not a GET byOrganization endpoint)
      try {
        const contactsRes = await mtFetch(
          `/api/contacts/${orgId}`,
          {
            method: "POST",
            headers: { ...proxyHeaders, "Content-Type": "application/json" },
            body: JSON.stringify({}),
          }
        );
        if (contactsRes.ok) {
          const contactsJson = (await contactsRes.json()) as {
            data?: { firstName?: string; lastName?: string; phone?: string; status?: string }[];
            total?: number;
          } | { firstName?: string; lastName?: string; phone?: string; status?: string }[];
          const list = Array.isArray(contactsJson)
            ? contactsJson
            : Array.isArray((contactsJson as { data?: unknown[] }).data)
              ? (contactsJson as { data: { firstName?: string; lastName?: string; phone?: string; status?: string }[] }).data
              : [];
          const total = !Array.isArray(contactsJson) && (contactsJson as { total?: number }).total != null
            ? (contactsJson as { total: number }).total
            : list.length;
          contextParts.push(`Total contacts: ${total}`);
        }
      } catch {
        /* non-fatal */
      }

      try {
        const journeysRes = await mtFetch(
          `/api/journeys/byOrganization/${orgId}`,
          { headers: proxyHeaders }
        );
        if (journeysRes.ok) {
          const journeysJson = (await journeysRes.json()) as {
            data?: { name: string; status?: string; description?: string }[];
          } | { name: string; status?: string; description?: string }[];
          const list = Array.isArray(journeysJson)
            ? journeysJson
            : Array.isArray((journeysJson as { data?: { name: string; status?: string }[] }).data)
              ? (journeysJson as { data: { name: string; status?: string; description?: string }[] }).data
              : [];
          contextParts.push(`Total journeys: ${list.length}`);
          if (list.length > 0) {
            const details = list.slice(0, 8).map((j) => {
              const status = j.status ?? "unknown";
              const desc = j.description ? ` — ${j.description.substring(0, 60)}` : "";
              return `"${j.name}" (${status})${desc}`;
            }).join("; ");
            contextParts.push(`Sample journeys: ${details}`);
          }
        }
      } catch {
        /* non-fatal */
      }

      const context = contextParts.length > 0 ? contextParts.join("\n") : "";

      const result = await askQuestion({
        organizationId: orgId,
        question,
        model,
        context,
      });

      res.json({
        answer: result.content,
        model: result.model,
        tokenUsage: {
          promptTokens: result.promptTokens,
          completionTokens: result.completionTokens,
          totalTokens: result.totalTokens,
          estimatedCostUsd: result.estimatedCostUsd,
        },
      });
    } catch (e: unknown) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Ask streaming (SSE)
  // -----------------------------------------------------------------------

  app.post("/api/local/ask", async (req, res) => {
    const { question, model } = req.body as {
      question?: string;
      model?: string;
    };

    if (!question || typeof question !== "string" || !question.trim()) {
      res.status(400).json({ error: "question is required" });
      return;
    }

    const sessionId = extractSessionId(req);
    const storedCookies = sessionStore[sessionId] || "";

    if (!storedCookies) {
      res.status(401).json({ error: "Not authenticated — please log in first." });
      return;
    }

    // ── Open the SSE stream BEFORE any data fetches so the client sees
    //    activity immediately instead of staring at a blank spinner.
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();

    const flushRes = () => {
      if (typeof (res as unknown as { flush?: () => void }).flush === "function") {
        (res as unknown as { flush: () => void }).flush();
      }
    };
    const sendChunk = (chunk: Record<string, unknown>) => {
      if (!res.writableEnded) {
        res.write(`data: ${JSON.stringify(chunk)}\n\n`);
        flushRes();
      }
    };
    const sendStatus = (text: string) => sendChunk({ type: "status", text });

    res.write(": ping\n\n");
    flushRes();

    const abortController = new AbortController();
    req.on("close", () => abortController.abort());

    try {
      // ── Resolve org ID (falls back to configured value on 403/404) ──────
      const proxyHeaders: Record<string, string> = {
        Accept: "application/json",
        "User-Agent": "MindfulText-CustomFrontend/1.0",
        Cookie: storedCookies,
      };

      let orgId = getConfiguredOrgId();
      try {
        const orgRes = await mtFetch(
          "/api/organizations/byUser",
          { headers: proxyHeaders }
        );
        if (orgRes.ok) {
          const orgJson = (await orgRes.json()) as
            | { data?: { id: string | number }[] }
            | { id: string | number }[];
          const orgs = Array.isArray(orgJson)
            ? orgJson
            : Array.isArray((orgJson as { data?: { id: string | number }[] }).data)
              ? (orgJson as { data: { id: string | number }[] }).data
              : [];
          if (orgs.length > 0 && orgs[0].id) {
            orgId = String(orgs[0].id).padStart(8, "0");
          }
        }
        // 401/403/404 → fall through to configured orgId
      } catch {
        // network error → fall through to configured orgId
      }

      // ── Build context with live status updates ────────────────────────────
      const contextParts: string[] = [];

      sendStatus("Loading drafts…");
      try {
        const drafts = await getContentDrafts(orgId);
        contextParts.push(`Total local drafts: ${drafts.length}`);
        if (drafts.length > 0) {
          const recentDrafts = drafts.slice(0, 5)
            .map((d) => `"${d.title}" (${d.status})`)
            .join(", ");
          contextParts.push(`Recent drafts: ${recentDrafts}`);
        }
        sendStatus(`✓ ${drafts.length} draft${drafts.length !== 1 ? "s" : ""} loaded`);
      } catch {
        sendStatus("✓ Drafts unavailable (skipped)");
      }

      sendStatus("Loading contacts…");
      try {
        const allContacts = await fetchAllMTContacts(orgId, proxyHeaders);
        const active = allContacts.filter((c) => !c.isArchived);
        contextParts.push(`Total contacts: ${active.length}`);

        const tagCounts = new Map<string, number>();
        for (const c of active) {
          if (Array.isArray(c.tags)) {
            for (const tag of c.tags) {
              if (typeof tag === "string" && tag.trim()) {
                const t = tag.trim();
                tagCounts.set(t, (tagCounts.get(t) ?? 0) + 1);
              }
            }
          }
        }
        if (tagCounts.size > 0) {
          const tagSummary = Array.from(tagCounts.entries())
            .sort((a, b) => b[1] - a[1])
            .map(([tag, count]) => `${tag} (${count})`)
            .join(", ");
          contextParts.push(`Contact tags: ${tagSummary}`);
        }
        sendStatus(`✓ ${active.length} contact${active.length !== 1 ? "s" : ""} loaded`);
      } catch {
        sendStatus("✓ Contacts unavailable (skipped)");
      }

      sendStatus("Loading journeys…");
      try {
        const journeysRes = await mtFetch(
          `/api/journeys/byOrganization/${orgId}`,
          { headers: proxyHeaders }
        );
        if (journeysRes.ok) {
          const journeysJson = (await journeysRes.json()) as
            | { data?: { name: string; status?: string }[] }
            | { name: string; status?: string }[];
          const list = Array.isArray(journeysJson)
            ? journeysJson
            : Array.isArray((journeysJson as { data?: { name: string; status?: string }[] }).data)
              ? (journeysJson as { data: { name: string; status?: string }[] }).data
              : [];
          contextParts.push(`Total journeys: ${list.length}`);
          if (list.length > 0) {
            const names = list.slice(0, 5)
              .map((j) => `"${j.name}" (${j.status ?? "unknown"})`)
              .join(", ");
            contextParts.push(`Journeys: ${names}`);
          }
          sendStatus(`✓ ${list.length} journey${list.length !== 1 ? "s" : ""} loaded`);
        }
      } catch {
        sendStatus("✓ Journeys unavailable (skipped)");
      }

      sendStatus("Thinking…");

      const context = contextParts.join("\n");

      // ── Stream AI response ────────────────────────────────────────────────
      try {
        for await (const chunk of askQuestionStream(
          { organizationId: orgId, question, model, context },
          abortController.signal,
        )) {
          if (res.writableEnded) break;
          sendChunk(chunk as unknown as Record<string, unknown>);
        }
      } catch (e: unknown) {
        // Error thrown from within askQuestionStream (e.g. network failure
        // reaching OpenRouter after headers were sent). Tag as modelError so
        // the client can offer a "Retry with Auto model" fallback.
        sendChunk({ type: "error", error: errMsg(e), modelError: true });
      }
    } catch (e: unknown) {
      // Error from context-gathering (before the stream started), or any other
      // application-level failure. Not a model API error.
      sendChunk({ type: "error", error: errMsg(e) });
    } finally {
      if (!res.writableEnded) res.end();
    }
  });

  // -----------------------------------------------------------------------
  // Auto-session endpoint — lets the frontend detect server-side auto-login
  // -----------------------------------------------------------------------

  // Bind the auto-login cookies (stored under AUTO_SESSION_ID) to the
  // caller's own X-Session-ID, so subsequent /api/local/* and proxy calls
  // authenticate against the caller's session entry rather than relying
  // on an AUTO_SESSION_ID fallback. This is what makes dev-mode auto-
  // login work after the strict /api/local/* auth gate above.
  function bindAutoSessionToCaller(req: Request) {
    const su = getAutoSessionUser();
    if (!su) return;
    const sid = extractSessionId(req);
    if (!sid || sid === AUTO_SESSION_ID) return;
    const autoCookies = sessionStore[AUTO_SESSION_ID];
    if (!autoCookies) return;
    if (sessionStore[sid] !== autoCookies) {
      sessionStore[sid] = autoCookies;
      saveSessionStore(sessionStore);
    }
    sessionOrgs[sid] = su.orgId;
  }

  app.get("/api/auto-session", (req, res) => {
    const su = getAutoSessionUser();
    if (su) {
      bindAutoSessionToCaller(req);
      res.json(su);
    } else {
      res.status(204).end();
    }
  });

  // POST /api/auto-session/refresh — triggered by the client on proxy 401.
  // Runs an immediate session validity check and re-login if needed, then
  // returns the refreshed session so the client can update its credentials
  // without waiting for the next 30-minute keep-alive interval.
  app.post("/api/auto-session/refresh", async (req, res) => {
    try {
      await checkAndRefreshAutoSession();
      const su = getAutoSessionUser();
      if (su) {
        bindAutoSessionToCaller(req);
        res.json(su);
      } else {
        res.status(204).end();
      }
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
    }
  });

  // -----------------------------------------------------------------------
  // Health / info
  // -----------------------------------------------------------------------

  // Debug: expose raw contacts API shape (pagination fields) for the first page
  app.get("/api/local/contacts-debug", async (req, res) => {
    const sessionId = extractSessionId(req);
    const storedCookies = sessionStore[sessionId] || "";
    if (!storedCookies) {
      res.status(401).json({ error: "Not authenticated" });
      return;
    }
    const headers: Record<string, string> = {
      Accept: "application/json",
      "User-Agent": "MindfulText-CustomFrontend/1.0",
      Cookie: storedCookies,
    };
    try {
      const path = `/api/contacts/byOrganization/${getConfiguredOrgId()}?page=1&pageSize=100`;
      const r = await mtFetch(path, { method: "GET", headers });
      const raw = (await r.json()) as Record<string, unknown>;
      const nonDataKeys = Object.keys(raw).filter((k) => k !== "data");
      const dataLen = Array.isArray(raw.data) ? (raw.data as unknown[]).length : null;
      res.json({
        status: r.status,
        nonDataKeys,
        dataLength: dataLen,
        paginationFields: Object.fromEntries(
          nonDataKeys.map((k) => [k, raw[k]])
        ),
      });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Entity snapshots (pre-edit backups for undo)
  // -----------------------------------------------------------------------

  app.post("/api/local/snapshots", async (req, res) => {
    try {
      // Auth gate: require an active session so anonymous users can't dump
      // (or pollute) snapshots which contain full PII records.
      const sessionId = extractSessionId(req);
      const storedCookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
      if (!storedCookies) {
        return res.status(401).json({ error: "Not authenticated — please log in first." });
      }

      const { organizationId, entityType, entityId, entityName, snapshot, reason } =
        req.body as {
          organizationId?: string;
          entityType?: string;
          entityId?: string;
          entityName?: string;
          snapshot?: unknown;
          reason?: string;
        };

      if (!organizationId || !entityType || !entityId || snapshot == null) {
        return res.status(400).json({
          error: "organizationId, entityType, entityId, snapshot are required",
        });
      }

      const row = await createEntitySnapshot({
        organizationId,
        entityType,
        entityId,
        entityName: entityName ?? null,
        snapshot: snapshot as any,
        reason: reason ?? "before_edit",
      });

      res.json(row);
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.get("/api/local/snapshots/:orgId", async (req, res) => {
    try {
      // Auth gate: snapshots contain full PII; require a session.
      const sessionId = extractSessionId(req);
      const storedCookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
      if (!storedCookies) {
        return res.status(401).json({ error: "Not authenticated — please log in first." });
      }

      const { entityType, entityId, limit } = req.query as {
        entityType?: string;
        entityId?: string;
        limit?: string;
      };
      const rows = await listEntitySnapshots(req.params.orgId, {
        entityType,
        entityId,
        limit: limit ? Number(limit) : undefined,
      });
      res.json(rows);
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // Restore a snapshot by re-PUTting it to MindfulText.
  app.post("/api/local/snapshots/:id/restore", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "entitySnapshot", req.params.id))) return;
      const id = Number(req.params.id);
      const snap = await getEntitySnapshot(id);
      if (!snap) return res.status(404).json({ error: "snapshot not found" });

      const sessionId = extractSessionId(req);
      const storedCookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
      if (!storedCookies) {
        return res.status(401).json({ error: "Not authenticated — please log in first." });
      }

      const pluralPath: Record<string, string> = {
        module: "modules",
        contact: "contacts",
        action: "actions",
        journey: "journeys",
      };
      const pathSegment = pluralPath[snap.entityType];
      if (!pathSegment) {
        return res.status(400).json({ error: `unknown entityType: ${snap.entityType}` });
      }

      // Coerce known array fields away from null so MindfulText accepts the body.
      const body = { ...(snap.snapshot as Record<string, any>) };
      body.organizationID = snap.organizationId;
      for (const k of ["texts", "messages", "actionIds", "actionIDs", "tags", "moduleIDs", "moduleIds"]) {
        if (body[k] === null) body[k] = [];
      }

      const upstream = await mtFetch(
        `/api/${pathSegment}/${snap.entityId}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          cookies: storedCookies,
          body: JSON.stringify(body),
        },
      );

      const text = await upstream.text();
      if (!upstream.ok) {
        return res.status(upstream.status).json({
          error: `Restore failed (HTTP ${upstream.status}): ${text.substring(0, 500)}`,
        });
      }
      res.json({ ok: true, snapshotId: snap.id, response: text.substring(0, 500) });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Reshape rules (org-level automation)
  // -----------------------------------------------------------------------

  app.get("/api/local/reshape-rules/:orgId", async (req, res) => {
    try { res.json(await listReshapeRules(req.params.orgId)); }
    catch (e) { res.status(500).json({ error: errMsg(e) }); }
  });
  app.post("/api/local/reshape-rules", async (req, res) => {
    try { res.status(201).json(await createReshapeRule(req.body)); }
    catch (e) { res.status(400).json({ error: errMsg(e) }); }
  });
  app.patch("/api/local/reshape-rules/:id", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "reshapeRule", req.params.id))) return;
      res.json(await updateReshapeRule(Number(req.params.id), req.body));
    } catch (e) { res.status(400).json({ error: errMsg(e) }); }
  });
  app.delete("/api/local/reshape-rules/:id", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "reshapeRule", req.params.id))) return;
      await deleteReshapeRule(Number(req.params.id));
      res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: errMsg(e) }); }
  });

  /**
   * Test a rule against a sample inbound message without persisting anything —
   * lets the operator preview which rules would match and what they'd propose
   * before turning them on.
   */
  app.post("/api/local/reshape-rules/:orgId/test", async (req, res) => {
    try {
      const { orgId } = req.params;
      const sampleContent = String(req.body?.content ?? "");
      const sampleContactId = String(req.body?.contactId ?? "__test_contact__");
      // Build an ephemeral journey object — DO NOT persist a row for the
      // sample contact, otherwise repeated rule-tests would litter the
      // personal_journeys table with throwaway data.
      const ephemeralJourney = {
        id: -1,
        organizationId: orgId,
        contactId: sampleContactId,
        moduleIds: Array.isArray(req.body?.queue) ? req.body.queue as string[] : [],
        currentIndex: 0,
        paused: false,
        lastAdvancedAt: null as Date | null,
        createdAt: null as Date | null,
        updatedAt: null as Date | null,
      };
      const proposals = await evaluateRules({
        organizationId: orgId,
        contactId: sampleContactId,
        inboundContent: sampleContent,
        currentJourney: ephemeralJourney as any,
      });
      res.json({
        matchedRules: proposals.map((p) => ({
          ruleId: p.rule.id,
          ruleName: p.rule.name,
          actionType: p.rule.actionType,
          approvalMode: p.rule.approvalMode,
          ops: p.ops,
          reason: p.reason,
          proposedSequence: p.proposedSequence,
        })),
        currentSequence: ephemeralJourney.moduleIds.slice(ephemeralJourney.currentIndex),
      });
    } catch (e) { res.status(400).json({ error: errMsg(e) }); }
  });

  // -----------------------------------------------------------------------
  // Local API — Pending changes (review queue)
  // -----------------------------------------------------------------------

  app.get("/api/local/pending-changes/:orgId", async (req, res) => {
    try {
      const status = req.query.status as string | undefined;
      const list = await listPendingChanges(req.params.orgId, status);
      // Enrich with the inbound message content + rule name so reviewers
      // can see "what they said" + "which rule fired" in one place.
      const ruleIds = Array.from(new Set(list.map((c) => c.ruleId).filter((x): x is number => !!x)));
      const inboundIds = Array.from(new Set(list.map((c) => c.inboundMessageId).filter((x): x is number => !!x)));
      const allRules = await listReshapeRules(req.params.orgId);
      const ruleById = new Map(allRules.map((r) => [r.id, r]));
      const inboundById = new Map<number, { content: string; receivedAt: Date | string | null }>();
      if (inboundIds.length) {
        const allInbound = await getInboundMessages(req.params.orgId);
        for (const m of allInbound) {
          if (inboundIds.includes(m.id)) inboundById.set(m.id, { content: m.content ?? "", receivedAt: m.receivedAt });
        }
      }
      const enriched = await Promise.all(
        list.map(async (c) => {
          const draft =
            c.inboundMessageId != null
              ? await getDraftMessageByInboundId(req.params.orgId, c.inboundMessageId)
              : null;
          return {
            ...c,
            ruleName: c.ruleId ? ruleById.get(c.ruleId)?.name ?? null : null,
            ruleActionType: c.ruleId ? ruleById.get(c.ruleId)?.actionType ?? null : null,
            inboundContent: c.inboundMessageId
              ? inboundById.get(c.inboundMessageId)?.content ?? null
              : null,
            draftReplyContent: draft?.draftContent ?? null,
            draftReplyStatus: draft?.status ?? null,
          };
        }),
      );
      void ruleIds; // referenced for future per-rule lookups
      res.json(enriched);
    } catch (e) { res.status(500).json({ error: errMsg(e) }); }
  });

  app.get("/api/local/pending-changes/:orgId/count", async (req, res) => {
    try { res.json({ count: await countPendingChanges(req.params.orgId) }); }
    catch (e) { res.status(500).json({ error: errMsg(e) }); }
  });

  // Issue a one-time confirm token for an operator-approved programmatic
  // mutation (send / module / journey edit) while agent-safe mode is on.
  // Reaching this route already requires a valid /api/local operator session.
  app.post("/api/local/operator/confirm-token", (_req, res) => {
    const { token, expiresAt } = issueConfirmToken();
    res.json({ token, expiresAt, agentSafeMode: AGENT_SAFE_MODE });
  });

  /** Approve (or edit-then-approve) a pending change — applies it now. */
  app.post("/api/local/pending-changes/:id/approve", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "pendingChange", req.params.id))) return;
      const id = Number(req.params.id);
      const change = await getPendingChange(id);
      if (!change) return res.status(404).json({ error: "not found" });
      if (change.status !== "pending") {
        return res.status(409).json({ error: `already ${change.status}` });
      }

      const editedSequence = req.body?.proposedSequence as string[] | undefined;
      let ops: ReshapeOp[];
      if (editedSequence) {
        // editedSequence is the upcoming slice (from currentIndex onward).
        // Rebuild the FULL queue by preserving everything before currentIndex
        // so we don't truncate already-sent modules or invalidate the index.
        const journey = await bootstrapJourneyForContact(change.organizationId, change.contactId);
        const past = journey.moduleIds.slice(0, journey.currentIndex);
        ops = [{ op: "reorder", newQueue: [...past, ...editedSequence] }];
      } else {
        ops = (change.proposedOps as unknown as ReshapeOp[]) ?? [];
      }

      await applyOps({
        organizationId: change.organizationId,
        contactId: change.contactId,
        ops,
        source: "review",
        ruleId: change.ruleId ?? undefined,
        reason: change.aiReason ?? undefined,
        inboundMessageId: change.inboundMessageId ?? undefined,
      });

      // Best-effort: record memory + push the next module via launch so the
      // approved change actually moves the contact forward on the wire.
      const sessionId = extractSessionId(req);
      const cookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || undefined;
      recordContactActivity({
        organizationId: change.organizationId,
        contactId: change.contactId,
        note: `${editedSequence ? "edited & approved" : "approved"} pending change #${id}`,
        storedCookies: cookies,
      }).catch(() => {});
      if (cookies) {
        launchNextForContact({
          organizationId: change.organizationId,
          contactId: change.contactId,
          storedCookies: cookies,
          source: "review",
        }).catch(() => {});
      }

      const decided = await decidePendingChange(
        id,
        editedSequence ? "edited" : "approved",
        req.body?.decidedBy,
        editedSequence,
      );
      res.json(decided);
    } catch (e) { res.status(500).json({ error: errMsg(e) }); }
  });

  app.post("/api/local/pending-changes/:id/reject", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "pendingChange", req.params.id))) return;
      const decided = await decidePendingChange(
        Number(req.params.id), "rejected", req.body?.decidedBy,
      );
      res.json(decided);
    } catch (e) { res.status(500).json({ error: errMsg(e) }); }
  });

  // -----------------------------------------------------------------------
  // Local API — Personal journeys (per contact)
  // -----------------------------------------------------------------------

  app.get("/api/local/personal-journey/:orgId/:contactId", async (req, res) => {
    try {
      const journey = await bootstrapJourneyForContact(req.params.orgId, req.params.contactId);
      const events = await listEvents(req.params.orgId, req.params.contactId, 30);
      res.json({ journey, events });
    } catch (e) { res.status(500).json({ error: errMsg(e) }); }
  });

  /** Manual reshape — body: { op: "insert"|"skip"|"reorder"|"pause"|"resume", … } */
  app.post("/api/local/personal-journey/:orgId/:contactId/op", async (req, res) => {
    try {
      const { orgId, contactId } = req.params;
      const op = req.body as ReshapeOp & { reason?: string };
      await applyOps({
        organizationId: orgId, contactId,
        ops: [op as ReshapeOp],
        source: "manual",
        reason: op.reason,
      });
      // Memory: record manual operator action (best-effort).
      const sessionId = extractSessionId(req);
      const cookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || undefined;
      recordContactActivity({
        organizationId: orgId, contactId,
        note: `manual ${op.op}${"moduleId" in op && op.moduleId ? ` ${op.moduleId}` : ""}`,
        storedCookies: cookies,
      }).catch(() => {});
      const journey = await getPersonalJourney(orgId, contactId);
      res.json({ journey });
    } catch (e) { res.status(400).json({ error: errMsg(e) }); }
  });

  // -----------------------------------------------------------------------
  // Local API — Contact memory & profile
  // -----------------------------------------------------------------------

  app.get("/api/local/contact-profile/:orgId/:contactId", async (req, res) => {
    try {
      const profile = await getContactProfile(req.params.orgId, req.params.contactId);
      const memory = await getContactMemory(req.params.orgId, req.params.contactId);
      res.json({ profile, memory });
    } catch (e) { res.status(500).json({ error: errMsg(e) }); }
  });

  app.post("/api/local/contact-profile/:orgId/:contactId/memory-toggle", async (req, res) => {
    try {
      const sessionId = extractSessionId(req);
      const cookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || undefined;
      const enabled = !!req.body?.enabled;
      const profile = await setMemoryEnabled(req.params.orgId, req.params.contactId, enabled, cookies);
      res.json(profile);
    } catch (e) { res.status(500).json({ error: errMsg(e) }); }
  });

  app.post("/api/local/contact-profile/:orgId/:contactId/memory-clear", async (req, res) => {
    try {
      const sessionId = extractSessionId(req);
      const cookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || undefined;
      await clearContactMemory(req.params.orgId, req.params.contactId, cookies);
      res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: errMsg(e) }); }
  });

  // Save the founder-written subscriber-page note for a single contact.
  app.patch("/api/local/contact-profile/:orgId/:contactId/page-note", async (req, res) => {
    try {
      const note = typeof req.body?.note === "string" ? req.body.note : "";
      const profile = await setContactPageNote(req.params.orgId, req.params.contactId, note);
      res.json(profile);
    } catch (e) { res.status(500).json({ error: errMsg(e) }); }
  });

  // -----------------------------------------------------------------------
  // Local API — Personal-journey templates (org default + per-tag)
  // -----------------------------------------------------------------------

  app.get("/api/local/journey-templates/:orgId", async (req, res) => {
    try { res.json(await listPersonalJourneyTemplates(req.params.orgId)); }
    catch (e) { res.status(500).json({ error: errMsg(e) }); }
  });
  app.post("/api/local/journey-templates", async (req, res) => {
    try { res.status(201).json(await upsertPersonalJourneyTemplate(req.body)); }
    catch (e) { res.status(400).json({ error: errMsg(e) }); }
  });
  app.delete("/api/local/journey-templates/:id", async (req, res) => {
    try {
      if (!(await ownsEntity(req, res, "personalJourneyTemplate", req.params.id))) return;
      await deletePersonalJourneyTemplate(Number(req.params.id));
      res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: errMsg(e) }); }
  });

  // -----------------------------------------------------------------------
  // Local API — Real MindfulText analytics ("reporting") proxy
  // -----------------------------------------------------------------------
  // Thin wrapper over POST /api/reporting/{orgId}. Accepts a named `range`
  // (today/3d/week/month/year/all) or an explicit integer `rangeInDays`, and
  // returns the real { newContacts, newLaunches, messagesSent,
  // messagesReceived } for that window. Single source of truth for the
  // message/growth headline numbers used across the founder dashboard.
  app.get("/api/local/analytics", async (req, res) => {
    try {
      const orgId = (req as Request & { sessionOrgId?: string }).sessionOrgId;
      if (!orgId) {
        return res.status(401).json({ error: "no organization for session" });
      }

      const rangeParam = String(req.query.range ?? "all");
      let rangeInDays: number;
      if (req.query.rangeInDays !== undefined) {
        const n = Number(req.query.rangeInDays);
        rangeInDays = Number.isFinite(n) ? Math.trunc(n) : -1;
      } else {
        rangeInDays = REPORTING_RANGE_DAYS[rangeParam] ?? -1;
      }

      const sessionId = extractSessionId(req);
      let cookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
      let data = await fetchMtReporting(orgId, rangeInDays, cookies);
      if (!data) {
        // Cookies may be stale — refresh the server auto-session once + retry.
        await checkAndRefreshAutoSession();
        cookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
        data = await fetchMtReporting(orgId, rangeInDays, cookies);
      }
      if (!data) {
        return res.status(502).json({ error: "MindfulText reporting request failed" });
      }
      res.json({ range: rangeParam, ...data });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // Daily reporting snapshots as a real calendar time-series. Optional
  // ?from / ?to (YYYY-MM-DD, [from, to)).
  app.get("/api/local/analytics/timeseries", async (req, res) => {
    try {
      const orgId = (req as Request & { sessionOrgId?: string }).sessionOrgId;
      if (!orgId) return res.status(401).json({ error: "no organization for session" });
      const from = req.query.from ? String(req.query.from) : null;
      const to = req.query.to ? String(req.query.to) : null;
      res.json({ snapshots: await getAnalyticsSnapshots(orgId, from, to) });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // Capture today's analytics snapshot on demand (the scheduler also does this
  // daily). Useful for seeding the time-series immediately.
  app.post("/api/local/analytics/snapshot", async (req, res) => {
    try {
      const orgId = (req as Request & { sessionOrgId?: string }).sessionOrgId;
      if (!orgId) return res.status(401).json({ error: "no organization for session" });
      const row = await captureDailySnapshot(orgId);
      if (!row) return res.status(502).json({ error: "could not fetch reporting for snapshot" });
      res.json(row);
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // Seed message_events from existing personalJourneyEvents + inboundMessages.
  app.post("/api/local/message-events/backfill", async (req, res) => {
    try {
      const orgId = (req as Request & { sessionOrgId?: string }).sessionOrgId;
      if (!orgId) return res.status(401).json({ error: "no organization for session" });
      res.json(await backfillMessageEvents(orgId));
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Revenue (Stripe) + attribution
  // -----------------------------------------------------------------------
  // Read-only revenue summary. Returns { connected: false } when Stripe isn't
  // configured so the dashboard can show a "connect Stripe" empty state.
  app.get("/api/local/revenue", async (req, res) => {
    try {
      const rangeParam = String(req.query.range ?? "month");
      const rangeInDays =
        req.query.rangeInDays !== undefined
          ? Math.trunc(Number(req.query.rangeInDays)) || 30
          : REPORTING_RANGE_DAYS[rangeParam] ?? 30;
      // Stripe has no "all time" sentinel; map -1 to a very large window.
      const days = rangeInDays < 0 ? 36_500 : rangeInDays;
      const force = req.query.refresh === "1";
      // Key by org so one org's cached revenue is never served to another, even
      // though the current Stripe client is account-global.
      const orgId = (req as Request & { sessionOrgId?: string }).sessionOrgId ?? "global";
      const r = await swr(
        `revenue|${orgId}|${days}`,
        DASHBOARD_CACHE_TTL_MS,
        () => getRevenueSummary(days),
        { force },
      );
      res.json({ ...r.value, cachedAt: new Date(r.cachedAt).toISOString(), stale: r.stale });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // UTM/source attribution summary for the org.
  app.get("/api/local/attribution", async (req, res) => {
    try {
      const orgId = (req as Request & { sessionOrgId?: string }).sessionOrgId;
      if (!orgId) return res.status(401).json({ error: "no organization for session" });
      const sinceDays =
        req.query.sinceDays !== undefined ? Math.trunc(Number(req.query.sinceDays)) : undefined;
      const force = req.query.refresh === "1";
      const r = await swr(
        `attribution|${orgId}|${sinceDays ?? "all"}`,
        DASHBOARD_CACHE_TTL_MS,
        () => getAttributionSummary(orgId, sinceDays),
        { force },
      );
      res.json({ ...r.value, cachedAt: new Date(r.cachedAt).toISOString(), stale: r.stale });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — AI insights over the real founder stats
  // -----------------------------------------------------------------------
  app.get("/api/local/insights", async (req, res) => {
    try {
      const orgId = (req as Request & { sessionOrgId?: string }).sessionOrgId;
      if (!orgId) return res.status(401).json({ error: "no organization for session" });

      const sessionId = extractSessionId(req);
      const force = req.query.refresh === "1";
      const compute = async () => {
      let cookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
      let probe = await fetchMtReporting(orgId, 7, cookies);
      if (!probe) {
        await checkAndRefreshAutoSession();
        cookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
        probe = await fetchMtReporting(orgId, 7, cookies);
      }
      const [rep7, rep14, rep30, rep60, repAll] = await Promise.all([
        probe ?? fetchMtReporting(orgId, 7, cookies),
        fetchMtReporting(orgId, 14, cookies),
        fetchMtReporting(orgId, 30, cookies),
        fetchMtReporting(orgId, 60, cookies),
        fetchMtReporting(orgId, -1, cookies),
      ]);
      const tokens = await getTokenUsageSummary(orgId);
      const snaps = await getAnalyticsSnapshots(orgId);

      type RepKey = "messagesSent" | "messagesReceived" | "newContacts" | "newLaunches";
      const delta = (cur: MtReporting | null, dbl: MtReporting | null, key: RepKey) => {
        const c = cur?.[key] ?? 0;
        const prior = dbl ? Math.max(0, (dbl[key] ?? 0) - c) : null;
        const pctChange =
          prior && prior > 0 ? Math.round(((c - prior) / prior) * 1000) / 10 : null;
        return { current: c, prior, pctChange };
      };

      const summary = {
        weekly: {
          sent: delta(rep7, rep14, "messagesSent"),
          received: delta(rep7, rep14, "messagesReceived"),
          newContacts: delta(rep7, rep14, "newContacts"),
          launches: delta(rep7, rep14, "newLaunches"),
        },
        monthly: {
          sent: delta(rep30, rep60, "messagesSent"),
          received: delta(rep30, rep60, "messagesReceived"),
          newContacts: delta(rep30, rep60, "newContacts"),
          launches: delta(rep30, rep60, "newLaunches"),
        },
        allTime: repAll
          ? {
              messagesSent: repAll.messagesSent,
              messagesReceived: repAll.messagesReceived,
              contacts: repAll.newContacts,
              launches: repAll.newLaunches,
            }
          : null,
        replyRate7dPct:
          rep7 && rep7.messagesSent > 0
            ? Math.round((rep7.messagesReceived / rep7.messagesSent) * 1000) / 10
            : null,
        aiCost: { totalUsd: tokens.totalCostUsd, totalTokens: tokens.totalTokens },
        snapshotsCaptured: snaps.length,
      };

      const result = await generateInsights({
        organizationId: orgId,
        summary: JSON.stringify(summary),
      });

      let insights: unknown[] = [];
      const match = result.content.match(/\[[\s\S]*\]/);
      if (match) {
        try {
          const v = JSON.parse(match[0]);
          if (Array.isArray(v)) insights = v;
        } catch {
          /* model returned non-JSON; leave insights empty */
        }
      }

      return {
        insights,
        summary,
        model: result.model,
        generatedAt: new Date().toISOString(),
      };
      };

      const r = await swr(`insights|${orgId}`, INSIGHTS_CACHE_TTL_MS, compute, { force });
      res.json({ ...r.value, cachedAt: new Date(r.cachedAt).toISOString(), stale: r.stale });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Attrition (opt-out / unsubscribe deep-dive)
  // -----------------------------------------------------------------------
  // Combines MindfulText's authoritative per-contact `isUnsubscribed` state
  // with a STOP-event scan of the message feed (which provably contains every
  // current opt-out's STOP). For each unsubscribed contact we pull their full
  // per-contact history (only the unsubbed set — cheap) to derive WHEN they
  // opted out, how many texts they received first, and which module/journey
  // they were on. STOP events are persisted to message_events for durability.
  app.get("/api/local/attrition", async (req, res) => {
    try {
      const orgId = (req as Request & { sessionOrgId?: string }).sessionOrgId;
      if (!orgId) return res.status(401).json({ error: "no organization for session" });

      const sessionId = extractSessionId(req);
      const force = req.query.refresh === "1";
      const compute = async () => {
      let cookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
      const buildHeaders = (): Record<string, string> => ({
        Accept: "application/json",
        "User-Agent": "MindfulText-CustomFrontend/1.0",
        ...(cookies ? { Cookie: cookies } : {}),
      });

      // One refresh+retry if the session looks stale (probe the contacts list).
      let contacts = await fetchAllMTContacts(orgId, buildHeaders());
      if (contacts.length === 0) {
        await checkAndRefreshAutoSession();
        cookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
        contacts = await fetchAllMTContacts(orgId, buildHeaders());
      }

      const fetchList = async (path: string): Promise<Record<string, unknown>[]> => {
        try {
          const r = await mtFetch(path, { headers: buildHeaders() });
          if (!r.ok) return [];
          const j = (await r.json()) as Record<string, unknown>;
          return Array.isArray(j)
            ? (j as Record<string, unknown>[])
            : Array.isArray((j as { data?: unknown[] }).data)
              ? ((j as { data: Record<string, unknown>[] }).data)
              : [];
        } catch {
          return [];
        }
      };

      const isOptOut = (s: unknown): boolean =>
        typeof s === "string" &&
        /^\s*(stop|stopall|unsubscribe|cancel|end|quit|remove me)\b/i.test(s.trim());
      const toSec = (v: unknown): number | null => {
        if (typeof v !== "number" || !Number.isFinite(v)) return null;
        return v < 1e12 ? v : Math.round(v / 1000);
      };
      const isoOf = (sec: number | null): string | null =>
        sec ? new Date(sec * 1000).toISOString() : null;

      // Name maps for module/journey resolution.
      const [modules, journeys, feed] = await Promise.all([
        fetchList(`/api/modules/byOrganization/${orgId}`),
        fetchList(`/api/journeys/byOrganization/${orgId}`),
        fetchList(`/api/messages/byOrganization/${orgId}`),
      ]);
      const nameById = (rows: Record<string, unknown>[]) => {
        const m = new Map<string, string>();
        for (const r of rows) {
          const id = r.id != null ? String(r.id) : "";
          const nm = typeof r.name === "string" ? r.name : "";
          if (id) m.set(id, nm || id);
        }
        return m;
      };
      const moduleNames = nameById(modules);
      const journeyNames = nameById(journeys);

      const active = (contacts as Record<string, unknown>[]).filter((c) => !c.isArchived);
      const messaged = active.filter((c) => c.hasReceivedMessage === true).length;
      const unsubbed = active.filter((c) => c.isUnsubscribed === true);

      // STOP-event timeline from the feed (monthly buckets) + persistence.
      // The feed reliably contains every current opt-out's STOP with a
      // timestamp (verified), so it's the source of truth for WHEN someone
      // opted out. byContact is used only to bound "texts before" + resolve
      // the module/journey they were on (STOP rows carry no module/journey).
      const feedStops = feed.filter((m) => m.outbound === false && isOptOut(m.content));
      const feedStopSecByContact = new Map<string, number>();
      for (const m of feedStops) {
        const id = m.contactID != null ? String(m.contactID) : "";
        const s = toSec(m.createdAt);
        if (!id || s == null) continue;
        const prev = feedStopSecByContact.get(id);
        if (prev == null || s < prev) feedStopSecByContact.set(id, s);
      }
      const byMonth = new Map<string, number>();
      const persistRows = [] as Parameters<typeof replaceOptOutScanEvents>[1];
      for (const m of feedStops) {
        const sec = toSec(m.createdAt);
        if (sec) {
          const month = new Date(sec * 1000).toISOString().slice(0, 7);
          byMonth.set(month, (byMonth.get(month) ?? 0) + 1);
        }
        persistRows.push({
          organizationId: orgId,
          direction: "reply",
          contactId: m.contactID != null ? String(m.contactID) : null,
          moduleId: m.moduleID != null && m.moduleID !== "" ? String(m.moduleID) : null,
          journeyId: m.journeyID != null && m.journeyID !== "" ? String(m.journeyID) : null,
          content: typeof m.content === "string" ? m.content.slice(0, 500) : null,
          source: "optout-scan",
          occurredAt: sec ? new Date(sec * 1000) : undefined,
        });
      }
      await replaceOptOutScanEvents(orgId, persistRows).catch(() => {});
      const timeline = Array.from(byMonth.entries())
        .map(([month, count]) => ({ month, count }))
        .sort((a, b) => a.month.localeCompare(b.month));

      // Per-unsubscribed-contact detail (only the unsubbed set — cheap).
      const detail = await Promise.all(
        unsubbed.map(async (c) => {
          const cid = String(c.id);
          const history = await fetchList(`/api/messages/${orgId}/byContact/${cid}`);
          type Msg = Record<string, unknown>;
          const sec = (m: Msg) => toSec(m.createdAt);
          const strOf = (m: Msg | undefined, key: string) => {
            const v = m?.[key];
            return v != null && v !== "" ? String(v) : "";
          };

          const stops = history
            .filter((m) => m.outbound === false && isOptOut(m.content) && sec(m) != null)
            .sort((a, b) => sec(a)! - sec(b)!);
          const stop: Msg | undefined = stops[0];
          // Prefer the feed's STOP timestamp (reliable, org-level); fall back
          // to the per-contact history's earliest STOP. Take the earliest of
          // the two when both exist so "texts before" is the true pre-opt-out
          // count.
          const feedSec = feedStopSecByContact.get(cid) ?? null;
          const histSec = stop ? sec(stop) : null;
          const unsubSec =
            feedSec != null && histSec != null
              ? Math.min(feedSec, histSec)
              : feedSec ?? histSec;
          const outboundBefore = history
            .filter(
              (m) =>
                m.outbound === true &&
                sec(m) != null &&
                (unsubSec == null || sec(m)! < unsubSec),
            )
            .sort((a, b) => sec(b)! - sec(a)!);
          const last: Msg | undefined = outboundBefore[0] ?? stop;
          const moduleId = strOf(last, "moduleID") || strOf(stop, "moduleID");
          const journeyId = strOf(last, "journeyID") || strOf(stop, "journeyID");
          const name = [c.firstName, c.lastName].filter(Boolean).join(" ").trim();
          return {
            contactId: cid,
            name: name || cid,
            tags: Array.isArray(c.tags) ? (c.tags as string[]) : [],
            unsubscribedAt: isoOf(unsubSec),
            textsBeforeUnsub: outboundBefore.length,
            moduleId: moduleId || null,
            moduleName: moduleId ? moduleNames.get(moduleId) ?? null : null,
            journeyId: journeyId || null,
            journeyName: journeyId ? journeyNames.get(journeyId) ?? null : null,
          };
        }),
      );
      detail.sort((a, b) => (b.unsubscribedAt ?? "").localeCompare(a.unsubscribedAt ?? ""));

      const denom = messaged > 0 ? messaged : active.length;
      return {
        summary: {
          currentlyUnsubscribed: unsubbed.length,
          stopEvents: feedStops.length,
          messagedContacts: messaged,
          totalContacts: active.length,
          unsubscribeRatePct:
            denom > 0 ? Math.round((unsubbed.length / denom) * 1000) / 10 : 0,
          avgTextsBeforeUnsub:
            detail.length > 0
              ? Math.round(
                  (detail.reduce((s, d) => s + d.textsBeforeUnsub, 0) / detail.length) * 10,
                ) / 10
              : 0,
        },
        timeline,
        contacts: detail,
      };
      };

      const r = await swr(`attrition|${orgId}`, DASHBOARD_CACHE_TTL_MS, compute, { force });
      res.json({ ...r.value, cachedAt: new Date(r.cachedAt).toISOString(), stale: r.stale });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // Public attribution capture — landing pages / the app post UTM params + a
  // first-party visitor id here. Not under /api/local, so it's unauthenticated
  // by design (it only writes attribution rows, no read access).
  // Cross-origin attribution intake for the marketing site. Origins are an
  // allowlist (TRACK_CORS_ORIGINS, comma-separated) defaulting to the
  // mindfultext.com apex + www. Only POST /api/track is exposed cross-origin.
  const TRACK_CORS_ORIGINS = (
    process.env.TRACK_CORS_ORIGINS ||
    "https://mindfultext.com,https://www.mindfultext.com"
  )
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  function applyTrackCors(req: Request, res: import("express").Response): void {
    const origin = req.headers.origin;
    if (origin && TRACK_CORS_ORIGINS.includes(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
      res.setHeader("Access-Control-Allow-Headers", "Content-Type");
      res.setHeader("Access-Control-Max-Age", "86400");
    }
    res.setHeader("Vary", "Origin");
  }

  app.options("/api/track", (req, res) => {
    applyTrackCors(req, res);
    res.sendStatus(204);
  });

  app.post("/api/track", async (req, res) => {
    applyTrackCors(req, res);
    try {
      const b = (req.body ?? {}) as Record<string, unknown>;
      const str = (v: unknown) =>
        typeof v === "string" && v.trim() ? v.trim().slice(0, 500) : null;
      await recordAttributionEvent({
        organizationId: getConfiguredOrgId() || null,
        visitorId: str(b.visitorId),
        contactId: str(b.contactId),
        utmSource: str(b.utmSource ?? b.utm_source),
        utmMedium: str(b.utmMedium ?? b.utm_medium),
        utmCampaign: str(b.utmCampaign ?? b.utm_campaign),
        utmTerm: str(b.utmTerm ?? b.utm_term),
        utmContent: str(b.utmContent ?? b.utm_content),
        referrer: str(b.referrer),
        landingPath: str(b.landingPath ?? b.path),
        userAgent: str(req.headers["user-agent"]),
        metadata: b.metadata && typeof b.metadata === "object" ? (b.metadata as Json) : null,
      });
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Dashboard stats
  // -----------------------------------------------------------------------
  //
  // Returns the 8 dashboard tiles. For each metric we report:
  //   { value, previous, changePct, supportsTrend }
  //
  // Time-filterable metrics (Texts/Replies/Sends/Messages Sent) query the
  // local DB twice — once for the requested window, once for the equal-length
  // window immediately preceding it — and compute changePct.
  //
  // Non-time-filterable metrics (Contacts/Journeys/Modules/Actions) come
  // from the MindfulText proxy list endpoints and always return the current
  // total, with `supportsTrend: false` so the UI hides the delta line.
  app.get("/api/local/dashboard-stats", async (req, res) => {
    try {
      // The /api/local/* middleware guarantees this is set; bail out if
      // a future refactor breaks that contract rather than silently
      // serving someone else's data.
      const orgId = (req as Request & { sessionOrgId?: string }).sessionOrgId;
      if (!orgId) {
        return res.status(401).json({ error: "no organization for session" });
      }
      const period = String(req.query.period || "month") as
        | "day" | "week" | "month" | "year" | "all" | "custom";

      // Resolve [start, end) in the user's IANA tz so window boundaries
      // line up with their local midnight, not the server's. Default to
      // UTC when no tz is supplied or when an unknown/invalid IANA value
      // is sent (so a malformed `tz` can't 500 the dashboard).
      const rawTz = String(req.query.tz || "UTC");
      let tz = rawTz;
      try {
        new Intl.DateTimeFormat("en-US", { timeZone: rawTz });
      } catch {
        tz = "UTC";
      }
      const now = new Date();
      let start: Date | null = null;
      let end: Date | null = null;
      let prevStart: Date | null = null;
      let prevEnd: Date | null = null;

      // Compute the period boundaries by stepping in *zoned* time and
      // converting back to UTC so DST shifts don't off-by-one the result.
      const zonedNow = toZonedTime(now, tz);
      if (period === "day") {
        const dayStart = startOfDay(zonedNow);
        start = fromZonedTime(dayStart, tz);
        end = fromZonedTime(addDays(dayStart, 1), tz);
        prevStart = fromZonedTime(addDays(dayStart, -1), tz);
        prevEnd = start;
      } else if (period === "week") {
        // Monday 00:00 through Sunday 23:59:59.999 in the user's tz.
        const weekStart = startOfWeek(zonedNow, { weekStartsOn: 1 });
        start = fromZonedTime(weekStart, tz);
        end = fromZonedTime(addWeeks(weekStart, 1), tz);
        prevStart = fromZonedTime(addWeeks(weekStart, -1), tz);
        prevEnd = start;
      } else if (period === "month") {
        const monthStart = startOfMonth(zonedNow);
        start = fromZonedTime(monthStart, tz);
        end = fromZonedTime(addMonths(monthStart, 1), tz);
        prevStart = fromZonedTime(addMonths(monthStart, -1), tz);
        prevEnd = start;
      } else if (period === "year") {
        const yearStart = startOfYear(zonedNow);
        start = fromZonedTime(yearStart, tz);
        end = fromZonedTime(addYears(yearStart, 1), tz);
        prevStart = fromZonedTime(addYears(yearStart, -1), tz);
        prevEnd = start;
      } else if (period === "custom") {
        // Client sends `start` and `end` as YYYY-MM-DD strings, where
        // `end` is *inclusive* of that calendar day. Convert via the
        // user's tz so DST transitions don't add or drop an hour.
        const s = req.query.start ? String(req.query.start) : "";
        const e = req.query.end ? String(req.query.end) : "";
        const sMatch = /^\d{4}-\d{2}-\d{2}$/.test(s);
        const eMatch = /^\d{4}-\d{2}-\d{2}$/.test(e);
        if (!sMatch || !eMatch) {
          return res.status(400).json({ error: "custom period requires start and end as YYYY-MM-DD" });
        }
        const sDay = startOfDay(parseISO(s));
        const eDay = startOfDay(parseISO(e));
        if (sDay > eDay) {
          return res.status(400).json({ error: "start must be on or before end" });
        }
        start = fromZonedTime(sDay, tz);
        end = fromZonedTime(addDays(eDay, 1), tz);
        const len = end.getTime() - start.getTime();
        prevEnd = start;
        prevStart = new Date(start.getTime() - len);
      } // "all" leaves all four null

      const supportsTrend = period !== "all";
      const force = req.query.refresh === "1";
      const cacheKey = `dashboard-stats|${orgId}|${period}|${tz}|${start?.toISOString() ?? ""}|${end?.toISOString() ?? ""}`;

      // Remember the tz + period this client actually uses so the startup
      // warm-up can seed the exact cache key real traffic hits (the key
      // includes tz). Best-effort and only on change to avoid disk churn;
      // never let a persistence hiccup affect the response.
      try {
        const cur = loadOrgSettings();
        if (cur.lastTz !== tz || cur.lastPeriod !== period) {
          saveOrgSettings({ ...cur, lastTz: tz, lastPeriod: period });
        }
      } catch {
        /* non-fatal */
      }

      const compute = async () => {

      // Returns null when the prior window has zero activity — caller
      // should render "New" (curr>0) or "—" (curr==0) instead of `+100%`.
      const pct = (curr: number, prev: number): number | null => {
        if (!supportsTrend) return null;
        if (prev === 0) return null;
        return Math.round(((curr - prev) / prev) * 1000) / 10;
      };

      // MindfulText proxy fetches for the four list-only metrics. Always
      // current totals; supportsTrend=false. If we can't auth we surface 0
      // rather than failing the whole endpoint — the time-series tiles
      // should still render.
      const sessionId = extractSessionId(req);
      const cookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
      const headers: Record<string, string> = {
        Accept: "application/json",
        "User-Agent": "MindfulText-CustomFrontend/1.0",
      };
      if (cookies) headers.Cookie = cookies;

      // Find the first present creation-timestamp on a MindfulText list item.
      // The MindfulText API isn't documented here, so we probe a few common
      // field names. If none are present we'll fall back to supportsTrend:false
      // for that resource (and log once so we can see what's actually returned).
      //
      // Verified via the diagnostic log line below on 2026-05-14 against
      // org 00000022: contacts, journeys, modules, and actions all expose
      // `createdAt` (dateLikeKeys=["createdAt","updatedAt"]) — the first
      // entry in this list already covers every upstream resource we tile.
      // If a future log emits a different name, add it here rather than
      // fabricating one upfront.
      // MindfulText list APIs return numeric timestamps as Unix *seconds*
      // (see client Module.createdAt). `new Date(seconds)` lands in 1970 and
      // breaks period bucketing — every tile looked like the lifetime total.
      const parseMtTimestamp = (v: unknown): Date | null => {
        if (typeof v === "string") {
          const d = new Date(v);
          return isNaN(d.getTime()) ? null : d;
        }
        if (typeof v === "number" && Number.isFinite(v)) {
          const ms = v < 1e12 ? v * 1000 : v;
          const d = new Date(ms);
          return isNaN(d.getTime()) ? null : d;
        }
        return null;
      };

      const CREATED_AT_FIELDS = [
        "createdAt", "createdDate", "dateCreated", "created",
        "createDate", "createTime", "timestamp",
      ];
      const pickCreatedAt = (item: Record<string, unknown>): Date | null => {
        for (const f of CREATED_AT_FIELDS) {
          const d = parseMtTimestamp(item[f]);
          if (d) return d;
        }
        return null;
      };

      // Fetch a MindfulText list and bucket items into the current and prior
      // windows by createdAt. Returns supportsTrend=false if the resource
      // doesn't expose any creation timestamp on its items.
      const loggedShape = new Set<string>();
      const fetchListWithBuckets = async (
        path: string,
        filter?: (item: Record<string, unknown>) => boolean,
      ): Promise<{ total: number; curr: number; prev: number; hasCreatedAt: boolean }> => {
        if (!cookies) return { total: 0, curr: 0, prev: 0, hasCreatedAt: false };
        try {
          const r = await mtFetch(path, { headers });
          if (!r.ok) return { total: 0, curr: 0, prev: 0, hasCreatedAt: false };
          const j = (await r.json()) as Record<string, unknown>;
          const arr: Record<string, unknown>[] = Array.isArray(j)
            ? (j as Record<string, unknown>[])
            : Array.isArray((j as { data?: unknown[] }).data)
              ? ((j as { data: Record<string, unknown>[] }).data)
              : [];

          const items = filter ? arr.filter(filter) : arr;
          const total = items.length;

          // Probe whether any item has a creation timestamp; log keys once
          // per path so we can adjust CREATED_AT_FIELDS if needed.
          const hasCreatedAt = items.some((it) => pickCreatedAt(it) !== null);
          if (!loggedShape.has(path) && items.length > 0) {
            loggedShape.add(path);
            const sample = items[0];
            const dateLikeKeys = Object.keys(sample).filter((k) => {
              const v = sample[k];
              if (typeof v !== "string" && typeof v !== "number") return false;
              const d = parseMtTimestamp(v);
              return d !== null && /date|time|created|sent|updated|at$/i.test(k);
            });
            console.log(
              `[dashboard-stats] ${path} hasCreatedAt=${hasCreatedAt} ` +
              `dateLikeKeys=${JSON.stringify(dateLikeKeys)}`,
            );
          }

          if (!hasCreatedAt || !start || !end || !prevStart || !prevEnd) {
            return { total, curr: total, prev: 0, hasCreatedAt };
          }

          let curr = 0;
          let prev = 0;
          for (const it of items) {
            const d = pickCreatedAt(it);
            if (!d) continue;
            const t = d.getTime();
            if (t >= start.getTime() && t < end.getTime()) curr++;
            else if (t >= prevStart.getTime() && t < prevEnd.getTime()) prev++;
          }
          return { total, curr, prev, hasCreatedAt };
        } catch {
          return { total: 0, curr: 0, prev: 0, hasCreatedAt: false };
        }
      };

      const contactsBuckets = async () => {
        if (!cookies) return { total: 0, curr: 0, prev: 0, hasCreatedAt: false, optOuts: 0, messaged: 0 };
        try {
          const all = await fetchAllMTContacts(orgId, headers);
          const items = all.filter((c) => !c.isArchived) as Record<string, unknown>[];
          const total = items.length;
          // Authoritative opt-out signal: MindfulText's per-contact
          // `isUnsubscribed` flag captures every STOP regardless of how it
          // arrived (carrier STOP, in-app, manual). `messaged` is the
          // deliverability denominator (contacts that ever received a text).
          const optOuts = items.filter((it) => it.isUnsubscribed === true).length;
          const messaged = items.filter((it) => it.hasReceivedMessage === true).length;
          const hasCreatedAt = items.some((it) => pickCreatedAt(it) !== null);
          if (!loggedShape.has("contacts") && items.length > 0) {
            loggedShape.add("contacts");
            const sample = items[0];
            const dateLikeKeys = Object.keys(sample).filter((k) => {
              const v = sample[k];
              if (typeof v !== "string" && typeof v !== "number") return false;
              const d = parseMtTimestamp(v);
              return d !== null && /date|time|created|sent|updated|at$/i.test(k);
            });
            console.log(
              `[dashboard-stats] contacts hasCreatedAt=${hasCreatedAt} ` +
              `dateLikeKeys=${JSON.stringify(dateLikeKeys)}`,
            );
          }
          if (!hasCreatedAt || !start || !end || !prevStart || !prevEnd) {
            return { total, curr: total, prev: 0, hasCreatedAt, optOuts, messaged };
          }
          let curr = 0;
          let prev = 0;
          for (const it of items) {
            const d = pickCreatedAt(it);
            if (!d) continue;
            const t = d.getTime();
            if (t >= start.getTime() && t < end.getTime()) curr++;
            else if (t >= prevStart.getTime() && t < prevEnd.getTime()) prev++;
          }
          return { total, curr, prev, hasCreatedAt, optOuts, messaged };
        } catch {
          return { total: 0, curr: 0, prev: 0, hasCreatedAt: false, optOuts: 0, messaged: 0 };
        }
      };

      // Message tiles use calendar [start, end) in the user's tz (midnight
      // boundaries for day/week/month/year/custom). Counts prefer MindfulText
      // reporting with explicit bounds, else snapshot cumulative diffs, else
      // local message_events / inboundMessages.
      let repCookies = cookies;
      const loadMessageCounts = (s: Date | null, e: Date | null) =>
        getCalendarMessageCounts(orgId, s, e, tz, repCookies);

      let messageCountsCur = await loadMessageCounts(start, end);
      if (
        period !== "all" &&
        messageCountsCur.sent === 0 &&
        messageCountsCur.received === 0
      ) {
        await checkAndRefreshAutoSession();
        repCookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
        messageCountsCur = await loadMessageCounts(start, end);
      }

      const messageCountsPrev =
        supportsTrend && prevStart && prevEnd
          ? await loadMessageCounts(prevStart, prevEnd)
          : null;

      const sendsCur = messageCountsCur.sent;
      const receivedCur = messageCountsCur.received;
      const textsCur = sendsCur + receivedCur;
      const sendsPrev = messageCountsPrev?.sent ?? null;
      const receivedPrev = messageCountsPrev?.received ?? null;
      const textsPrev =
        messageCountsPrev !== null
          ? (sendsPrev ?? 0) + (receivedPrev ?? 0)
          : null;

      const [
        contactsB,
        journeysB,
        modulesB,
        actionsB,
        subsB,
      ] = await Promise.all([
        contactsBuckets(),
        fetchListWithBuckets(`/api/journeys/byOrganization/${orgId}`),
        fetchListWithBuckets(`/api/modules/byOrganization/${orgId}`),
        fetchListWithBuckets(`/api/actions/byOrganization/${orgId}`),
        // Subscriptions = "Journeys Launched" (every launched journey
        // creates one subscription row). Matches MindfulText Analytics.
        fetchListWithBuckets(`/api/subscriptions/byOrganization/${orgId}`),
      ]);

      type Metric = {
        value: number;
        previous: number | null;
        changePct: number | null;
        supportsTrend: boolean;
        isNewActivity?: boolean;
        format?: "number" | "percent";
      };
      // No trend support (period === "all" or local-only sources we don't
      // bucket): show the lifetime total and suppress the delta line.
      const flat = (value: number): Metric => ({
        value, previous: null, changePct: null, supportsTrend: false,
      });
      // Headline = count in the selected period (curr). Delta compares curr
      // vs the equal-length prior period. All-time shows lifetime total.
      const listTrend = (b: { total: number; curr: number; prev: number; hasCreatedAt: boolean }): Metric => {
        if (!supportsTrend) return flat(b.total);
        if (!b.hasCreatedAt) return flat(b.total);
        return {
          value: b.curr,
          previous: b.prev,
          changePct: pct(b.curr, b.prev),
          supportsTrend: true,
          isNewActivity: b.prev === 0 && b.curr > 0,
        };
      };

      // Metric from a real reporting current/prior pair. `prev === null`
      // (all-time, or no prior window available) renders as a flat tile.
      const reportingMetric = (cur: number, prev: number | null): Metric => {
        if (!supportsTrend || prev === null) return flat(cur);
        return {
          value: cur,
          previous: prev,
          changePct: pct(cur, prev),
          supportsTrend: true,
          isNewActivity: prev === 0 && cur > 0,
        };
      };

      // Opt-outs come from MindfulText's authoritative per-contact
      // `isUnsubscribed` flag (every STOP, however it arrived), not a keyword
      // scan of the webhook-only inbound table. It's a point-in-time state, so
      // it has no period window/trend here — flat total. Rate denominator is
      // contacts that have received a message (deliverability-style); fall back
      // to total contacts if the messaged count is unavailable.
      const optOutTotal = contactsB.optOuts;
      const optOutDenom = contactsB.messaged > 0 ? contactsB.messaged : contactsB.total;
      const unsubRate =
        optOutDenom > 0 ? Math.round((optOutTotal / optOutDenom) * 1000) / 10 : 0;
      const unsubscribeRateMetric: Metric = { ...flat(unsubRate), format: "percent" };

      return {
        period,
        start: start?.toISOString() ?? null,
        end: end?.toISOString() ?? null,
        metrics: {
          contacts: listTrend(contactsB),
          journeys: listTrend(journeysB),
          modules: listTrend(modulesB),
          actions: listTrend(actionsB),
          texts: reportingMetric(textsCur, textsPrev),
          replies: reportingMetric(receivedCur, receivedPrev),
          sends: reportingMetric(sendsCur, sendsPrev),
          stops: flat(optOutTotal),
          unsubscribeRate: unsubscribeRateMetric,
          journeysLaunched: listTrend(subsB),
        },
      };
      };

      const r = await swr(cacheKey, DASHBOARD_CACHE_TTL_MS, compute, { force });
      res.json({ ...r.value, cachedAt: new Date(r.cachedAt).toISOString(), stale: r.stale });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Subscriptions snapshot via the auto-session
  // -----------------------------------------------------------------------
  // Workbench needs the full subscriptions list to compute per-journey and
  // per-module subscriber counts. The MindfulText proxy is keyed by per-tab
  // browser session, so a fresh tab without a UI login has no cookies and
  // the upstream returns 401. Mirror the contacts/dashboard-stats pattern:
  // serve from the server-side auto-session, and on 401 refresh once and
  // retry before giving up.
  app.get("/api/local/subscriptions/:orgId", async (req, res) => {
    const orgId = req.params.orgId;
    const url = `https://dev.mindfultext.com/api/subscriptions/byOrganization/${orgId}`;

    const fetchOnce = async (): Promise<{ status: number; json: unknown }> => {
      const cookies = sessionStore[AUTO_SESSION_ID] || "";
      if (!cookies) return { status: 401, json: null };
      const r = await mtFetch(url, { cookies });
      const ct = r.headers.get("content-type") || "";
      const json = ct.includes("application/json") ? await r.json() : null;
      return { status: r.status, json };
    };

    try {
      let result = await fetchOnce();
      if (result.status === 401) {
        console.log("[local/subscriptions] 401 — refreshing auto-session and retrying once");
        await checkAndRefreshAutoSession();
        result = await fetchOnce();
      }
      if (result.status < 200 || result.status >= 300) {
        return res.status(502).json({
          error: `MindfulText subscriptions request failed with HTTP ${result.status}`,
        });
      }
      const j = result.json as Record<string, unknown> | unknown[] | null;
      const arr: unknown[] = Array.isArray(j)
        ? j
        : j && Array.isArray((j as { data?: unknown[] }).data)
          ? (j as { data: unknown[] }).data
          : [];
      // Normalize MindfulText's capital-ID field names to the lowercase
      // shape the client's Subscription type and Workbench resolver expect.
      const normalized = arr.map((row) => {
        const r = row as Record<string, unknown>;
        return {
          ...r,
          id: r.id ?? r.ID,
          contactId: r.contactId ?? r.contactID,
          journeyId: r.journeyId ?? r.journeyID,
          status: r.status ?? r.state,
        };
      });
      res.json(normalized);
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Per-journey unique contact counts (server-side aggregation)
  // -----------------------------------------------------------------------
  // The Workbench only needs `{ journeyId -> uniqueContactCount }` for its
  // count badges. Shipping the entire subscriptions list (~2900+ rows for
  // org `00000022`, growing) just to compute that on the client is wasteful.
  // This endpoint fetches the same upstream list using the auto-session,
  // aggregates by journeyId (unique contactIds), and returns a small JSON
  // object. Mirrors the auto-session 401-refresh pattern used above.
  app.get("/api/local/subscription-counts/:orgId", async (req, res) => {
    const orgId = req.params.orgId;
    const url = `https://dev.mindfultext.com/api/subscriptions/byOrganization/${orgId}`;

    const fetchOnce = async (): Promise<{ status: number; json: unknown }> => {
      const cookies = sessionStore[AUTO_SESSION_ID] || "";
      if (!cookies) return { status: 401, json: null };
      const r = await mtFetch(url, { cookies });
      const ct = r.headers.get("content-type") || "";
      const json = ct.includes("application/json") ? await r.json() : null;
      return { status: r.status, json };
    };

    try {
      let result = await fetchOnce();
      if (result.status === 401) {
        console.log("[local/subscription-counts] 401 — refreshing auto-session and retrying once");
        await checkAndRefreshAutoSession();
        result = await fetchOnce();
      }
      if (result.status < 200 || result.status >= 300) {
        return res.status(502).json({
          error: `MindfulText subscriptions request failed with HTTP ${result.status}`,
        });
      }
      const j = result.json as Record<string, unknown> | unknown[] | null;
      const arr: unknown[] = Array.isArray(j)
        ? j
        : j && Array.isArray((j as { data?: unknown[] }).data)
          ? (j as { data: unknown[] }).data
          : [];
      const perJourney = new Map<string, Set<string>>();
      for (const row of arr) {
        const r = row as Record<string, unknown>;
        const journeyId = (r.journeyId ?? r.journeyID) as string | undefined;
        const contactId = (r.contactId ?? r.contactID) as string | undefined;
        if (!journeyId || !contactId) continue;
        let s = perJourney.get(journeyId);
        if (!s) { s = new Set(); perJourney.set(journeyId, s); }
        s.add(contactId);
      }
      const counts: Record<string, number> = {};
      perJourney.forEach((set, jid) => { counts[jid] = set.size; });
      res.json(counts);
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Unique contact count across a set of journeys
  // -----------------------------------------------------------------------
  // Used by the Workbench module pivot: when a single module is selected
  // and the full subscriptions list isn't loaded, summing per-journey
  // counts double-counts contacts that subscribe to multiple parent
  // journeys. This endpoint fetches the upstream subscriptions list,
  // filters to operationally-live statuses (matching `ACTIVE_SUB_STATUSES`
  // on the client), and returns a single deduped contact count for the
  // requested journeyIds — restoring the accuracy of the old "load
  // everything and dedupe" path without forcing the bulk download.
  app.post("/api/local/subscription-counts/:orgId/unique-contacts", async (req, res) => {
    const orgId = req.params.orgId;
    const body = (req.body ?? {}) as { journeyIds?: unknown };
    const journeyIds = Array.isArray(body.journeyIds)
      ? (body.journeyIds.filter((x) => typeof x === "string" && x.length > 0) as string[])
      : [];
    if (journeyIds.length === 0) {
      return res.json({ uniqueContactCount: 0 });
    }
    const wanted = new Set(journeyIds);
    const ACTIVE_STATUSES = new Set(["active", "paused", "sending"]);
    const url = `https://dev.mindfultext.com/api/subscriptions/byOrganization/${orgId}`;

    const fetchOnce = async (): Promise<{ status: number; json: unknown }> => {
      const cookies = sessionStore[AUTO_SESSION_ID] || "";
      if (!cookies) return { status: 401, json: null };
      const r = await mtFetch(url, { cookies });
      const ct = r.headers.get("content-type") || "";
      const json = ct.includes("application/json") ? await r.json() : null;
      return { status: r.status, json };
    };

    try {
      let result = await fetchOnce();
      if (result.status === 401) {
        console.log("[local/subscription-counts/unique-contacts] 401 — refreshing auto-session and retrying once");
        await checkAndRefreshAutoSession();
        result = await fetchOnce();
      }
      if (result.status < 200 || result.status >= 300) {
        return res.status(502).json({
          error: `MindfulText subscriptions request failed with HTTP ${result.status}`,
        });
      }
      const j = result.json as Record<string, unknown> | unknown[] | null;
      const arr: unknown[] = Array.isArray(j)
        ? j
        : j && Array.isArray((j as { data?: unknown[] }).data)
          ? (j as { data: unknown[] }).data
          : [];
      const unique = new Set<string>();
      for (const row of arr) {
        const r = row as Record<string, unknown>;
        const journeyId = (r.journeyId ?? r.journeyID) as string | undefined;
        const contactId = (r.contactId ?? r.contactID) as string | undefined;
        if (!journeyId || !contactId) continue;
        if (!wanted.has(journeyId)) continue;
        const status = ((r.status ?? r.state) as string | undefined ?? "").toLowerCase();
        if (status && !ACTIVE_STATUSES.has(status)) continue;
        unique.add(contactId);
      }
      res.json({ uniqueContactCount: unique.size });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Journey Progress (Gantt data)
  // -----------------------------------------------------------------------
  // Returns a structured payload for the Journey Progress page: every active
  // journey with its ordered module list and each active/sending subscriber's
  // current position. No AI, no LLM — pure MindfulText REST + in-process
  // aggregation. Cached 2 minutes (swr) to avoid hammering MT on every load.
  // -----------------------------------------------------------------------

  app.get("/api/local/journey-progress", async (req, res) => {
    const orgId = getConfiguredOrgId();
    const CACHE_TTL_MS = 2 * 60 * 1000;
    const cacheKey = `journey-progress:${orgId}`;

    const buildHeaders = (): Record<string, string> => ({
      Accept: "application/json",
      "User-Agent": "MindfulText-CustomFrontend/1.0",
      Cookie: sessionStore[AUTO_SESSION_ID] || "",
    });

    const fetchList = async (path: string): Promise<Record<string, unknown>[]> => {
      const r = await mtFetch(path, { headers: buildHeaders() });
      // Surface expired/invalid sessions as an auth error instead of silently
      // returning [] (which would render as a misleading "no active journeys").
      if (r.status === 401 || r.status === 403) throw new Error("Not authenticated");
      if (!r.ok) return [];
      const j = (await r.json()) as Record<string, unknown> | unknown[];
      const arr = Array.isArray(j) ? j : Array.isArray((j as { data?: unknown[] }).data) ? (j as { data: unknown[] }).data : [];
      return arr as Record<string, unknown>[];
    };

    interface JourneyProgressPayload {
      journeys: {
        id: string;
        name: string;
        modules: { id: string; name: string }[];
        contacts: {
          id: string;
          name: string;
          tags: string[];
          currentModuleIndex: number;
          nextSendAt: string | null;
          state: string;
        }[];
      }[];
      cachedAt: number;
    }

    try {
      const result = await swr<JourneyProgressPayload>(cacheKey, CACHE_TTL_MS, async () => {
        const headers = buildHeaders();
        if (!headers.Cookie) throw new Error("Not authenticated");

        const [rawJourneys, rawModules, rawSubs] = await Promise.all([
          fetchList(`/api/journeys/byOrganization/${orgId}`),
          fetchList(`/api/modules/byOrganization/${orgId}`),
          fetchList(`/api/subscriptions/byOrganization/${orgId}`),
        ]);

        // Index modules by id for fast name lookup
        const modulesById = new Map<string, string>();
        for (const m of rawModules) {
          const id = String(m.id ?? m.ID ?? "");
          const name = typeof m.name === "string" ? m.name : id;
          if (id) modulesById.set(id, name);
        }

        // A subscription is "live" (shown on this page) when MindfulText still
        // intends to send it more messages. Terminal states (cancelled /
        // completed) are excluded. "sending" is a real, transient state (a
        // message is actively going out right now), not a bug.
        const LIVE_STATES = new Set(["active", "sending", "paused"]);

        const subNum = (v: unknown): number => {
          const n = typeof v === "number" ? v : parseInt(String(v ?? ""), 10);
          return Number.isFinite(n) ? n : 0;
        };

        // Contacts re-enroll over time, so the same (contact, journey) pair can
        // appear in many subscription rows. Keep only the most recently updated
        // LIVE row per (contact, journey) so the roster + statuses reflect the
        // current reality instead of leaking stale historical enrollments.
        const latestByPair = new Map<string, Record<string, unknown>>();
        for (const sub of rawSubs) {
          const state = String(sub.state ?? sub.status ?? "").toLowerCase();
          if (!LIVE_STATES.has(state)) continue;
          const cid = String(sub.contactID ?? sub.contactId ?? "");
          const jid = String(sub.journeyID ?? sub.journeyId ?? "");
          if (!cid || !jid) continue;
          const key = `${jid}::${cid}`;
          const existing = latestByPair.get(key);
          if (!existing) { latestByPair.set(key, sub); continue; }
          const a = subNum(sub.updatedAt) || subNum(sub.createdAt);
          const b = subNum(existing.updatedAt) || subNum(existing.createdAt);
          if (a >= b) latestByPair.set(key, sub);
        }

        // Group the deduped live subs by journey.
        const subsByJourney = new Map<string, Record<string, unknown>[]>();
        for (const sub of Array.from(latestByPair.values())) {
          const jid = String(sub.journeyID ?? sub.journeyId ?? "");
          let arr = subsByJourney.get(jid);
          if (!arr) { arr = []; subsByJourney.set(jid, arr); }
          arr.push(sub);
        }

        // Resolve names + tags only for contacts that actually appear in a live
        // subscription. `fetchAllMTContacts` paginates automatically (100/page);
        // we index by ID and keep only the ones we need.
        const neededContactIds = new Set<string>();
        for (const subs of Array.from(subsByJourney.values())) {
          for (const s of subs) {
            const cid = String(s.contactID ?? s.contactId ?? "");
            if (cid) neededContactIds.add(cid);
          }
        }
        const contactInfo = new Map<string, { name: string; tags: string[] }>();
        if (neededContactIds.size > 0) {
          try {
            const allContacts = await fetchAllMTContacts(orgId, headers);
            for (const c of allContacts) {
              const r = c as Record<string, unknown>;
              const id = String(r.id ?? r.ID ?? "");
              if (!id || !neededContactIds.has(id)) continue;
              const first = typeof r.firstName === "string" ? r.firstName : "";
              const last = typeof r.lastName === "string" ? r.lastName : "";
              const full = `${first} ${last}`.trim() || String(r.phoneNumber ?? r.phone ?? id);
              const tags = Array.isArray(r.tags) ? (r.tags as unknown[]).map(String) : [];
              contactInfo.set(id, { name: full, tags });
            }
          } catch {
            // non-fatal — names/tags fall back to id / empty
          }
        }

        // MindfulText's zero-date sentinel for "no scheduled send".
        const ZERO_DATE_PREFIX = "0001-01-01";

        // Build the journey list
        const journeys: JourneyProgressPayload["journeys"] = [];

        for (const j of rawJourneys) {
          const jid = String(j.id ?? j.ID ?? "");
          if (!jid) continue;

          const jname = typeof j.name === "string" ? j.name : jid;

          // Module order: journeys carry moduleIDs (or legacy moduleIds).
          const rawModuleIds: string[] = Array.isArray((j as Record<string, unknown>).moduleIDs)
            ? ((j as Record<string, unknown>).moduleIDs as unknown[]).map(String)
            : Array.isArray((j as Record<string, unknown>).moduleIds)
              ? ((j as Record<string, unknown>).moduleIds as unknown[]).map(String)
              : [];

          if (rawModuleIds.length === 0) continue;

          const modules = rawModuleIds.map((mid) => ({
            id: mid,
            name: modulesById.get(mid) ?? mid,
          }));

          // Map each module ID to its position in THIS journey's order so we can
          // resolve a contact's current position from nextMessage.moduleID.
          const moduleIndexById = new Map<string, number>();
          rawModuleIds.forEach((mid, i) => moduleIndexById.set(mid, i));

          const subs = subsByJourney.get(jid) ?? [];

          const contacts = subs.map((sub) => {
            const cid = String(sub.contactID ?? sub.contactId ?? "");
            const info = contactInfo.get(cid);
            const cname = info?.name ?? `Contact ${cid}`;
            const tags = info?.tags ?? [];
            const state = String(sub.state ?? sub.status ?? "active").toLowerCase();

            const nm = (sub.nextMessage ?? {}) as Record<string, unknown>;

            // CURRENT position: resolve by matching nextMessage.moduleID against
            // the journey's module order. nextMessage.moduleIndex is an internal
            // counter that does NOT line up with journey.moduleIDs, so we must
            // look the module ID up; fall back to 0 only if it's missing.
            const nmModuleId = String(nm.moduleID ?? nm.moduleId ?? "");
            const resolvedIdx = moduleIndexById.has(nmModuleId)
              ? (moduleIndexById.get(nmModuleId) as number)
              : 0;
            const currentModuleIndex = Math.max(0, Math.min(resolvedIdx, rawModuleIds.length - 1));

            // NEXT send time lives in nextMessage.sendAt. The zero-date sentinel
            // means there is genuinely no upcoming send.
            const rawSendAt = nm.sendAt != null ? String(nm.sendAt) : "";
            const nextSendAt = rawSendAt && !rawSendAt.startsWith(ZERO_DATE_PREFIX)
              ? rawSendAt
              : null;

            return { id: cid, name: cname, tags, currentModuleIndex, nextSendAt, state };
          });

          // Only include journeys that have live contacts
          if (contacts.length > 0) {
            journeys.push({ id: jid, name: jname, modules, contacts });
          }
        }

        // Sort journeys by subscriber count descending
        journeys.sort((a, b) => b.contacts.length - a.contacts.length);

        return { journeys, cachedAt: Date.now() };
      });

      res.json(result.value);
    } catch (e) {
      const msg = errMsg(e);
      const status = msg === "Not authenticated" ? 401 : 500;
      res.status(status).json({ error: msg });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Contact journey history (grouped by tag)
  //
  // Unlike /journey-progress (which only shows where LIVE contacts are right
  // now), this returns the FULL enrollment history per contact across every
  // journey and every state (active / paused / sending / completed /
  // cancelled), so the founder can pick a tag and compare how similar
  // contacts have moved through their journeys over time.
  //
  // Important MindfulText data quirk: only LIVE subscriptions retain a
  // populated `nextMessage.moduleID`. On completion the row is marked
  // `completed` (the contact finished every module) and on cancellation the
  // `nextMessage` position is CLEARED — MindfulText does not record which
  // module a cancelled contact stopped on, so we surface that honestly
  // rather than fabricating a position.
  // -----------------------------------------------------------------------
  app.get("/api/local/contact-journeys", async (req, res) => {
    const orgId = getConfiguredOrgId();
    const CACHE_TTL_MS = 2 * 60 * 1000;
    const cacheKey = `contact-journeys:${orgId}`;

    const buildHeaders = (): Record<string, string> => ({
      Accept: "application/json",
      "User-Agent": "MindfulText-CustomFrontend/1.0",
      Cookie: sessionStore[AUTO_SESSION_ID] || "",
    });

    const fetchList = async (path: string): Promise<Record<string, unknown>[]> => {
      const r = await mtFetch(path, { headers: buildHeaders() });
      if (r.status === 401 || r.status === 403) throw new Error("Not authenticated");
      // Surface other upstream failures (e.g. 5xx) instead of returning [] —
      // a silent empty list here looks like a genuine "no history" to the UI.
      if (!r.ok) throw new Error(`Upstream ${r.status} for ${path}`);
      const j = (await r.json()) as Record<string, unknown> | unknown[];
      const arr = Array.isArray(j) ? j : Array.isArray((j as { data?: unknown[] }).data) ? (j as { data: unknown[] }).data : [];
      return arr as Record<string, unknown>[];
    };

    interface Enrollment {
      subscriptionId: string;
      journeyId: string;
      state: string;
      startDate: string | null;
      startedAt: number;          // unix seconds (createdAt) — drives chronological order
      completedAt: number | null; // unix seconds, or null when not completed
      // Current module position (0-based). Only resolvable for LIVE states;
      // null for completed (finished all) and cancelled (position cleared).
      currentModuleIndex: number | null;
      nextSendAt: string | null;
    }

    interface ContactJourneysPayload {
      journeys: Record<string, { id: string; name: string; modules: { id: string; name: string }[] }>;
      tags: string[];
      contacts: {
        id: string;
        name: string;
        tags: string[];
        enrollments: Enrollment[];
      }[];
      cachedAt: number;
    }

    try {
      const result = await swr<ContactJourneysPayload>(cacheKey, CACHE_TTL_MS, async () => {
        const headers = buildHeaders();
        if (!headers.Cookie) throw new Error("Not authenticated");

        const [rawJourneys, rawModules, rawSubs] = await Promise.all([
          fetchList(`/api/journeys/byOrganization/${orgId}`),
          fetchList(`/api/modules/byOrganization/${orgId}`),
          fetchList(`/api/subscriptions/byOrganization/${orgId}`),
        ]);

        const modulesById = new Map<string, string>();
        for (const m of rawModules) {
          const id = String(m.id ?? m.ID ?? "");
          const name = typeof m.name === "string" ? m.name : id;
          if (id) modulesById.set(id, name);
        }

        // Build the journey catalog (id → name + ordered modules) and a
        // per-journey module-index lookup for resolving live positions.
        const journeyCatalog: ContactJourneysPayload["journeys"] = {};
        const moduleIndexByJourney = new Map<string, Map<string, number>>();
        for (const j of rawJourneys) {
          const jid = String(j.id ?? j.ID ?? "");
          if (!jid) continue;
          const jname = typeof j.name === "string" ? j.name : jid;
          const rawModuleIds: string[] = Array.isArray((j as Record<string, unknown>).moduleIDs)
            ? ((j as Record<string, unknown>).moduleIDs as unknown[]).map(String)
            : Array.isArray((j as Record<string, unknown>).moduleIds)
              ? ((j as Record<string, unknown>).moduleIds as unknown[]).map(String)
              : [];
          journeyCatalog[jid] = {
            id: jid,
            name: jname,
            modules: rawModuleIds.map((mid) => ({ id: mid, name: modulesById.get(mid) ?? mid })),
          };
          const idxMap = new Map<string, number>();
          rawModuleIds.forEach((mid, i) => idxMap.set(mid, i));
          moduleIndexByJourney.set(jid, idxMap);
        }

        const LIVE_STATES = new Set(["active", "sending", "paused"]);
        const ZERO_DATE_PREFIX = "0001-01-01";
        const subNum = (v: unknown): number => {
          const n = typeof v === "number" ? v : parseInt(String(v ?? ""), 10);
          return Number.isFinite(n) ? n : 0;
        };

        // Group every enrollment (all states) by contact.
        const enrollmentsByContact = new Map<string, Enrollment[]>();
        for (const sub of rawSubs) {
          const cid = String(sub.contactID ?? sub.contactId ?? "");
          const jid = String(sub.journeyID ?? sub.journeyId ?? "");
          if (!cid || !jid) continue;

          const state = String(sub.state ?? sub.status ?? "").toLowerCase();

          // Ensure the referenced journey exists in the catalog even if the
          // journey was deleted upstream (so the UI can still name it).
          if (!journeyCatalog[jid]) {
            journeyCatalog[jid] = { id: jid, name: `Journey ${jid}`, modules: [] };
            moduleIndexByJourney.set(jid, new Map());
          }

          let currentModuleIndex: number | null = null;
          let nextSendAt: string | null = null;
          if (LIVE_STATES.has(state)) {
            const nm = (sub.nextMessage ?? {}) as Record<string, unknown>;
            const nmModuleId = String(nm.moduleID ?? nm.moduleId ?? "");
            const idxMap = moduleIndexByJourney.get(jid);
            const modCount = journeyCatalog[jid].modules.length;
            const resolved = idxMap?.has(nmModuleId) ? (idxMap.get(nmModuleId) as number) : 0;
            currentModuleIndex = modCount > 0 ? Math.max(0, Math.min(resolved, modCount - 1)) : 0;
            const rawSendAt = nm.sendAt != null ? String(nm.sendAt) : "";
            nextSendAt = rawSendAt && !rawSendAt.startsWith(ZERO_DATE_PREFIX) ? rawSendAt : null;
          }

          const completedRaw = subNum(sub.completedAt);
          const startDateStr = typeof sub.startDate === "string" && sub.startDate ? sub.startDate : null;
          // Chronological order is driven by createdAt; fall back to parsing
          // startDate ("YYYY-MM-DD") when createdAt is missing/zero.
          let startedAt = subNum(sub.createdAt);
          if (startedAt <= 0 && startDateStr) {
            const parsed = Date.parse(startDateStr);
            if (Number.isFinite(parsed)) startedAt = Math.floor(parsed / 1000);
          }
          const enrollment: Enrollment = {
            subscriptionId: String(sub.id ?? sub.ID ?? ""),
            journeyId: jid,
            state,
            startDate: startDateStr,
            startedAt,
            completedAt: state === "completed" && completedRaw > 0 ? completedRaw : null,
            currentModuleIndex,
            nextSendAt,
          };

          let arr = enrollmentsByContact.get(cid);
          if (!arr) { arr = []; enrollmentsByContact.set(cid, arr); }
          arr.push(enrollment);
        }

        // Resolve names + tags only for contacts that have history.
        const contactInfo = new Map<string, { name: string; tags: string[] }>();
        if (enrollmentsByContact.size > 0) {
          try {
            const allContacts = await fetchAllMTContacts(orgId, headers);
            for (const c of allContacts) {
              const r = c as Record<string, unknown>;
              const id = String(r.id ?? r.ID ?? "");
              if (!id || !enrollmentsByContact.has(id)) continue;
              const first = typeof r.firstName === "string" ? r.firstName : "";
              const last = typeof r.lastName === "string" ? r.lastName : "";
              const full = `${first} ${last}`.trim() || String(r.phoneNumber ?? r.phone ?? id);
              const tags = Array.isArray(r.tags)
                ? (r.tags as unknown[]).map(String).map((t) => t.trim()).filter((t) => t.length > 0)
                : [];
              contactInfo.set(id, { name: full, tags });
            }
          } catch {
            // non-fatal — names/tags fall back to id / empty
          }
        }

        const tagSet = new Set<string>();
        const contacts: ContactJourneysPayload["contacts"] = [];
        for (const [cid, enrollments] of Array.from(enrollmentsByContact.entries())) {
          const info = contactInfo.get(cid);
          const name = info?.name ?? `Contact ${cid}`;
          const tags = info?.tags ?? [];
          for (const t of tags) tagSet.add(t);
          // Chronological order: oldest enrollment first.
          enrollments.sort((a, b) => a.startedAt - b.startedAt);
          contacts.push({ id: cid, name, tags, enrollments });
        }

        // Sort contacts by name for a stable, scannable list.
        contacts.sort((a, b) => a.name.localeCompare(b.name));

        return {
          journeys: journeyCatalog,
          tags: Array.from(tagSet).sort((a, b) => a.localeCompare(b)),
          contacts,
          cachedAt: Date.now(),
        };
      });

      res.json(result.value);
    } catch (e) {
      const msg = errMsg(e);
      const status = msg === "Not authenticated" ? 401 : 500;
      res.status(status).json({ error: msg });
    }
  });

  // Local API — Audience briefs
  // -----------------------------------------------------------------------

  /** List every tag found on MindfulText contacts joined with any saved brief. */
  app.get("/api/local/audiences/:orgId", async (req, res) => {
    try {
      const orgId = req.params.orgId;
      const sessionId = extractSessionId(req);
      const storedCookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";

      if (!storedCookies) {
        return res.status(401).json({ error: "Not authenticated — please log in first." });
      }

      const proxyHeaders: Record<string, string> = {
        Accept: "application/json",
        "User-Agent": "MindfulText-CustomFrontend/1.0",
        Cookie: storedCookies,
      };

      // Reuse the same tag-frequency logic the Ask context builder uses.
      let tagCounts = new Map<string, number>();
      try {
        const allContacts = await fetchAllMTContacts(orgId, proxyHeaders);
        const active = allContacts.filter((c) => !c.isArchived);
        for (const c of active) {
          if (Array.isArray(c.tags)) {
            for (const tag of c.tags) {
              if (typeof tag === "string" && tag.trim()) {
                const t = tag.trim();
                tagCounts.set(t, (tagCounts.get(t) ?? 0) + 1);
              }
            }
          }
        }
      } catch {
        // Non-fatal — return empty tag list, but still surface saved briefs below.
      }

      const briefs = await listAudienceBriefs(orgId);
      const briefByTag = new Map<string, { brief: string; updatedAt: Date | null }>();
      for (const b of briefs) {
        briefByTag.set(b.tag, { brief: b.brief ?? "", updatedAt: b.updatedAt ?? null });
      }

      // Surface any saved briefs whose tag no longer appears on contacts —
      // the user should still be able to see/edit them.
      for (const tag of Array.from(briefByTag.keys())) {
        if (!tagCounts.has(tag)) tagCounts.set(tag, 0);
      }

      const audiences = Array.from(tagCounts.entries())
        .map(([tag, contactCount]) => ({
          tag,
          contactCount,
          brief: briefByTag.get(tag)?.brief ?? "",
          briefUpdatedAt: briefByTag.get(tag)?.updatedAt ?? null,
        }))
        .sort((a, b) => b.contactCount - a.contactCount || a.tag.localeCompare(b.tag));

      res.json({ audiences });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  /** Upsert a brief for an (org, tag) pair. */
  app.put("/api/local/audiences/:orgId/:tag", async (req, res) => {
    try {
      const { orgId, tag } = req.params;
      const decodedTag = decodeURIComponent(tag);
      const brief = typeof req.body?.brief === "string" ? req.body.brief : "";
      const row = await upsertAudienceBrief({
        organizationId: orgId,
        tag: decodedTag,
        brief,
      });
      res.json(row);
    } catch (e) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  /** Clear the brief for an (org, tag) pair. */
  app.delete("/api/local/audiences/:orgId/:tag", async (req, res) => {
    try {
      const { orgId, tag } = req.params;
      await deleteAudienceBrief(orgId, decodeURIComponent(tag));
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  /** Resolve MindfulText session headers or throw 401. */
  async function mtProxyHeaders(req: Request): Promise<Record<string, string>> {
    const sessionId = extractSessionId(req);
    const storedCookies = sessionStore[sessionId] || sessionStore[AUTO_SESSION_ID] || "";
    if (!storedCookies) {
      throw new Error("Not authenticated — please log in first.");
    }
    return {
      Accept: "application/json",
      "User-Agent": "MindfulText-CustomFrontend/1.0",
      Cookie: storedCookies,
    };
  }

  /** Group detail — members + engagement rollups for a single tag. */
  app.get("/api/local/audiences/:orgId/:tag/detail", async (req, res) => {
    try {
      const { orgId } = req.params;
      const tag = decodeURIComponent(req.params.tag);
      const proxyHeaders = await mtProxyHeaders(req);
      const allContacts = await fetchAllMTContacts(orgId, proxyHeaders);
      const members = filterContactsByTag(allContacts, tag);
      const briefRow = await getAudienceBrief(orgId, tag);
      const detail = await buildGroupDetail(orgId, members, {
        kind: "tag",
        tag,
        brief: briefRow?.brief ?? "",
        briefUpdatedAt: briefRow?.updatedAt ?? null,
      });
      res.json(detail);
    } catch (e) {
      const msg = errMsg(e);
      res.status(msg.includes("Not authenticated") ? 401 : 500).json({ error: msg });
    }
  });

  /** Bulk-enroll every contact in a tag into a journey template. */
  app.post("/api/local/audiences/:orgId/:tag/enroll", async (req, res) => {
    try {
      const { orgId } = req.params;
      const tag = decodeURIComponent(req.params.tag);
      const templateId = Number(req.body?.templateId);
      if (!Number.isFinite(templateId)) {
        return res.status(400).json({ error: "templateId is required" });
      }
      const template = await getPersonalJourneyTemplateById(orgId, templateId);
      if (!template) return res.status(404).json({ error: "Template not found" });

      const proxyHeaders = await mtProxyHeaders(req);
      const allContacts = await fetchAllMTContacts(orgId, proxyHeaders);
      const members = filterContactsByTag(allContacts, tag);
      const moduleIds = template.moduleIds ?? [];
      let enrolled = 0;
      for (const c of members) {
        const id = contactIdOf(c);
        if (!id) continue;
        await applyTemplateToContact(
          orgId,
          id,
          moduleIds,
          "manual",
          `bulk_enroll_tag:${tag}`,
        );
        enrolled += 1;
      }
      res.json({ ok: true, enrolled, templateId, tag });
    } catch (e) {
      const msg = errMsg(e);
      res.status(msg.includes("Not authenticated") ? 401 : 500).json({ error: msg });
    }
  });

  /** Get-or-create subscriber page links for every contact in a tag. */
  app.post("/api/local/audiences/:orgId/:tag/subscriber-links", async (req, res) => {
    try {
      const { orgId } = req.params;
      const tag = decodeURIComponent(req.params.tag);
      const proxyHeaders = await mtProxyHeaders(req);
      const allContacts = await fetchAllMTContacts(orgId, proxyHeaders);
      const members = filterContactsByTag(allContacts, tag);
      const links: { contactId: string; name: string; id: number; token: string; url: string }[] = [];
      for (const c of members) {
        const contactId = contactIdOf(c);
        if (!contactId) continue;
        const row = await getOrCreatePageToken(orgId, contactId);
        const fn = typeof c.firstName === "string" ? c.firstName : "";
        const ln = typeof c.lastName === "string" ? c.lastName : "";
        const name = `${fn} ${ln}`.trim() || (typeof c.name === "string" ? c.name : contactId);
        links.push({
          contactId,
          name,
          id: row.id,
          token: row.token,
          url: publicPageUrl(req, row.token),
        });
      }
      res.json({ tag, links });
    } catch (e) {
      const msg = errMsg(e);
      res.status(msg.includes("Not authenticated") ? 401 : 500).json({ error: msg });
    }
  });

  // -----------------------------------------------------------------------
  // Local API — Saved segments (multi-tag cohorts)
  // -----------------------------------------------------------------------

  app.get("/api/local/segments/:orgId", async (req, res) => {
    try {
      const rows = await listSegments(req.params.orgId);
      res.json({ segments: rows });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.post("/api/local/segments/:orgId", async (req, res) => {
    try {
      const orgId = req.params.orgId;
      const name = typeof req.body?.name === "string" ? req.body.name.trim() : "";
      const includeTags = Array.isArray(req.body?.includeTags)
        ? req.body.includeTags.filter((t: unknown) => typeof t === "string" && t.trim()).map((t: string) => t.trim())
        : [];
      const excludeTags = Array.isArray(req.body?.excludeTags)
        ? req.body.excludeTags.filter((t: unknown) => typeof t === "string" && t.trim()).map((t: string) => t.trim())
        : [];
      const matchMode = req.body?.matchMode === "AND" ? "AND" : "OR";
      if (!name) return res.status(400).json({ error: "name is required" });
      if (includeTags.length === 0) {
        return res.status(400).json({ error: "includeTags must contain at least one tag" });
      }
      const row = await createSegment({
        organizationId: orgId,
        name,
        includeTags,
        excludeTags,
        matchMode,
      });
      res.status(201).json(row);
    } catch (e) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  app.patch("/api/local/segments/:orgId/:id", async (req, res) => {
    try {
      const orgId = req.params.orgId;
      const id = Number(req.params.id);
      const patch: Record<string, unknown> = {};
      if (typeof req.body?.name === "string") patch.name = req.body.name.trim();
      if (Array.isArray(req.body?.includeTags)) {
        patch.includeTags = req.body.includeTags
          .filter((t: unknown) => typeof t === "string" && t.trim())
          .map((t: string) => t.trim());
      }
      if (Array.isArray(req.body?.excludeTags)) {
        patch.excludeTags = req.body.excludeTags
          .filter((t: unknown) => typeof t === "string" && t.trim())
          .map((t: string) => t.trim());
      }
      if (req.body?.matchMode === "AND" || req.body?.matchMode === "OR") {
        patch.matchMode = req.body.matchMode;
      }
      const row = await updateSegment(orgId, id, patch);
      if (!row) return res.status(404).json({ error: "Segment not found" });
      res.json(row);
    } catch (e) {
      res.status(400).json({ error: errMsg(e) });
    }
  });

  app.delete("/api/local/segments/:orgId/:id", async (req, res) => {
    try {
      await deleteSegment(req.params.orgId, Number(req.params.id));
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.get("/api/local/segments/:orgId/:id/detail", async (req, res) => {
    try {
      const orgId = req.params.orgId;
      const id = Number(req.params.id);
      const segment = await getSegment(orgId, id);
      if (!segment) return res.status(404).json({ error: "Segment not found" });

      const proxyHeaders = await mtProxyHeaders(req);
      const allContacts = await fetchAllMTContacts(orgId, proxyHeaders);
      const members = filterContactsBySegmentRow(allContacts, segment);
      const detail = await buildGroupDetail(orgId, members, {
        kind: "segment",
        segment,
      });
      res.json(detail);
    } catch (e) {
      const msg = errMsg(e);
      res.status(msg.includes("Not authenticated") ? 401 : 500).json({ error: msg });
    }
  });

  app.post("/api/local/segments/:orgId/:id/enroll", async (req, res) => {
    try {
      const orgId = req.params.orgId;
      const id = Number(req.params.id);
      const templateId = Number(req.body?.templateId);
      if (!Number.isFinite(templateId)) {
        return res.status(400).json({ error: "templateId is required" });
      }
      const segment = await getSegment(orgId, id);
      if (!segment) return res.status(404).json({ error: "Segment not found" });
      const template = await getPersonalJourneyTemplateById(orgId, templateId);
      if (!template) return res.status(404).json({ error: "Template not found" });

      const proxyHeaders = await mtProxyHeaders(req);
      const allContacts = await fetchAllMTContacts(orgId, proxyHeaders);
      const members = filterContactsBySegmentRow(allContacts, segment);
      const moduleIds = template.moduleIds ?? [];
      let enrolled = 0;
      for (const c of members) {
        const contactId = contactIdOf(c);
        if (!contactId) continue;
        await applyTemplateToContact(
          orgId,
          contactId,
          moduleIds,
          "manual",
          `bulk_enroll_segment:${segment.name}`,
        );
        enrolled += 1;
      }
      res.json({ ok: true, enrolled, templateId, segmentId: id });
    } catch (e) {
      const msg = errMsg(e);
      res.status(msg.includes("Not authenticated") ? 401 : 500).json({ error: msg });
    }
  });

  app.post("/api/local/segments/:orgId/:id/subscriber-links", async (req, res) => {
    try {
      const orgId = req.params.orgId;
      const id = Number(req.params.id);
      const segment = await getSegment(orgId, id);
      if (!segment) return res.status(404).json({ error: "Segment not found" });

      const proxyHeaders = await mtProxyHeaders(req);
      const allContacts = await fetchAllMTContacts(orgId, proxyHeaders);
      const members = filterContactsBySegmentRow(allContacts, segment);
      const links: { contactId: string; name: string; id: number; token: string; url: string }[] = [];
      for (const c of members) {
        const contactId = contactIdOf(c);
        if (!contactId) continue;
        const row = await getOrCreatePageToken(orgId, contactId);
        const fn = typeof c.firstName === "string" ? c.firstName : "";
        const ln = typeof c.lastName === "string" ? c.lastName : "";
        const name = `${fn} ${ln}`.trim() || (typeof c.name === "string" ? c.name : contactId);
        links.push({
          contactId,
          name,
          id: row.id,
          token: row.token,
          url: publicPageUrl(req, row.token),
        });
      }
      res.json({ segmentId: id, links });
    } catch (e) {
      const msg = errMsg(e);
      res.status(msg.includes("Not authenticated") ? 401 : 500).json({ error: msg });
    }
  });

  // -----------------------------------------------------------------------
  // Webhook intake — outside agents (e.g. Cursor) post drafts directly
  // -----------------------------------------------------------------------

  /**
   * POST /api/webhooks/drafts
   * Header: X-Webhook-Secret: $CONTENT_WEBHOOK_SECRET
   * Body:
   *   { audienceTag: string,
   *     organizationId?: string,        // defaults to single-org "00000022"
   *     title?: string,
   *     // EITHER fully-written texts (skip AI):
   *     texts?: Array<string | { body: string; order?: number; charCount?: number }>,
   *     // OR a topic to plan-and-generate:
   *     topic?: string,
   *     goals?: string,
   *     textCount?: number,
   *     additionalContext?: string }
   */
  app.post("/api/webhooks/drafts", async (req, res) => {
    try {
      const expected = process.env.CONTENT_WEBHOOK_SECRET;
      if (!expected) {
        return res.status(503).json({
          error: "Webhook intake disabled — CONTENT_WEBHOOK_SECRET is not configured on the server.",
        });
      }
      const provided = req.headers["x-webhook-secret"];
      if (typeof provided !== "string" || provided !== expected) {
        return res.status(401).json({ error: "Invalid or missing X-Webhook-Secret header." });
      }

      const WebhookSchema = z
        .object({
          organizationId: z.string().optional(),
          audienceTag: z.string().min(1, "audienceTag is required"),
          title: z.string().optional(),
          topic: z.string().optional(),
          goals: z.string().optional(),
          textCount: z.number().int().positive().max(50).optional(),
          additionalContext: z.string().optional(),
          texts: z
            .array(
              z.union([
                z.string().min(1),
                z.object({
                  body: z.string().min(1),
                  order: z.number().int().optional(),
                  charCount: z.number().int().optional(),
                }),
              ]),
            )
            .optional(),
        })
        .refine((v) => !!v.topic || (Array.isArray(v.texts) && v.texts.length > 0), {
          message: "Provide either `topic` (to plan + generate) or non-empty `texts[]`.",
        });

      const parsed = WebhookSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join("; ") });
      }
      const body = parsed.data;
      const organizationId = body.organizationId || getConfiguredOrgId();

      // Path A — pre-written texts: create the draft directly in `draft` status.
      if (Array.isArray(body.texts) && body.texts.length > 0) {
        const normalizedTexts = body.texts.map((t, idx) =>
          typeof t === "string"
            ? { order: idx + 1, body: t, charCount: t.length }
            : { order: t.order ?? idx + 1, body: t.body, charCount: t.charCount ?? t.body.length },
        );
        const draft = await createContentDraft({
          organizationId,
          title: body.title || (body.topic ?? `Webhook draft for ${body.audienceTag}`),
          audienceTag: body.audienceTag,
          generatedTexts: { texts: normalizedTexts },
          status: "draft",
          metadata: { source: "webhook" },
        });
        return res.status(201).json({
          draftId: draft.id,
          status: draft.status,
          viewUrl: `/drafts`,
        });
      }

      // Path B — topic only: run plan + generate, leave the draft in `draft` status.
      const planResult = await createContentPlan({
        organizationId,
        topic: body.topic as string,
        goals: body.goals,
        textCount: body.textCount,
        additionalContext: body.additionalContext,
        audienceTag: body.audienceTag,
      });
      const contentPlan = parseJsonContent(planResult.content);

      const draft = await createContentDraft({
        organizationId,
        title: body.title || (body.topic as string),
        audienceTag: body.audienceTag,
        contentPlan,
        status: "generating",
        metadata: {
          source: "webhook",
          planModel: planResult.model,
          planTokens: planResult.totalTokens,
          planCostUsd: planResult.estimatedCostUsd,
        },
      });

      const genResult = await generateTextsFromPlan({
        organizationId,
        contentPlan,
        audienceTag: body.audienceTag,
      });
      const generatedTexts = parseJsonContent(genResult.content);

      const existingMeta =
        draft.metadata !== null && typeof draft.metadata === "object"
          ? (draft.metadata as Record<string, unknown>)
          : {};

      const updated = await updateContentDraft(draft.id, {
        generatedTexts,
        status: "draft",
        metadata: {
          ...existingMeta,
          generateModel: genResult.model,
          generateTokens: genResult.totalTokens,
          generateCostUsd: genResult.estimatedCostUsd,
        },
      });

      res.status(201).json({
        draftId: updated.id,
        status: updated.status,
        viewUrl: `/drafts`,
      });
    } catch (e) {
      res.status(500).json({ error: errMsg(e) });
    }
  });

  app.get("/api/local/health", (_req, res) => {
    res.json({
      status: "ok",
      features: [
        "content_drafts",
        "draft_messages",
        "inbound_tracking",
        "agent_memory",
        "agent_rules",
        "token_tracking",
        "content_programs",
      ],
      rulesFile: "mindfultext.md",
    });
  });

  const httpServer = createServer(app);

  startBackgroundJobs();

  return httpServer;
}
