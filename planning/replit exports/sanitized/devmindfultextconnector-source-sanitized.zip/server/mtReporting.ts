/**
 * MindfulText "reporting" (the real Analytics page) — discovered endpoint.
 *
 * The Analytics page on dev.mindfultext.com is powered by
 *   POST /api/reporting/{orgId}   body: { rangeInDays }
 * returning { data: { start, end, rangeInDays, newContacts, newLaunches,
 * messagesSent, messagesReceived } }. `rangeInDays` is a rolling window
 * counted back from "now" (NOT calendar-aligned); -1 means all time.
 * These are the authoritative totals (e.g. 58k+ messagesSent) that the old
 * 16-row /api/messages feed could never reproduce.
 */
import { addDays } from "date-fns";
import { toZonedTime } from "date-fns-tz";
import {
  calendarDateInTz,
  periodDeltaFromSnapshots,
  type CalendarMessageCounts,
} from "./dashboardMetrics";
import {
  getAnalyticsSnapshots,
  countMessageEventsInRange,
  countInboundMessages,
} from "./storage";
import { mtFetch } from "./mtClient";

export const REPORTING_RANGE_DAYS: Record<string, number> = {
  today: 1,
  day: 1,
  "3d": 3,
  week: 7,
  "7d": 7,
  month: 30,
  "30d": 30,
  year: 365,
  "365d": 365,
  all: -1,
};

export interface MtReporting {
  start: string;
  end: string;
  rangeInDays: number;
  newContacts: number;
  newLaunches: number;
  messagesSent: number;
  messagesReceived: number;
}

/**
 * Fetch MindfulText's real analytics for an org over a rolling window.
 * Returns null on any auth/transport/parse failure so callers can fall back
 * (e.g. refresh the auto-session and retry) without throwing.
 */
export async function fetchMtReporting(
  orgId: string,
  rangeInDays: number,
  cookies: string,
): Promise<MtReporting | null> {
  if (!cookies) return null;
  try {
    const r = await mtFetch(`/api/reporting/${orgId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      cookies,
      body: JSON.stringify({ rangeInDays }),
    });
    if (!r.ok) return null;
    const j = (await r.json()) as { data?: Partial<MtReporting> };
    const d = j?.data;
    if (!d) return null;
    return {
      start: String(d.start ?? ""),
      end: String(d.end ?? ""),
      rangeInDays: Number(d.rangeInDays ?? rangeInDays),
      newContacts: Number(d.newContacts ?? 0),
      newLaunches: Number(d.newLaunches ?? 0),
      messagesSent: Number(d.messagesSent ?? 0),
      messagesReceived: Number(d.messagesReceived ?? 0),
    };
  } catch {
    return null;
  }
}

/**
 * Try MindfulText reporting with explicit calendar bounds. Returns a result
 * only when the response `start` aligns with the requested window (within 1h).
 */
export async function fetchMtReportingForCalendarWindow(
  orgId: string,
  start: Date,
  end: Date,
  cookies: string,
): Promise<MtReporting | null> {
  if (!cookies) return null;
  const rangeInDays = Math.max(
    1,
    Math.ceil((end.getTime() - start.getTime()) / 86_400_000),
  );
  const bodies: Record<string, unknown>[] = [
    { start: start.toISOString(), end: end.toISOString() },
    { startDate: start.toISOString(), endDate: end.toISOString() },
    { rangeInDays, start: start.toISOString(), end: end.toISOString() },
  ];
  for (const body of bodies) {
    try {
      const r = await mtFetch(`/api/reporting/${orgId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        cookies,
        body: JSON.stringify(body),
      });
      if (!r.ok) continue;
      const j = (await r.json()) as { data?: Partial<MtReporting> };
      const d = j?.data;
      if (!d) continue;
      const parsed: MtReporting = {
        start: String(d.start ?? ""),
        end: String(d.end ?? ""),
        rangeInDays: Number(d.rangeInDays ?? rangeInDays),
        newContacts: Number(d.newContacts ?? 0),
        newLaunches: Number(d.newLaunches ?? 0),
        messagesSent: Number(d.messagesSent ?? 0),
        messagesReceived: Number(d.messagesReceived ?? 0),
      };
      if (parsed.start) {
        const respStart = Date.parse(parsed.start);
        if (
          Number.isFinite(respStart) &&
          Math.abs(respStart - start.getTime()) < 3_600_000
        ) {
          return parsed;
        }
      }
    } catch {
      /* try next body shape */
    }
  }
  return null;
}

/** Calendar-aligned message counts for dashboard tiles. */
export async function getCalendarMessageCounts(
  orgId: string,
  start: Date | null,
  end: Date | null,
  tz: string,
  cookies: string,
): Promise<CalendarMessageCounts> {
  if (!start || !end) {
    const rep = await fetchMtReporting(orgId, -1, cookies);
    return {
      sent: rep?.messagesSent ?? 0,
      received: rep?.messagesReceived ?? 0,
    };
  }

  const calRep = await fetchMtReportingForCalendarWindow(orgId, start, end, cookies);
  if (calRep) {
    return {
      sent: calRep.messagesSent,
      received: calRep.messagesReceived,
    };
  }

  const zonedStart = toZonedTime(start, tz);
  const fromDay = calendarDateInTz(addDays(zonedStart, -1), tz);
  const lastDay = calendarDateInTz(new Date(end.getTime() - 1), tz);
  const toSnap = calendarDateInTz(addDays(toZonedTime(new Date(end.getTime() - 1), tz), 1), tz);
  const snaps = await getAnalyticsSnapshots(orgId, fromDay, toSnap);
  const repAll = await fetchMtReporting(orgId, -1, cookies);
  const fromSnaps = periodDeltaFromSnapshots(snaps, start, end, tz, repAll);
  if (fromSnaps) return fromSnaps;

  const [sent, received] = await Promise.all([
    countMessageEventsInRange(orgId, start, end, "send"),
    countInboundMessages(orgId, start, end),
  ]);
  return { sent, received };
}
