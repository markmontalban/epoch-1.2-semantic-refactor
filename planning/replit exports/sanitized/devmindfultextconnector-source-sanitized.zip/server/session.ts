/**
 * Session-cookie store + helpers for the MindfulText proxy.
 *
 * The browser sends a stable `X-Session-ID`; we map it to the MindfulText
 * `Set-Cookie` string captured at login. The store is persisted to a small
 * gitignored JSON file so sessions survive restarts. `sessionStore` and
 * `sessionOrgs` are shared singletons (mutated in place, never reassigned).
 */
import fs from "fs";
import path from "path";
import type { Request } from "express";
import { mtFetch } from "./mtClient";

/** Session id used for the server's own auto-login cookies. */
export const AUTO_SESSION_ID = "auto-session";

const sessionFile = path.join(process.cwd(), ".session-cookies.json");

export function loadSessionStore(): Record<string, string> {
  try {
    if (fs.existsSync(sessionFile)) {
      return JSON.parse(fs.readFileSync(sessionFile, "utf-8"));
    }
  } catch {
    /* empty */
  }
  return {};
}

export function saveSessionStore(store: Record<string, string>) {
  try {
    fs.writeFileSync(sessionFile, JSON.stringify(store, null, 2));
  } catch {
    /* empty */
  }
}

/** sid -> MindfulText cookie string. */
export const sessionStore: Record<string, string> = loadSessionStore();

// sid -> resolved orgId. Populated lazily when the session first hits a
// /api/local/* route; org-scoped routes use this to derive orgId from the
// session instead of trusting a client-supplied query param.
export const sessionOrgs: Record<string, string> = {};

export function extractSessionId(req: Request): string {
  const headerSid = req.headers["x-session-id"];
  if (typeof headerSid === "string" && headerSid.trim()) {
    return headerSid.trim();
  }
  return req.ip || req.socket.remoteAddress || "default";
}

export async function resolveOrgIdFromCookies(cookies: string): Promise<string | null> {
  try {
    const r = await mtFetch("/api/organizations/byUser", { cookies });
    if (!r.ok) return null;
    const j = (await r.json()) as Record<string, unknown>;
    const orgs = Array.isArray(j)
      ? (j as { id: string | number }[])
      : Array.isArray((j as { data?: unknown[] }).data)
        ? ((j as { data: { id: string | number }[] }).data)
        : [];
    if (orgs.length > 0 && orgs[0].id != null) {
      return String(orgs[0].id).padStart(8, "0");
    }
    return null;
  } catch {
    return null;
  }
}
