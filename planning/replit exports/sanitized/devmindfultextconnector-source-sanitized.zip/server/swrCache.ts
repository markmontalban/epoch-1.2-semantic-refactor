// ---------------------------------------------------------------------------
// In-process stale-while-revalidate cache.
//
// A single-instance app doesn't need Redis: a module-level Map is enough to
// make repeat dashboard loads near-instant. Each entry carries the value plus
// the time it was fetched. Within `ttlMs` a hit is returned immediately and is
// considered fresh. Past the TTL the *stale* value is still returned right
// away while a background refresh repopulates the entry, so a response is
// never blocked on a slow upstream once we have any value at all.
// ---------------------------------------------------------------------------

interface Entry<T> {
  value: T;
  cachedAt: number;
  refreshing: boolean;
}

const store = new Map<string, Entry<unknown>>();

export interface SwrResult<T> {
  value: T;
  /** Epoch ms when the underlying value was last fetched from upstream. */
  cachedAt: number;
  /** True when a stale value was served and a background refresh kicked off. */
  stale: boolean;
}

/**
 * Get a cached value or (re)compute it via `fetcher`.
 *
 * - Fresh hit (age < ttlMs): return the cached value, `stale: false`.
 * - Stale hit (age >= ttlMs): return the cached value immediately with
 *   `stale: true` and trigger a single background refresh (deduped).
 * - Miss: await `fetcher`, store, and return `stale: false`.
 * - `force`: bypass any cached value and await a fresh fetch.
 *
 * The `fetcher` should re-resolve any request-scoped inputs it needs (e.g.
 * session cookies) at call time so background refreshes use current state.
 */
export async function swr<T>(
  key: string,
  ttlMs: number,
  fetcher: () => Promise<T>,
  opts?: { force?: boolean },
): Promise<SwrResult<T>> {
  const force = opts?.force === true;
  const existing = store.get(key) as Entry<T> | undefined;
  const now = Date.now();

  if (existing && !force) {
    const age = now - existing.cachedAt;
    if (age < ttlMs) {
      return { value: existing.value, cachedAt: existing.cachedAt, stale: false };
    }
    // Stale: serve the old value and refresh in the background (deduped).
    if (!existing.refreshing) {
      existing.refreshing = true;
      void fetcher()
        .then((value) => {
          store.set(key, { value, cachedAt: Date.now(), refreshing: false });
        })
        .catch(() => {
          // Keep the stale value on failure; allow a later retry.
          existing.refreshing = false;
        });
    }
    return { value: existing.value, cachedAt: existing.cachedAt, stale: true };
  }

  // Miss, or a forced refresh: compute synchronously and store.
  const value = await fetcher();
  const cachedAt = Date.now();
  store.set(key, { value, cachedAt, refreshing: false });
  return { value, cachedAt, stale: false };
}

/**
 * Drop cached entries. With no argument the whole cache is cleared (used when
 * the active org changes); with a prefix only matching keys are removed.
 */
export function invalidateSwr(prefix?: string): void {
  if (!prefix) {
    store.clear();
    return;
  }
  for (const k of Array.from(store.keys())) {
    if (k.startsWith(prefix)) store.delete(k);
  }
}
