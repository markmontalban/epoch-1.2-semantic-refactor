import fs from "fs";
import path from "path";
import { getActiveRules, getActiveMemories, getAudienceBrief } from "../storage";

const RULES_FILE = path.join(process.cwd(), "mindfultext.md");

let cachedBaseRules: string | null = null;

/**
 * Load the base rules from mindfultext.md (cached after first read).
 */
function loadBaseRules(): string {
  if (cachedBaseRules) return cachedBaseRules;
  try {
    cachedBaseRules = fs.readFileSync(RULES_FILE, "utf-8");
  } catch {
    cachedBaseRules =
      "You are MindfulText AI. Help create thoughtful SMS content.";
  }
  return cachedBaseRules;
}

/** Call this if mindfultext.md is hot-reloaded. */
export function invalidateBaseRulesCache() {
  cachedBaseRules = null;
}

/** Current base prompt text (from cache or disk). */
export function getBaseRules(): string {
  return loadBaseRules();
}

/** Overwrite the base prompt (mindfultext.md) and refresh the cache. */
export function setBaseRules(content: string): void {
  fs.writeFileSync(RULES_FILE, content, "utf-8");
  cachedBaseRules = content;
}

/**
 * Build the full system prompt for an AI call.
 *
 * Layers (in order):
 *   1. mindfultext.md — base personality & constraints
 *   2. Organization-specific rules from the database
 *   3. Active memories (facts, preferences, summaries)
 */
export async function buildSystemPrompt(
  organizationId: string,
  scope?: string,
  audienceTag?: string | null,
): Promise<string> {
  const parts: string[] = [loadBaseRules()];

  const orgRules = await getActiveRules(organizationId, scope);
  if (orgRules.length > 0) {
    parts.push("\n\n---\n## Organization-specific rules\n");
    for (const rule of orgRules) {
      parts.push(`### ${rule.name}\n${rule.content}\n`);
    }
  }

  const globalRules = scope
    ? await getActiveRules(organizationId, "global")
    : [];
  for (const rule of globalRules) {
    parts.push(`### ${rule.name}\n${rule.content}\n`);
  }

  const memories = await getActiveMemories(organizationId);
  if (memories.length > 0) {
    parts.push("\n\n---\n## Agent memory (known facts about this organization)\n");
    for (const mem of memories) {
      parts.push(`- **${mem.key}**: ${mem.value}`);
    }
  }

  // Audience guidance — appended last so it overrides earlier defaults
  // when crafting tone/angle for a specific contact group.
  if (audienceTag) {
    const brief = await getAudienceBrief(organizationId, audienceTag);
    if (brief && brief.brief.trim()) {
      parts.push(
        `\n\n---\n## Audience guidance — tag "${audienceTag}"\n${brief.brief.trim()}\n`,
      );
    }
  }

  return parts.join("\n");
}
