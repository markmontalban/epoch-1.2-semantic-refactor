import { buildSystemPrompt } from "./rules";
import { logTokenUsage } from "../storage";

// ---------------------------------------------------------------------------
// Model configuration
// ---------------------------------------------------------------------------

/**
 * OpenRouter Auto Router picks a model per request. Override with
 * OPENROUTER_MODEL to pin a single model (e.g. for local debugging).
 */
const ROUTING_MODEL =
  process.env.OPENROUTER_MODEL?.trim() || "openai/gpt-oss-20b:free";

const OPENROUTER_DOCS_AUTO =
  "https://openrouter.ai/docs/guides/routing/routers/auto-router";

/** Cost per 1M tokens (input / output) — rough estimates when the routed slug is known. */
const MODEL_COSTS: Record<string, { input: number; output: number }> = {
  "tencent/hy3-preview:free": { input: 0, output: 0 },
  "google/gemini-2.0-flash-exp:free": { input: 0, output: 0 },
  "openai/gpt-oss-20b:free": { input: 0, output: 0 },
  "openrouter/auto": { input: 0, output: 0 },
  "moonshotai/kimi-k2.6": { input: 0.14, output: 0.56 },
  "openai/gpt-oss-120b": { input: 5, output: 15 },
  "anthropic/claude-sonnet-4.6": { input: 3, output: 15 },
  "openai/gpt-4o": { input: 2.5, output: 10 },
  "openai/gpt-4o-mini": { input: 0.15, output: 0.6 },
  "anthropic/claude-sonnet-4-20250514": { input: 3, output: 15 },
  "anthropic/claude-sonnet-4.5": { input: 3, output: 15 },
  "anthropic/claude-3-5-haiku-20241022": { input: 0.8, output: 4 },
  "google/gemini-2.0-flash-001": { input: 0.1, output: 0.4 },
  "meta-llama/llama-3.1-70b-instruct": { input: 0.5, output: 0.7 },
};

const OPENROUTER_BASE =
  process.env.OPENROUTER_BASE_URL || "https://openrouter.ai/api/v1";

function getApiKey(): string {
  const key = process.env.OPENROUTER_API_KEY;
  if (!key) throw new Error("OPENROUTER_API_KEY is required");
  return key;
}

// ---------------------------------------------------------------------------
// Core completion function
// ---------------------------------------------------------------------------

interface CompletionOptions {
  model: string;
  systemPrompt: string;
  userPrompt: string;
  temperature?: number;
  maxTokens?: number;
}

interface CompletionResult {
  content: string;
  /** Model actually billed (OpenRouter sets this when using openrouter/auto). */
  model: string;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  estimatedCostUsd: number;
}

export async function complete(opts: CompletionOptions): Promise<CompletionResult> {
  const res = await fetch(`${OPENROUTER_BASE}/chat/completions`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${getApiKey()}`,
      "Content-Type": "application/json",
      "HTTP-Referer": "https://mindfultext.com",
      "X-Title": "MindfulText AI",
    },
    body: JSON.stringify({
      model: opts.model,
      messages: [
        { role: "system", content: opts.systemPrompt },
        { role: "user", content: opts.userPrompt },
      ],
      temperature: opts.temperature ?? 0.7,
      max_tokens: opts.maxTokens ?? 4096,
    }),
  });

  if (!res.ok) {
    const errorBody = await res.text();
    throw new Error(`AI API error ${res.status}: ${errorBody}`);
  }

  const json = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
    usage?: {
      prompt_tokens?: number;
      completion_tokens?: number;
    };
    model?: string;
  };
  const choice = json.choices?.[0];
  const usage = json.usage ?? {};

  const promptTokens = usage.prompt_tokens ?? 0;
  const completionTokens = usage.completion_tokens ?? 0;
  const resolvedModel = json.model ?? opts.model;

  const costs =
    MODEL_COSTS[resolvedModel] ?? { input: 1, output: 3 };
  const estimatedCostUsd =
    (promptTokens * costs.input + completionTokens * costs.output) / 1_000_000;

  return {
    content: choice?.message?.content ?? "",
    model: resolvedModel,
    promptTokens,
    completionTokens,
    totalTokens: promptTokens + completionTokens,
    estimatedCostUsd: Math.round(estimatedCostUsd * 10000) / 10000,
  };
}

// ---------------------------------------------------------------------------
// High-level AI operations
// ---------------------------------------------------------------------------

export interface ContentPlanRequest {
  organizationId: string;
  topic: string;
  audience?: string;
  goals?: string;
  textCount?: number;
  additionalContext?: string;
  /** MindfulText contact tag — pulls in the matching audience brief if set. */
  audienceTag?: string | null;
}

/**
 * Step 1: Create a content plan with research (OpenRouter Auto Router).
 */
export async function createContentPlan(req: ContentPlanRequest) {
  const systemPrompt = await buildSystemPrompt(
    req.organizationId,
    "content_generation",
    req.audienceTag,
  );

  const userPrompt = `Create a detailed content plan for an SMS text module.

Topic: ${req.topic}
${req.audience ? `Target audience: ${req.audience}` : ""}
${req.audienceTag ? `Target audience tag: ${req.audienceTag} (see Audience guidance in system prompt)` : ""}
${req.goals ? `Goals: ${req.goals}` : ""}
Number of texts: ${req.textCount ?? 10}
${req.additionalContext ? `Additional context: ${req.additionalContext}` : ""}

Please provide:
1. A research summary with key facts and sources
2. The module structure and arc
3. For each text: a one-line summary, target character count, and call-to-action type
4. Suggested send cadence

Return the plan as JSON with this structure:
{
  "title": "...",
  "researchSummary": "...",
  "arc": "intro → core → reflection → action",
  "cadence": "...",
  "texts": [
    { "order": 1, "summary": "...", "targetChars": 160, "ctaType": "reflection" }
  ]
}`;

  const result = await complete({
    model: ROUTING_MODEL,
    systemPrompt,
    userPrompt,
    temperature: 0.6,
  });

  await logTokenUsage({
    organizationId: req.organizationId,
    taskType: "content_planning",
    model: result.model,
    promptTokens: result.promptTokens,
    completionTokens: result.completionTokens,
    totalTokens: result.totalTokens,
    estimatedCostUsd: result.estimatedCostUsd,
    referenceType: "content_draft",
  });

  return result;
}

export interface ContentGenerateRequest {
  organizationId: string;
  contentPlan: any;
  batchSize?: number;
  audienceTag?: string | null;
}

/**
 * Step 2: Generate actual SMS texts from the plan (OpenRouter Auto Router).
 */
export async function generateTextsFromPlan(req: ContentGenerateRequest) {
  const systemPrompt = await buildSystemPrompt(
    req.organizationId,
    "content_generation",
    req.audienceTag,
  );

  const planJson =
    typeof req.contentPlan === "string"
      ? req.contentPlan
      : JSON.stringify(req.contentPlan, null, 2);

  const userPrompt = `Based on this content plan, write the actual SMS texts.

Content Plan:
${planJson}

For each text in the plan, write the final SMS body. Keep each text under the target character count. Make them warm, action-oriented, and engaging.

Return as JSON:
{
  "texts": [
    { "order": 1, "body": "...", "charCount": 142 }
  ]
}`;

  const result = await complete({
    model: ROUTING_MODEL,
    systemPrompt,
    userPrompt,
    temperature: 0.8,
  });

  await logTokenUsage({
    organizationId: req.organizationId,
    taskType: "content_generation",
    model: result.model,
    promptTokens: result.promptTokens,
    completionTokens: result.completionTokens,
    totalTokens: result.totalTokens,
    estimatedCostUsd: result.estimatedCostUsd,
    referenceType: "content_draft",
  });

  return result;
}

export interface DraftReplyRequest {
  organizationId: string;
  inboundContent: string;
  contactId?: string;
  contactPhone?: string;
}

/**
 * Auto-generate a draft reply to an inbound message (OpenRouter Auto Router).
 */
export async function generateDraftReply(req: DraftReplyRequest) {
  const systemPrompt = await buildSystemPrompt(
    req.organizationId,
    "reply_drafting",
  );

  const userPrompt = `A contact sent this message:

"${req.inboundContent}"

Draft a warm, helpful reply under 160 characters. This is a DRAFT — a human will review it before sending.`;

  const result = await complete({
    model: ROUTING_MODEL,
    systemPrompt,
    userPrompt,
    temperature: 0.7,
    maxTokens: 256,
  });

  await logTokenUsage({
    organizationId: req.organizationId,
    taskType: "reply_drafting",
    model: result.model,
    promptTokens: result.promptTokens,
    completionTokens: result.completionTokens,
    totalTokens: result.totalTokens,
    estimatedCostUsd: result.estimatedCostUsd,
    referenceType: "draft_message",
  });

  return result;
}

export interface AskQuestionRequest {
  organizationId: string;
  question: string;
  model?: string;
  context?: string;
}

/**
 * Ask a natural-language question about MindfulText data.
 */
export async function askQuestion(req: AskQuestionRequest): Promise<CompletionResult> {
  const systemPrompt = await buildSystemPrompt(req.organizationId, "content_generation");

  const fullSystem = `${systemPrompt}

You are a helpful assistant for MindfulText, a customer journey management platform.
Answer the user's questions clearly and concisely using the data context provided.
${req.context ? `\n--- Current data snapshot ---\n${req.context}\n---` : ""}`;

  const result = await complete({
    model: req.model || ROUTING_MODEL,
    systemPrompt: fullSystem,
    userPrompt: req.question,
    temperature: 0.7,
    maxTokens: 1024,
  });

  await logTokenUsage({
    organizationId: req.organizationId,
    taskType: "ask_question",
    model: result.model,
    promptTokens: result.promptTokens,
    completionTokens: result.completionTokens,
    totalTokens: result.totalTokens,
    estimatedCostUsd: result.estimatedCostUsd,
    referenceType: "ask",
  });

  return result;
}

/**
 * Generate 3-5 plain-language founder highlights from a metrics summary.
 * Returns the raw completion; the caller parses the JSON array of insights.
 */
export async function generateInsights(req: {
  organizationId: string;
  summary: string;
}): Promise<CompletionResult> {
  const systemPrompt = await buildSystemPrompt(req.organizationId, "global");

  const fullSystem = `${systemPrompt}

You are an analytics co-pilot for the founder of MindfulText, an SMS coaching
business. Given a JSON metrics summary, surface the 3-5 MOST important,
specific, quantitative highlights a founder should know right now (growth,
engagement, deliverability, cost, revenue). Be concrete (cite the numbers and
the % change). Never invent data not present in the summary.

Return ONLY a JSON array, no prose:
[
  { "title": "short headline", "detail": "one quantitative sentence", "sentiment": "positive" | "negative" | "neutral" }
]`;

  const result = await complete({
    model: ROUTING_MODEL,
    systemPrompt: fullSystem,
    userPrompt: `Metrics summary:\n${req.summary}`,
    temperature: 0.4,
    maxTokens: 900,
  });

  await logTokenUsage({
    organizationId: req.organizationId,
    taskType: "insights",
    model: result.model,
    promptTokens: result.promptTokens,
    completionTokens: result.completionTokens,
    totalTokens: result.totalTokens,
    estimatedCostUsd: result.estimatedCostUsd,
    referenceType: "insights",
  });

  return result;
}

export interface AskStreamChunk {
  type: "delta" | "done" | "error" | "thinking" | "status";
  content?: string;
  /** For type:"status" — human-readable loading message */
  text?: string;
  model?: string;
  promptTokens?: number;
  completionTokens?: number;
  totalTokens?: number;
  estimatedCostUsd?: number;
  error?: string;
  /** True when the error originated from the upstream model API (4xx/5xx from OpenRouter),
   *  as opposed to a local network, auth, or application error. */
  modelError?: boolean;
}

/**
 * Stream an Ask response token-by-token using OpenRouter SSE.
 * Yields AskStreamChunk objects; the final chunk has type "done" with usage stats.
 */
export async function* askQuestionStream(
  req: AskQuestionRequest,
  signal?: AbortSignal,
): AsyncGenerator<AskStreamChunk> {
  const systemPrompt = await buildSystemPrompt(req.organizationId, "content_generation");

  const fullSystem = `${systemPrompt}

You are a helpful assistant for MindfulText, a customer journey management platform.
Answer the user's questions clearly and concisely using the data context provided.
${req.context ? `\n--- Current data snapshot ---\n${req.context}\n---` : ""}`;

  const res = await fetch(`${OPENROUTER_BASE}/chat/completions`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${getApiKey()}`,
      "Content-Type": "application/json",
      "HTTP-Referer": "https://mindfultext.com",
      "X-Title": "MindfulText AI",
    },
    body: JSON.stringify({
      model: req.model || ROUTING_MODEL,
      messages: [
        { role: "system", content: fullSystem },
        { role: "user", content: req.question },
      ],
      temperature: 0.7,
      max_tokens: 1024,
      stream: true,
    }),
    signal,
  });

  if (!res.ok) {
    const errorBody = await res.text();
    yield { type: "error", error: `AI API error ${res.status}: ${errorBody}`, modelError: true };
    return;
  }

  if (!res.body) {
    yield { type: "error", error: "No response body from AI API", modelError: true };
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let resolvedModel = req.model || ROUTING_MODEL;
  let promptTokens = 0;
  let completionTokens = 0;

  // ── <think> tag state machine ──────────────────────────────────────────
  // Some models embed chain-of-thought inside <think>...</think> tags in the
  // content stream. We extract those tokens and emit them as "thinking" chunks
  // so they never leak into the user-visible delta output.
  const THINK_OPEN = "<think>";
  const THINK_CLOSE = "</think>";
  const MAX_TAG_LEN = Math.max(THINK_OPEN.length, THINK_CLOSE.length);
  let insideThink = false;
  let contentBuf = ""; // partial content buffered while watching for tag boundaries

  function* processContentChunk(incoming: string): Generator<AskStreamChunk> {
    contentBuf += incoming;
    while (contentBuf.length > 0) {
      const tag = insideThink ? THINK_CLOSE : THINK_OPEN;
      const idx = contentBuf.indexOf(tag);
      if (idx !== -1) {
        // Emit everything before the tag boundary
        if (idx > 0) {
          yield { type: insideThink ? "thinking" : "delta", content: contentBuf.slice(0, idx) };
        }
        contentBuf = contentBuf.slice(idx + tag.length);
        insideThink = !insideThink;
        // Continue the loop — there may be another tag in the remainder
      } else {
        // Complete tag not yet seen — emit only the safe prefix (hold back
        // enough bytes that a split tag can be matched on the next chunk).
        const keepLen = Math.min(MAX_TAG_LEN - 1, contentBuf.length);
        const safeLen = contentBuf.length - keepLen;
        if (safeLen > 0) {
          yield { type: insideThink ? "thinking" : "delta", content: contentBuf.slice(0, safeLen) };
          contentBuf = contentBuf.slice(safeLen);
        }
        break;
      }
    }
  }

  function* flushContentBuf(): Generator<AskStreamChunk> {
    if (contentBuf.length > 0) {
      yield { type: insideThink ? "thinking" : "delta", content: contentBuf };
      contentBuf = "";
    }
  }
  // ── end state machine ───────────────────────────────────────────────────

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed === ":") continue;
        if (!trimmed.startsWith("data:")) continue;

        const dataStr = trimmed.slice(5).trim();
        if (dataStr === "[DONE]") continue;

        try {
          const parsed = JSON.parse(dataStr) as {
            choices?: Array<{
              delta?: {
                content?: string;
                /** OpenRouter native reasoning field — present for models like
                 *  Kimi K2, DeepSeek R1, QwQ that expose chain-of-thought. */
                reasoning?: string;
              };
              finish_reason?: string;
            }>;
            model?: string;
            usage?: { prompt_tokens?: number; completion_tokens?: number };
          };

          if (parsed.model) resolvedModel = parsed.model;
          if (parsed.usage) {
            promptTokens = parsed.usage.prompt_tokens ?? promptTokens;
            completionTokens = parsed.usage.completion_tokens ?? completionTokens;
          }

          // Native reasoning field (OpenRouter passthrough for Kimi K2, DeepSeek R1, etc.)
          const reasoning = parsed.choices?.[0]?.delta?.reasoning;
          if (reasoning) {
            yield { type: "thinking", content: reasoning };
          }

          // Content field — run through <think> tag state machine so models
          // that embed reasoning as <think>...</think> are handled correctly.
          const delta = parsed.choices?.[0]?.delta?.content;
          if (delta) {
            yield* processContentChunk(delta);
          }
        } catch {
          /* malformed chunk — skip */
        }
      }
    }
    // Flush any remaining buffered content after the stream ends
    yield* flushContentBuf();
  } finally {
    reader.releaseLock();
  }

  const costs = MODEL_COSTS[resolvedModel] ?? { input: 1, output: 3 };
  const estimatedCostUsd =
    Math.round(
      ((promptTokens * costs.input + completionTokens * costs.output) / 1_000_000) * 10000,
    ) / 10000;

  await logTokenUsage({
    organizationId: req.organizationId,
    taskType: "ask_question",
    model: resolvedModel,
    promptTokens,
    completionTokens,
    totalTokens: promptTokens + completionTokens,
    estimatedCostUsd,
    referenceType: "ask",
  }).catch(() => {/* non-fatal */});

  yield {
    type: "done",
    model: resolvedModel,
    promptTokens,
    completionTokens,
    totalTokens: promptTokens + completionTokens,
    estimatedCostUsd,
  };
}

/**
 * Describe routing configuration for the settings UI.
 */
export function getAvailableModels() {
  return {
    routingModel: ROUTING_MODEL,
    description:
      ROUTING_MODEL === "openrouter/auto"
        ? "OpenRouter Auto Router selects a model per request from a curated pool; you are billed at the routed model’s rate."
        : "Using a fixed model (OPENROUTER_MODEL override).",
    docsUrl: OPENROUTER_DOCS_AUTO,
    referencePricingByModel: Object.entries(MODEL_COSTS).map(([id, costs]) => ({
      id,
      inputCostPer1M: costs.input,
      outputCostPer1M: costs.output,
      note: "Illustrative; actual routed model may vary when using openrouter/auto",
    })),
  };
}
