import { addDays } from "date-fns";
import { formatInTimeZone, toZonedTime } from "date-fns-tz";
import type { AnalyticsSnapshot } from "@shared/schema";

export type CalendarMessageCounts = { sent: number; received: number };

/** Calendar date (YYYY-MM-DD) for an instant in the user's IANA timezone. */
export function calendarDateInTz(instant: Date, tz: string): string {
  return formatInTimeZone(instant, tz, "yyyy-MM-dd");
}

function latestSnapshotOnOrBefore(
  snapshots: AnalyticsSnapshot[],
  dayStr: string,
): AnalyticsSnapshot | null {
  let best: AnalyticsSnapshot | null = null;
  for (const s of snapshots) {
    if (s.snapshotDate > dayStr) continue;
    if (s.totalSent == null && s.totalReceived == null) continue;
    if (!best || s.snapshotDate > best.snapshotDate) best = s;
  }
  return best;
}

/**
 * Derive calendar-period message counts from daily snapshots that store
 * MindfulText all-time cumulative totals (`totalSent` / `totalReceived`).
 *
 * Period [start, end) in the user's tz:
 *   count = cumulative(last day in period) − cumulative(day before start)
 */
export function periodDeltaFromSnapshots(
  snapshots: AnalyticsSnapshot[],
  start: Date,
  end: Date,
  tz: string,
  liveTotals: { messagesSent: number; messagesReceived: number } | null,
): CalendarMessageCounts | null {
  const zonedStart = toZonedTime(start, tz);
  const dayBeforeStart = calendarDateInTz(addDays(zonedStart, -1), tz);
  const lastDay = calendarDateInTz(new Date(end.getTime() - 1), tz);
  const todayStr = calendarDateInTz(new Date(), tz);

  const snapBefore = latestSnapshotOnOrBefore(snapshots, dayBeforeStart);
  const snapEnd = latestSnapshotOnOrBefore(snapshots, lastDay);

  const sentBefore = snapBefore?.totalSent ?? null;
  const recvBefore = snapBefore?.totalReceived ?? null;
  let sentEnd = snapEnd?.totalSent ?? null;
  let recvEnd = snapEnd?.totalReceived ?? null;

  // Period includes today — use live all-time totals for the end boundary.
  if (liveTotals && lastDay >= todayStr) {
    if (sentEnd == null) sentEnd = liveTotals.messagesSent;
    if (recvEnd == null) recvEnd = liveTotals.messagesReceived;
  }

  if (
    sentEnd == null ||
    recvEnd == null ||
    sentBefore == null ||
    recvBefore == null
  ) {
    return null;
  }

  return {
    sent: Math.max(0, sentEnd - sentBefore),
    received: Math.max(0, recvEnd - recvBefore),
  };
}
