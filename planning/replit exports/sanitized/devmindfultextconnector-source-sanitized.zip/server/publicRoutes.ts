/**
 * Public, token-scoped subscriber pages.
 *
 * These routes have NO session auth — access is gated entirely by an
 * unguessable page token. They are strictly read-only with respect to
 * subscriber and MindfulText data; the only write is an append-only page-view
 * event for founder analytics. Upstream MindfulText reads use the server-side
 * auto-session and are cached so a public page never hammers the API.
 */
import type { Express } from "express";
import { mtFetch } from "./mtClient";
import { sessionStore, AUTO_SESSION_ID } from "./session";
import {
  getActivePageToken,
  touchPageTokenVisit,
  recordPageEvent,
  listPublishedContent,
  getPageSettings,
  defaultPageSettings,
} from "./storage";
import { getExistingContactProfile } from "./contactMemory";
import { listEvents } from "./personalJourney";
import { textBodies } from "./linkHarvester";

type MTContact = {
  id?: string;
  _id?: string;
  contactID?: string;
  firstName?: string;
  tags?: string[];
  isArchived?: boolean;
  [k: string]: unknown;
};

const CONTACT_TTL_MS = 5 * 60_000;
const MODULE_TTL_MS = 10 * 60_000;
const contactsByOrg = new Map<string, { at: number; contacts: MTContact[] }>();
const moduleNamesByOrg = new Map<string, { at: number; names: Map<string, string> }>();
const moduleNotesByOrg = new Map<string, { at: number; notes: Map<string, string> }>();

function autoCookies(): string {
  return sessionStore[AUTO_SESSION_ID] || "";
}

function contactIdOf(c: MTContact): string | null {
  return (c.id ?? c._id ?? c.contactID ?? null) as string | null;
}

/** All contacts for an org, cached for a few minutes (best-effort). */
async function getOrgContacts(orgId: string): Promise<MTContact[]> {
  const cached = contactsByOrg.get(orgId);
  if (cached && Date.now() - cached.at < CONTACT_TTL_MS) return cached.contacts;
  const cookies = autoCookies();
  if (!cookies) return cached?.contacts ?? [];

  const all: MTContact[] = [];
  for (let page = 1; page <= 50; page++) {
    const r = await mtFetch(
      `/api/contacts/byOrganization/${orgId}?page=${page}&pageSize=100`,
      { cookies },
    );
    if (!r.ok) break;
    const raw = (await r.json()) as Record<string, unknown>;
    const items = Array.isArray(raw.data)
      ? (raw.data as MTContact[])
      : Array.isArray(raw)
        ? (raw as MTContact[])
        : [];
    all.push(...items);
    if (items.length < 100) break;
  }
  if (all.length) contactsByOrg.set(orgId, { at: Date.now(), contacts: all });
  return all.length ? all : (cached?.contacts ?? []);
}

/** moduleId -> display name, cached for a few minutes (best-effort). */
async function getModuleNames(orgId: string): Promise<Map<string, string>> {
  const cached = moduleNamesByOrg.get(orgId);
  if (cached && Date.now() - cached.at < MODULE_TTL_MS) return cached.names;
  const cookies = autoCookies();
  const names = new Map<string, string>();
  if (cookies) {
    try {
      const r = await mtFetch(`/api/modules/byOrganization/${orgId}`, { cookies });
      if (r.ok) {
        const j = (await r.json()) as { data?: { id: string; name?: string }[] };
        for (const m of j.data ?? []) {
          if (m.id) names.set(String(m.id), m.name ?? String(m.id));
        }
      }
    } catch {
      /* best-effort */
    }
  }
  if (names.size) moduleNamesByOrg.set(orgId, { at: Date.now(), names });
  return names.size ? names : (cached?.names ?? names);
}

/** Short human summary of a module: its first text, URLs stripped. */
function summarizeBodies(bodies: string[]): string {
  const first = bodies.find((b) => b && b.trim());
  if (!first) return "";
  const cleaned = first
    .replace(/https?:\/\/\S+/g, "")
    .replace(/\s+/g, " ")
    .trim();
  return cleaned.length > 180 ? `${cleaned.slice(0, 177).trimEnd()}…` : cleaned;
}

/**
 * moduleId -> one-line note, fetched lazily per module (only the modules a
 * subscriber actually received) and cached for a few minutes.
 */
async function getModuleNotes(
  orgId: string,
  moduleIds: string[],
): Promise<Map<string, string>> {
  let entry = moduleNotesByOrg.get(orgId);
  if (!entry || Date.now() - entry.at > MODULE_TTL_MS) {
    entry = { at: Date.now(), notes: new Map() };
    moduleNotesByOrg.set(orgId, entry);
  }
  const cookies = autoCookies();
  if (!cookies) return entry.notes;
  const missing = moduleIds.filter((id) => !entry!.notes.has(id));
  await Promise.all(
    missing.map(async (id) => {
      try {
        const r = await mtFetch(`/api/modules/${id}`, { cookies });
        if (!r.ok) return;
        const j = (await r.json()) as Record<string, unknown>;
        const data = (j.data ?? j) as { texts?: unknown[] };
        entry!.notes.set(id, summarizeBodies(textBodies(data.texts)));
      } catch {
        /* best-effort */
      }
    }),
  );
  return entry.notes;
}

/** Words that mark a module title as a variant of another (e.g. sleep version). */
const VARIANT_WORDS = new Set([
  "sleep", "version", "edition", "variant", "copy", "night", "nighttime",
  "v2", "v3", "2", "3",
]);

/** Collapse variant markers so "Calm Reset" and "Calm Reset (Sleep Version)" group together. */
function normalizeModuleTitle(title: string): string {
  return title
    .toLowerCase()
    .replace(/\(.*?\)/g, " ")
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w && !VARIANT_WORDS.has(w))
    .join(" ")
    .trim();
}

export function registerPublicRoutes(app: Express) {
  // Read-only subscriber profile: topics, content received, and a library feed.
  app.get("/api/public/profile/:token", async (req, res) => {
    const token = req.params.token;
    const link = await getActivePageToken(token);
    if (!link) return res.status(404).json({ error: "Not found" });

    const orgId = link.organizationId;
    const contactId = link.contactId;

    let firstName = "";
    let topics: string[] = [];
    try {
      const contacts = await getOrgContacts(orgId);
      const me = contacts.find((c) => contactIdOf(c) === contactId);
      if (me) {
        firstName = typeof me.firstName === "string" ? me.firstName : "";
        topics = Array.isArray(me.tags)
          ? me.tags.filter((t) => typeof t === "string" && t.trim()).map(String)
          : [];
      }
    } catch {
      /* best-effort — page still renders with library content */
    }

    // One entry per module the subscriber received, with a short note and
    // variants (e.g. "…(Sleep Version)") collapsed into a single card.
    const received: {
      moduleId: string;
      title: string;
      note: string;
      sentAt: string | null;
      variantCount: number;
    }[] = [];
    try {
      const events = await listEvents(orgId, contactId, 100);
      const names = await getModuleNames(orgId);
      const seen = new Set<string>();
      const items: { moduleId: string; title: string; sentAt: string | null }[] = [];
      for (const e of events) {
        if (e.eventType !== "sent" || !e.moduleId || seen.has(e.moduleId)) continue;
        seen.add(e.moduleId);
        items.push({
          moduleId: e.moduleId,
          title: names.get(e.moduleId) ?? "A message you received",
          sentAt: e.createdAt ? new Date(e.createdAt).toISOString() : null,
        });
      }
      const notes = await getModuleNotes(orgId, items.map((i) => i.moduleId));
      const groups = new Map<string, typeof items>();
      for (const item of items) {
        const key = normalizeModuleTitle(item.title) || item.moduleId;
        const group = groups.get(key);
        if (group) group.push(item);
        else groups.set(key, [item]);
      }
      for (const group of Array.from(groups.values())) {
        // Shortest title is usually the base name (variants add suffixes).
        const display = group.reduce((a, b) => (b.title.length < a.title.length ? b : a));
        const latest = group.reduce((a, b) =>
          (b.sentAt ?? "") > (a.sentAt ?? "") ? b : a,
        );
        const note = group.map((g) => notes.get(g.moduleId) ?? "").find(Boolean) ?? "";
        received.push({
          moduleId: display.moduleId,
          title: display.title,
          note,
          sentAt: latest.sentAt,
          variantCount: group.length,
        });
      }
      received.sort((a, b) => (b.sentAt ?? "").localeCompare(a.sentAt ?? ""));
    } catch {
      /* best-effort */
    }

    // Meditation library: published link items only, topic matches first.
    let library: {
      id: number;
      title: string;
      body: string;
      topic: string | null;
      theme: string | null;
      complexity: string | null;
      url: string | null;
    }[] = [];
    try {
      const all = await listPublishedContent(orgId, { onlyPublished: true });
      const topicSet = new Set(topics.map((t) => t.toLowerCase()));
      const meditations = all.filter((p) => p.contentType === "meditation" && p.url);
      meditations.sort((a, b) => {
        const am = a.topic && topicSet.has(a.topic.toLowerCase()) ? 1 : 0;
        const bm = b.topic && topicSet.has(b.topic.toLowerCase()) ? 1 : 0;
        return bm - am; // stable: recency order preserved within each bucket
      });
      library = meditations.slice(0, 500).map((p) => ({
        id: p.id,
        title: p.title,
        body: p.body,
        topic: p.topic ?? null,
        theme: p.theme ?? null,
        complexity: p.complexity ?? null,
        url: p.url ?? null,
      }));
    } catch {
      /* best-effort */
    }

    const { organizationId: _o, ...defaults } = defaultPageSettings();
    let settings: Record<string, unknown> = defaults;
    try {
      const saved = await getPageSettings(orgId);
      if (saved) {
        const { id, createdAt, updatedAt, organizationId, ...rest } = saved;
        settings = rest;
      }
    } catch {
      /* best-effort — fall back to defaults */
    }

    let personalNote: string | null = null;
    try {
      const profile = await getExistingContactProfile(orgId, contactId);
      personalNote = profile?.pageNote ?? null;
    } catch {
      /* best-effort */
    }

    res.json({ firstName, topics, received, library, settings, personalNote });
  });

  // Append-only page-view log (analytics only — not a subscriber/MT mutation).
  app.post("/api/public/profile/:token/view", async (req, res) => {
    const token = req.params.token;
    const link = await getActivePageToken(token);
    if (!link) return res.status(404).json({ error: "Not found" });

    const body = (req.body ?? {}) as { eventType?: unknown; path?: unknown };
    // Public endpoint: constrain what callers can write into the event log.
    const ALLOWED_EVENT_TYPES = new Set(["view", "content_open"]);
    const eventType =
      typeof body.eventType === "string" && ALLOWED_EVENT_TYPES.has(body.eventType)
        ? body.eventType
        : "view";
    const path =
      typeof body.path === "string" ? body.path.slice(0, 500) : null;
    try {
      await Promise.all([
        recordPageEvent({
          organizationId: link.organizationId,
          contactId: link.contactId,
          token,
          eventType,
          path,
          userAgent: (req.headers["user-agent"] as string) ?? null,
        }),
        touchPageTokenVisit(token),
      ]);
    } catch {
      /* analytics is best-effort; never fail the page */
    }
    res.json({ ok: true });
  });
}
