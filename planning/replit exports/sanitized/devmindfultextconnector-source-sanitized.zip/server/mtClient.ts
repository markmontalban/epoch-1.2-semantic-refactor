/**
 * Centralized MindfulText HTTP client.
 *
 * One place that owns the base URL, standard headers, a request timeout that
 * aborts hung sockets (so a slow upstream can't stall the Node event loop),
 * and `{ data }` response unwrapping. Server-side callers should use this
 * instead of constructing bare `fetch` calls to dev.mindfultext.com.
 *
 * Scope note: this intentionally covers timeouts + unwrapping only. Retries,
 * circuit breaking, and schema validation are tracked separately.
 */
const BASE_URL = "https://dev.mindfultext.com";

/** Request timeout in ms. Override with MT_TIMEOUT_MS. */
const DEFAULT_TIMEOUT_MS = (() => {
  const raw = parseInt(process.env.MT_TIMEOUT_MS || "", 10);
  return Number.isFinite(raw) && raw > 0 ? raw : 15_000;
})();

export interface MtFetchOptions {
  method?: string;
  /** Extra headers merged over the defaults (Accept + User-Agent). */
  headers?: Record<string, string>;
  body?: string;
  /** MindfulText session cookie string, set as the `Cookie` header. */
  cookies?: string;
  redirect?: RequestRedirect;
  /** Per-call timeout override in ms. */
  timeoutMs?: number;
}

/**
 * Fetch a MindfulText endpoint with a timeout and the standard headers.
 * `path` may be an absolute URL or a path beginning with `/`.
 * Throws on network error or timeout (the AbortError surfaces as a throw).
 */
export async function mtFetch(path: string, opts: MtFetchOptions = {}): Promise<Response> {
  const url = path.startsWith("http") ? path : `${BASE_URL}${path}`;
  const headers: Record<string, string> = {
    Accept: "application/json",
    "User-Agent": "MindfulText-CustomFrontend/1.0",
    ...opts.headers,
  };
  if (opts.cookies) headers.Cookie = opts.cookies;

  return fetch(url, {
    method: opts.method ?? "GET",
    headers,
    body: opts.body,
    redirect: opts.redirect,
    signal: AbortSignal.timeout(opts.timeoutMs ?? DEFAULT_TIMEOUT_MS),
  });
}

/**
 * Fetch JSON and unwrap a `{ data }` envelope when present. Returns `null` on
 * a non-2xx response or any transport/parse failure, matching the existing
 * fall-back-friendly call sites.
 */
export async function mtFetchJson<T = unknown>(
  path: string,
  opts: MtFetchOptions = {},
): Promise<T | null> {
  try {
    const res = await mtFetch(path, opts);
    if (!res.ok) return null;
    const json = (await res.json()) as unknown;
    if (json && typeof json === "object" && "data" in json) {
      return (json as { data: T }).data;
    }
    return json as T;
  } catch {
    return null;
  }
}
