/**
 * Inbound reply processing — shared by the HTTP intake route and the
 * MindfulText messages-feed poller.
 */
import { mtFetch } from "./mtClient";
import { AUTO_SESSION_ID, sessionStore } from "./session";
import { getConfiguredOrgId } from "./orgSettings";
import {
  createInboundMessage,
  createDraftMessage,
  findPriorAdvancedEvent,
  setInboundAttribution,
  recordMessageEvent,
  isMtMessageIdKnown,
} from "./storage";
import type { InboundMessage, DraftMessage } from "../shared/schema";
import { generateDraftReply } from "./ai";
import { bootstrapJourneyForContact } from "./personalJourney";
import { evaluateRules, dispatchProposal } from "./reshape";
import { recordContactActivity } from "./contactMemory";

/** Matches STOP/opt-out replies — skip draft + reshape for these. */
export function isOptOut(content: string): boolean {
  return /^\s*(stop|stopall|unsubscribe|cancel|end|quit|remove me)\b/i.test(content.trim());
}

function toUnixSec(v: unknown): number | null {
  if (typeof v !== "number" || !Number.isFinite(v)) return null;
  return v < 1e12 ? v : Math.round(v / 1000);
}

export interface ProcessInboundReplyOpts {
  organizationId: string;
  contactId?: string | null;
  contactPhone?: string | null;
  content: string;
  contactTags?: string[];
  mtMessageId?: string;
  mtModuleId?: string | null;
  occurredAt?: Date;
  storedCookies?: string;
  metadata?: Record<string, unknown> | null;
  /** Skip AI draft generation (defaults true for STOP messages). */
  skipDraft?: boolean;
  /** Skip reshape rule evaluation (defaults true for STOP messages). */
  skipReshape?: boolean;
  /** Source tag stored on message_events rows. */
  eventSource?: "webhook" | "poll" | "manual";
}

export interface ProcessInboundReplyResult {
  skipped?: boolean;
  reason?: string;
  inbound?: InboundMessage;
  draftReply?: DraftMessage | null;
  reshape: { applied: number[]; pending: number[] };
  tokenUsage?: {
    model: string;
    totalTokens: number;
    estimatedCostUsd: number;
  };
}

export async function processInboundReply(
  opts: ProcessInboundReplyOpts,
): Promise<ProcessInboundReplyResult> {
  const reshapeOutcome: { applied: number[]; pending: number[] } = {
    applied: [],
    pending: [],
  };

  if (opts.mtMessageId) {
    const dup = await isMtMessageIdKnown(opts.organizationId, opts.mtMessageId);
    if (dup) {
      return { skipped: true, reason: "duplicate", reshape: reshapeOutcome };
    }
  }

  const isStop = isOptOut(opts.content);
  const skipDraft = opts.skipDraft ?? isStop;
  const skipReshape = opts.skipReshape ?? isStop;

  const metadata: Record<string, unknown> = {
    ...(opts.metadata ?? {}),
    ...(opts.mtMessageId ? { mtMessageId: opts.mtMessageId } : {}),
  };

  const inbound = await createInboundMessage({
    organizationId: opts.organizationId,
    contactId: opts.contactId ?? undefined,
    contactPhone: opts.contactPhone ?? undefined,
    content: opts.content,
    draftGenerated: !skipDraft,
    metadata,
    receivedAt: opts.occurredAt,
  });

  // Module attribution — prefer feed moduleId when present, else prior advanced event.
  if (opts.contactId) {
    try {
      if (opts.mtModuleId) {
        await setInboundAttribution(inbound.id, {
          moduleId: opts.mtModuleId,
          attributionSource: "poll",
          metadata: {
            ...metadata,
            feedModuleId: opts.mtModuleId,
          },
        });
        inbound.moduleId = opts.mtModuleId;
        inbound.attributionSource = "poll";
      } else {
        const receivedAt = opts.occurredAt ?? inbound.receivedAt ?? new Date();
        const prior = await findPriorAdvancedEvent(
          opts.organizationId,
          opts.contactId,
          receivedAt,
        );
        if (prior?.moduleId) {
          const ageMs =
            receivedAt.getTime() - (prior.createdAt?.getTime() ?? receivedAt.getTime());
          await setInboundAttribution(inbound.id, {
            moduleId: prior.moduleId,
            attributionSource: "prior_send",
            metadata: {
              ...metadata,
              priorSendEventId: prior.id,
              priorSendAgeMs: ageMs,
            },
          });
          inbound.moduleId = prior.moduleId;
          inbound.attributionSource = "prior_send";
        } else {
          await setInboundAttribution(inbound.id, {
            moduleId: null,
            attributionSource: "none",
          });
          inbound.attributionSource = "none";
        }
      }
    } catch (err) {
      console.warn(
        "[inbound] attribution failed:",
        err instanceof Error ? err.message : err,
      );
    }
  }

  // Live reply row for analytics dashboards.
  try {
    await recordMessageEvent({
      organizationId: opts.organizationId,
      direction: "reply",
      contactId: opts.contactId ?? null,
      contactPhone: opts.contactPhone ?? null,
      moduleId: inbound.moduleId ?? opts.mtModuleId ?? null,
      content: opts.content,
      source: opts.eventSource ?? (opts.mtMessageId ? "poll" : "webhook"),
      occurredAt: opts.occurredAt ?? inbound.receivedAt ?? undefined,
    });
  } catch (err) {
    console.warn(
      "[inbound] message_events write failed:",
      err instanceof Error ? err.message : err,
    );
  }

  let draftReply: DraftMessage | null = null;
  let tokenUsage: ProcessInboundReplyResult["tokenUsage"];

  if (!skipDraft) {
    const aiResult = await generateDraftReply({
      organizationId: opts.organizationId,
      inboundContent: opts.content,
      contactId: opts.contactId ?? undefined,
      contactPhone: opts.contactPhone ?? undefined,
    });

    draftReply = await createDraftMessage({
      organizationId: opts.organizationId,
      contactId: opts.contactId ?? undefined,
      contactPhone: opts.contactPhone ?? undefined,
      inboundMessageId: inbound.id,
      draftContent: aiResult.content.replace(/^["']|["']$/g, ""),
      status: "generated",
      aiModel: aiResult.model,
      metadata: {
        tokens: aiResult.totalTokens,
        costUsd: aiResult.estimatedCostUsd,
      },
    });

    tokenUsage = {
      model: aiResult.model,
      totalTokens: aiResult.totalTokens,
      estimatedCostUsd: aiResult.estimatedCostUsd,
    };
  }

  if (opts.contactId && !skipReshape) {
    try {
      const journey = await bootstrapJourneyForContact(
        opts.organizationId,
        opts.contactId,
        opts.contactTags ?? [],
      );
      const proposals = await evaluateRules({
        organizationId: opts.organizationId,
        contactId: opts.contactId,
        inboundContent: opts.content,
        currentJourney: journey,
      });
      for (const p of proposals) {
        const result = await dispatchProposal({
          organizationId: opts.organizationId,
          contactId: opts.contactId,
          inboundMessageId: inbound.id,
          proposal: p,
          storedCookies: opts.storedCookies,
        });
        if (result.kind === "applied") reshapeOutcome.applied.push(result.ruleId);
        else reshapeOutcome.pending.push(result.pendingId);
      }
    } catch (err) {
      console.warn(
        "[inbound] reshape evaluation failed:",
        err instanceof Error ? err.message : err,
      );
    }

    try {
      await recordContactActivity({
        organizationId: opts.organizationId,
        contactId: opts.contactId,
        note: `replied: "${opts.content.substring(0, 200)}"`,
        storedCookies: opts.storedCookies,
      });
    } catch (err) {
      console.warn(
        "[inbound] memory write failed:",
        err instanceof Error ? err.message : err,
      );
    }
  }

  return { inbound, draftReply, reshape: reshapeOutcome, tokenUsage };
}

export interface PollInboundResult {
  processed: number;
  skipped: number;
  duplicates: number;
  errors: number;
}

/** Poll MindfulText's org messages feed for new inbound replies. */
export async function pollInboundReplies(orgIdArg?: string): Promise<PollInboundResult> {
  const organizationId = orgIdArg || getConfiguredOrgId();
  const cookies = sessionStore[AUTO_SESSION_ID] || "";
  if (!organizationId || !cookies) {
    return { processed: 0, skipped: 0, duplicates: 0, errors: 0 };
  }

  const res = await mtFetch(`/api/messages/byOrganization/${organizationId}`, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "User-Agent": "MindfulText-CustomFrontend/1.0",
      Cookie: cookies,
    },
  });
  if (!res.ok) {
    throw new Error(`MindfulText messages feed returned ${res.status}`);
  }

  const raw = (await res.json()) as Record<string, unknown> | unknown[];
  const feed: Record<string, unknown>[] = Array.isArray(raw)
    ? (raw as Record<string, unknown>[])
    : Array.isArray((raw as { data?: unknown[] }).data)
      ? ((raw as { data: Record<string, unknown>[] }).data)
      : [];

  const inboundRows = feed
    .filter((m) => m.outbound === false)
    .sort((a, b) => (toUnixSec(a.createdAt) ?? 0) - (toUnixSec(b.createdAt) ?? 0));

  let processed = 0;
  let skipped = 0;
  let duplicates = 0;
  let errors = 0;

  for (const m of inboundRows) {
    const mtMessageId = m.id != null ? String(m.id) : "";
    const content = typeof m.content === "string" ? m.content : "";
    const contactId = m.contactID != null ? String(m.contactID) : undefined;
    const contactPhone =
      typeof m.phoneNumber === "string"
        ? m.phoneNumber
        : typeof m.phone === "string"
          ? m.phone
          : undefined;

    if (!mtMessageId) {
      skipped += 1;
      continue;
    }

    if (!content.trim()) {
      skipped += 1;
      continue;
    }

    const sec = toUnixSec(m.createdAt);
    const moduleId =
      m.moduleID != null && m.moduleID !== "" ? String(m.moduleID) : null;

    try {
      const result = await processInboundReply({
        organizationId,
        contactId,
        contactPhone,
        content,
        mtMessageId,
        mtModuleId: moduleId,
        occurredAt: sec ? new Date(sec * 1000) : undefined,
        storedCookies: cookies,
        eventSource: "poll",
      });

      if (result.skipped) duplicates += 1;
      else processed += 1;
    } catch (err) {
      errors += 1;
      console.warn(
        `[inbound-poll] failed for mtMessageId=${mtMessageId}:`,
        err instanceof Error ? err.message : err,
      );
    }
  }

  if (processed > 0) {
    console.log(
      `[inbound-poll] org ${organizationId}: processed=${processed} duplicates=${duplicates} skipped=${skipped} errors=${errors}`,
    );
  }

  return { processed, skipped, duplicates, errors };
}
