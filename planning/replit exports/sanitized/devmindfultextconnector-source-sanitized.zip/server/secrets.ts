import crypto from "crypto";

// Encryption-at-rest for sensitive values persisted to disk (currently the
// MindfulText password in `.org-settings.json`). Uses AES-256-GCM with a key
// derived from a server-side secret so reading the file alone no longer yields
// the cleartext password.
//
// Key precedence:
//   1. `SETTINGS_ENCRYPTION_KEY` env var (required for production).
//   2. `SESSION_SECRET` env var (existing server-side secret) as a fallback.
//   3. A built-in dev key (logged loudly). NEVER for production — anyone who
//      reads this source can decrypt the file.
//
// Ciphertext format (string, so it round-trips JSON cleanly):
//   `enc:v1:<base64 iv>:<base64 tag>:<base64 ciphertext>`
// Anything not matching that prefix is treated as legacy plaintext and will be
// re-encrypted on the next save (migration path).

const VERSION_PREFIX = "enc:v1:";
const DEV_KEY_MATERIAL = "mindfultext-dev-only-encryption-key-do-not-use-in-prod";

let cachedKey: Buffer | null = null;
let warnedAboutDevKey = false;
let warnedAboutDecryptFailure = false;

function getKeyMaterial(): { material: string; source: "env" | "session" | "dev" } {
  const env = process.env.SETTINGS_ENCRYPTION_KEY;
  if (env && env.length >= 16) return { material: env, source: "env" };
  const session = process.env.SESSION_SECRET;
  if (session && session.length >= 16) return { material: session, source: "session" };
  return { material: DEV_KEY_MATERIAL, source: "dev" };
}

function getKey(): Buffer {
  if (cachedKey) return cachedKey;
  const { material, source } = getKeyMaterial();
  if (source === "dev" && !warnedAboutDevKey) {
    warnedAboutDevKey = true;
    console.warn(
      "[secrets] SETTINGS_ENCRYPTION_KEY (and SESSION_SECRET) are not set — " +
        "falling back to a built-in dev key. Stored credentials are NOT safe " +
        "from anyone with source-code access. Set SETTINGS_ENCRYPTION_KEY in " +
        "production.",
    );
  }
  // Static salt is fine: the secret is the env var, not the salt. scryptSync
  // gives us a 32-byte key suitable for AES-256.
  cachedKey = crypto.scryptSync(material, "mindfultext-settings-salt-v1", 32);
  return cachedKey;
}

export function encryptSecret(plaintext: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", getKey(), iv);
  const ct = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return (
    VERSION_PREFIX +
    iv.toString("base64") + ":" +
    tag.toString("base64") + ":" +
    ct.toString("base64")
  );
}

// Returns the cleartext, or `null` if `stored` looks encrypted but cannot be
// decrypted (wrong key, corruption, etc.). Legacy plaintext values (anything
// without the version prefix) are returned as-is so existing `.org-settings.json`
// files keep working until the next save rewrites them encrypted.
export function decryptSecret(stored: string): string | null {
  if (!stored.startsWith(VERSION_PREFIX)) return stored;
  const parts = stored.slice(VERSION_PREFIX.length).split(":");
  if (parts.length !== 3) return null;
  try {
    const iv = Buffer.from(parts[0], "base64");
    const tag = Buffer.from(parts[1], "base64");
    const ct = Buffer.from(parts[2], "base64");
    const decipher = crypto.createDecipheriv("aes-256-gcm", getKey(), iv);
    decipher.setAuthTag(tag);
    const pt = Buffer.concat([decipher.update(ct), decipher.final()]);
    return pt.toString("utf8");
  } catch (e) {
    if (!warnedAboutDecryptFailure) {
      warnedAboutDecryptFailure = true;
      console.warn(
        "[secrets] Failed to decrypt a stored secret — the encryption key " +
          "likely changed. The user will need to re-enter their MindfulText " +
          "credentials in Settings. (" +
          (e instanceof Error ? e.message : String(e)) +
          ")",
      );
    }
    return null;
  }
}

export function isEncrypted(stored: string): boolean {
  return stored.startsWith(VERSION_PREFIX);
}
