import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "../shared/schema";

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL is required. Provision a PostgreSQL database and set the connection string.",
  );
}

const { Pool } = pg;

export const db = drizzle({
  client: new Pool({ connectionString: process.env.DATABASE_URL }),
  schema,
});
