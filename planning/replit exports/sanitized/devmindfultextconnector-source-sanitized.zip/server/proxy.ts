/**
 * MindfulText session-cookie proxy.
 *
 * Forwards `/api/proxy/mindfultext/*` requests to dev.mindfultext.com using the
 * caller's stored session cookies, rewrites org-bearing path/body positions to
 * the configured org (single-user safety), captures Set-Cookie updates, and
 * enforces agent-safe mode on mutating upstream calls.
 */
import type { Express } from "express";
import { getConfiguredOrgId } from "./orgSettings";
import { mtFetch } from "./mtClient";
import {
  AUTO_SESSION_ID,
  sessionStore,
  saveSessionStore,
  extractSessionId,
} from "./session";
import {
  AGENT_SAFE_MODE,
  PROXY_STRICT_AUTH,
  consumeConfirmToken,
  isGuardedUpstreamMutation,
} from "./agentSafety";

export function registerProxyRoutes(app: Express): void {
  app.all("/api/proxy/mindfultext/*", async (req, res) => {
    try {
      let targetPath = req.path.replace("/api/proxy/mindfultext", "");
      // Single-user mode: rewrite well-known org-bearing path positions to
      // the configured org id so a stale client (e.g. an old tab whose
      // localStorage still has the previous org id) cannot reach a different
      // MindfulText organization. Detail/entity-id positions are left alone
      // because we can't safely tell entity ids from org ids in those slots.
      const configuredOrg = getConfiguredOrgId();
      const before = targetPath;
      // Unambiguously org-scoped patterns are always rewritten:
      //   /byOrganization/<id>, /launch/<id>, /api/<resource>/<id>/search
      targetPath = targetPath
        .replace(/\/byOrganization\/[^\/?]+/g, `/byOrganization/${configuredOrg}`)
        .replace(/\/launch\/[^\/?]+/g, `/launch/${configuredOrg}`)
        .replace(/^\/api\/([^\/?]+)\/[^\/?]+\/search$/g, `/api/$1/${configuredOrg}/search`);
      // /api/<resource>/<id> is ambiguous between "create with orgId" (POST)
      // and "detail by entityId" (GET/PUT/DELETE). For known org-scoped
      // create routes we rewrite only on POST so detail/update flows that
      // legitimately use entity ids are left untouched.
      const ORG_SCOPED_CREATE_RESOURCES = new Set([
        "contacts", "journeys", "modules", "messages", "subscriptions",
        "integrations", "actions", "teamMembers", "audiences",
      ]);
      if (req.method === "POST") {
        targetPath = targetPath.replace(
          /^\/api\/([^\/?]+)\/([^\/?]+)$/,
          (full, resource: string) => {
            if (!ORG_SCOPED_CREATE_RESOURCES.has(resource)) return full;
            return `/api/${resource}/${configuredOrg}`;
          },
        );
      }
      if (before !== targetPath) {
        console.warn(`[proxy] rewrote org-bearing path "${before}" → "${targetPath}" (configured ${configuredOrg})`);
      }
      // Also normalize any organizationId / organizationID in JSON request
      // bodies to the configured value before forwarding (MindfulText uses
      // both casings depending on endpoint).
      if (req.body && typeof req.body === "object" && !Array.isArray(req.body)) {
        const bodyObj = req.body as Record<string, unknown>;
        for (const key of ["organizationId", "organizationID"] as const) {
          const bo = bodyObj[key];
          if (bo === undefined || bo === null || bo === "") continue;
          if (String(bo).padStart(8, "0") !== configuredOrg) {
            console.warn(`[proxy] rewrote body.${key} ${String(bo)} → ${configuredOrg}`);
            bodyObj[key] = configuredOrg;
          }
        }
      }
      const targetUrl = `https://dev.mindfultext.com${targetPath}`;
      const incomingContentType = req.headers["content-type"] || "";

      let body: string | undefined;
      if (req.method !== "GET" && req.method !== "HEAD") {
        if (
          incomingContentType.includes("application/x-www-form-urlencoded")
        ) {
          body = new URLSearchParams(
            req.body as Record<string, string>,
          ).toString();
        } else if (incomingContentType.includes("application/json")) {
          body = JSON.stringify(req.body);
        }
      }

      const sessionId = extractSessionId(req);
      const storedCookies = sessionStore[sessionId] || "";

      const isInteractiveSession =
        sessionId !== AUTO_SESSION_ID && !!sessionStore[sessionId];

      // Phase 2 (opt-in via PROXY_STRICT_AUTH): require an interactive operator
      // session or a one-time confirm token for ALL proxy traffic, not just
      // mutations. Off by default so the founder's normal browsing is untouched.
      if (PROXY_STRICT_AUTH && !isInteractiveSession) {
        const confirmHeader = req.headers["x-operator-confirm"] as string | undefined;
        if (!consumeConfirmToken(confirmHeader)) {
          console.warn(
            `[proxy-strict] blocked ${req.method} ${targetPath} — no interactive session or confirm token`,
          );
          return res.status(403).json({
            error: "proxy_strict_auth",
            message:
              "Blocked by strict proxy auth: this request needs an operator session or a one-time confirm token.",
          });
        }
      }

      // Agent-safe mode: sends (subscription launches) and module/journey edits
      // forwarded to MindfulText must come from an interactive operator session
      // (the browser UI) or carry a one-time confirm token the operator issued.
      // This blocks agents, scripts, and webhooks from mutating without
      // approval, while leaving normal UI requests untouched.
      if (AGENT_SAFE_MODE && isGuardedUpstreamMutation(req.method, targetPath)) {
        const confirmHeader = req.headers["x-operator-confirm"] as string | undefined;
        const approved = isInteractiveSession || consumeConfirmToken(confirmHeader);
        if (!approved) {
          console.warn(
            `[agent-safe] blocked ${req.method} ${targetPath} — needs an operator session or confirm token`,
          );
          return res.status(403).json({
            error: "agent_safe_mode",
            message:
              "Blocked by agent-safe mode: sending messages and editing modules/journeys requires an operator session or a one-time confirm token.",
          });
        }
      }

      const headers: Record<string, string> = {
        Accept: "application/json",
        "User-Agent": "MindfulText-CustomFrontend/1.0",
      };
      if (incomingContentType) headers["Content-Type"] = incomingContentType;
      if (req.headers.authorization)
        headers.Authorization = req.headers.authorization as string;
      if (storedCookies) headers.Cookie = storedCookies;
      else if (req.headers.cookie)
        headers.Cookie = req.headers.cookie as string;

      console.log(
        `[PROXY] ${req.method} → ${targetUrl} (session: ${sessionId.substring(0, 8)}… cookies: ${storedCookies ? "yes" : "no"})`,
      );

      const response = await mtFetch(targetUrl, {
        method: req.method,
        headers,
        body,
        redirect: "manual",
      });

      const responseContentType =
        response.headers.get("content-type") || "";
      const payload = responseContentType.includes("application/json")
        ? await response.json()
        : await response.text();

      console.log(
        `[PROXY] ${req.method} ${targetPath} → ${response.status} ${
          typeof payload === "object"
            ? JSON.stringify(payload).substring(0, 200)
            : String(payload).substring(0, 200)
        }`,
      );

      const setCookieHeaders = response.headers.getSetCookie?.() || [];
      if (setCookieHeaders.length > 0) {
        const cookieMap = new Map<string, string>();
        for (const cookie of storedCookies
          ? storedCookies.split("; ")
          : []) {
          const [name] = cookie.split("=");
          if (name) cookieMap.set(name, cookie);
        }
        for (const raw of setCookieHeaders) {
          const nameValue = raw.split(";")[0].trim();
          const [name] = nameValue.split("=");
          if (name && nameValue) cookieMap.set(name, nameValue);
        }
        sessionStore[sessionId] = Array.from(cookieMap.values()).join("; ");
        saveSessionStore(sessionStore);
        console.log(
          `[PROXY] Stored ${setCookieHeaders.length} cookie(s) for session ${sessionId.substring(0, 8)}…`,
        );
      }

      res.status(response.status);
      if (responseContentType)
        res.set("Content-Type", responseContentType);
      if (responseContentType.includes("application/json")) res.json(payload);
      else res.send(payload);
    } catch (error) {
      res.status(500).json({
        error: "Proxy error",
        message: error instanceof Error ? error.message : "Unknown error",
        target: req.path,
      });
    }
  });
}
