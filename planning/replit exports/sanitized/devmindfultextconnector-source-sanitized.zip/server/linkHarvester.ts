/**
 * Link harvester — pulls every MindfulText module's texts through the proxy,
 * extracts the URLs inside them, and stages them (with module/day context and
 * a likely-meditation guess) for founder review on the Library screen.
 *
 * Read-only with respect to MindfulText: only GET requests, using the same
 * session cookies the dashboard already holds.
 */
import { mtFetch } from "./mtClient";
import { insertHarvestedLinks } from "./storage";
import type { InsertHarvestedLink } from "../shared/schema";

type MTModule = {
  id?: string;
  _id?: string;
  moduleID?: string;
  name?: string;
  texts?: unknown[];
  [k: string]: unknown;
};

const URL_RE = /https?:\/\/[^\s<>"'\])]+/gi;

/** Words that make a link look like a meditation (URL slug or nearby text). */
const MEDITATION_HINTS = [
  "meditation", "meditat", "mindful", "guided", "body-scan", "bodyscan",
  "body scan", "breathwork", "breathing", "breath", "relax", "calm",
  "sleep", "yoga-nidra", "nidra", "visualization", "visualisation", "grounding",
];

/** Links that are almost certainly NOT library content. */
const NON_CONTENT_HINTS = [
  "unsubscribe", "privacy", "terms", "facebook.com", "instagram.com",
  "twitter.com", "x.com/", "linkedin.com", "tiktok.com", "calendly.",
  "zoom.us", "forms.", "surveymonkey", "typeform", "maps.google",
  "goo.gl/maps", "mailto:", "login", "signin", "sign-up", "signup",
];

const THEME_KEYWORDS: Array<[theme: string, words: string[]]> = [
  ["sleep", ["sleep", "insomnia", "bedtime", "night", "nidra"]],
  ["stress", ["stress", "anxiety", "anxious", "worry", "overwhelm"]],
  ["focus", ["focus", "concentration", "attention", "clarity"]],
  ["gratitude", ["gratitude", "grateful", "thankful"]],
  ["breathing", ["breath", "breathing", "breathwork"]],
  ["calm", ["calm", "relax", "grounding", "soothe"]],
  ["morning", ["morning", "wake", "sunrise", "start your day"]],
];

function moduleIdOf(m: MTModule): string | null {
  return (m.id ?? m._id ?? m.moduleID ?? null) as string | null;
}

/** Pull SMS bodies out of the various shapes module texts arrive in. */
export function textBodies(texts: unknown[] | undefined): string[] {
  if (!Array.isArray(texts)) return [];
  return texts.map((t) => {
    if (typeof t === "string") return t;
    if (t && typeof t === "object") {
      const r = t as Record<string, unknown>;
      for (const key of ["body", "text", "message", "content"]) {
        if (typeof r[key] === "string") return r[key] as string;
      }
    }
    return "";
  });
}

/** Trim trailing punctuation a regex match tends to swallow. */
function cleanUrl(raw: string): string {
  let url = raw.trim();
  while (/[.,;:!?)\]'"»]$/.test(url)) url = url.slice(0, -1);
  // Lowercase scheme + host only (paths can be case-sensitive).
  try {
    const u = new URL(url);
    return `${u.protocol.toLowerCase()}//${u.host.toLowerCase()}${u.pathname}${u.search}${u.hash}`;
  } catch {
    return url;
  }
}

/** ~240-char window of the text centered on the URL, for review context. */
function contextAround(text: string, url: string): string {
  const idx = text.indexOf(url);
  const at = idx >= 0 ? idx : 0;
  const start = Math.max(0, at - 120);
  const end = Math.min(text.length, at + url.length + 120);
  let snippet = text.slice(start, end).replace(/\s+/g, " ").trim();
  if (start > 0) snippet = `…${snippet}`;
  if (end < text.length) snippet = `${snippet}…`;
  return snippet;
}

function hasAny(haystack: string, needles: string[]): boolean {
  return needles.some((n) => haystack.includes(n));
}

export function classifyLink(url: string, context: string): {
  likelyMeditation: boolean;
  suggestedTheme: string | null;
} {
  const lower = `${url} ${context}`.toLowerCase();
  if (hasAny(url.toLowerCase(), NON_CONTENT_HINTS)) {
    return { likelyMeditation: false, suggestedTheme: null };
  }
  const likelyMeditation = hasAny(lower, MEDITATION_HINTS);
  let suggestedTheme: string | null = null;
  for (const [theme, words] of THEME_KEYWORDS) {
    if (hasAny(lower, words)) {
      suggestedTheme = theme;
      break;
    }
  }
  return { likelyMeditation, suggestedTheme };
}

/** Human title guess from the URL slug, falling back to module + day. */
export function titleFromUrl(
  url: string,
  moduleName: string | null,
  dayIndex: number | null,
): string {
  try {
    const u = new URL(url);
    const segments = u.pathname.split("/").filter(Boolean);
    const slug = segments[segments.length - 1] ?? "";
    const bare = decodeURIComponent(slug)
      .replace(/\.(html?|php|aspx?|mp3|mp4|m4a|wav|ogg|pdf)$/i, "")
      .replace(/[-_+]+/g, " ")
      .trim();
    // Slugs that are just ids/numbers aren't titles.
    if (bare.length >= 4 && /[a-z]/i.test(bare)) {
      return bare
        .split(" ")
        .filter(Boolean)
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
        .join(" ");
    }
  } catch {
    /* fall through */
  }
  if (moduleName && dayIndex) return `${moduleName} — Day ${dayIndex}`;
  return moduleName ?? url;
}

export interface HarvestSummary {
  modulesScanned: number;
  modulesFailed: number;
  urlsFound: number;
  newStaged: number;
  alreadyKnown: number;
}

async function fetchModuleList(orgId: string, cookies: string): Promise<MTModule[]> {
  const r = await mtFetch(`/api/modules/byOrganization/${orgId}`, { cookies });
  if (!r.ok) throw new Error(`Module list failed (${r.status})`);
  const j = (await r.json()) as Record<string, unknown>;
  return Array.isArray(j.data) ? (j.data as MTModule[]) : Array.isArray(j) ? (j as MTModule[]) : [];
}

async function fetchModuleDetail(moduleId: string, cookies: string): Promise<MTModule | null> {
  const r = await mtFetch(`/api/modules/${moduleId}`, { cookies });
  if (!r.ok) return null;
  const j = (await r.json()) as Record<string, unknown>;
  const data = (j.data ?? j) as MTModule;
  return data && typeof data === "object" ? data : null;
}

/**
 * Scan all modules for URLs and stage new ones for review.
 * Links already harvested (any status) are skipped by the org+url unique index,
 * so re-running is safe and cheap.
 */
export async function harvestModuleLinks(
  orgId: string,
  cookies: string,
): Promise<HarvestSummary> {
  const list = await fetchModuleList(orgId, cookies);
  const summary: HarvestSummary = {
    modulesScanned: 0,
    modulesFailed: 0,
    urlsFound: 0,
    newStaged: 0,
    alreadyKnown: 0,
  };

  // url -> candidate row (first occurrence wins within a run)
  const candidates = new Map<string, InsertHarvestedLink>();

  const CONCURRENCY = 5;
  for (let i = 0; i < list.length; i += CONCURRENCY) {
    const batch = list.slice(i, i + CONCURRENCY);
    await Promise.all(
      batch.map(async (listed) => {
        const moduleId = moduleIdOf(listed);
        if (!moduleId) return;
        try {
          // The list payload sometimes already carries texts; use it if so.
          let mod: MTModule | null = Array.isArray(listed.texts) && listed.texts.length > 0
            ? listed
            : await fetchModuleDetail(moduleId, cookies);
          if (!mod) {
            summary.modulesFailed++;
            return;
          }
          summary.modulesScanned++;
          const name = typeof mod.name === "string" ? mod.name : (typeof listed.name === "string" ? listed.name : null);
          const bodies = textBodies(mod.texts);
          bodies.forEach((body, idx) => {
            if (!body) return;
            for (const match of body.match(URL_RE) ?? []) {
              const url = cleanUrl(match);
              if (!url || candidates.has(url)) {
                if (url) summary.urlsFound++;
                continue;
              }
              summary.urlsFound++;
              const context = contextAround(body, match);
              const { likelyMeditation, suggestedTheme } = classifyLink(url, context);
              candidates.set(url, {
                organizationId: orgId,
                url,
                moduleId,
                moduleName: name,
                dayIndex: idx + 1,
                context,
                likelyMeditation,
                suggestedTitle: titleFromUrl(url, name, idx + 1),
                suggestedTheme,
                status: "staged",
              });
            }
          });
        } catch {
          summary.modulesFailed++;
        }
      }),
    );
  }

  const inserted = await insertHarvestedLinks(Array.from(candidates.values()));
  summary.newStaged = inserted.length;
  summary.alreadyKnown = candidates.size - inserted.length;
  return summary;
}
