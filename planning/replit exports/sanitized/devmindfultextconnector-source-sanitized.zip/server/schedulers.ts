/**
 * Background jobs: auto-login + dashboard cache warm-up at startup, periodic
 * session keep-alive, and daily analytics snapshots.
 *
 * `checkAndRefreshAutoSession` and `captureDailySnapshot` are also invoked
 * on demand by routes, so they're exported alongside `startBackgroundJobs`.
 */
import {
  AUTO_SESSION_ID,
  sessionStore,
  saveSessionStore,
} from "./session";
import {
  loadOrgSettings,
  getConfiguredOrgId,
  performAutoLogin,
  probeOrgsByUser,
  setAutoSessionUser,
} from "./orgSettings";
import { fetchMtReporting } from "./mtReporting";
import { upsertAnalyticsSnapshot, backfillMessageEvents } from "./storage";
import { pollInboundReplies } from "./inbound";

const SESSION_KEEP_ALIVE_INTERVAL_MS = 30 * 60 * 1000; // 30 minutes
const SNAPSHOT_INTERVAL_MS = 24 * 60 * 60 * 1000; // daily
const INBOUND_POLL_INTERVAL_MS = 3 * 60 * 1000; // 3 minutes

// Cache warm-up — the founder-dashboard SWR cache (server/swrCache.ts) is
// in-process, so it's empty after every restart/redeploy and the first
// visit pays the full cold cost again (dashboard-stats is ~6s). Pre-warm
// the hot read endpoints by hitting them over loopback with the
// auto-session id, which runs the exact same handler → swr() path. Going
// through the real handlers (rather than calling swr() directly here)
// guarantees the cache key matches what a genuine request produces, so the
// first real visit is actually served from the warmed entry.
//
// Non-fatal by design: it only runs once cookies exist (respecting the
// auto-session), and every request failure is logged and swallowed.
async function warmDashboardCaches(): Promise<void> {
  const cookies = sessionStore[AUTO_SESSION_ID];
  if (!cookies) {
    console.log("[warm-up] No auto-session cookies yet — skipping cache warm-up");
    return;
  }
  const port = parseInt(process.env.PORT || "5000", 10);
  const base = `http://127.0.0.1:${port}`;
  // Warm dashboard-stats for the tz + period this user's browser actually
  // sends (persisted from prior real requests). The cache key includes tz,
  // so warming UTC/month would miss the usual non-UTC first request after a
  // restart. Fall back to month/UTC before any request has been recorded.
  // "custom" can't be warmed without start/end, so fall back to month.
  const settings = loadOrgSettings();
  const warmPeriod =
    settings.lastPeriod && settings.lastPeriod !== "custom" ? settings.lastPeriod : "month";
  const warmTz = settings.lastTz || "UTC";
  const statsQuery = `period=${encodeURIComponent(warmPeriod)}&tz=${encodeURIComponent(warmTz)}`;
  // revenue/attribution use their own defaults. Routed with the auto-session
  // id so the /api/local auth gate resolves the configured org and the
  // handlers reuse the auto-session cookies upstream.
  const targets = [
    `/api/local/dashboard-stats?${statsQuery}`,
    "/api/local/revenue",
    "/api/local/attribution",
  ];

  // These are trusted loopback startup calls over plain HTTP. In production
  // the HTTPS-enforcement middleware (server/index.ts) redirects any request
  // whose `x-forwarded-proto` isn't `https` — which would bounce this call to
  // an https URL this plain-HTTP server can't serve, defeating the warm-up.
  // Setting the header marks the hop as already-secured so it isn't
  // redirected. `redirect: "manual"` keeps any unexpected redirect visible as
  // a 3xx status instead of silently following it. We also retry on
  // connection-refused because listen() may not have bound the port yet.
  const warmOne = async (path: string): Promise<string> => {
    const url = `${base}${path}`;
    for (let attempt = 1; attempt <= 5; attempt++) {
      try {
        const r = await fetch(url, {
          headers: {
            "X-Session-ID": AUTO_SESSION_ID,
            "X-Forwarded-Proto": "https",
            Accept: "application/json",
          },
          redirect: "manual",
        });
        return String(r.status);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        if (attempt < 5 && /ECONNREFUSED|ECONNRESET|fetch failed/i.test(msg)) {
          await new Promise((resolve) => setTimeout(resolve, attempt * 500));
          continue;
        }
        return `failed: ${msg}`;
      }
    }
    return "failed: exhausted retries";
  };

  const results = await Promise.all(
    targets.map(async (path) => `${path} → ${await warmOne(path)}`),
  );
  console.log(`[warm-up] complete: ${results.join(" | ")}`);
}

// Periodically verify the auto-session is still valid and re-login if not.
export async function checkAndRefreshAutoSession(): Promise<void> {
  // Use the same credential precedence as performAutoLogin: Settings-saved
  // first, env vars as fallback. Without either, there's nothing to keep
  // alive.
  const settings = loadOrgSettings();
  const email = settings.email || process.env.MINDFULTEXT_EMAIL;
  const password = settings.password || process.env.MINDFULTEXT_PASSWORD;
  if (!email || !password) return;

  const storedCookies = sessionStore[AUTO_SESSION_ID];
  if (!storedCookies) {
    console.log("[keep-alive] No cookies stored — attempting login");
    await performAutoLogin(sessionStore, saveSessionStore);
    return;
  }

  try {
    // Use the same probe as the rest of the app — `forbidden` means the
    // cookies are still valid for per-org calls, so we must NOT re-login.
    const probe = await probeOrgsByUser(storedCookies);
    if (probe.status === "unauthorized") {
      console.log(`[keep-alive] Session expired (401) — clearing and re-logging in`);
      setAutoSessionUser(null);
      delete sessionStore[AUTO_SESSION_ID];
      saveSessionStore(sessionStore);
      await performAutoLogin(sessionStore, saveSessionStore);
    } else {
      console.log(`[keep-alive] Auto-session still valid (probe=${probe.status})`);
    }
  } catch (err) {
    // Network error is transient — log and let the next interval retry.
    // Do NOT clear cookies: the remote server may just be briefly unreachable.
    console.warn("[keep-alive] Ping failed (network error) — will retry next interval:", err instanceof Error ? err.message : String(err));
  }
}

// Analytics snapshot scheduler — build a real calendar time-series from
// MindfulText's reporting endpoint (which only exposes rolling windows).
export async function captureDailySnapshot(orgIdArg?: string) {
  const orgId = orgIdArg || getConfiguredOrgId();
  const cookies = sessionStore[AUTO_SESSION_ID] || "";
  if (!orgId || !cookies) return null;
  // Per-day delta + cumulative all-time totals, both from the real endpoint.
  const day = await fetchMtReporting(orgId, 1, cookies);
  const all = await fetchMtReporting(orgId, -1, cookies);
  if (!day && !all) return null;
  const today = new Date().toISOString().slice(0, 10);
  const row = await upsertAnalyticsSnapshot({
    organizationId: orgId,
    snapshotDate: today,
    newContacts: day?.newContacts ?? 0,
    newLaunches: day?.newLaunches ?? 0,
    messagesSent: day?.messagesSent ?? 0,
    messagesReceived: day?.messagesReceived ?? 0,
    totalContacts: all?.newContacts ?? null,
    totalLaunches: all?.newLaunches ?? null,
    totalSent: all?.messagesSent ?? null,
    totalReceived: all?.messagesReceived ?? null,
  });
  console.log(`[analytics-snapshot] captured ${today} for org ${orgId}`);
  return row;
}

/** Kick off all background jobs. Called once after the server is constructed. */
export function startBackgroundJobs(): void {
  // Kick off auto-login after the server is ready (non-blocking), then warm
  // the dashboard caches once cookies are established.
  setImmediate(() => {
    performAutoLogin(sessionStore, saveSessionStore)
      .then(() => warmDashboardCaches())
      .catch((err) => {
        console.error("[auto-login] Unhandled error in performAutoLogin:", err);
      });
  });

  setInterval(() => {
    checkAndRefreshAutoSession().catch((err) => {
      console.error("[keep-alive] Unhandled error in checkAndRefreshAutoSession:", err);
    });
  }, SESSION_KEEP_ALIVE_INTERVAL_MS);

  // One-time seed of message_events + first snapshot, a bit after startup so
  // the auto-login has time to establish cookies.
  setTimeout(() => {
    const orgId = getConfiguredOrgId();
    if (orgId) {
      backfillMessageEvents(orgId)
        .then((r) => {
          if (!r.skipped) {
            console.log(`[message-events] backfilled ${r.sends} sends + ${r.replies} replies for org ${orgId}`);
          }
        })
        .catch((err) => console.error("[message-events] backfill failed:", err));
      pollInboundReplies(orgId).catch((err) =>
        console.error("[inbound-poll] initial poll failed:", err),
      );
    }
    captureDailySnapshot().catch((err) =>
      console.error("[analytics-snapshot] initial capture failed:", err),
    );
  }, 90 * 1000);

  setInterval(() => {
    captureDailySnapshot().catch((err) =>
      console.error("[analytics-snapshot] scheduled capture failed:", err),
    );
  }, SNAPSHOT_INTERVAL_MS);

  // Poll MindfulText for new inbound replies and run reshape + draft pipeline.
  setInterval(() => {
    pollInboundReplies().catch((err) =>
      console.error("[inbound-poll] scheduled poll failed:", err),
    );
  }, INBOUND_POLL_INTERVAL_MS);
}
