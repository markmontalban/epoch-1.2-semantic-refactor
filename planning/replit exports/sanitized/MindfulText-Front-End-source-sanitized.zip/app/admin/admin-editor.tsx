"use client";

import type {
  FaqItem,
  FeatureItem,
  FooterColumn,
  GalleryShot,
  IntegrationItem,
  LinkItem,
  PricingTier,
  SiteContent,
  Testimonial,
} from "@/lib/content-types";
import { useCallback, useRef, useState, type ReactNode } from "react";

type SaveState = "idle" | "saving" | "saved" | "error";

function cloneContent(content: SiteContent): SiteContent {
  return JSON.parse(JSON.stringify(content)) as SiteContent;
}

/* ---------- Small building blocks ---------- */

function Field({
  label,
  value,
  onChange,
  multiline,
  type = "text",
}: {
  label: string;
  value: string | number;
  onChange: (value: string) => void;
  multiline?: boolean;
  type?: string;
}): ReactNode {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-xs font-medium text-neutral-500">{label}</span>
      {multiline ? (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={3}
          className="w-full rounded-lg border border-neutral-300 bg-white px-3 py-2 text-sm text-neutral-900 outline-none focus:border-neutral-500"
        />
      ) : (
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full rounded-lg border border-neutral-300 bg-white px-3 py-2 text-sm text-neutral-900 outline-none focus:border-neutral-500"
        />
      )}
    </label>
  );
}

function ImageField({
  label,
  value,
  onChange,
  video,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  video?: boolean;
}): ReactNode {
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback(
    async (file: File) => {
      setUploading(true);
      try {
        const formData = new FormData();
        formData.append("file", file);
        const res = await fetch("/api/admin/upload", {
          method: "POST",
          body: formData,
        });
        if (!res.ok) throw new Error("Upload failed");
        const data = await res.json();
        onChange(data.url);
      } catch {
        alert("Upload failed. Please try again.");
      } finally {
        setUploading(false);
      }
    },
    [onChange]
  );

  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-xs font-medium text-neutral-500">{label}</span>
      <div className="flex items-center gap-3">
        {video ? (
          value && (
            <video
              src={value}
              className="h-16 w-16 rounded-lg object-cover bg-neutral-200"
              muted
            />
          )
        ) : (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={value || "https://placehold.co/64x64?text=+"}
            alt=""
            className="h-16 w-16 rounded-lg object-cover bg-neutral-200"
          />
        )}
        <div className="flex flex-1 flex-col gap-1.5">
          <input
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder="Image/video URL"
            className="w-full rounded-lg border border-neutral-300 bg-white px-3 py-2 text-sm text-neutral-900 outline-none focus:border-neutral-500"
          />
          <input
            ref={inputRef}
            type="file"
            accept={video ? "video/*" : "image/*"}
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void handleFile(file);
              e.target.value = "";
            }}
          />
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            disabled={uploading}
            className="w-fit rounded-md border border-neutral-300 px-2.5 py-1 text-xs font-medium text-neutral-700 hover:bg-neutral-100 disabled:opacity-50"
          >
            {uploading ? "Uploading..." : "Upload file"}
          </button>
        </div>
      </div>
    </div>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}): ReactNode {
  return (
    <section className="rounded-2xl border border-neutral-200 bg-white p-6">
      <h2 className="mb-5 text-lg font-semibold text-neutral-900">{title}</h2>
      <div className="flex flex-col gap-5">{children}</div>
    </section>
  );
}

function AddRemoveList<T>({
  items,
  onChange,
  newItem,
  renderItem,
  label,
}: {
  items: T[];
  onChange: (items: T[]) => void;
  newItem: () => T;
  renderItem: (item: T, index: number, update: (item: T) => void) => ReactNode;
  label: string;
}): ReactNode {
  return (
    <div className="flex flex-col gap-3">
      {items.map((item, i) => (
        <div
          key={i}
          className="flex flex-col gap-3 rounded-xl border border-neutral-200 p-4"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1">
              {renderItem(item, i, (updated) => {
                const next = items.slice();
                next[i] = updated;
                onChange(next);
              })}
            </div>
            <button
              type="button"
              onClick={() => onChange(items.filter((_, idx) => idx !== i))}
              className="shrink-0 rounded-md border border-neutral-300 px-2 py-1 text-xs font-medium text-neutral-500 hover:bg-neutral-100"
            >
              Remove
            </button>
          </div>
        </div>
      ))}
      <button
        type="button"
        onClick={() => onChange([...items, newItem()])}
        className="w-fit rounded-md border border-dashed border-neutral-400 px-3 py-1.5 text-xs font-medium text-neutral-600 hover:bg-neutral-100"
      >
        + Add {label}
      </button>
    </div>
  );
}

function LinkListEditor({
  items,
  onChange,
  label,
}: {
  items: LinkItem[];
  onChange: (items: LinkItem[]) => void;
  label: string;
}): ReactNode {
  return (
    <AddRemoveList
      items={items}
      onChange={onChange}
      newItem={() => ({ label: "New link", href: "#" })}
      label={label}
      renderItem={(item, _i, update) => (
        <div className="grid grid-cols-2 gap-3">
          <Field
            label="Label"
            value={item.label}
            onChange={(label) => update({ ...item, label })}
          />
          <Field
            label="Link"
            value={item.href}
            onChange={(href) => update({ ...item, href })}
          />
        </div>
      )}
    />
  );
}

function ImageListEditor({
  images,
  onChange,
}: {
  images: string[];
  onChange: (images: string[]) => void;
}): ReactNode {
  return (
    <AddRemoveList
      items={images}
      onChange={onChange}
      newItem={() => ""}
      label="image"
      renderItem={(url, _i, update) => (
        <ImageField label="Image" value={url} onChange={update} />
      )}
    />
  );
}

/* ---------- Main editor ---------- */

export function AdminEditor({
  initialContent,
}: {
  initialContent: SiteContent;
}): ReactNode {
  const [content, setContent] = useState<SiteContent>(() =>
    cloneContent(initialContent)
  );
  const [saveState, setSaveState] = useState<SaveState>("idle");

  const update = useCallback((mutator: (draft: SiteContent) => void) => {
    setContent((prev) => {
      const next = cloneContent(prev);
      mutator(next);
      return next;
    });
  }, []);

  const handleSave = useCallback(async () => {
    setSaveState("saving");
    try {
      const res = await fetch("/api/admin/content", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(content),
      });
      if (!res.ok) throw new Error("Save failed");
      const saved = await res.json();
      setContent(saved);
      setSaveState("saved");
      setTimeout(() => setSaveState("idle"), 2000);
    } catch {
      setSaveState("error");
    }
  }, [content]);

  return (
    <div className="min-h-screen bg-neutral-50 pb-32">
      <div className="sticky top-0 z-10 flex items-center justify-between border-b border-neutral-200 bg-white/95 px-6 py-4 backdrop-blur">
        <div>
          <h1 className="text-xl font-semibold text-neutral-900">
            Site content admin
          </h1>
          <p className="text-sm text-neutral-500">
            Edit homepage copy, images, and section visibility. Changes go
            live on save.
          </p>
        </div>
        <div className="flex items-center gap-3">
          {saveState === "saved" && (
            <span className="text-sm text-green-600">Saved</span>
          )}
          {saveState === "error" && (
            <span className="text-sm text-red-600">Failed to save</span>
          )}
          <a
            href="/"
            target="_blank"
            rel="noreferrer"
            className="rounded-lg border border-neutral-300 px-4 py-2 text-sm font-medium text-neutral-700 hover:bg-neutral-100"
          >
            View site
          </a>
          <button
            type="button"
            onClick={handleSave}
            disabled={saveState === "saving"}
            className="rounded-lg bg-neutral-900 px-4 py-2 text-sm font-medium text-white hover:bg-neutral-800 disabled:opacity-60"
          >
            {saveState === "saving" ? "Saving..." : "Save changes"}
          </button>
        </div>
      </div>

      <div className="mx-auto flex max-w-3xl flex-col gap-6 px-6 py-8">
        <Section title="Section visibility">
          <label className="flex items-center justify-between gap-3">
            <span className="text-sm text-neutral-700">
              Show &quot;Made with Cortex&quot; gallery section
            </span>
            <input
              type="checkbox"
              checked={content.sections.gallery}
              onChange={(e) =>
                update((d) => {
                  d.sections.gallery = e.target.checked;
                })
              }
              className="size-4"
            />
          </label>
          <label className="flex items-center justify-between gap-3">
            <span className="text-sm text-neutral-700">
              Show &quot;Lands where you publish&quot; integrations section
            </span>
            <input
              type="checkbox"
              checked={content.sections.integrations}
              onChange={(e) =>
                update((d) => {
                  d.sections.integrations = e.target.checked;
                })
              }
              className="size-4"
            />
          </label>
        </Section>

        <Section title="Branding">
          <ImageField
            label="Logo image (leave empty to use the default mark)"
            value={content.branding.logoImage}
            onChange={(v) => update((d) => (d.branding.logoImage = v))}
          />
        </Section>

        <Section title="Navigation">
          <div className="grid grid-cols-2 gap-3">
            <Field
              label="Login label"
              value={content.nav.loginLabel}
              onChange={(v) => update((d) => (d.nav.loginLabel = v))}
            />
            <Field
              label="Login link"
              value={content.nav.loginHref}
              onChange={(v) => update((d) => (d.nav.loginHref = v))}
            />
            <Field
              label="Sign up label"
              value={content.nav.signUpLabel}
              onChange={(v) => update((d) => (d.nav.signUpLabel = v))}
            />
            <Field
              label="Sign up link"
              value={content.nav.signUpHref}
              onChange={(v) => update((d) => (d.nav.signUpHref = v))}
            />
          </div>
          <p className="text-xs font-medium text-neutral-500">Pill links</p>
          <LinkListEditor
            items={content.nav.pillLinks}
            onChange={(items) => update((d) => (d.nav.pillLinks = items))}
            label="pill link"
          />
          <p className="text-xs font-medium text-neutral-500">Menu links</p>
          <LinkListEditor
            items={content.nav.primaryLinks}
            onChange={(items) => update((d) => (d.nav.primaryLinks = items))}
            label="menu link"
          />
          <p className="text-xs font-medium text-neutral-500">
            Legal / other links
          </p>
          <LinkListEditor
            items={content.nav.legalLinks}
            onChange={(items) => update((d) => (d.nav.legalLinks = items))}
            label="legal link"
          />
          <p className="text-xs font-medium text-neutral-500">
            Social links
          </p>
          <LinkListEditor
            items={content.nav.socialLinks}
            onChange={(items) => update((d) => (d.nav.socialLinks = items))}
            label="social link"
          />
        </Section>

        <Section title="Hero">
          <Field
            label="Headline"
            value={content.hero.headline}
            onChange={(v) => update((d) => (d.hero.headline = v))}
          />
          <Field
            label="Subtext"
            value={content.hero.subtext}
            onChange={(v) => update((d) => (d.hero.subtext = v))}
            multiline
          />
          <div className="grid grid-cols-2 gap-3">
            <Field
              label="Primary CTA label"
              value={content.hero.primaryCtaLabel}
              onChange={(v) => update((d) => (d.hero.primaryCtaLabel = v))}
            />
            <Field
              label="Primary CTA link"
              value={content.hero.primaryCtaHref}
              onChange={(v) => update((d) => (d.hero.primaryCtaHref = v))}
            />
            <Field
              label="Secondary CTA label"
              value={content.hero.secondaryCtaLabel}
              onChange={(v) => update((d) => (d.hero.secondaryCtaLabel = v))}
            />
            <Field
              label="Secondary CTA link"
              value={content.hero.secondaryCtaHref}
              onChange={(v) => update((d) => (d.hero.secondaryCtaHref = v))}
            />
          </div>
          <p className="text-xs font-medium text-neutral-500">
            Orbiting tile images
          </p>
          <ImageListEditor
            images={content.hero.images}
            onChange={(images) => update((d) => (d.hero.images = images))}
          />
        </Section>

        <Section title="Video showcase">
          <ImageField
            label="Video file"
            value={content.videoShowcase.videoUrl}
            onChange={(v) => update((d) => (d.videoShowcase.videoUrl = v))}
            video
          />
          <ImageField
            label="Poster image"
            value={content.videoShowcase.posterUrl}
            onChange={(v) => update((d) => (d.videoShowcase.posterUrl = v))}
          />
          <Field
            label="Caption"
            value={content.videoShowcase.caption}
            onChange={(v) => update((d) => (d.videoShowcase.caption = v))}
          />
        </Section>

        <Section title="Manifesto">
          <Field
            label="Statement"
            value={content.manifesto.statement}
            onChange={(v) => update((d) => (d.manifesto.statement = v))}
            multiline
          />
        </Section>

        <Section title="Features">
          <Field
            label="Heading"
            value={content.features.heading}
            onChange={(v) => update((d) => (d.features.heading = v))}
          />
          <Field
            label="Description"
            value={content.features.description}
            onChange={(v) => update((d) => (d.features.description = v))}
            multiline
          />
          <AddRemoveList
            items={content.features.items}
            onChange={(items) => update((d) => (d.features.items = items))}
            newItem={(): FeatureItem => ({ title: "New feature", body: "", image: "" })}
            label="feature"
            renderItem={(item, _i, updateItem) => (
              <div className="flex flex-col gap-3">
                <Field
                  label="Title"
                  value={item.title}
                  onChange={(title) => updateItem({ ...item, title })}
                />
                <Field
                  label="Body"
                  value={item.body}
                  onChange={(body) => updateItem({ ...item, body })}
                  multiline
                />
                <ImageField
                  label="Image"
                  value={item.image}
                  onChange={(image) => updateItem({ ...item, image })}
                />
              </div>
            )}
          />
        </Section>

        <Section title="App showcase (how it works)">
          <Field
            label="Heading"
            value={content.appShowcase.heading}
            onChange={(v) => update((d) => (d.appShowcase.heading = v))}
          />
          <Field
            label="Description"
            value={content.appShowcase.description}
            onChange={(v) => update((d) => (d.appShowcase.description = v))}
            multiline
          />
          <Field
            label="Demo prompt text"
            value={content.appShowcase.prompt}
            onChange={(v) => update((d) => (d.appShowcase.prompt = v))}
          />
          <p className="text-xs font-medium text-neutral-500">
            Prompt chips
          </p>
          <AddRemoveList
            items={content.appShowcase.promptChips}
            onChange={(items) =>
              update((d) => (d.appShowcase.promptChips = items))
            }
            newItem={() => "New chip"}
            label="chip"
            renderItem={(chip, _i, updateChip) => (
              <Field label="Chip" value={chip} onChange={updateChip} />
            )}
          />
          <p className="text-xs font-medium text-neutral-500">
            Phone screen images
          </p>
          <ImageListEditor
            images={content.appShowcase.screenImages}
            onChange={(images) =>
              update((d) => (d.appShowcase.screenImages = images))
            }
          />
          <p className="text-xs font-medium text-neutral-500">
            Steps (fixed at 4 — the phone animation is built around exactly
            this many stages)
          </p>
          <div className="flex flex-col gap-3">
            {content.appShowcase.steps.map((step, i) => (
              <div
                key={i}
                className="flex flex-col gap-3 rounded-xl border border-neutral-200 p-4"
              >
                <Field
                  label="Title"
                  value={step.title}
                  onChange={(title) =>
                    update((d) => {
                      const current = d.appShowcase.steps[i];
                      if (current) current.title = title;
                    })
                  }
                />
                <Field
                  label="Body"
                  value={step.body}
                  onChange={(body) =>
                    update((d) => {
                      const current = d.appShowcase.steps[i];
                      if (current) current.body = body;
                    })
                  }
                  multiline
                />
              </div>
            ))}
          </div>
        </Section>

        {content.sections.gallery && (
          <Section title="Gallery (Made with Cortex)">
            <Field
              label="Heading"
              value={content.gallery.heading}
              onChange={(v) => update((d) => (d.gallery.heading = v))}
            />
            <Field
              label="Description"
              value={content.gallery.description}
              onChange={(v) => update((d) => (d.gallery.description = v))}
              multiline
            />
            {(["rowA", "rowB"] as const).map((rowKey) => (
              <div key={rowKey} className="flex flex-col gap-2">
                <p className="text-xs font-medium text-neutral-500">
                  {rowKey === "rowA" ? "Row 1 shots" : "Row 2 shots"}
                </p>
                <AddRemoveList
                  items={content.gallery[rowKey]}
                  onChange={(items) => update((d) => (d.gallery[rowKey] = items))}
                  newItem={(): GalleryShot => ({ image: "", prompt: "" })}
                  label="shot"
                  renderItem={(shot, _i, updateShot) => (
                    <div className="flex flex-col gap-3">
                      <ImageField
                        label="Image"
                        value={shot.image}
                        onChange={(image) => updateShot({ ...shot, image })}
                      />
                      <Field
                        label="Prompt caption"
                        value={shot.prompt}
                        onChange={(prompt) => updateShot({ ...shot, prompt })}
                      />
                    </div>
                  )}
                />
              </div>
            ))}
          </Section>
        )}

        {content.sections.integrations && (
          <Section title="Integrations (Lands where you publish)">
            <Field
              label="Heading"
              value={content.integrations.heading}
              onChange={(v) => update((d) => (d.integrations.heading = v))}
            />
            <Field
              label="Description"
              value={content.integrations.description}
              onChange={(v) => update((d) => (d.integrations.description = v))}
              multiline
            />
            {(["rowA", "rowB"] as const).map((rowKey) => (
              <div key={rowKey} className="flex flex-col gap-2">
                <p className="text-xs font-medium text-neutral-500">
                  {rowKey === "rowA" ? "Row 1 apps" : "Row 2 apps"}
                </p>
                <AddRemoveList
                  items={content.integrations[rowKey]}
                  onChange={(items) =>
                    update((d) => (d.integrations[rowKey] = items))
                  }
                  newItem={(): IntegrationItem => ({ name: "New app", blurb: "" })}
                  label="app"
                  renderItem={(item, _i, updateItem) => (
                    <div className="grid grid-cols-2 gap-3">
                      <Field
                        label="Name"
                        value={item.name}
                        onChange={(name) => updateItem({ ...item, name })}
                      />
                      <Field
                        label="Blurb"
                        value={item.blurb}
                        onChange={(blurb) => updateItem({ ...item, blurb })}
                      />
                    </div>
                  )}
                />
              </div>
            ))}
          </Section>
        )}

        <Section title="Testimonials">
          <Field
            label="Heading"
            value={content.testimonials.heading}
            onChange={(v) => update((d) => (d.testimonials.heading = v))}
          />
          <Field
            label="Description"
            value={content.testimonials.description}
            onChange={(v) => update((d) => (d.testimonials.description = v))}
            multiline
          />
          <AddRemoveList
            items={content.testimonials.items}
            onChange={(items) => update((d) => (d.testimonials.items = items))}
            newItem={
              (): Testimonial => ({
                quote: "",
                name: "New person",
                role: "",
                avatar: "",
              })
            }
            label="testimonial"
            renderItem={(item, _i, updateItem) => (
              <div className="flex flex-col gap-3">
                <Field
                  label="Quote"
                  value={item.quote}
                  onChange={(quote) => updateItem({ ...item, quote })}
                  multiline
                />
                <div className="grid grid-cols-2 gap-3">
                  <Field
                    label="Name"
                    value={item.name}
                    onChange={(name) => updateItem({ ...item, name })}
                  />
                  <Field
                    label="Role"
                    value={item.role}
                    onChange={(role) => updateItem({ ...item, role })}
                  />
                </div>
                <ImageField
                  label="Avatar"
                  value={item.avatar}
                  onChange={(avatar) => updateItem({ ...item, avatar })}
                />
              </div>
            )}
          />
        </Section>

        <Section title="Pricing">
          <Field
            label="Heading"
            value={content.pricing.heading}
            onChange={(v) => update((d) => (d.pricing.heading = v))}
          />
          <Field
            label="Description"
            value={content.pricing.description}
            onChange={(v) => update((d) => (d.pricing.description = v))}
            multiline
          />
          <AddRemoveList
            items={content.pricing.tiers}
            onChange={(items) => update((d) => (d.pricing.tiers = items))}
            newItem={
              (): PricingTier => ({
                name: "New tier",
                blurb: "",
                monthly: 0,
                yearly: 0,
                features: [],
                cta: "Get started",
                highlighted: false,
              })
            }
            label="tier"
            renderItem={(tier, _i, updateTier) => (
              <div className="flex flex-col gap-3">
                <div className="grid grid-cols-2 gap-3">
                  <Field
                    label="Name"
                    value={tier.name}
                    onChange={(name) => updateTier({ ...tier, name })}
                  />
                  <Field
                    label="CTA label"
                    value={tier.cta}
                    onChange={(cta) => updateTier({ ...tier, cta })}
                  />
                </div>
                <Field
                  label="Blurb"
                  value={tier.blurb}
                  onChange={(blurb) => updateTier({ ...tier, blurb })}
                />
                <div className="grid grid-cols-2 gap-3">
                  <Field
                    label="Monthly price ($)"
                    type="number"
                    value={tier.monthly}
                    onChange={(v) =>
                      updateTier({ ...tier, monthly: Number(v) || 0 })
                    }
                  />
                  <Field
                    label="Yearly price ($/mo)"
                    type="number"
                    value={tier.yearly}
                    onChange={(v) =>
                      updateTier({ ...tier, yearly: Number(v) || 0 })
                    }
                  />
                </div>
                <label className="flex items-center gap-2 text-sm text-neutral-700">
                  <input
                    type="checkbox"
                    checked={tier.highlighted}
                    onChange={(e) =>
                      updateTier({ ...tier, highlighted: e.target.checked })
                    }
                    className="size-4"
                  />
                  Highlight as most popular
                </label>
                <p className="text-xs font-medium text-neutral-500">
                  Features
                </p>
                <AddRemoveList
                  items={tier.features}
                  onChange={(features) => updateTier({ ...tier, features })}
                  newItem={() => "New feature"}
                  label="feature"
                  renderItem={(feature, _fi, updateFeature) => (
                    <Field
                      label="Feature"
                      value={feature}
                      onChange={updateFeature}
                    />
                  )}
                />
              </div>
            )}
          />
        </Section>

        <Section title="FAQ">
          <Field
            label="Heading"
            value={content.faq.heading}
            onChange={(v) => update((d) => (d.faq.heading = v))}
          />
          <Field
            label="Description (use {email} where the contact email should appear)"
            value={content.faq.description}
            onChange={(v) => update((d) => (d.faq.description = v))}
            multiline
          />
          <Field
            label="Contact email"
            value={content.faq.contactEmail}
            onChange={(v) => update((d) => (d.faq.contactEmail = v))}
          />
          <AddRemoveList
            items={content.faq.items}
            onChange={(items) => update((d) => (d.faq.items = items))}
            newItem={(): FaqItem => ({ question: "New question", answer: "" })}
            label="question"
            renderItem={(item, _i, updateItem) => (
              <div className="flex flex-col gap-3">
                <Field
                  label="Question"
                  value={item.question}
                  onChange={(question) => updateItem({ ...item, question })}
                />
                <Field
                  label="Answer"
                  value={item.answer}
                  onChange={(answer) => updateItem({ ...item, answer })}
                  multiline
                />
              </div>
            )}
          />
        </Section>

        <Section title="Final call to action">
          <Field
            label="Headline"
            value={content.finalCta.headline}
            onChange={(v) => update((d) => (d.finalCta.headline = v))}
          />
          <Field
            label="Subtext"
            value={content.finalCta.subtext}
            onChange={(v) => update((d) => (d.finalCta.subtext = v))}
            multiline
          />
          <div className="grid grid-cols-2 gap-3">
            <Field
              label="Primary CTA label"
              value={content.finalCta.primaryCtaLabel}
              onChange={(v) => update((d) => (d.finalCta.primaryCtaLabel = v))}
            />
            <Field
              label="Primary CTA link"
              value={content.finalCta.primaryCtaHref}
              onChange={(v) => update((d) => (d.finalCta.primaryCtaHref = v))}
            />
            <Field
              label="Secondary CTA label"
              value={content.finalCta.secondaryCtaLabel}
              onChange={(v) =>
                update((d) => (d.finalCta.secondaryCtaLabel = v))
              }
            />
            <Field
              label="Secondary CTA link"
              value={content.finalCta.secondaryCtaHref}
              onChange={(v) =>
                update((d) => (d.finalCta.secondaryCtaHref = v))
              }
            />
          </div>
          <p className="text-xs font-medium text-neutral-500">
            Fanned print images
          </p>
          <ImageListEditor
            images={content.finalCta.images}
            onChange={(images) => update((d) => (d.finalCta.images = images))}
          />
        </Section>

        <Section title="Footer">
          <Field
            label="Tagline"
            value={content.footer.tagline}
            onChange={(v) => update((d) => (d.footer.tagline = v))}
            multiline
          />
          <div className="grid grid-cols-2 gap-3">
            <Field
              label="CTA label"
              value={content.footer.ctaLabel}
              onChange={(v) => update((d) => (d.footer.ctaLabel = v))}
            />
            <Field
              label="CTA link"
              value={content.footer.ctaHref}
              onChange={(v) => update((d) => (d.footer.ctaHref = v))}
            />
            <Field
              label="Copyright name"
              value={content.footer.copyrightName}
              onChange={(v) => update((d) => (d.footer.copyrightName = v))}
            />
            <Field
              label="Big background wordmark"
              value={content.footer.wordmark}
              onChange={(v) => update((d) => (d.footer.wordmark = v))}
            />
          </div>
          <p className="text-xs font-medium text-neutral-500">
            Footer columns
          </p>
          <AddRemoveList
            items={content.footer.columns}
            onChange={(items) => update((d) => (d.footer.columns = items))}
            newItem={(): FooterColumn => ({ title: "New column", links: [] })}
            label="column"
            renderItem={(column, _i, updateColumn) => (
              <div className="flex flex-col gap-3">
                <Field
                  label="Column title"
                  value={column.title}
                  onChange={(title) => updateColumn({ ...column, title })}
                />
                <LinkListEditor
                  items={column.links}
                  onChange={(links) => updateColumn({ ...column, links })}
                  label="link"
                />
              </div>
            )}
          />
        </Section>
      </div>
    </div>
  );
}
