import { AdminEditor } from "@/app/admin/admin-editor";
import { getSiteContent } from "@/lib/content";
import type { ReactNode } from "react";

export const dynamic = "force-dynamic";

export default async function AdminPage(): Promise<ReactNode> {
  const content = await getSiteContent();
  return <AdminEditor initialContent={content} />;
}
