import { AppShowcase } from "@/components/app-showcase";
import { Faq } from "@/components/faq";
import { Features } from "@/components/features";
import { FinalCta } from "@/components/final-cta";
import { Footer } from "@/components/footer";
import { Gallery } from "@/components/gallery";
import { Hero } from "@/components/hero";
import { Integrations } from "@/components/integrations";
import { Manifesto } from "@/components/manifesto";
import { Nav } from "@/components/nav/nav";
import { Pricing } from "@/components/pricing";
import { Testimonials } from "@/components/testimonials";
import { VideoShowcase } from "@/components/video-showcase";
import { getSiteContent } from "@/lib/content";
import { createMetadata, siteConfig } from "@/lib/metadata";
import type { Metadata } from "next";
import type { ReactNode } from "react";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  ...createMetadata({
    title: "Home",
    description: `Welcome to ${siteConfig.name}. ${siteConfig.description}`,
    path: "/",
  }),
  title: { absolute: "AI App Template" },
};

export default async function HomePage(): Promise<ReactNode> {
  const content = await getSiteContent();

  return (
    <>
      <span id="top" className="sr-only" />
      <Nav content={content.nav} logoImage={content.branding.logoImage} />
      <main id="main-content" className="flex-1 overflow-x-clip">
        <Hero
          images={content.hero.images}
          headline={content.hero.headline}
          subtext={content.hero.subtext}
          primaryCtaLabel={content.hero.primaryCtaLabel}
          primaryCtaHref={content.hero.primaryCtaHref}
          secondaryCtaLabel={content.hero.secondaryCtaLabel}
          secondaryCtaHref={content.hero.secondaryCtaHref}
        />
        <VideoShowcase content={content.videoShowcase} />
        <Manifesto statement={content.manifesto.statement} />
        <Features content={content.features} />
        <AppShowcase content={content.appShowcase} />
        {content.sections.gallery && <Gallery content={content.gallery} />}
        {content.sections.integrations && (
          <Integrations content={content.integrations} />
        )}
        <Testimonials content={content.testimonials} />
        <Pricing content={content.pricing} />
        <Faq content={content.faq} />
        <FinalCta content={content.finalCta} />
      </main>
      <Footer content={content.footer} logoImage={content.branding.logoImage} />
    </>
  );
}
