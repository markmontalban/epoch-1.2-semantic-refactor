import { getSiteContent, saveSiteContent } from "@/lib/content";
import { ZodError } from "zod";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(): Promise<NextResponse> {
  const content = await getSiteContent();
  return NextResponse.json(content);
}

export async function PUT(request: Request): Promise<NextResponse> {
  try {
    const body = await request.json();
    const saved = await saveSiteContent(body);
    return NextResponse.json(saved);
  } catch (error) {
    if (error instanceof ZodError) {
      return NextResponse.json(
        { error: "Invalid content", issues: error.issues },
        { status: 400 }
      );
    }
    console.error("Failed to save site content", error);
    return NextResponse.json(
      { error: "Failed to save content" },
      { status: 500 }
    );
  }
}
