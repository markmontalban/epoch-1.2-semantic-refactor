import { detectFileType } from "@/lib/file-signature";
import { uploadAsset } from "@/lib/storage";
import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";

export const dynamic = "force-dynamic";

const MAX_BYTES = 25 * 1024 * 1024; // 25MB

export async function POST(request: Request): Promise<NextResponse> {
  try {
    const formData = await request.formData();
    const file = formData.get("file");
    if (!(file instanceof File)) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }
    if (file.size > MAX_BYTES) {
      return NextResponse.json(
        { error: "File too large. Maximum size is 25MB." },
        { status: 400 }
      );
    }

    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // Trust only the file's actual bytes, never the client-declared
    // filename/Content-Type: those are trivially spoofable and this
    // endpoint is intentionally public (per task scope). SVG is excluded
    // by construction since it has no fixed binary signature we check for,
    // which also rules out inline-script SVG being served same-origin.
    const detected = detectFileType(buffer);
    if (!detected) {
      return NextResponse.json(
        { error: "Unsupported file type. Allowed: JPEG, PNG, WebP, GIF, MP4, MOV, WebM." },
        { status: 400 }
      );
    }

    const key = `${randomUUID()}${detected.extension}`;
    const url = await uploadAsset(key, buffer);

    return NextResponse.json({ url });
  } catch (error) {
    console.error("Upload failed", error);
    return NextResponse.json({ error: "Upload failed" }, { status: 500 });
  }
}
