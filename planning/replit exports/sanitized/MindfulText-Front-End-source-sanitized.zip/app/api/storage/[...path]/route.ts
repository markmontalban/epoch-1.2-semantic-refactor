import { readAsset } from "@/lib/storage";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/** Kept in sync with the upload allowlist in app/api/admin/upload/route.ts.
 * SVG is intentionally not served inline (stored-XSS risk on this origin). */
const CONTENT_TYPES: Record<string, string> = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".mp4": "video/mp4",
  ".mov": "video/quicktime",
  ".webm": "video/webm",
};

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ path: string[] }> }
): Promise<NextResponse> {
  const { path } = await params;
  const objectKey = path.join("/");
  const asset = await readAsset(objectKey);
  if (!asset) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const ext = /\.[a-zA-Z0-9]+$/.exec(objectKey)?.[0]?.toLowerCase() ?? "";
  const contentType = CONTENT_TYPES[ext];
  if (!contentType) {
    // Unknown/legacy extension (e.g. a pre-existing .svg): serve as a
    // forced download rather than guessing a renderable type, so the
    // browser never executes it as HTML/SVG/script in this origin.
    return new NextResponse(new Uint8Array(asset.buffer), {
      headers: {
        "Content-Type": "application/octet-stream",
        "Content-Disposition": "attachment",
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  }

  return new NextResponse(new Uint8Array(asset.buffer), {
    headers: {
      "Content-Type": contentType,
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}
