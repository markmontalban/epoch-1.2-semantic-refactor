# Cortex — AI App Landing Page

A premium, minimal AI mobile-app landing page built with Next.js 16, React 19, Tailwind CSS v4, and TypeScript. Cortex is a fictional hyperreal photo & video generation app.

## Stack

- **Framework**: Next.js 16 with App Router (fully static-prerenderable)
- **UI**: React 19, TypeScript (strict mode)
- **Styles**: Tailwind CSS v4 with CSS-variable design tokens
- **3D / WebGL**: React Three Fiber + Three.js (hero orbit field)
- **Animation**: motion/react (scroll-driven, reduced-motion friendly)
- **Smooth scroll**: Lenis (feature-flagged via `lib/config.ts`)
- **Dark mode**: next-themes (floating bottom-right switch)

## Running

```bash
next dev --hostname 0.0.0.0 --port 5000
```

The dev server runs on **port 5000** (required for Replit's preview pane).

## Design tokens (`app/globals.css`)

Light theme (`:root`):
- `--background: #faf7f2` — warm off-white
- `--foreground: #3a3535` — dark brown-black
- `--muted: #ede7dc` — subtle warm tint
- `--muted-foreground: #9a8f87` — secondary text
- `--border: #ddd5c8` — warm border
- `--ring: #f7941d` — orange accent (focus rings)
- `--surface: #3a3535` — inverted panel bg (nav pill, pricing highlight, CTA)
- `--surface-foreground: #faf7f2` — inverted panel text
- `--accent-orange: #f7941d` / `--accent-rose: #e8728a` / `--accent-sky: #7dbcd5` — use sparingly

## User preferences

- Light theme only; dark mode toggle kept but light is the primary aesthetic.
- Animation intensity ~30% lower than original: orbital ring durations extended, marquee speed reduced, scroll boost capped.
- Shadows tuned for light backgrounds (no heavy dark rgba glows).
- Keep layout, components, and animation effects — only retune visuals.
