import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Disable source maps in production to protect code
  productionBrowserSourceMaps: false,
  devIndicators: false,
};

export default nextConfig;
