"use client";

import { SectionHeading } from "@/components/section-heading";
import type { IntegrationItem } from "@/lib/content-types";
import { useReducedMotion } from "@/lib/motion";
import {
  Aperture,
  Clapperboard,
  Dribbble,
  Figma,
  Film,
  Framer,
  Instagram,
  Linkedin,
  Slack,
  Twitter,
  Webhook,
  Youtube,
  type LucideIcon,
} from "lucide-react";
import {
  motion,
  useScroll,
  useTransform,
  type MotionValue,
} from "motion/react";
import { useRef, type ReactNode } from "react";

type Integration = IntegrationItem;

/** Icons cycle by position so any admin-edited list still gets an icon. */
const ICON_CYCLE: readonly LucideIcon[] = [
  Instagram,
  Youtube,
  Twitter,
  Figma,
  Slack,
  Dribbble,
  Aperture,
  Film,
  Clapperboard,
  Framer,
  Linkedin,
  Webhook,
];

/** Horizontal travel of each row across the section's scroll range, in px. */
const ROW_TRAVEL = 160;

function Pill({
  integration,
  icon: Icon,
}: {
  integration: Integration;
  icon: LucideIcon;
}): ReactNode {
  return (
    <div className="border-border bg-background flex shrink-0 items-center gap-2.5 rounded-full border py-3.5 pr-5 pl-4 whitespace-nowrap">
      <Icon
        className="text-foreground size-4"
        strokeWidth={1.75}
        aria-hidden="true"
      />
      <span className="text-foreground text-sm font-medium">
        {integration.name}
      </span>
      <span className="text-muted-foreground text-xs">{integration.blurb}</span>
    </div>
  );
}

function ScrubRow({
  items,
  x,
}: {
  items: Integration[];
  x: MotionValue<number> | undefined;
}): ReactNode {
  return (
    <div className="flex justify-center">
      <motion.div {...(x ? { style: { x } } : {})} className="flex w-max gap-3">
        {items.map((integration, i) => (
          <Pill
            key={integration.name}
            integration={integration}
            icon={ICON_CYCLE[i % ICON_CYCLE.length] ?? Instagram}
          />
        ))}
        <div aria-hidden="true" className="flex gap-3">
          {items.map((integration, i) => (
            <Pill
              key={`copy-${integration.name}`}
              integration={integration}
              icon={ICON_CYCLE[i % ICON_CYCLE.length] ?? Instagram}
            />
          ))}
        </div>
      </motion.div>
    </div>
  );
}

export function Integrations({
  content,
}: {
  content: {
    heading: string;
    description: string;
    rowA: Integration[];
    rowB: Integration[];
  };
}): ReactNode {
  const reduce = useReducedMotion();
  const sectionRef = useRef<HTMLElement>(null);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  });

  const xA = useTransform(scrollYProgress, [0, 1], [-ROW_TRAVEL, ROW_TRAVEL]);
  const xB = useTransform(scrollYProgress, [0, 1], [ROW_TRAVEL, -ROW_TRAVEL]);

  return (
    <section
      ref={sectionRef}
      id="integrations"
      className="scroll-mt-24 pb-24 sm:pb-32"
    >
      <div className="mx-auto max-w-[1440px] px-5 sm:px-8 lg:px-10">
        <SectionHeading
          align="center"
          title={content.heading}
          description={content.description}
        />
      </div>

      <div className="mt-14 flex flex-col gap-3">
        <ScrubRow items={content.rowA} x={reduce ? undefined : xA} />
        <ScrubRow items={content.rowB} x={reduce ? undefined : xB} />
      </div>
    </section>
  );
}
