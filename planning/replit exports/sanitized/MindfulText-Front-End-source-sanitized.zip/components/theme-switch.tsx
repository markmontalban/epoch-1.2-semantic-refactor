"use client";

import type { ReactNode } from "react";

// Light-only mode: toggle is hidden. To re-enable dark mode, restore the full
// component body, set enableSystem in providers.tsx, and update the .dark block
// in globals.css to complement the warm palette.
export function ThemeSwitch(): ReactNode {
  return null;
}
