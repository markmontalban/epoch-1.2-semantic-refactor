import { Logo } from "@/components/nav/logo";
import type { FooterContent } from "@/lib/content-types";
import type { ReactNode } from "react";

export function Footer({
  content,
  logoImage,
}: {
  content: FooterContent;
  logoImage?: string | undefined;
}): ReactNode {
  return (
    <footer className="border-border border-t">
      <div className="mx-auto max-w-[1440px] px-5 pt-16 sm:px-8 sm:pt-20 lg:px-10">
        <div className="flex flex-col gap-14 lg:flex-row lg:justify-between">
          <div className="max-w-xs">
            <Logo image={logoImage} />
            <p className="text-muted-foreground mt-6 text-sm leading-relaxed">
              {content.tagline}
            </p>
            <a
              href={content.ctaHref}
              style={{ backgroundColor: "var(--accent-orange)", color: "#3a2008" }}
              className="focus-ring mt-8 inline-flex h-11 items-center rounded-full px-6 text-sm font-medium transition-opacity hover:opacity-85"
            >
              {content.ctaLabel}
            </a>
          </div>

          <div className="grid grid-cols-2 gap-x-8 gap-y-10 sm:grid-cols-4 lg:gap-x-16">
            {content.columns.map((column) => (
              <div key={column.title}>
                <h3 className="text-foreground text-sm font-medium tracking-tight">
                  {column.title}
                </h3>
                <ul className="mt-4 space-y-3">
                  {column.links.map((link) => (
                    <li key={link.href}>
                      <a
                        href={link.href}
                        className="focus-ring text-muted-foreground hover:text-foreground text-sm transition-colors"
                      >
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 flex flex-col-reverse items-start justify-between gap-4 pt-6 sm:flex-row sm:items-center">
          <p className="text-muted-foreground text-xs">
            © {new Date().getFullYear()} {content.copyrightName}. All rights
            reserved.
          </p>
          <p className="text-muted-foreground text-xs">
            Every frame on this page was generated.
          </p>
        </div>

        <div
          aria-hidden="true"
          className="pointer-events-none overflow-hidden select-none"
        >
          <p className="text-muted translate-y-[22%] text-center text-[clamp(90px,22vw,300px)] leading-[0.85] font-medium tracking-tighter">
            {content.wordmark}
          </p>
        </div>
      </div>
    </footer>
  );
}
