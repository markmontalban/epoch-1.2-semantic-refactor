"use client";

import { useReducedMotion } from "@/lib/motion";
import {
  motion,
  useScroll,
  useTransform,
  type MotionValue,
} from "motion/react";
import { useMemo, useRef, type ReactNode } from "react";

function Word({
  children,
  progress,
  range,
}: {
  children: string;
  progress: MotionValue<number>;
  range: [number, number];
}): ReactNode {
  const opacity = useTransform(progress, range, [0.12, 1]);

  return (
    <motion.span style={{ opacity }} className="inline">
      {children}{" "}
    </motion.span>
  );
}

export function Manifesto({ statement }: { statement: string }): ReactNode {
  const prefersReducedMotion = useReducedMotion();
  const textRef = useRef<HTMLParagraphElement>(null);
  const words = useMemo(() => statement.split(" "), [statement]);

  const { scrollYProgress } = useScroll({
    target: textRef,
    offset: ["start 0.85", "start 0.3"],
  });

  return (
    <section
      aria-label="The Cortex standard"
      className="mx-auto max-w-[1440px] px-5 py-28 sm:px-8 sm:py-40 lg:px-10"
    >
      <p
        ref={textRef}
        className="text-foreground max-w-4xl text-[clamp(26px,4.2vw,52px)] leading-[1.18] font-medium tracking-tight"
      >
        {prefersReducedMotion
          ? statement
          : words.map((word, i) => {
              const start = i / words.length;
              const end = start + 1 / words.length;
              return (
                <Word
                  key={`${word}-${i}`}
                  progress={scrollYProgress}
                  range={[start, end]}
                >
                  {word}
                </Word>
              );
            })}
      </p>
    </section>
  );
}
