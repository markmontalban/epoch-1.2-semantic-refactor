import type { ReactNode } from "react";

export function Logo({ image }: { image?: string | undefined } = {}): ReactNode {
  return (
    <a
      href="#top"
      aria-label="Cortex home"
      className="focus-ring group inline-flex"
    >
      <span className="border-border bg-background flex h-13 w-13 items-center justify-center rounded-full border transition-transform duration-500 group-hover:rotate-360">
        {image ? (
          // eslint-disable-next-line @next/next/no-img-element -- admin-uploaded
          // image of unknown/variable dimensions from app storage, not a static asset.
          <img
            src={image}
            alt="Logo"
            className="h-8 w-8 rounded-full object-cover"
          />
        ) : (
          <svg
            viewBox="0 0 115 116"
            className="h-6 w-6"
            fill="none"
            aria-hidden="true"
          >
            <path
              d="M65.5223 1.01564C63.0826 -0.204227 60.212 1.56988 60.212 4.29759C60.212 5.68743 60.9972 6.95799 62.2403 7.57954L90.608 21.7634C97.2414 25.0801 97.2414 34.5463 90.608 37.8631L65.1871 50.5735C62.138 52.0981 60.212 55.2144 60.212 58.6234V106.875C60.212 113.565 67.2528 117.917 73.2369 114.925L109.937 96.5744C112.987 95.0499 114.913 91.9335 114.913 88.5246V31.2731C114.913 27.8641 112.987 24.7478 109.937 23.2232L65.5223 1.01564Z"
              className="fill-foreground"
            />
            <path
              d="M0 84.6134C0 88.0223 1.92602 91.1387 4.97508 92.6632L49.3903 114.871C51.83 116.091 54.7006 114.317 54.7006 111.589C54.7006 110.199 53.9153 108.928 52.6722 108.307L24.3046 94.1231C17.6711 90.8064 17.6711 81.3401 24.3046 78.0234L49.7255 65.3129C52.7746 63.7884 54.7006 60.672 54.7006 57.2631V9.01161C54.7006 2.32117 47.6598 -2.03029 41.6757 0.961767L4.97508 19.3121C1.92602 20.8366 0 23.953 0 27.3619V84.6134Z"
              className="fill-foreground"
            />
          </svg>
        )}
      </span>
    </a>
  );
}
