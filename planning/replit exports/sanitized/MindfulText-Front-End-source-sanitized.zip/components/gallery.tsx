"use client";

import { SectionHeading } from "@/components/section-heading";
import type { GalleryShot } from "@/lib/content-types";
import { useReducedMotion } from "@/lib/motion";
import {
  motion,
  useAnimationFrame,
  useMotionValue,
  useScroll,
  useSpring,
  useTransform,
  useVelocity,
} from "motion/react";
import Image from "next/image";
import { useRef, type ReactNode } from "react";

type Shot = GalleryShot;

const COPIES = 5;
const SET_FRACTION = 100 / COPIES;
const BASE_SPEED = 0.385; // reduced ~30%
const MAX_VELOCITY_BOOST = 2.8; // reduced ~30%

function wrap(min: number, max: number, value: number): number {
  const range = max - min;
  return ((((value - min) % range) + range) % range) + min;
}

function ShotCard({ shot }: { shot: Shot }): ReactNode {
  return (
    <figure className="mr-5 w-[240px] shrink-0 sm:w-[300px]">
      <div className="overflow-hidden rounded-2xl">
        <Image
          src={shot.image}
          alt={`Generated frame: ${shot.prompt}`}
          width={600}
          height={800}
          unoptimized
          className="aspect-[3/4] w-full object-cover transition-transform duration-700 ease-out hover:scale-[1.04]"
        />
      </div>
      <figcaption className="text-muted-foreground mt-3 font-mono text-[11px] tracking-tight">
        “{shot.prompt}”
      </figcaption>
    </figure>
  );
}

function MarqueeRow({
  shots,
  direction,
}: {
  shots: Shot[];
  direction: 1 | -1;
}): ReactNode {
  const prefersReducedMotion = useReducedMotion();
  const baseX = useMotionValue(direction === 1 ? -SET_FRACTION / 2 : 0);
  const directionFactor = useRef<number>(direction);

  const { scrollY } = useScroll();
  const scrollVelocity = useVelocity(scrollY);
  const smoothVelocity = useSpring(scrollVelocity, {
    damping: 50,
    stiffness: 400,
  });
  const velocityFactor = useTransform(
    smoothVelocity,
    [0, 1200],
    [0, MAX_VELOCITY_BOOST],
    { clamp: false }
  );

  const x = useTransform(baseX, (value) => `${wrap(-SET_FRACTION, 0, value)}%`);

  useAnimationFrame((_, delta) => {
    if (prefersReducedMotion) return;
    const step = BASE_SPEED * (delta / 1000);
    const boost = velocityFactor.get();
    if (boost < 0) directionFactor.current = -direction;
    else if (boost > 0) directionFactor.current = direction;
    const moveBy = directionFactor.current * step * (1 + Math.abs(boost)) * -1;
    baseX.set(baseX.get() + moveBy);
  });

  if (prefersReducedMotion) {
    return (
      <div className="overflow-x-auto px-5 sm:px-8 lg:px-10">
        <div className="flex w-max">
          {shots.map((shot) => (
            <ShotCard key={shot.image} shot={shot} />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="overflow-hidden">
      <motion.div style={{ x }} className="flex w-max">
        {Array.from({ length: COPIES }, (_, copy) =>
          shots.map((shot) => (
            <ShotCard key={`${copy}-${shot.image}`} shot={shot} />
          ))
        )}
      </motion.div>
    </div>
  );
}

export function Gallery({
  content,
}: {
  content: { heading: string; description: string; rowA: Shot[]; rowB: Shot[] };
}): ReactNode {
  return (
    <section
      id="gallery"
      className="scroll-mt-24 overflow-hidden pb-24 sm:pb-32"
    >
      <div className="mx-auto max-w-[1440px] px-5 sm:px-8 lg:px-10">
        <SectionHeading
          title={content.heading}
          description={content.description}
        />
      </div>

      <div className="mt-14 flex flex-col gap-10">
        <MarqueeRow shots={content.rowA} direction={1} />
        <MarqueeRow shots={content.rowB} direction={-1} />
      </div>
    </section>
  );
}
