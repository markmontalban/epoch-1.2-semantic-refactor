"use client";

import { SectionHeading } from "@/components/section-heading";
import type {
  Testimonial,
  TestimonialsContent,
} from "@/lib/content-types";
import { useReducedMotion } from "@/lib/motion";
import { motion, useScroll, useTransform } from "motion/react";
import Image from "next/image";
import { useMemo, useRef, type ReactNode } from "react";

/** Splits testimonials round-robin into 3 columns for the desktop parallax layout. */
function buildColumns(count: number): number[][] {
  const columns: number[][] = [[], [], []];
  for (let i = 0; i < count; i += 1) {
    columns[i % 3]?.push(i);
  }
  return columns;
}

function QuoteCard({ testimonial }: { testimonial: Testimonial }): ReactNode {
  return (
    <figure className="border-border bg-background flex flex-col gap-8 rounded-3xl border p-7 sm:p-8">
      <blockquote className="text-foreground text-lg leading-relaxed font-medium tracking-tight text-balance">
        “{testimonial.quote}”
      </blockquote>
      <figcaption className="flex items-center gap-3">
        <Image
          src={testimonial.avatar}
          alt={testimonial.name}
          width={80}
          height={80}
          unoptimized
          className="border-border size-10 shrink-0 rounded-full border object-cover"
        />
        <div>
          <p className="text-foreground text-sm font-medium">
            {testimonial.name}
          </p>
          <p className="text-muted-foreground mt-0.5 text-xs">
            {testimonial.role}
          </p>
        </div>
      </figcaption>
    </figure>
  );
}

export function Testimonials({
  content,
}: {
  content: TestimonialsContent;
}): ReactNode {
  const reduce = useReducedMotion();
  const sectionRef = useRef<HTMLElement>(null);
  const testimonials = content.items;
  const columns = useMemo(
    () => buildColumns(testimonials.length),
    [testimonials.length]
  );

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  });

  const yLeft = useTransform(scrollYProgress, [0, 1], [40, -64]);
  const yMiddle = useTransform(scrollYProgress, [0, 1], [128, -24]);
  const yRight = useTransform(scrollYProgress, [0, 1], [72, -104]);
  const columnY = [yLeft, yMiddle, yRight];

  return (
    <section
      ref={sectionRef}
      id="reviews"
      className="mx-auto max-w-[1440px] scroll-mt-24 px-5 pb-24 sm:px-8 sm:pb-32 lg:px-10"
    >
      <SectionHeading title={content.heading} description={content.description} />

      {reduce ? (
        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial) => (
            <QuoteCard key={testimonial.name} testimonial={testimonial} />
          ))}
        </div>
      ) : (
        <>
          <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:hidden">
            {testimonials.map((testimonial) => (
              <QuoteCard key={testimonial.name} testimonial={testimonial} />
            ))}
          </div>

          <div className="mt-16 hidden grid-cols-3 gap-4 lg:grid">
            {columns.map((column, i) => (
              <motion.div
                key={column.join("-") || `empty-${i}`}
                style={{ y: columnY[i] ?? yLeft }}
                className="flex flex-col gap-4"
              >
                {column.map((index) => {
                  const testimonial = testimonials[index];
                  if (!testimonial) return null;
                  return (
                    <QuoteCard
                      key={testimonial.name}
                      testimonial={testimonial}
                    />
                  );
                })}
              </motion.div>
            ))}
          </div>
        </>
      )}
    </section>
  );
}
