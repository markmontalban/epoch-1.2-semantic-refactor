"use client";

import { MagneticLink } from "@/components/magnetic-link";
import type { FinalCtaContent } from "@/lib/content-types";
import { softEase, useReducedMotion } from "@/lib/motion";
import { motion, useScroll, useTransform, type Variants } from "motion/react";
import Image from "next/image";
import { useMemo, useRef, type ReactNode } from "react";

const PRINT_LAYOUT = [
  { x: -224, y: 30, r: -13 },
  { x: -112, y: 8, r: -6 },
  { x: 0, y: 0, r: 0 },
  { x: 112, y: 8, r: 6 },
  { x: 224, y: 30, r: 13 },
];

const FAN_CONTAINER: Variants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.07, delayChildren: 0.1 } },
};

const WORD_CONTAINER: Variants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.055, delayChildren: 0.25 } },
};

const WORD_ITEM: Variants = {
  hidden: { y: "110%" },
  visible: { y: 0, transition: { duration: 0.7, ease: softEase } },
};

function PrintFan({
  reduce,
  images,
}: {
  reduce: boolean;
  images: string[];
}): ReactNode {
  return (
    <motion.div
      initial={reduce ? false : "hidden"}
      viewport={{ once: true, margin: "-80px" }}
      variants={FAN_CONTAINER}
      {...(reduce ? {} : { whileInView: "visible" })}
      aria-hidden="true"
      className="relative h-24 w-full origin-top scale-50 sm:h-48 sm:scale-100"
    >
      {images.map((src, i) => {
        const layout = PRINT_LAYOUT[i] ?? { x: 0, y: 0, r: 0 };
        return (
          <motion.div
            key={src}
            variants={{
              hidden: { opacity: 0, y: 48, x: layout.x * 0.25, rotate: 0 },
              visible: {
                opacity: 1,
                x: layout.x,
                y: layout.y,
                rotate: layout.r,
                transition: { type: "spring", stiffness: 220, damping: 22 },
              },
            }}
            {...(reduce
              ? {
                  style: {
                    transform: `translate(${layout.x}px, ${layout.y}px) rotate(${layout.r}deg)`,
                  },
                }
              : {
                  whileHover: {
                    y: layout.y - 10,
                    rotate: layout.r * 0.4,
                  },
                })}
            className="absolute top-0 left-1/2 -ml-15 w-30 overflow-hidden rounded-2xl border border-black/10 shadow-[0_16px_40px_-12px_rgba(58,53,53,0.22)]"
          >
            <Image
              src={src}
              alt=""
              width={240}
              height={320}
              unoptimized
              className="aspect-[3/4] w-full object-cover"
            />
          </motion.div>
        );
      })}
    </motion.div>
  );
}

export function FinalCta({ content }: { content: FinalCtaContent }): ReactNode {
  const reduce = useReducedMotion();
  const sectionRef = useRef<HTMLElement>(null);
  const words = useMemo(
    () => content.headline.split(" "),
    [content.headline]
  );

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "center center"],
  });
  const scale = useTransform(scrollYProgress, [0, 1], [0.93, 1]);
  const panelY = useTransform(scrollYProgress, [0, 1], [40, 0]);

  return (
    <section
      ref={sectionRef}
      id="sign-up"
      className="mx-auto max-w-[1440px] scroll-mt-24 px-5 pb-24 sm:px-8 sm:pb-32 lg:px-10"
    >
      <motion.div
        style={{
          backgroundColor: "var(--surface)",
          color: "var(--surface-foreground)",
          ...(reduce ? {} : { scale, y: panelY }),
        }}
        className="flex flex-col items-center overflow-hidden rounded-[40px] px-6 pt-16 pb-24 text-center sm:pt-20 sm:pb-32"
      >
        <PrintFan reduce={reduce} images={content.images} />

        <h2 className="mt-12 max-w-3xl text-[clamp(34px,5.5vw,68px)] leading-[1.06] font-medium tracking-tight">
          {reduce ? (
            content.headline
          ) : (
            <>
              <span className="sr-only">{content.headline}</span>
              <motion.span
                aria-hidden="true"
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-80px" }}
                variants={WORD_CONTAINER}
                className="flex flex-wrap justify-center gap-x-[0.28em]"
              >
                {words.map((word, i) => (
                  <span
                    key={`${word}-${i}`}
                    className="-mb-[0.12em] inline-flex overflow-hidden pb-[0.12em]"
                  >
                    <motion.span variants={WORD_ITEM} className="inline-block">
                      {word}
                    </motion.span>
                  </span>
                ))}
              </motion.span>
            </>
          )}
        </h2>
        <p className="mt-6 max-w-md text-base leading-relaxed opacity-65">
          {content.subtext}
        </p>
        <div className="mt-10 flex flex-col items-center gap-3 sm:flex-row">
          <MagneticLink
            href={content.primaryCtaHref}
            reduce={reduce}
            style={{
              backgroundColor: "var(--surface-foreground)",
              color: "var(--surface)",
            }}
            className="focus-ring inline-flex h-13 items-center rounded-full px-8 text-sm font-medium"
          >
            {content.primaryCtaLabel}
          </MagneticLink>
          <a
            href={content.secondaryCtaHref}
            className="focus-ring inline-flex h-13 items-center rounded-full border border-current/25 px-8 text-sm font-medium transition-opacity hover:opacity-70"
          >
            {content.secondaryCtaLabel}
          </a>
        </div>
      </motion.div>
    </section>
  );
}
