/**
 * Shared shape for all editable site content. `DEFAULT_CONTENT` mirrors the
 * original hardcoded copy so the live site is unchanged until an admin edit
 * is saved.
 */

export type LinkItem = { label: string; href: string };

export type NavContent = {
  pillLinks: LinkItem[];
  primaryLinks: LinkItem[];
  legalLinks: LinkItem[];
  socialLinks: LinkItem[];
  loginLabel: string;
  loginHref: string;
  signUpLabel: string;
  signUpHref: string;
};

export type HeroContent = {
  headline: string;
  subtext: string;
  primaryCtaLabel: string;
  primaryCtaHref: string;
  secondaryCtaLabel: string;
  secondaryCtaHref: string;
  images: string[];
};

export type VideoShowcaseContent = {
  videoUrl: string;
  posterUrl: string;
  caption: string;
};

export type ManifestoContent = {
  statement: string;
};

export type AppShowcaseStep = { title: string; body: string };

export type AppShowcaseContent = {
  heading: string;
  description: string;
  steps: AppShowcaseStep[];
  prompt: string;
  promptChips: string[];
  screenImages: string[];
};

export type SectionsVisibility = {
  gallery: boolean;
  integrations: boolean;
};

export type BrandingContent = {
  /** Empty string means "use the default vector mark" (components/nav/logo.tsx). */
  logoImage: string;
};

export type FeatureItem = { title: string; body: string; image: string };

export type FeaturesContent = {
  heading: string;
  description: string;
  items: FeatureItem[];
};

export type GalleryShot = { image: string; prompt: string };

export type GalleryContent = {
  heading: string;
  description: string;
  rowA: GalleryShot[];
  rowB: GalleryShot[];
};

export type IntegrationItem = { name: string; blurb: string };

export type IntegrationsContent = {
  heading: string;
  description: string;
  rowA: IntegrationItem[];
  rowB: IntegrationItem[];
};

export type Testimonial = {
  quote: string;
  name: string;
  role: string;
  avatar: string;
};

export type TestimonialsContent = {
  heading: string;
  description: string;
  items: Testimonial[];
};

export type PricingTier = {
  name: string;
  blurb: string;
  monthly: number;
  yearly: number;
  features: string[];
  cta: string;
  highlighted: boolean;
};

export type PricingContent = {
  heading: string;
  description: string;
  tiers: PricingTier[];
};

export type FaqItem = { question: string; answer: string };

export type FaqContent = {
  heading: string;
  description: string;
  contactEmail: string;
  items: FaqItem[];
};

export type FinalCtaContent = {
  headline: string;
  subtext: string;
  primaryCtaLabel: string;
  primaryCtaHref: string;
  secondaryCtaLabel: string;
  secondaryCtaHref: string;
  images: string[];
};

export type FooterColumn = { title: string; links: LinkItem[] };

export type FooterContent = {
  tagline: string;
  ctaLabel: string;
  ctaHref: string;
  columns: FooterColumn[];
  copyrightName: string;
  wordmark: string;
};

export type SiteContent = {
  sections: SectionsVisibility;
  branding: BrandingContent;
  nav: NavContent;
  hero: HeroContent;
  videoShowcase: VideoShowcaseContent;
  manifesto: ManifestoContent;
  features: FeaturesContent;
  appShowcase: AppShowcaseContent;
  gallery: GalleryContent;
  integrations: IntegrationsContent;
  testimonials: TestimonialsContent;
  pricing: PricingContent;
  faq: FaqContent;
  finalCta: FinalCtaContent;
  footer: FooterContent;
};

const HERO_IMAGES = [
  "https://images.unsplash.com/photo-1779881718722-5e7fa09fad7f?q=80&w=770&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "https://images.unsplash.com/photo-1780150048191-2e1eefe95665?q=80&w=812&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "https://images.unsplash.com/photo-1778051131564-192e359b601d?q=80&w=774&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "https://images.unsplash.com/photo-1779465190086-021c2012bc4c?q=80&w=770&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "https://images.unsplash.com/photo-1779630541798-1f3d987aa440?q=80&w=770&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "https://images.unsplash.com/photo-1776715139438-c4b4076cc592?q=80&w=770&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "https://images.unsplash.com/photo-1769968065389-60c3a887d14c?q=80&w=776&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "https://images.unsplash.com/photo-1775668076243-1676696bf27e?q=80&w=778&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "https://images.unsplash.com/photo-1773698719619-51e67f93a39f?q=80&w=818&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  "https://images.unsplash.com/photo-1771153568007-92b0997828ae?q=80&w=770&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
];

export const DEFAULT_CONTENT: SiteContent = {
  sections: {
    gallery: false,
    integrations: false,
  },
  branding: {
    logoImage: "",
  },
  nav: {
    pillLinks: [
      { label: "Product", href: "#product" },
      { label: "Pricing", href: "#pricing" },
    ],
    primaryLinks: [
      { label: "Overview", href: "#overview" },
      { label: "How it works", href: "#how-it-works" },
      { label: "Gallery", href: "#gallery" },
      { label: "Reviews", href: "#reviews" },
    ],
    legalLinks: [
      { label: "Privacy Policy", href: "#privacy" },
      { label: "Terms of Service", href: "#terms" },
      { label: "Cookie Policy", href: "#cookies" },
    ],
    socialLinks: [
      { label: "Instagram", href: "#instagram" },
      { label: "X", href: "#x" },
      { label: "LinkedIn", href: "#linkedin" },
    ],
    loginLabel: "Login",
    loginHref: "#login",
    signUpLabel: "Sign up",
    signUpHref: "#sign-up",
  },
  hero: {
    headline: "Hyperreal photos and film",
    subtext:
      "Cortex generates film-quality photos and video on your phone. Every result is carefully reviewed.",
    primaryCtaLabel: "Get the app",
    primaryCtaHref: "#sign-up",
    secondaryCtaLabel: "See how it works",
    secondaryCtaHref: "#product",
    images: HERO_IMAGES,
  },
  videoShowcase: {
    videoUrl:
      "https://videos.pexels.com/video-files/3015510/3015510-hd_1920_1080_24fps.mp4",
    posterUrl:
      "https://images.pexels.com/videos/3015510/free-video-3015510.jpg?auto=compress&cs=tinysrgb&w=1600",
    caption: "Watch the film — generated with Cortex",
  },
  manifesto: {
    statement:
      "Almost real is not real. Cortex was built for the last one percent — pores, grain, the way light falls off a face. It renders thousands of frames and reviews every single one. You only ever see the keepers.",
  },
  features: {
    heading: "Built for the last one percent",
    description:
      "Most generators get you close. Cortex is engineered for the part that makes people stop scrolling and ask what camera you used.",
    items: [
      {
        title: "Trained on light",
        body: "Tuned for the physical stuff — skin, fabric, lens falloff, grain. Frames behave like they came out of a camera, not a model.",
        image:
          "https://images.unsplash.com/photo-1779881718722-5e7fa09fad7f?q=80&w=770&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      },
      {
        title: "Reviewed by people",
        body: "Every render passes a human review before it reaches you. Warped hands and melted text never make it to your library.",
        image:
          "https://images.unsplash.com/photo-1778051131564-192e359b601d?q=80&w=774&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      },
      {
        title: "Photo and film",
        body: "Stills up to 4K and motion clips up to sixty seconds, from the same prompt. One idea, every format you post in.",
        image:
          "https://images.unsplash.com/photo-1779630541798-1f3d987aa440?q=80&w=770&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      },
      {
        title: "Phone-first",
        body: "Describe, generate, keep. The whole loop runs on your phone and lands straight in your camera roll at full resolution.",
        image:
          "https://images.unsplash.com/photo-1773698719619-51e67f93a39f?q=80&w=818&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      },
    ],
  },
  appShowcase: {
    heading: "From sentence to keeper",
    description:
      "The whole pipeline lives in one app. No desktop, no exports, no editing suite — just the loop below, on repeat.",
    steps: [
      {
        title: "Describe the shot",
        body: "Type what you see in your head. Lens, light, mood — Cortex speaks photography, so direct it like a DP.",
      },
      {
        title: "Generate takes",
        body: "Cortex renders a set of takes in seconds, each one a different read on your prompt. Pick a direction, push it further.",
      },
      {
        title: "The review pass",
        body: "Every take is inspected at full zoom before it reaches you. If a frame would not survive a close look, you never see it.",
      },
      {
        title: "Straight to camera roll",
        body: "Approved frames land in your library at full resolution. No exports, no watermarks on paid plans, nothing to clean up.",
      },
    ],
    prompt: "35mm portrait at golden hour, wind in her hair, faint film grain",
    promptChips: ["Portrait", "35mm", "Golden hour", "Grain"],
    screenImages: HERO_IMAGES.slice(0, 9),
  },
  gallery: {
    heading: "Made with Cortex",
    description:
      "Every frame below came out of the app, prompt included. Nothing retouched, nothing staged.",
    rowA: [
      {
        image:
          "https://images.unsplash.com/photo-1779881718722-5e7fa09fad7f?q=80&w=770&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        prompt: "portrait, 85mm, tungsten spill, smoke",
      },
      {
        image:
          "https://images.unsplash.com/photo-1780150048191-2e1eefe95665?q=80&w=812&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        prompt: "city crosswalk at dusk, slight motion blur",
      },
      {
        image:
          "https://images.unsplash.com/photo-1778051131564-192e359b601d?q=80&w=774&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        prompt: "north coast, 16mm, storm light",
      },
      {
        image:
          "https://images.unsplash.com/photo-1779465190086-021c2012bc4c?q=80&w=770&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        prompt: "studio still, hard flash, chrome",
      },
      {
        image:
          "https://images.unsplash.com/photo-1779630541798-1f3d987aa440?q=80&w=770&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        prompt: "desert highway, heat shimmer, 4pm",
      },
    ],
    rowB: [
      {
        image:
          "https://images.unsplash.com/photo-1776715139438-c4b4076cc592?q=80&w=770&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        prompt: "greenhouse interior, soft overcast",
      },
      {
        image:
          "https://images.unsplash.com/photo-1769968065389-60c3a887d14c?q=80&w=776&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        prompt: "dancer mid-turn, strobe freeze",
      },
      {
        image:
          "https://images.unsplash.com/photo-1775668076243-1676696bf27e?q=80&w=778&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        prompt: "alpine lake, dawn fog, drone wide",
      },
      {
        image:
          "https://images.unsplash.com/photo-1773698719619-51e67f93a39f?q=80&w=818&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        prompt: "night market, neon reflections, rain",
      },
      {
        image:
          "https://images.unsplash.com/photo-1771153568007-92b0997828ae?q=80&w=770&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        prompt: "kitchen scene, window light, 50mm",
      },
    ],
  },
  integrations: {
    heading: "Lands where you publish",
    description:
      "Keepers route straight from your camera roll into the apps you post, pitch, and cut in. No export dance.",
    rowA: [
      { name: "Instagram", blurb: "Reels-ready" },
      { name: "YouTube", blurb: "Straight to Shorts" },
      { name: "X", blurb: "Auto-post" },
      { name: "Figma", blurb: "Into your frames" },
      { name: "Slack", blurb: "Share to channels" },
      { name: "Dribbble", blurb: "Portfolio shots" },
    ],
    rowB: [
      { name: "Lightroom", blurb: "Edit roundtrip" },
      { name: "Premiere", blurb: "Timeline-ready" },
      { name: "Final Cut", blurb: "XML export" },
      { name: "Framer", blurb: "Embed live" },
      { name: "LinkedIn", blurb: "Native posts" },
      { name: "Webhooks", blurb: "Anything custom" },
    ],
  },
  testimonials: {
    heading: "Creators keep the receipts",
    description:
      "Photographers, directors, and designers use Cortex where the work has to hold up to a close look.",
    items: [
      {
        quote:
          "I stopped explaining that it is AI. People just ask what camera I shoot with, and honestly I let them wonder.",
        name: "Lena Ortiz",
        role: "Portrait photographer",
        avatar:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=160&h=160&auto=format&fit=crop&crop=faces",
      },
      {
        quote:
          "The review pass is the whole product for me. I post what Cortex approves and it has never once embarrassed me.",
        name: "Theo Marchetti",
        role: "Creator",
        avatar:
          "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=160&h=160&auto=format&fit=crop&crop=faces",
      },
      {
        quote:
          "Storyboards used to take my team a week of pulls and sketches. Now I walk into the room with finished frames.",
        name: "Amara Diallo",
        role: "Art director",
        avatar:
          "https://images.unsplash.com/photo-1589156280159-27698a70f29e?q=80&w=160&h=160&auto=format&fit=crop&crop=faces",
      },
      {
        quote:
          "It does light the way light actually behaves. Falloff, bounce, color temperature. That is the entire game.",
        name: "Jonas Lindqvist",
        role: "Director of photography",
        avatar:
          "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=160&h=160&auto=format&fit=crop&crop=faces",
      },
      {
        quote:
          "I cut a full mood film for a client pitch on the train ride to the meeting. They asked who shot it.",
        name: "Priya Raman",
        role: "Brand designer",
        avatar:
          "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=160&h=160&auto=format&fit=crop&crop=faces",
      },
      {
        quote:
          "My camera roll finally looks like the inside of my head. Fewer frames than other apps give you, but every one lands.",
        name: "Marcus Cole",
        role: "Stylist",
        avatar:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=160&h=160&auto=format&fit=crop&crop=faces",
      },
    ],
  },
  pricing: {
    heading: "Pay for keepers, not noise",
    description:
      "Every plan runs the full engine and the full review pass. Upgrade when you need more frames, longer film, or cleaner exports.",
    tiers: [
      {
        name: "Free",
        blurb: "Try the engine, keep your first frames.",
        monthly: 0,
        yearly: 0,
        features: [
          "20 generations per month",
          "1080p stills",
          "10-second clips",
          "Standard review queue",
          "Cortex mark on exports",
        ],
        cta: "Get the app",
        highlighted: false,
      },
      {
        name: "Pro",
        blurb: "For creators who post every day.",
        monthly: 14,
        yearly: 11,
        features: [
          "1,000 generations per month",
          "4K stills",
          "30-second clips",
          "Priority review queue",
          "Clean exports, no mark",
          "Full prompt history",
        ],
        cta: "Start with Pro",
        highlighted: true,
      },
      {
        name: "Studio",
        blurb: "For teams and heavy production use.",
        monthly: 32,
        yearly: 24,
        features: [
          "Everything in Pro",
          "60-second clips",
          "Batch generation",
          "5 linked devices",
          "Early access to new looks",
        ],
        cta: "Start with Studio",
        highlighted: false,
      },
    ],
  },
  faq: {
    heading: "Fair questions, straight answers",
    description: "Anything else, write to {email}. A person reads every single message.",
    contactEmail: "hello@example.com",
    items: [
      {
        question: "What is Cortex?",
        answer:
          "Cortex is a mobile app that generates hyperrealistic photos and video from a written description. It runs the full loop on your phone: describe a shot, get a set of takes, and keep the frames that pass review.",
      },
      {
        question: "What does the review pass actually do?",
        answer:
          "Every generation is checked before it reaches your library — geometry, hands, eyes, text, and texture are inspected at full zoom. Frames that would fall apart under a close look are rejected and rerun. You see fewer results than other apps show you, and that is the point.",
      },
      {
        question: "Do I own what I generate?",
        answer:
          "Yes. Every frame and clip you keep is yours to use anywhere — personal, client, or commercial work. Cortex never resells or trains on your private generations.",
      },
      {
        question: "Can it generate real people?",
        answer:
          "Only with consent. You can build a likeness from your own face or from someone who has approved it inside the app. Prompts that target public figures or unconsented likenesses are declined at review.",
      },
      {
        question: "Which phones does it run on?",
        answer:
          "Cortex runs on iOS 17 or later and Android 13 or later. Generation happens in the cloud, so older devices work fine — you just need a connection.",
      },
      {
        question: "How long can the videos be?",
        answer:
          "Free plans render clips up to 10 seconds, Pro up to 30, and Studio up to 60. Every clip is reviewed frame by frame, the same as stills.",
      },
      {
        question: "Can I cancel anytime?",
        answer:
          "Yes. Cancel from the app in two taps. Your plan stays active until the end of the billing period, and everything you generated stays in your camera roll.",
      },
    ],
  },
  finalCta: {
    headline: "Your next shot is a sentence away",
    subtext:
      "Free to try on iOS and Android. Describe the frame, keep only what survives review.",
    primaryCtaLabel: "Get the app",
    primaryCtaHref: "#sign-up",
    secondaryCtaLabel: "See pricing",
    secondaryCtaHref: "#pricing",
    images: HERO_IMAGES.slice(0, 5),
  },
  footer: {
    tagline: "Hyperreal photos and film, generated and reviewed on your phone.",
    ctaLabel: "Get the app",
    ctaHref: "#sign-up",
    columns: [
      {
        title: "Product",
        links: [
          { label: "Overview", href: "#overview" },
          { label: "How it works", href: "#how-it-works" },
          { label: "Gallery", href: "#gallery" },
          { label: "Pricing", href: "#pricing" },
          { label: "FAQ", href: "#faq" },
        ],
      },
      {
        title: "Company",
        links: [
          { label: "About", href: "#about" },
          { label: "Careers", href: "#careers" },
          { label: "Press", href: "#press" },
        ],
      },
      {
        title: "Legal",
        links: [
          { label: "Privacy Policy", href: "#privacy" },
          { label: "Terms of Service", href: "#terms" },
          { label: "Cookie Policy", href: "#cookies" },
        ],
      },
      {
        title: "Social",
        links: [
          { label: "Instagram", href: "#instagram" },
          { label: "X", href: "#x" },
          { label: "LinkedIn", href: "#linkedin" },
        ],
      },
    ],
    copyrightName: "Cortex",
    wordmark: "Cortex",
  },
};
