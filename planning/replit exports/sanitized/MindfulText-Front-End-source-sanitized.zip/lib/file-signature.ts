/**
 * Detects a file's real type from its leading bytes ("magic numbers"),
 * ignoring anything the client claims via filename or `Content-Type`.
 * Used by the upload route so a spoofed MIME type (e.g. HTML/SVG relabeled
 * as `image/png`) cannot get past the allowlist and be served same-origin.
 */

export type DetectedFile = {
  extension: string;
  contentType: string;
};

function matches(buffer: Buffer, offset: number, bytes: number[]): boolean {
  if (buffer.length < offset + bytes.length) return false;
  for (let i = 0; i < bytes.length; i++) {
    if (buffer[offset + i] !== bytes[i]) return false;
  }
  return true;
}

export function detectFileType(buffer: Buffer): DetectedFile | null {
  // PNG
  if (matches(buffer, 0, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) {
    return { extension: ".png", contentType: "image/png" };
  }
  // JPEG
  if (matches(buffer, 0, [0xff, 0xd8, 0xff])) {
    return { extension: ".jpg", contentType: "image/jpeg" };
  }
  // GIF87a / GIF89a
  if (
    matches(buffer, 0, [0x47, 0x49, 0x46, 0x38, 0x37, 0x61]) ||
    matches(buffer, 0, [0x47, 0x49, 0x46, 0x38, 0x39, 0x61])
  ) {
    return { extension: ".gif", contentType: "image/gif" };
  }
  // WEBP: "RIFF"...."WEBP"
  if (
    matches(buffer, 0, [0x52, 0x49, 0x46, 0x46]) &&
    matches(buffer, 8, [0x57, 0x45, 0x42, 0x50])
  ) {
    return { extension: ".webp", contentType: "image/webp" };
  }
  // MP4 / MOV (ISO base media): bytes 4-7 are "ftyp"
  if (matches(buffer, 4, [0x66, 0x74, 0x79, 0x70])) {
    const brand = buffer.subarray(8, 12).toString("ascii");
    if (brand.startsWith("qt")) {
      return { extension: ".mov", contentType: "video/quicktime" };
    }
    return { extension: ".mp4", contentType: "video/mp4" };
  }
  // WebM / Matroska EBML header
  if (matches(buffer, 0, [0x1a, 0x45, 0xdf, 0xa3])) {
    return { extension: ".webm", contentType: "video/webm" };
  }
  return null;
}
