import "server-only";
import { Client } from "@replit/object-storage";

let client: Client | undefined;

function getClient(): Client {
  if (!client) client = new Client();
  return client;
}

/** Uploads a buffer to app storage under `uploads/<key>` and returns the
 * app-served URL the homepage/admin should use to display it. */
export async function uploadAsset(
  key: string,
  buffer: Buffer,
): Promise<string> {
  const objectKey = `uploads/${key}`;
  const result = await getClient().uploadFromBytes(objectKey, buffer);
  if (!result.ok) {
    throw new Error(`Failed to upload asset: ${result.error?.message ?? "unknown error"}`);
  }
  return `/api/storage/${objectKey}`;
}

export async function readAsset(
  objectKey: string,
): Promise<{ buffer: Buffer } | null> {
  const result = await getClient().downloadAsBytes(objectKey);
  if (!result.ok) return null;
  const [data] = result.value;
  return { buffer: Buffer.from(data) };
}
