import { Pool } from "pg";

declare global {
  var __pgPool: Pool | undefined;
  var __pgSchemaReady: Promise<void> | undefined;
}

const SCHEMA_SQL = `
  CREATE TABLE IF NOT EXISTS site_content (
    id TEXT PRIMARY KEY,
    data JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
  );
`;

function rawPool(): Pool {
  if (!global.__pgPool) {
    global.__pgPool = new Pool({ connectionString: process.env.DATABASE_URL });
  }
  return global.__pgPool;
}

/** Lazily ensures the `site_content` table exists. Safe to call on every
 * request: `CREATE TABLE IF NOT EXISTS` is a no-op once the table is there,
 * and the readiness promise is cached so it only runs once per process. */
export async function getPool(): Promise<Pool> {
  const pool = rawPool();
  if (!global.__pgSchemaReady) {
    global.__pgSchemaReady = pool.query(SCHEMA_SQL).then(() => undefined);
  }
  await global.__pgSchemaReady;
  return pool;
}
