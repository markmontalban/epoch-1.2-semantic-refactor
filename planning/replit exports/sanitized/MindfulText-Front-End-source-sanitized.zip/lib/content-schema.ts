import { z } from "zod";

const linkItem = z.object({ label: z.string(), href: z.string() });

const navSchema = z.object({
  pillLinks: z.array(linkItem),
  primaryLinks: z.array(linkItem),
  legalLinks: z.array(linkItem),
  socialLinks: z.array(linkItem),
  loginLabel: z.string(),
  loginHref: z.string(),
  signUpLabel: z.string(),
  signUpHref: z.string(),
});

const heroSchema = z.object({
  headline: z.string(),
  subtext: z.string(),
  primaryCtaLabel: z.string(),
  primaryCtaHref: z.string(),
  secondaryCtaLabel: z.string(),
  secondaryCtaHref: z.string(),
  images: z.array(z.string()).min(1),
});

const videoShowcaseSchema = z.object({
  videoUrl: z.string(),
  posterUrl: z.string(),
  caption: z.string(),
});

const manifestoSchema = z.object({
  statement: z.string(),
});

const appShowcaseStep = z.object({ title: z.string(), body: z.string() });

const appShowcaseSchema = z.object({
  heading: z.string(),
  description: z.string(),
  steps: z.array(appShowcaseStep).length(4),
  prompt: z.string(),
  promptChips: z.array(z.string()),
  screenImages: z.array(z.string()).min(1),
});

const sectionsSchema = z.object({
  gallery: z.boolean(),
  integrations: z.boolean(),
});

const brandingSchema = z.object({
  logoImage: z.string(),
});

const featureItemSchema = z.object({
  title: z.string(),
  body: z.string(),
  image: z.string(),
});

const featuresSchema = z.object({
  heading: z.string(),
  description: z.string(),
  items: z.array(featureItemSchema).min(1),
});

const galleryShotSchema = z.object({ image: z.string(), prompt: z.string() });

const gallerySchema = z.object({
  heading: z.string(),
  description: z.string(),
  rowA: z.array(galleryShotSchema).min(1),
  rowB: z.array(galleryShotSchema).min(1),
});

const integrationItemSchema = z.object({
  name: z.string(),
  blurb: z.string(),
});

const integrationsSchema = z.object({
  heading: z.string(),
  description: z.string(),
  rowA: z.array(integrationItemSchema).min(1),
  rowB: z.array(integrationItemSchema).min(1),
});

const testimonialSchema = z.object({
  quote: z.string(),
  name: z.string(),
  role: z.string(),
  avatar: z.string(),
});

const testimonialsSchema = z.object({
  heading: z.string(),
  description: z.string(),
  items: z.array(testimonialSchema),
});

const pricingTierSchema = z.object({
  name: z.string(),
  blurb: z.string(),
  monthly: z.number(),
  yearly: z.number(),
  features: z.array(z.string()),
  cta: z.string(),
  highlighted: z.boolean(),
});

const pricingSchema = z.object({
  heading: z.string(),
  description: z.string(),
  tiers: z.array(pricingTierSchema).min(1),
});

const faqItemSchema = z.object({ question: z.string(), answer: z.string() });

const faqSchema = z.object({
  heading: z.string(),
  description: z.string(),
  contactEmail: z.string(),
  items: z.array(faqItemSchema),
});

const finalCtaSchema = z.object({
  headline: z.string(),
  subtext: z.string(),
  primaryCtaLabel: z.string(),
  primaryCtaHref: z.string(),
  secondaryCtaLabel: z.string(),
  secondaryCtaHref: z.string(),
  images: z.array(z.string()).min(1),
});

const footerColumnSchema = z.object({
  title: z.string(),
  links: z.array(linkItem),
});

const footerSchema = z.object({
  tagline: z.string(),
  ctaLabel: z.string(),
  ctaHref: z.string(),
  columns: z.array(footerColumnSchema),
  copyrightName: z.string(),
  wordmark: z.string(),
});

export const siteContentSchema = z.object({
  sections: sectionsSchema,
  branding: brandingSchema,
  nav: navSchema,
  hero: heroSchema,
  videoShowcase: videoShowcaseSchema,
  manifesto: manifestoSchema,
  features: featuresSchema,
  appShowcase: appShowcaseSchema,
  gallery: gallerySchema,
  integrations: integrationsSchema,
  testimonials: testimonialsSchema,
  pricing: pricingSchema,
  faq: faqSchema,
  finalCta: finalCtaSchema,
  footer: footerSchema,
});
