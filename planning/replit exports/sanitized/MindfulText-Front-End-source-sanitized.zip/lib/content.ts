import "server-only";
import { getPool } from "@/lib/db";
import { DEFAULT_CONTENT, type SiteContent } from "@/lib/content-types";
import { siteContentSchema } from "@/lib/content-schema";

const ROW_ID = "default";

/** Deep-merges stored content over the defaults so newly added fields in
 * `DEFAULT_CONTENT` are never missing from older saved records. */
function mergeWithDefaults(stored: unknown): SiteContent {
  if (!stored || typeof stored !== "object") return DEFAULT_CONTENT;
  return { ...DEFAULT_CONTENT, ...(stored as Partial<SiteContent>) };
}

export async function getSiteContent(): Promise<SiteContent> {
  const pool = await getPool();
  const result = await pool.query<{ data: unknown }>(
    "SELECT data FROM site_content WHERE id = $1",
    [ROW_ID]
  );
  if (result.rows.length === 0) return DEFAULT_CONTENT;
  return mergeWithDefaults(result.rows[0]?.data);
}

export async function saveSiteContent(input: unknown): Promise<SiteContent> {
  const parsed = siteContentSchema.parse(input);
  const pool = await getPool();
  await pool.query(
    `INSERT INTO site_content (id, data, updated_at)
     VALUES ($1, $2, now())
     ON CONFLICT (id) DO UPDATE SET data = $2, updated_at = now()`,
    [ROW_ID, JSON.stringify(parsed)]
  );
  return parsed;
}
